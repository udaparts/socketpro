#include "stdafx.h"
#include "sslsession.h"
#include <algorithm> 
#include <functional>
#include <cctype>
#include "../commshared/LogGlobals.h"

extern PThreadExceptionHandlers g_teh;

namespace SC { namespace ClientSide {

	CSslSession::CSslSession(ISessionCallback *sc, const char *host, unsigned int port, const char *certCN, unsigned int timedout, bool autoConnecting, bool v6)
		: m_bEndianDiff(false),
		m_ss(ssClosed),
		m_hSocket(INVALID_SOCKET),
		m_qRead(DEFAULT_READ_BUFFER_SIZE, DEFAULT_READ_BUFFER_BLOCK_SIZE),
		m_qWrite(DEFAULT_WRITE_BUFFER_SIZE, DEFAULT_WRITE_BUFFER_BLOCK_SIZE),
		m_sc(sc),
		m_AutoConnecting(autoConnecting),
		m_strHost(host),
		m_port(port),
		m_timedout(timedout),
		m_v6(v6),
		m_id(0),
		m_hEvent(::CreateEvent(nullptr, FALSE, FALSE, nullptr)),
		m_bReconnecting(false),
		m_certCN(certCN ? certCN : ""),
		m_pCertContext(nullptr) {
		assert(m_sc);
		::memset(&m_hCreds, 0, sizeof(m_hCreds));
	}

	CSslSession::~CSslSession()
	{
		FreeCredHandle();
		if (m_hSocket != INVALID_SOCKET)
		{
			::closesocket(m_hSocket);
		}
		::CloseHandle(m_hEvent);
		if (m_pCertContext) {
			::CertFreeCertificateContext(m_pCertContext);
			m_pCertContext = nullptr;
		}
	}

	void CSslSession::OnCloseInternal()
	{
		m_cs.lock();
		if (m_ss == ssClosed) {
			m_cs.unlock();
			return;
		}
		int res = ::closesocket(m_hSocket);
		m_ss = ssClosed;
		if (m_pCertContext) {
			::CertFreeCertificateContext(m_pCertContext);
			m_pCertContext = nullptr;
		}
		m_cv.notify_all();
		m_cs.unlock();
		if (!m_bReconnecting) {
			m_sc->OnAborted();
		}
		m_hSocket = INVALID_SOCKET;
		Initialize();
	}

	const ICertificate* const CSslSession::GetCertificate() const
	{
		return m_pCert.get();
	}

	void CSslSession::PostCloseInternal(DWORD errCode)
	{
		m_ss = ssClosing;
		if (!m_ec) {
			switch (errCode) {
				case SEC_E_NO_CREDENTIALS:
					//m_ec.assign(status, "No credentials are available in the security package");
					m_ec.assign(errCode, "Client certificate authentication is required but no private key is associated with certificate " + m_certCN + "@" + CCertificateImpl::CertStore.GetName());
					break;
				case SEC_E_UNKNOWN_CREDENTIALS:
					//The credentials supplied to the package were not recognized
					m_ec.assign(errCode, "Reading private key from " + m_certCN + "@" + CCertificateImpl::CertStore.GetName() + " not permitted because of low privilege");
					break;
				default:
					m_ec.assign(errCode);
					break;
			}
		}
		while (!::PostThreadMessage(m_id, WM_POSTCLOSE, (WPARAM)errCode, 0)) {
			::Sleep(1);
		}
	}

	void CSslSession::PostClose(DWORD errCode)
	{
		CAutoLock al(m_cs);
		PostCloseInternal(errCode);
	}

	tagSessionState CSslSession::GetSessionState()
	{
		return m_ss;
	}

	bool CSslSession::IsDiffEndian()
	{
		return m_bEndianDiff;
	}

	bool CSslSession::IsAutoConnecting()
	{
		return m_AutoConnecting;
	}

	bool CSslSession::WaitConnection(unsigned int ms)
	{
		//don't permit calling this method from hosting thread
		if (::GetCurrentThreadId() == m_id) {
			return false;
		}
		auto now = std::chrono::system_clock::now();
		CAutoLock al(m_cs);
		if (m_ss < ssConnecting) {
			return false;
		}
		if (CCertificateImpl::CertStore.IsOpened()) {
			if (m_ss >= ssSslHandshaked) {
				return true;
			}
			return (m_cv.wait_until(al, now + std::chrono::milliseconds(ms)) == std::cv_status::no_timeout && m_ss >= ssSslHandshaked);
		}
		if (m_ss >= ssConnected) {
			return true;
		}
		return (m_cv.wait_until(al, now + std::chrono::milliseconds(ms)) == std::cv_status::no_timeout && m_ss >= ssConnected);
	}

	bool CSslSession::WaitAll(unsigned int ms)
	{
		//don't permit calling this method from hosting thread
		if (::GetCurrentThreadId() == m_id) {
			return false;
		}
		auto now = std::chrono::system_clock::now();
		CAutoLock al(m_cs);
		if (m_ss < ssConnected) {
			return false;
		}
		if (!m_deqRequest.size()) {
			return true;
		}
		return (m_cv.wait_until(al, now + std::chrono::milliseconds(ms)) == std::cv_status::no_timeout && m_ss >= ssConnected);
	}

	bool CSslSession::ProcessInternal()
	{
		unsigned short id;
		if (m_qRead.GetSize() < sizeof(CRequestHeader) && !m_rh.RequestId)
		{
			return false;
		}
		if (!m_rh.RequestId) {
			m_qRead >> m_rh;
			if (m_bEndianDiff) {
				CBuffer::ChangeEndian((unsigned char*)&m_rh.RequestId, sizeof(m_rh.RequestId));
				CBuffer::ChangeEndian((unsigned char*)&m_rh.Size, sizeof(m_rh.Size));
			}
		}
		if (m_qRead.GetSize() < m_rh.Size)
		{
			return false;
		}
		if (m_rh.RequestId == idServerException)
		{
			id = *((const unsigned short *)m_qRead.GetBuffer());
		}
		else
		{
			id = m_rh.RequestId;
		}

#if defined(BAD_COMM_ENVIRONMENT) && defined(ENABLE_RANDOM_RECEIVING_CRASH)
		srand((unsigned int)time(nullptr));
		unsigned int random = (unsigned int) rand();
		if (1 == (random % COMM_RANDOM_STRENGTH)) {
			CStringW outputMessage;
			outputMessage.Format(L"File -- %ls, function name -- %ls, line number -- %d, message = %ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"RECEIVING_CRASH_CODE");
			OutputDebugStringW(outputMessage);
			::exit(RECEIVING_CRASH_CODE);
		}
#endif

		m_sc->OnArrive(m_rh.RequestId, m_rh.Size);

		{
			CAutoLock al(m_cs);
			size_t count = m_deqRequest.size();
			if (count)
			{
				if (m_deqRequest.front() == id)
				{
					m_deqRequest.pop_front();
					--count;
				}
				if (!count)
				{
					m_cv.notify_all();
				}
			}
		}
		m_qRead.Pop(m_rh.Size);
		m_rh.Reset();
		return true;
	}

	unsigned int CSslSession::Retrieve(unsigned char *receiver, unsigned int size)
	{
		if(!receiver || !size)
		{
			return 0;
		}
		if (::GetCurrentThreadId() != m_id)
		{
			return BAD_RETRIEVE_THREAD;
		}
		if (size > m_rh.Size)
		{
			size = m_rh.Size;
		}
		if (size > m_qRead.GetSize())
		{
			size = m_qRead.GetSize();
		}
		m_qRead.Pop(receiver, size);
		m_rh.Size -= size;
		return size;
	}

	void CSslSession::DoHeartBeat() {
		CRequestHeader rh;
		rh.RequestId = idHeartBeat;
		if (m_pSspi) {
			CScopeBuffer sb;
			sb << rh;
			m_cs.lock();
			SECURITY_STATUS ss = m_pSspi->Encrypt(sb->GetBuffer(), sb->GetSize(), m_qWrite);
			assert(ss == SEC_E_OK);
		}
		else {
			m_cs.lock();
			m_qWrite << rh;
		}
		Write();
		m_cs.unlock();
	}

	unsigned int CSslSession::Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool oneWay)
	{
		if (RequestId < idStartRequestId && RequestId != idAuthentication && RequestId != idServerInfo)
		{
			return BAD_REQUEST;
		}
		if (!buffer)
		{
			size = 0;
		}
		CRequestHeader rh;
		rh.RequestId = RequestId;
		rh.Size = size;
		m_cs.lock();
		if (m_ss < ssConnected)
		{
			m_cs.unlock();
			return SESSION_CLOSED;
		}
		if (m_pSspi)
		{
			m_cs.unlock();
			CScopeBuffer sb;
			sb << rh;
			sb->Push(buffer, size);
			m_cs.lock();
			SECURITY_STATUS ss = m_pSspi->Encrypt(sb->GetBuffer(), sb->GetSize(), m_qWrite);
			if (RequestId == idAuthentication)
			{
				sb->CleanTrack();
			}
			assert(ss == SEC_E_OK);
		}
		else
		{
			m_qWrite << rh;
			m_qWrite.Push(buffer, size);
		}
		Write();
		if (RequestId == idAuthentication)
		{
			m_qWrite.CleanTrack();
		}
		if (!oneWay)
		{
			m_deqRequest.push_back(RequestId);
		}
		m_cs.unlock();
		return size;
	}

	unsigned int CSslSession::GetSendingBufferSize()
	{
		CAutoLock al(m_cs);
		return m_qWrite.GetSize();
	}

	HRESULT CSslSession::GetErrCode()
	{
		CAutoLock al(m_cs);
		if (m_ec.value()) {
			return MAKE_HRESULT(SEVERITY_ERROR, COMM_FAC, m_ec.value());
		}
		return S_OK;
	}

	unsigned int CSslSession::GetErrMsg(wchar_t *recv, unsigned int size) {
		if (!size || !recv)
		{
			return 0;
		}
		--size;
		if (!size)
		{
			return 0;
		}
		std::wstring str;
		m_cs.lock();
		if (m_ec)
		{
			str = SC::ToWide(m_ec.message());
		}
		m_cs.unlock();
		str.erase(std::find_if(str.rbegin(), str.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), str.end());
		size_t len = str.size();
		if(size > (unsigned int)len)
		{
			size = (unsigned int)len;
		}
		::memcpy(recv, str.c_str(), size * sizeof(wchar_t));
		recv[size] = L'\0';
		return size;
	}

	unsigned int CSslSession::GetErrMsg(char *recv, unsigned int size)
	{
		if (!size || !recv)
		{
			return 0;
		}
		--size;
		if (!size)
		{
			return 0;
		}
		std::string str;
		m_cs.lock();
		if (m_ec)
		{
			str = m_ec.message();
		}
		m_cs.unlock();
		str.erase(std::find_if(str.rbegin(), str.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), str.end());
		size_t len = str.size();
		if(size > (unsigned int)len)
		{
			size = (unsigned int)len;
		}
		::memcpy(recv, str.c_str(), size);
		recv[size] = '\0';
		return size;
	}

	unsigned int CSslSession::GetPeerName(char *name, unsigned int size)
	{
		struct sockaddr_storage sa;
		int len = sizeof(sa);
		int res = ::getpeername(m_hSocket, (LPSOCKADDR)&sa, &len);
		if (res == SOCKET_ERROR) {
			if (name && size) {
				name[0] = 0;
			}
			return (~0);
		}
		char buffer[128] = {0};
		res = ::getnameinfo((struct sockaddr*)&sa, len, buffer, sizeof(buffer), 0, 0, NI_NUMERICHOST);
		if (res == SOCKET_ERROR) {
			if (name && size) {
				name[0] = 0;
			}
			return (~0);
		}
		if (name && size > 0)
		{
			size -= 1;
			std::string s = buffer;
			if (s.length() <= size)
			{
				size = (unsigned int)s.length();
			}
			::memcpy(name, s.c_str(), size);
			name[size] = 0;
		}
		SOCKADDR_IN *si = (SOCKADDR_IN*)&sa;
		return si->sin_port;
	}

	unsigned int CSslSession::GetSockName(char *name, unsigned int size)
	{
		struct sockaddr_storage sa;
		int len = sizeof(sa);
		int res = ::getsockname(m_hSocket, (LPSOCKADDR)&sa, &len);
		if (res == SOCKET_ERROR) {
			if (name && size) {
				name[0] = 0;
			}
			return (~0);
		}
		char buffer[128] = {0};
		res = ::getnameinfo((struct sockaddr*)&sa, len, buffer, sizeof(buffer), 0, 0, NI_NUMERICHOST);
		if (res == SOCKET_ERROR) {
			if (name && size) {
				name[0] = 0;
			}
			return (~0);
		}
		if (name && size > 0)
		{
			size -= 1;
			std::string s = buffer;
			if (s.length() <= size)
			{
				size = (unsigned int)s.length();
			}
			::memcpy(name, s.c_str(), size);
			name[size] = 0;
		}
		SOCKADDR_IN *si = (SOCKADDR_IN*)&sa;
		return si->sin_port;
	}

	size_t CSslSession::GetRequestCountQueued()
	{
		CAutoLock al(m_cs);
		return m_deqRequest.size();
	}

	const ICertificate* const CSslSession::GetSelfCert() const {
		return m_pSelfCert.get();
	}

	void CSslSession::handle_read() 
	{
		m_bReconnecting = false;
		{
			CAutoLock al(m_cs);
			if (m_ss < ssAuthentcated && m_qRead.GetSize() >= sizeof(m_rh))
			{
				//peek the first 8 bytes of data
				CRequestHeader *rh = (CRequestHeader*)m_qRead.GetBuffer();
				switch (rh->RequestId)
				{
				case idAuthenticationReserved:
					m_bEndianDiff = true;
				case idAuthentication:
					{
						unsigned int size = rh->Size;
						if (m_bEndianDiff)
						{
							CBuffer::ChangeEndian((unsigned char*)&size, sizeof(size));
						}
						if (rh->Size <= MAX_LEN_PER_IO_TRANS)
						{
							m_ss = ssAuthentcated;
							break;
						}
					}
				default:
					//m_ec.assign(ERROR_ACCESS_DENIED);
					//OnCloseInternal();
					break;
				}	 
			}
		}
		while(ProcessInternal())
		{
		}
	}

	void CSslSession::Write()
	{
		if (m_qWrite.GetSize() == 0)
		{
			return;
		}

#if defined(BAD_COMM_ENVIRONMENT) && defined(ENABLE_RANDOM_SENDING)
		const char *start = (const char*)m_qWrite.GetBuffer();
		unsigned int remaining = (int)m_qWrite.GetSize();
		unsigned int planned = (remaining <= RANDOM_SENDING_BYTE) ? remaining : RANDOM_SENDING_BYTE;
		int sent = ::send(m_hSocket, start, (int)planned, 0);
		int res = sent;
		while (sent > 0 && planned > 0) {
			res += sent;
			start += sent;
			remaining -= (unsigned int)sent;
			planned = (remaining <= RANDOM_SENDING_BYTE) ? remaining : RANDOM_SENDING_BYTE;
			Sleep(RANDOM_DELAY_MS);
			sent = ::send(m_hSocket, start, (int)planned, 0);
		}
#else
		int res = ::send(m_hSocket, (const char*)m_qWrite.GetBuffer(), (int)m_qWrite.GetSize(), 0);
#endif

#if defined(BAD_COMM_ENVIRONMENT) && defined(ENABLE_RANDOM_SENDING_CRASH)
		srand((unsigned int)time(nullptr));
		unsigned int random = (unsigned int) rand();
		if (1 == (random % COMM_RANDOM_STRENGTH)) {
			CStringW outputMessage;
			outputMessage.Format(L"File -- %ls, function name -- %ls, line number -- %d, message = %ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"SENDING_CRASH_CODE");
			OutputDebugStringW(outputMessage);
			::exit(SENDING_CRASH_CODE);
		}
#endif
		if (res > 0)
		{
			m_qWrite.Pop((unsigned int)res);
		}
		else if (res == SOCKET_ERROR)
		{
			res = ::WSAGetLastError();
			if (res != WSAEWOULDBLOCK)
			{
				PostCloseInternal(res);
				return;
			}
		}
	}

	void CSslSession::OnLessInternal()
	{
		if (m_ss >= ssAuthentcated) {
			m_cs.lock();
			unsigned int len = m_qWrite.GetSize();
			m_cs.unlock();
			if (!len) {
				m_sc->OnLess();
			}
		}
	}

	void CSslSession::Initialize()
	{
		m_bEndianDiff = false;
		m_ss = ssClosed;
		m_qRead.SetSize(0);
		m_qWrite.SetSize(0);
		::memset(&m_rh, 0, sizeof(m_rh));
		m_deqRequest.clear();
		m_pSspi.reset();
		m_bReconnecting = false;
	}

	bool CSslSession::StartConnecting()
	{
		m_hSocket = ::socket(m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (m_hSocket == INVALID_SOCKET)
		{
			m_ec.assign(::WSAGetLastError());
			CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, (L"::socket failed with error code = " + std::to_wstring(m_ec.value())).c_str());
			return false;
		}
		int res = ::WSAEventSelect(m_hSocket, m_hEvent, FD_CONNECT|FD_CLOSE|FD_READ|FD_WRITE);
		if (res != 0)
		{
			m_ec.assign(::WSAGetLastError());
			CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, (L"::WSAEventSelect failed with error code = " + std::to_wstring(m_ec.value())).c_str());
			return false;
		}

		std::string port = std::to_string(m_port);
		struct addrinfo aiHints;
		struct addrinfo *aiList = nullptr;
		::memset(&aiHints, 0, sizeof(aiHints));
		aiHints.ai_family = m_v6 ? AF_INET6 : AF_INET;
		aiHints.ai_socktype = SOCK_STREAM;
		aiHints.ai_protocol = IPPROTO_TCP;
		res = ::getaddrinfo(m_strHost.c_str(), port.c_str(), &aiHints, &aiList);
		if (res != 0)
		{
			m_ec.assign(::WSAGetLastError());
			CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, (L"::getaddrinfo failed with error code = " + std::to_wstring(m_ec.value())).c_str());
			return false;
		}
		res = ::connect(m_hSocket, aiList->ai_addr, m_v6 ? sizeof(sockaddr_in6) : sizeof(sockaddr_in));
		if (res == SOCKET_ERROR)
		{
			res = ::WSAGetLastError();
			if (res != WSAEWOULDBLOCK)
			{
				m_ec.assign(res);
				CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, (L"::connect failed with error code = " + std::to_wstring(m_ec.value())).c_str());
				return false;
			}
		}
		return true;
	}

	void CSslSession::OnConencted(int errCode)
	{
		m_pCert.reset();
		m_qRead.SetSize(0);
		m_qWrite.SetSize(0);
		if (errCode == 0)
		{
			int optValue = 512 * 1024;
			int res = ::setsockopt(m_hSocket, SOL_SOCKET, SO_RCVBUF, (const char*)&optValue, sizeof(optValue));
			res = ::setsockopt(m_hSocket, SOL_SOCKET, SO_SNDBUF, (const char*)&optValue, sizeof(optValue));
			u_long iMode = 1;
			res = ::ioctlsocket(m_hSocket, FIONBIO, &iMode);
			optValue = 1;
			res = ::setsockopt(m_hSocket, IPPROTO_TCP, TCP_NODELAY, (const char*)&optValue, sizeof(optValue));
			CAutoLock al(m_cs);
			m_ss = ssConnected;
			if (!CCertificateImpl::CertStore.IsOpened())
			{
				m_cv.notify_all();
				if (m_bReconnecting) {
					//re-send authentication data
				}
			}
		}
		else
		{
			m_cs.lock();
			m_ec.assign(errCode);
			m_cs.unlock();
			OnCloseInternal();
		}
	}

	void CSslSession::OnWritable(int errCode)
	{
		if (m_ss < ssConnected) {
			return;
		}
		if (errCode) {
			PostClose(errCode);
		}
		else {
			if (CCertificateImpl::CertStore.IsOpened() && m_ss <= ssSslHandshaking) {
				SECURITY_STATUS ss = OpenCred();
				if (ss == SEC_E_OK) {
					m_pSspi.reset(new CSspi(true, &m_hCreds, false));
					m_cs.lock();
					//m_qRead should be always empty, and m_qWrite contains ClientHello data after calling
					if (m_pSspi->DoHandshake(m_qRead.GetBuffer(), m_qRead.GetSize(), m_qWrite)) {
						CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, L"Before ParseClientHello");
						if (CSSLHello::ParseHello(m_qWrite.GetBuffer(), m_qWrite.GetSize(), m_ch)) {
							CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, L"After ParseClientHello");
						}
						else {
							CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, E_FAIL, L"ParseClientHello failed as hello info not completed yet for unexpected reasons!!!");
						}

#ifdef BAD_COMM_ENVIRONMENT
						srand((unsigned int)time(nullptr));
						int random = rand();
						unsigned int len = ((unsigned int)random % m_qWrite.GetSize());
						int res = ::send(m_hSocket, (const char*)m_qWrite.GetBuffer(), (int)len, 0);
						m_qWrite.Pop(len);
						::Sleep(len);
#endif
						Write(); //sending ClientHello data onto server
						m_ss = ssSslHandshaking;
						m_cs.unlock();
						m_sc->OnSslHandshake(&m_ch);
					}
					else {
						m_cs.unlock();
						ss = m_pSspi->GetLastStatus();
						CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, (L"Failed in DoHandshake ss = " + std::to_wstring(ss)).c_str());
					}
				}
				if (ss != SEC_E_OK) {
					PostClose(ss);
				}
				else {
					OnLessInternal();
				}
			}
			else {
				{
					CAutoLock al(m_cs);
					Write();
				}
				OnLessInternal();
			}
		}
	}

	void CSslSession::OnAvailable(int errCode) {
		if (m_AutoConnecting && m_ss == ssClosed) {
			m_bReconnecting = true;
			StartConnecting();
			return;
		}
		if (m_ss < ssConnected) {
			return;
		}
		if (errCode) {
			PostClose(errCode);
		}
		else {
			if (m_pSspi) {
				if (m_ss < ssSslHandshaked) {
					int res = ::recv(m_hSocket, (char*)m_qRead.GetBuffer(m_qRead.GetSize()), m_qRead.GetTailSize(), 0);
					if (res == SOCKET_ERROR || res == 0) {
						PostClose(WSAECONNABORTED);
						return;
					}
					bool ok;
					m_qRead.SetSize(m_qRead.GetSize() + (unsigned int)res);
					{
						TLSHelloHeader *pTLS = nullptr;
						if (m_qRead.GetSize() > sizeof(TLSHelloHeader)) {
							pTLS = (TLSHelloHeader *)m_qRead.GetBuffer();
							unsigned short len = pTLS->Record.length;
							CBuffer::ChangeEndian((unsigned char*)&len, sizeof(len));
							if (m_qRead.GetSize() >= (len + sizeof(TLSRecord)) && pTLS->Handshake.GetHandshakeType() == server_hello && m_ch.GetHandshakeType() == client_hello) {
								CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, L"Before ParseHello");
								if (CSSLHello::ParseHello(m_qRead.GetBuffer(), m_qRead.GetSize(), m_ch)) {
									CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, L"After ParseHello");
								}
								else {
									CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, E_FAIL, L"Failed with ParseHello");
								}
								m_sc->OnSslHandshake(&m_ch);
							}
							else {
								pTLS = nullptr;
								CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_FALSE, L"Server hello info data fragmentation");
							}
						}
						else {
							CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_FALSE, L"Server hello info data fragmentation");
						}
						CAutoLock al(m_cs);
						ok = m_pSspi->DoHandshake(m_qRead.GetBuffer(), m_qRead.GetSize(), m_qWrite);
					}
					if (ok) {
						if (m_pSspi->GetLastStatus() != SEC_E_INCOMPLETE_MESSAGE) {
							m_qRead.SetSize(0);
						}
						if (m_pSspi->GetHandshakeState() == hsDone) {
							m_ch.Handshake.msg_type = (unsigned char)finished;
							{
								CAutoLock al(m_cs);
								m_ss = ssSslHandshaked;
								Write();
								if (m_pSspi->GetCertContext()) {
									m_pCert.reset(new CCertificateImpl(m_pSspi, m_strHost.c_str()));
								}
								m_cv.notify_all();
							}
							m_sc->OnSslHandshake(&m_ch);
						}
						else if (SEC_I_INCOMPLETE_CREDENTIALS == m_pSspi->GetLastStatus()) {
							if (m_certCN.size()) {
								m_pCertContext = ::CertFindCertificateInStore(CCertificateImpl::CertStore.GetCertStore(), X509_ASN_ENCODING|PKCS_7_ASN_ENCODING, 0, CERT_FIND_SUBJECT_STR, CA2CT(m_certCN.c_str()), nullptr);
								if (m_pCertContext) {
									m_pSelfCert.reset(new CCertificateImpl(m_pCertContext, ""));
								}
								else {
									m_pSelfCert.reset();
								}
							}
							SECURITY_STATUS ss = OpenCred();
							if (ss == SEC_E_OK) {
								m_pSspi->ResetCredHandle(&m_hCreds);
								ok = m_pSspi->DoHandshake(m_qRead.GetBuffer(), m_qRead.GetSize(), m_qWrite);
								if (!ok) {
									ss = m_pSspi->GetLastStatus();
									CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, (L"Failed in DoHandshake ss = " + std::to_wstring(ss)).c_str());
									PostClose(ss);
								}
								else {
									if (m_pSspi->GetLastStatus() != SEC_E_INCOMPLETE_MESSAGE) {
										m_qRead.SetSize(0);
									}
									CAutoLock al(m_cs);
									Write();
								}
							}
							else {
								CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, (L"Failed in DoHandshake ss = " + std::to_wstring(ss)).c_str());
								PostClose(ss);
							}
						}
						else {
							CAutoLock al(m_cs);
							Write();
						}
					}
					else {
						SECURITY_STATUS ss = m_pSspi->GetLastStatus();
						CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, (L"Failed in DoHandshake ss = " + std::to_wstring(ss)).c_str());
						PostClose(ss);
					}
				}
				else {
					int res;
					CScopeBuffer sb;
					do {
						res = ::recv(m_hSocket, (char*)sb->GetBuffer(), (int)sb->GetMaxSize(), 0);
						if (res > 0) {
							if (!m_pSspi->Decrypt(sb->GetBuffer(), (DWORD)res, m_qRead))
							{
								SECURITY_STATUS ss = m_pSspi->GetLastStatus();
								CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, (L"Failed in Decrypt ss = " + std::to_wstring(ss)).c_str());
								PostClose(ss);
								return;
							}
						}
						else if (res == SOCKET_ERROR) {
							res = ::WSAGetLastError();
							if (res != WSAEWOULDBLOCK) {
								PostClose(res);
								return;
							}
						}
						handle_read();
					} while(res == (int)sb->GetMaxSize());
				}
			}
			else
			{
				int res;
				int max;
				do
				{
					m_qRead.SetHeadPosition();
					max = (int)m_qRead.GetTailSize();
					if (max == 0) {
						m_qRead.ReallocBuffer(m_qRead.GetSize() + MAX_LEN_PER_IO_TRANS);
						max = (int)m_qRead.GetTailSize();
					}
					res = ::recv(m_hSocket, (char*)m_qRead.GetBuffer(m_qRead.GetSize()), max, 0);
					if (res > 0)
					{
						m_qRead.SetSize(m_qRead.GetSize() + (unsigned int)res);
						handle_read();
					}
					else if (res == SOCKET_ERROR)
					{
						res = ::WSAGetLastError();
						if (res != WSAEWOULDBLOCK)
						{
							PostClose(res);
						}
						break;
					}
				}while(res >= max);
			}
		}
	}

	void CSslSession::FreeCredHandle()
	{
		if (m_hCreds.dwLower || m_hCreds.dwUpper)
		{
			::FreeCredentialsHandle(&m_hCreds);
			::memset(&m_hCreds, 0, sizeof(m_hCreds));
		}
	}

	SECURITY_STATUS CSslSession::OpenCred()
	{
		FreeCredHandle();
		SECURITY_STATUS Status = SEC_E_OK;
		SCHANNEL_CRED SchannelCred;
		::memset(&SchannelCred, 0, sizeof(SchannelCred));

		PCCERT_CONTEXT pCertContext = nullptr;
		if (m_pSelfCert) {
			pCertContext = m_pSelfCert->GetCertContext();
		}
		if (pCertContext) {
			SchannelCred.cCreds = 1;
			SchannelCred.paCred = &pCertContext;
		}
		SchannelCred.dwVersion  = SCHANNEL_CRED_VERSION;
		SchannelCred.grbitEnabledProtocols = SP_PROT_TLS1_X_CLIENT; //disable SSL3.0 at client side //SP_PROT_SSL3TLS1_X_CLIENTS;
		SchannelCred.dwFlags = (SCH_CRED_NO_DEFAULT_CREDS | SCH_CRED_MANUAL_CRED_VALIDATION | SCH_CRED_REVOCATION_CHECK_CHAIN | SCH_SEND_ROOT_CERT);
		SECURITY_STATUS ss = ::AcquireCredentialsHandle(nullptr,
			UNISP_NAME,
			SECPKG_CRED_OUTBOUND,
			nullptr,
			&SchannelCred,
			nullptr,
			nullptr,
			&m_hCreds,
			nullptr);
		return ss;
	}

	void CSslSession::OnClosed(int errCode)
	{
		m_cs.lock();
		m_ec.assign(errCode);
		m_cs.unlock();
		OnCloseInternal();
		FreeCredHandle();
	}

	void CSslSession::DoConnetionInternal()
	{
		DWORD dwRes;
		if (g_teh) {
			g_teh();
		}
		m_cs.lock();
		m_ec.assign(0);
		m_cs.unlock();
		SetLastError(0);
		HRESULT hr = ::CoInitializeEx(nullptr, COINIT_MULTITHREADED);
		DWORD dwMs = (m_timedout/2 > 1000) ? m_timedout/2 : 1000;
		m_id = ::GetCurrentThreadId();
		CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"Start session initial connecting");
		if (!StartConnecting()) {
			CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, L"Session initial connecting failed");
			OnCloseInternal();
			CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"End session working thread");
			return;
		}
		DWORD nCount = 1;
		CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"Start tracking socket events and others");
		do
		{
			dwRes = ::MsgWaitForMultipleObjects(nCount, &m_hEvent, FALSE, dwMs, QS_ALLEVENTS);
			if (dwRes >= WAIT_OBJECT_0 && dwRes <= (WAIT_OBJECT_0 + nCount - 1))
			{
				WSANETWORKEVENTS NetworkEvents;
				::memset(&NetworkEvents, 0, sizeof(NetworkEvents));
				int nRtn = ::WSAEnumNetworkEvents(m_hSocket, m_hEvent, &NetworkEvents);
				if ((NetworkEvents.lNetworkEvents & FD_CONNECT) == FD_CONNECT) {
					int errCode = NetworkEvents.iErrorCode[FD_CONNECT_BIT];
					if (errCode == 0) {
						dwMs = 1000;
					}
					CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, (L"Socket OnConencted with error code = " + std::to_wstring(errCode)).c_str());
					OnConencted(errCode);
					CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, (L"Socket OnConencted completed with error code = " + std::to_wstring(errCode)).c_str());
				}
				if ((NetworkEvents.lNetworkEvents & FD_WRITE) == FD_WRITE) {
					//CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, (L"Socket OnWritable with error code = " + std::to_wstring(NetworkEvents.iErrorCode[FD_WRITE_BIT])).c_str());
					OnWritable(NetworkEvents.iErrorCode[FD_WRITE_BIT]);
				}
				else if ((NetworkEvents.lNetworkEvents & FD_READ) == FD_READ) {
					//CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_PLANTCONFIG, S_OK, (L"Socket OnAvailable with error code = " + std::to_wstring(NetworkEvents.iErrorCode[FD_READ_BIT])).c_str());
					OnAvailable(NetworkEvents.iErrorCode[FD_READ_BIT]);
				}
				else if ((NetworkEvents.lNetworkEvents & FD_CLOSE) == FD_CLOSE) {
					dwMs = (m_timedout/2 > 1000) ? m_timedout/2 : 1000;
					CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_ERROR, LOG_TYPE_ERROR, E_FAIL, (L"Socket OnClosed with error code = " + std::to_wstring(NetworkEvents.iErrorCode[FD_CLOSE_BIT])).c_str());
					OnClosed(NetworkEvents.iErrorCode[FD_CLOSE_BIT]);
				}
			}
			else if (dwRes == WAIT_OBJECT_0 + nCount)
			{
				MSG	msg;
				while (::PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
				{
					switch(msg.message)
					{
					case WM_POSTCLOSE:
						CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"msg.message equals WM_POSTCLOSE");
						OnCloseInternal();
						break;
					case WM_QUIT:
						OnCloseInternal();
						CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"msg.message equals WM_QUIT");
						return; //thread shutdown
					default:
						break;
					}
				}
			}
			else if (dwRes >= WAIT_ABANDONED_0 && dwRes <= (WAIT_ABANDONED_0 + nCount - 1)) {
				CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"MsgWaitForMultipleObjects returns dwRes >= WAIT_ABANDONED_0 && dwRes <= (WAIT_ABANDONED_0 + nCount - 1)");
				dwRes = 0;
			}
			else if (dwRes == WAIT_TIMEOUT) {
				//CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"MsgWaitForMultipleObjects returns timeout");
				m_cs.lock();
				bool heart_beat = (!m_deqRequest.size() && m_ss >= ssAuthentcated);
				bool poll = (m_deqRequest.size() || m_ss >= ssAuthentcated);
				m_cs.unlock();
				if (poll) {
					OnAvailable(0);
				}
				if (heart_beat) {
					DoHeartBeat();
				}
			}
			else {
				CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, (L"MsgWaitForMultipleObjects returns an unexpected value = " + std::to_wstring(dwRes)).c_str());
				assert(false);
			}
		}while(true);
		if (S_OK == hr) {
			::CoUninitialize();
		}
		CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"End session working thread");
	}

	void CSslSession::Destroy()
	{
		int index = 0;
		{
			CAutoLock al(m_cs);
			if (m_ss > ssClosing) {
				m_ss = ssClosing;
			}
		}
		while(!::PostThreadMessage(m_id, WM_QUIT, 0, 0) && index <= 3)
		{
			::Sleep(1);
			++index;
		}
		m_pHostThread->join();
		CAutoLock al(m_cs);
		m_pHostThread.reset();
	}

	bool CSslSession::Start()
	{
		CAutoLock al(m_cs);
		if (m_pHostThread)
		{
			return true;
		}
		m_ss = ssConnecting;
		CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"Start session working thread");
		m_pHostThread.reset(new std::thread(std::bind(&CSslSession::DoConnetionInternal, this)));
		//CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"Start waiting for session connection");
		//bool retVal = m_cv.wait_for(al, std::chrono::milliseconds(m_timedout)) != std::cv_status::timeout && m_ss >= ssConnected;
		//CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, (L"End waiting for session connection with retVal = " + std::to_wstring(retVal)).c_str());
		return true;
	}

	void CSslSession::LogMessage(const wchar_t* file, const wchar_t *funcName, int lineNumber,	int statusId, int typeId, int resultId, const wchar_t* message)
	{
		CStringW location;

		WCHAR drive[_MAX_DRIVE], dir[_MAX_DIR], fname[_MAX_FNAME], ext[_MAX_EXT];
		_wsplitpath_s( file, drive, _MAX_DRIVE, dir, _MAX_DIR, fname, _MAX_FNAME, ext, _MAX_EXT);
		location.Format(L"%s:%d", fname, lineNumber);

		CStringW outputMessage;
		outputMessage.Format(L"File -- %ls, function name -- %ls, line number -- %d, message = %ls\r\n", fname, funcName, lineNumber, message);
		OutputDebugStringW(outputMessage);
	}

} //namespace ClientSide
} //namespace SC
