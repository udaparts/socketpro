

#ifndef _SECURE_COMM_CLIENT_SSL_SESSION_IMPLEMENTATION_H_
#define _SECURE_COMM_CLIENT_SSL_SESSION_IMPLEMENTATION_H_

#include <deque>
#include "../commshared/scsslsocketbase.h"
#include "../commshared/certificateimpl.h"

namespace SC { namespace ClientSide {

	class CSslSession : public IClientSession
	{
	public:
		CSslSession(ISessionCallback *sc, const char *host, unsigned int port, const char *certCN, unsigned int timedout, bool autoConnecting, bool b6);
		virtual ~CSslSession();

	public:
		const static unsigned int MAX_LEN_PER_IO_TRANS = 8 * 1024;
		const static unsigned int WM_POSTCLOSE = WM_USER + 100;
		const static unsigned int DEFAULT_READ_BUFFER_SIZE = 320 * 1024;
		const static unsigned int DEFAULT_READ_BUFFER_BLOCK_SIZE = 128 * 1024;
		const static unsigned int DEFAULT_WRITE_BUFFER_SIZE = 256 * 1024;
		const static unsigned int DEFAULT_WRITE_BUFFER_BLOCK_SIZE = 128 * 1024;

		//implementations for IClientSession methods
		virtual tagSessionState GetSessionState();
		virtual HRESULT GetErrCode();
		virtual bool IsDiffEndian();
		virtual void PostClose(DWORD errCode);
		virtual unsigned int GetSendingBufferSize();
		virtual unsigned int GetErrMsg(char *recv, unsigned int size);
		virtual unsigned int GetErrMsg(wchar_t *recv, unsigned int chars);
		virtual unsigned int Retrieve(unsigned char *receiver, unsigned int size);
		virtual unsigned int GetPeerName(char *name, unsigned int size);
		virtual unsigned int GetSockName(char *name, unsigned int size);
		virtual const ICertificate* const GetCertificate() const;
		virtual bool WaitAll(unsigned int ms);
		virtual unsigned int Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool oneWay);
		virtual bool IsAutoConnecting();
		virtual size_t GetRequestCountQueued();
		virtual const ICertificate* const GetSelfCert() const;
		virtual bool WaitConnection(unsigned int ms);

	public:
		bool Start();
		void Destroy();
		static void LogMessage(const wchar_t* file, const wchar_t *funcName, int lineNumber, int statusId, int typeId, int resultId, const wchar_t* message);

	private:
		//no copy constructor and assignment operator
		CSslSession(const CSslSession &session);
		CSslSession& operator=(const CSslSession &session);
		void PostCloseInternal(DWORD errCode);

	private:
		void handle_read();
		void Write();
		void OnCloseInternal();
		bool ProcessInternal();
		void Initialize();
		void DoConnetionInternal();
		void OnLessInternal();
		bool StartConnecting();
		void OnConencted(int errCode);
		void OnWritable(int errCode);
		void OnAvailable(int errCode);
		void OnClosed(int errCode);
		void FreeCredHandle();
		SECURITY_STATUS OpenCred();
		void DoHeartBeat();
		

	private:
		CMutex m_cs;
		std::atomic<bool> m_bEndianDiff;
		std::atomic<tagSessionState> m_ss;
		CErrCode m_ec; //protected by m_cs
		SOCKET m_hSocket;

		//reading
		CBuffer m_qRead;

		//writing
		CBuffer m_qWrite; //protected by m_cs
		CRequestHeader m_rh;
		ISessionCallback *m_sc;
		bool m_AutoConnecting; //not well implemented yet!

		std::deque<unsigned short> m_deqRequest; //protected by m_cs
		CConditionVariable m_cv;

		std::string m_strHost;
		unsigned int m_port;
		unsigned int m_timedout;
		bool m_v6;
		DWORD m_id;
		CSharedThreadPtr m_pHostThread;

		WSAEVENT m_hEvent;
		CredHandle m_hCreds;
		CSspiPtr m_pSspi;
		CCertificateImplPtr m_pCert; //protected by m_cs
		bool m_bReconnecting;
		CCertificateImplPtr m_pSelfCert;
		std::string m_certCN;
		PCCERT_CONTEXT m_pCertContext;

		CSSLHello m_ch; //protected by m_cs
	};

} //namespace ClientSide
} //namespace SC

#endif