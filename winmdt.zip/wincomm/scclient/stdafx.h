// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>

#include <mutex>
#include <atomic>

namespace SC { namespace ClientSide {

typedef std::mutex CMutex;
typedef std::unique_lock<std::mutex> CAutoLock;

} //namespace SC
} //namespace ClientSide
