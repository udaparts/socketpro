
#include "stdafx.h"
#include "sslsession.h"
#include "initclient.h"
#include "../commshared/LogGlobals.h"

PThreadExceptionHandlers g_teh = nullptr;
void WINAPI SetThreadStackCrashHandler_Client(PThreadExceptionHandlers teh) {
	g_teh = teh;
}

PThreadExceptionHandlers WINAPI GetThreadStackCrashHandler_Client() {
	return g_teh;
}

namespace SC 
{
	CWinSocketStartup CWinSocketStartup::m_startup;
	namespace ClientSide {
		CClientInit CClientInit::ClientInit;
	}
}

using namespace SC;
using namespace SC::ClientSide;

IClientSession* WINAPI DoClientConnection(ISessionCallback *sc, const char *host, unsigned int port, const char *certCN, unsigned int timedout, bool autoConnecting, bool v6)
{
	if (!sc) {
		return nullptr;
	}
	CSslSession *session = new CSslSession(sc, host, port, certCN, timedout, autoConnecting, v6);
	CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"Begin CSslSession connecting ......");
	session->Start();
	CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"End CSslSession connecting ......");
	return session;
}

void WINAPI DestroyClient(IClientSession *session)
{
	CSslSession *s = dynamic_cast<CSslSession *>(session);
	if (s)
	{
		CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"Begin destroying CSslSession");
		s->Destroy();
		delete s;
		CSslSession::LogMessage(__FILEW__, __FUNCTIONW__, __LINE__, LOG_STATUS_SUCCESS, LOG_TYPE_TRACING, S_OK, L"End destroying CSslSession");
	}
}

int WINAPI SetCertificateVerifyFile(const char *caFile)
{
	int ec = 0;
	if (caFile) {
		bool ok = false;
		CStringA file(caFile);
		if (file.CompareNoCase("root") == 0) {
			ok = CCertificateImpl::CertStore.OpenStore(cstRoot);
		}
		else if (file.CompareNoCase("my") == 0) {
			ok = CCertificateImpl::CertStore.OpenStore(cstMy);
		}
		else if (file.CompareNoCase("ca") == 0) {
			ok = CCertificateImpl::CertStore.OpenStore(cstCa);
		}
		else if (file.CompareNoCase("spc") == 0) {
			ok = CCertificateImpl::CertStore.OpenStore(cstSpc);
		}
		else {
			ok = CCertificateImpl::CertStore.OpenStore(CA2CT(caFile));
		}
		if (!ok) {
			ec = (int)CCertificateImpl::CertStore.GetErrCode().value();
		}
	}
	return ec;
}

SC::tagCertStoreType WINAPI GetClientCertStoreType() {
	return CCertificateImpl::CertStore.GetCertStoreType();
}

HCERTSTORE WINAPI GetClientCertStore() {
	return CCertificateImpl::CertStore.GetCertStore();
}