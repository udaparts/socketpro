
#ifndef ___SECURE_COMM_SSPI_I_H__
#define ___SECURE_COMM_SSPI_I_H__

#include "../../include/membuffer.h"

#ifndef SECURITY_WIN32
#define SECURITY_WIN32
#endif
#include <security.h>
#include <wincrypt.h>
#include <sspi.h>
#include <schannel.h>
#include <memory>
#include "../../include/storetype.h"
#include "errcode.h"
#include "../../include/handshakestage.h"
#include <map>

#ifdef BAD_COMM_ENVIRONMENT
#include <time.h>
#endif

namespace SC {

	//http://www.iana.org/assignments/tls-extensiontype-values
	enum tagExtensionType
	{
		server_name = 0,                             /* RFC 6066 */
		max_fragment_length = 1,                     /* RFC 6066 */
		client_certificate_url = 2,                  /* RFC 6066 */
		trusted_ca_keys = 3,                         /* RFC 6066 */
		truncated_hmac = 4,                          /* RFC 6066 */
		status_request = 5,                          /* RFC 6066 */
		supported_groups = 10,                       /* RFC 8422, 7919 */
		signature_algorithms = 13,                   /* RFC 8446 */
		use_srtp = 14,                               /* RFC 5764 */
		heartbeat = 15,                              /* RFC 6520 */
		application_layer_protocol_negotiation = 16, /* RFC 7301 */
		signed_certificate_timestamp = 18,           /* RFC 6962 */
		client_certificate_type = 19,                /* RFC 7250 */
		server_certificate_type = 20,                /* RFC 7250 */
		padding = 21,                                /* RFC 7685 */
		pre_shared_key = 41,                         /* RFC 8446 */
		early_data = 42,                             /* RFC 8446 */
		supported_versions = 43,                     /* RFC 8446 */
		cookie = 44,                                 /* RFC 8446 */
		psk_key_exchange_modes = 45,                 /* RFC 8446 */
		certificate_authorities = 47,                /* RFC 8446 */
		oid_filters = 48,                            /* RFC 8446 */
		post_handshake_auth = 49,                    /* RFC 8446 */
		signature_algorithms_cert = 50,              /* RFC 8446 */
		key_share = 51,								 /* RFC 8446 */
		//52-65279                                   /* Unassigned */
		private_use = 65280,                         /* RFC 8446 */
		renegotiation_info = 65281,                  /* RFC 5746 */
		//65282-65535                                /* Reserved for Private Use */
	};

#pragma pack(push,1)
	struct TLSRecord
	{
		unsigned char type;
		tagContentType GetContentType() const { return (tagContentType)type; }

		unsigned short version;
		tagProtocol GetProtocolVersion() const { return (tagProtocol)version; }

		unsigned short length; //big endian

		static const unsigned char STRUCT_SIZE = 5;
	};

	struct TLSHandshake
	{
		unsigned char msg_type;

		tagHandshakeType GetHandshakeType() const { return (tagHandshakeType)msg_type; }

		//uint24 length
		unsigned char LenHigh;
		unsigned char LenMid;
		unsigned char LenLow;

		unsigned short GetHandshakeLen() const { unsigned short len = LenMid; len <<= 8; len += LenLow; return len; }
		static const unsigned char STRUCT_SIZE = 4;
	};

	struct TLSRandom
	{
		unsigned int gmt_unix_time;
		unsigned char random_bytes[28];
		static const unsigned char STRUCT_SIZE = 32;
	};

	struct TLSHelloHeader
	{
		TLSHelloHeader()
		{
			::memset(this, 0, sizeof(TLSHelloHeader));
		}

		TLSRecord Record; //5
		TLSHandshake Handshake; //9
		unsigned short client_version; //or server_version, 11
		tagProtocol GetVersion() const { return (tagProtocol)client_version; }
		TLSRandom Random; //43
		unsigned char SessionIdLength; //44

		static const unsigned char STRUCT_SIZE = 44;

		//remaining bytes
	};

	enum tagCompressionMethod
	{
		null = 0,
		DEFLATE = 1,
	};

	struct TLSExtension
	{
		TLSExtension() : extension_type(0), length(0), extension_data(nullptr)
		{

		}
		unsigned short extension_type;
		unsigned short length;

		static const unsigned char STRUCT_SIZE = 4;

		const unsigned char *extension_data; //size depends on length
	};

#pragma pack(pop)

	typedef std::map<unsigned short, std::string> CCipherMap;
	extern CCipherMap g_mapCipher;

	class CSSLHello : public TLSHelloHeader, public ITLSProtocol
	{
	public:
		CSSLHello() : TLSHelloHeader(), Compression(0), ExtensionsLength(0)
		{
		}
		CSSLHello(const CSSLHello &ch); //no copy constructor

	public:
		CSSLHello & operator=(const CSSLHello &ch); //no assignment operator

		static bool ParseHello(const unsigned char* const buffer, unsigned int bytes, CSSLHello &ssl_hello)
		{
#if defined(BAD_COMM_ENVIRONMENT) && defined(ENABLE_RANDOM_HANDSHAKING_CRASH)
			srand((unsigned int)time(nullptr));
			unsigned int random = (unsigned int) rand();
			if (1 == (random % RANDOM_CRASH_STRENGTH)) {
				CStringW outputMessage;
				outputMessage.Format(L"File -- %ls, function name -- %ls, line number -- %d, message = %ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"HANDSHAKING_CRASH_CODE");
				OutputDebugStringW(outputMessage);
				::exit(HANDSHAKING_CRASH_CODE);
			}
#endif
			assert(buffer);
			//assert(bytes > TLSHelloHeader::STRUCT_SIZE);
			if (!buffer || bytes <= TLSHelloHeader::STRUCT_SIZE) {
				return false; //hello info not trnasferred completed yet
			}
			TLSHelloHeader *pTLS = (TLSHelloHeader *)buffer;
			unsigned short len = pTLS->Record.length;
			CBuffer::ChangeEndian((unsigned char*)&len, sizeof(len));
			//assert((len + sizeof(TLSRecord)) <= bytes);
			if ((len + sizeof(TLSRecord)) > bytes) {
				return false; //hello info not trnasferred completed yet
			}
			ssl_hello.SetHeader(*pTLS);
			tagProtocol protocol = ssl_hello.GetProtocolVersion();
			switch (protocol) {
				case SC::TLSv1_0:
				case SC::TLSv1_1:
				case SC::TLSv1_2:
				case SC::TLSv1_3:
					break; //we only support TLSv1_0 until TLSv1_3
				case SC::SSL2_0:
				case SC::SSL3_0:
				default:
					return false;
			}
			assert((ssl_hello.Record.length + sizeof(TLSRecord)) <= bytes);
			if ((ssl_hello.Record.length + sizeof(TLSRecord)) > bytes) {
				return false;
			}
			unsigned short *pSuites = (unsigned short *)(buffer + sizeof(TLSHelloHeader) + pTLS->SessionIdLength);
			unsigned short suites_bytes;
			if (ssl_hello.GetHandshakeType() == client_hello) {
				assert(ssl_hello.Handshake.GetHandshakeLen() == (ssl_hello.Record.length - sizeof(TLSHandshake)));
				suites_bytes = *pSuites;
				CBuffer::ChangeEndian((unsigned char*)&suites_bytes, sizeof(suites_bytes));
				ssl_hello.SetCiphers(pSuites + 1, suites_bytes / sizeof(unsigned short));
				suites_bytes += sizeof(unsigned short);
				suites_bytes += 1; //compression methods
			}
			else if (ssl_hello.GetHandshakeType() == server_hello) {
				ssl_hello.SetCiphers(pSuites, 1);
				suites_bytes = sizeof(unsigned short);
			}
			else {
				assert(false); //not implemented
				return false;
			}
			ssl_hello.Compression = *(buffer + sizeof(TLSHelloHeader) + pTLS->SessionIdLength + suites_bytes);
			suites_bytes += 1;
			if (ssl_hello.GetProtocolVersion() <= SC::TLSv1_0) {
				return true;
			}
			//extensions length
			const unsigned char *pEL = buffer + sizeof(TLSHelloHeader) + pTLS->SessionIdLength + suites_bytes;
			len = *((unsigned short*)pEL);
			CBuffer::ChangeEndian((unsigned char*)&len, sizeof(len));
			ssl_hello.ExtensionsLength = len;
			const unsigned char *extensions = pEL + sizeof(unsigned short);
			unsigned short remaining = (unsigned short)(bytes - (extensions - buffer)); //
			if (ssl_hello.GetHandshakeType() == client_hello) {
				assert(remaining == len);
			}
			else if (ssl_hello.GetHandshakeType() == server_hello) {
				assert(remaining >= len);
				remaining = len;
			}
			else {
				assert(false); //not implemented
				return false;
			}

			while (remaining) {
				TLSExtension ext = *((TLSExtension*)extensions);
				CBuffer::ChangeEndian((unsigned char*)&ext.extension_type, sizeof(ext.extension_type));
				CBuffer::ChangeEndian((unsigned char*)&ext.length, sizeof(ext.length));
				extensions += TLSExtension::STRUCT_SIZE;
				remaining -= TLSExtension::STRUCT_SIZE;
				len = ext.length; //value length in bytes
				if (len) {
					ext.extension_data = extensions;
					extensions += len;
					remaining -= len;
				}
				switch (ext.extension_type) {
					case (unsigned short)supported_versions: //TLSv1.3
					{
						unsigned short version;
						if (ssl_hello.GetHandshakeType() == client_hello) {
							version = *((unsigned short*)(ext.extension_data + 1));
						}
						else if (ssl_hello.GetHandshakeType() == server_hello) {
							version = *((unsigned short*)ext.extension_data);
						}
						CBuffer::ChangeEndian((unsigned char*)&version, sizeof(version));
						ssl_hello.client_version = version;
						ssl_hello.Record.version = version;
					}
					break;
					default:
						break;
				}
			}
			assert(!remaining);
			return true;
		}

	private:
		void SetHeader(const TLSHelloHeader &hh)
		{
			Record = hh.Record;
			CBuffer::ChangeEndian((unsigned char*)&Record.version, sizeof(Record.version));
			CBuffer::ChangeEndian((unsigned char*)&Record.length, sizeof(Record.length));
			Handshake = hh.Handshake;
			client_version = hh.client_version;
			CBuffer::ChangeEndian((unsigned char*)&client_version, sizeof(client_version));
			Random = hh.Random;
			CBuffer::ChangeEndian((unsigned char*)&Random.gmt_unix_time, sizeof(Random.gmt_unix_time));
			SessionIdLength = hh.SessionIdLength;
		}

		void SetCiphers(const unsigned short *pCipher, unsigned int count)
		{
			m_strCipherSuites.clear();
			for (unsigned int n = 0; n < count; ++n) {
				unsigned short cipher = pCipher[n];
				CBuffer::ChangeEndian((unsigned char*)&cipher, sizeof(cipher));
				if (m_strCipherSuites.size()) {
					m_strCipherSuites.push_back(';');
				}
				auto find = g_mapCipher.find(cipher);
				if (find == g_mapCipher.end()) {
					assert(false);
				}
				else {
					m_strCipherSuites += find->second;
				}
			}
		}
	public:
		//ITLSProtocol
		const char* GetCiphers() const
		{
			return m_strCipherSuites.c_str();
		}

		tagProtocol GetVersion() const
		{
			return TLSHelloHeader::GetVersion();
		}

		tagHandshakeType GetHandshakeType() const
		{
			return Handshake.GetHandshakeType();
		}

		tagContentType GetContentType() const { return Record.GetContentType(); }
		tagProtocol GetProtocolVersion() const { return (tagProtocol)client_version; }

	private:
		std::string m_strCipherSuites;
		unsigned char Compression;
		unsigned short ExtensionsLength;
	};

	typedef BOOL (WINAPI *PCertGetCertificateChain)(HCERTCHAINENGINE hChainEngine,
		PCCERT_CONTEXT pCertContext,
		LPFILETIME pTime,
		HCERTSTORE hAdditionalStore,
		PCERT_CHAIN_PARA pChainPara,
		DWORD dwFlags,
		LPVOID pvReserved,
		PCCERT_CHAIN_CONTEXT* ppChainContext);

	typedef BOOL (WINAPI *PCertVerifyCertificateChainPolicy)(
		LPCSTR pszPolicyOID,
		PCCERT_CHAIN_CONTEXT pChainContext,
		PCERT_CHAIN_POLICY_PARA pPolicyPara,
		PCERT_CHAIN_POLICY_STATUS pPolicyStatus
		);

	class CScCert
	{
	public:
		CScCert();
		~CScCert();

	public:
		bool IsOpened();
		bool OpenFromPfxFile(const wchar_t *filePfx, const wchar_t *password);
		void Close();
		HCERTSTORE GetCertStore();
		bool OpenStore(tagCertStoreType cst = cstRoot);
		bool OpenStore(const wchar_t *certFile);
		tagCertStoreType GetCertStoreType();
		CErrCode GetErrCode();
		std::string GetName();

	private:
		static void SetCertGetCertificateChainFunc();
		static void SetCipherMap();

	public:
		static PCertGetCertificateChain CertGetCertificateChain;
		static PCertVerifyCertificateChainPolicy CertVerifyCertificateChainPolicy;

	private:
		CScCert(const CScCert &cert);
		CScCert& operator=(const CScCert &cert);
		HCERTSTORE m_hCertStore;
		CMDTCriticalSection m_cs;
		tagCertStoreType m_cst;
		CErrCode m_ec;
		std::string m_name;
	};

	enum tagSslHandshakeState
	{
		hsStart = 0,
		hsShaking = 1,
		hsDone = 2
	};

	class CSspi
	{
	public:
		CSspi(bool client, PCredHandle pCredHandle, bool clientCertAuth);
		~CSspi();

	public:
		bool IsInitialized() const;
		bool DoHandshake(const unsigned char *buffer, DWORD dwSize, CBuffer &token);
		tagSslHandshakeState GetHandshakeState() const;
		SECURITY_STATUS GetLastStatus() const;
		bool Decrypt(const unsigned char *buffer, DWORD dwSize, CBuffer &read);
		SECURITY_STATUS Encrypt(const unsigned char *buffer, DWORD dwSize, CBuffer &write);
		PCCERT_CONTEXT GetCertContext() const;
		PSecHandle GetCtxHandle() const;
		void ResetCredHandle(PCredHandle pCredHandle);

	private:
		CSspi(const CSspi &sspi);
		CSspi& operator=(const CSspi &sspi);
		void DeleteContext();
		void DeleteCertContext();

	private:
		const static unsigned int INITIAL_CRYPTION_BUFFER_SIZE = 20 * 1024;
		CScopeBuffer m_sbIn;
		CScopeBuffer m_sbOut;
		bool m_client;
		PCredHandle m_pCredHandle;
		CtxtHandle m_CtxHandle;
		SecPkgContext_StreamSizes	m_StreamSizes;
		tagSslHandshakeState m_hs;
		SECURITY_STATUS m_ss;
		TimeStamp m_tsExpiry;
		CBuffer &m_qIn;
		CBuffer &m_qOut;
		PCCERT_CONTEXT	m_pCertContext;
		bool m_bClientReset;
		bool m_clientCertAuth;
	};
	typedef std::shared_ptr<CSspi> CSspiPtr;
}

#endif