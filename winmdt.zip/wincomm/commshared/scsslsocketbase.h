#ifndef ___SECURE_COMM_SSL_SOCKET_BASE_DEFINES_I_H__
#define ___SECURE_COMM_SSL_SOCKET_BASE_DEFINES_I_H__

#include <memory>

#include <thread>
#include <system_error>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <condition_variable>
#include "scsspi.h"
#include <string>

#include "errcode.h"

namespace SC {
	typedef std::condition_variable CConditionVariable;
	typedef std::shared_ptr<std::thread> CSharedThreadPtr;

	const DWORD	CK_SHUT_DOWN_IO_PORT = -1;
	const DWORD CK_SHUT_DOWN_SOCKET = -2;
	const DWORD CH_LESS_INTERNAL = -3;
	const DWORD CK_SLOW_REQUEST_PROCESSED = -4; //server side only

#pragma pack(push,1)
	typedef struct CRequestHeader {
		CRequestHeader()
			: RequestId(0),
			Reserved(0),
			Size(0) {
		}
		void Reset() {
			RequestId = 0;
			Reserved = 0;
			Size = 0;
		}
		unsigned short RequestId; //A request identification number, which can NOT be zero
		unsigned short Reserved; //Reserved for the future use, for example, online compression/decompression
		unsigned int Size; //Request chunk data size in bytes
	} RequestHeader;
#pragma pack(pop)

	class CWinSocketStartup
	{
		CWinSocketStartup()
		{
			WSADATA wsaData;
			WORD wVersionRequested = MAKEWORD(2, 2);
			int err = ::WSAStartup(wVersionRequested, &wsaData);
		}

		~CWinSocketStartup()
		{
			int err = ::WSACleanup();
		}
		static CWinSocketStartup m_startup;
	};
}


#endif