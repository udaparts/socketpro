// A reduced copy of the original in server/globals.

#ifndef LOG_TYPE_GLOBALS_H
#define LOG_TYPE_GLOBALS_H



///////////////////////////////////////////////////////////////////////////////////////////////
// Log Data
//

#define	U_SUCCESS		0x10001			/* operation successfule    */
#define	U_FAILURE		0x10002			/* operation failed, error  */
#define	U_ABORT			0x10004			/* operator aborted process */
#define	U_IERR			0x10008			/* INTERNAL ERROR           */
#define	U_SECUR			0x10010			/* Security Hit           */

/* this set is used by those things that should only log local  */
/* like when local IS the master                                */

// These releate to the LG_Status table
#define	M_SUCCESS		1			/* operation successfule    */
#define	M_FAILURE		2			/* operation failed, error  */
#define	M_ABORT			3			/* operator aborted process */
#define	M_IERR			4			/* INTERNAL ERROR           */
#define	M_SECUR			5			/* Security Hit           */
#define M_INFO			6
#define M_WARNING		7
#define M_RESULT		8	
#define M_START			9	

#define LOG_STATUS_SUCCESS M_SUCCESS
#define LOG_STATUS_FAILURE M_FAILURE
#define LOG_STATUS_ABORT M_ABORT
#define LOG_STATUS_ERROR M_IERR
#define LOG_STATUS_SECURITY M_SECUR
#define LOG_STATUS_INFO M_INFO
#define LOG_STATUS_WARNING M_WARNING
#define LOG_STATUS_RESULT M_RESULT
#define LOG_STATUS_START M_START


#define ERROR_LOG		"Error"
#define COMM_LOG		"Communications"
#define ACTVTY_LOG 		"Activity"
#define ARCHIVE_LOG 	"Archive"
#define MAJOR_LOG 		"Major"
#define SECUR_LOG 		"Security"

#define LOG_LEVEL2		2
#define LOG_LEVEL3		3
#define LOG_LEVEL4		4
#define LOG_LEVEL5		5
#define LOG_LEVEL_MAX	25

// these relate to the LG_Event table
#define LOG_EVENT_UCS	1
#define LOG_EVENT_USER	2
#define LOG_EVENT_SWEEP	3
#define LOG_EVENT_TSC	4
#define LOG_EVENT_AGENT	5
#define LOG_EVENT_CLIENT	6
#define LOG_EVENT_APPROVAL	7
#define LOG_EVENT_PLANTCFG	8
#define LOG_EVENT_EVENT	9			// log messages being generated during event processing

// These values do not relate to any table
// however they are critical in that they tell the database the object
// in the log_object field that we are reporting on.
#define LOG_OBJECT_AREA		1		  // log object to hold id of rm_area (program/area)
#define LOG_OBJECT_USER		2			// log object to hold id of user
#define LOG_OBJECT_CLIENT	3			// log object to hold id of client
#define LOG_OBJECT_DEVICE	4			// log object to hold id of device
#define LOG_OBJECT_WIRE		5			// log object to hold id of wire
#define LOG_OBJECT_USERGROUP 6			// log object to hold id of a usergroup (was LOG_OBJECT_CLASS)
#define LOG_OBJECT_BRIDGE	7			// log object to hold id of bridge
#define LOG_OBJECT_GLOBAL	8			// handle condition where we expect no data in log_object
#define LOG_OBJECT_APPLIST	9			// log object to hold id of approval list
#define LOG_OBJECT_APPGRP	10			// log object to hold id of approval group
#define LOG_OBJECT_REVISION	11			// log object to hold id of revision (RM_Revision)
#define LOG_OBJECT_TASKGROUP 12			// log_object to hold item of task group (tsc group)
#define LOG_OBJECT_VERSION	13			// log object to hold id of version (RM_Version)
#define LOG_OBJECT_TASKGROUPITEM	14	// log object to hold id of tsc item (not sure if needed but added for completeness...)
#define LOG_OBJECT_PERSONALITY		15	// log object to hold a personality id (PS_Personality)
#define LOG_OBJECT_CLIENTGROUP		16	// log object to hold a client group id
#define LOG_OBJECT_ATTRIBUTE	17
#define LOG_OBJECT_REGION		18
#define LOG_OBJECT_APP			19		// log object to hold an app id

#define LOG_OBJECT_MAXNUMBER	20		// set to one larger than that largest Object number
										// used by the logging to set the size ofthe array.

#define LOG_TYPEGROUP_ID_PROGRAM_RUNTIME	1
#define LOG_TYPEGROUP_ID_ADMIN				2
#define LOG_TYPEGROUP_ID_DISCONNECTED		3

// These values relate to the LG_Types table
#define LOG_TYPE_PREVIOUS		0
#define LOG_TYPE_TRACING		1
#define LOG_TYPE_PLANTCONFIG	2		// plant configuration - device, wires, paths, bridges, connections	 PLANTCONFIG
#define LOG_TYPE_ERROR			3		// ucsd errors where the protocol is the cause of the error
#define LOG_TYPE_REVISION		4		// revisions, versions, (uploads, downloads)
#define LOG_TYPE_COMPARE		5		// compares operations 
#define LOG_TYPE_LOCAL			6		// from the client when manipulating the local
#define LOG_TYPE_PROGRAM		7		// program create,delete,attr stuff 
#define LOG_TYPE_LOGIN			8		// login logout
#define LOG_TYPE_AREA			9		// area create/delete
#define LOG_TYPE_CONFIG			10		// LEGACY - SHOULD NOT BE USING
#define LOG_TYPE_TSC			11		// tsc admin
#define LOG_TYPE_APPROVAL		12		// approval process
//#define LOG_TYPE_PRIVILEGE		13
#define LOG_TYPE_LICENSE		14		// licensing logs
#define LOG_TYPE_USER_ADMIN		15		// changes to user and class administration
#define LOG_TYPE_CLIENT_ADMIN	16	// changes to client parameters
#define LOG_TYPE_SITE_ADMIN		17		// changes to site administration
#define LOG_TYPE_PTYPE			18		// logs around personality general stuff
#define LOG_TYPE_REPORTING		19
#define LOG_TYPE_PROTOCOL		20		// differentiate actual protocol logs to the trace

#endif
