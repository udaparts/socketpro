#include "stdafx.h"
#include "certificateimpl.h"
#include <winhttp.h>
#include "../../include/mdtcertutil.h"

namespace SC {

	CScCert CCertificateImpl::CertStore;

	CCertificateImpl::CCertificateImpl(CSspiPtr pSspi, const char *serverName)
		: m_pCertContext(pSspi->GetCertContext()),
		m_sc(pSspi->GetCtxHandle()),
		m_strSessionInfo("SSL version: ") 
	{
		std::string s(serverName);
		m_strServerName.assign(s.begin(), s.end());
		SetSessionInfo();
		SetPerm();
		SetPublickey();
	}

	CCertificateImpl::CCertificateImpl(PCCERT_CONTEXT pCertContext, const char *serverName) 
		: m_pCertContext(pCertContext),
		m_sc(nullptr) 
	{
		std::string s(serverName);
		m_strServerName.assign(s.begin(), s.end());
		SetSessionInfo();
		SetPerm();
		SetPublickey();
	}

	CCertificateImpl::~CCertificateImpl()
	{

	}

	void CCertificateImpl::SetPublickey()
	{
		unsigned char *p = m_pCertContext->pCertInfo->SubjectPublicKeyInfo.PublicKey.pbData;
		unsigned int len = m_pCertContext->pCertInfo->SubjectPublicKeyInfo.PublicKey.cbData;
		m_vPublicKey.assign(p, p + len);
	}

	void CCertificateImpl::SetSessionInfo()
	{
		char szName[4096] = {0};
		PCCERT_CONTEXT p = m_pCertContext;
		::CertNameToStrA(p->dwCertEncodingType, &p->pCertInfo->Issuer, CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, szName, sizeof(szName));
		m_strIssuer = szName;
		::CertNameToStrA(p->dwCertEncodingType, &p->pCertInfo->Subject, CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, szName, sizeof(szName));
		m_strSubject = szName;

		if (!m_sc) {
			return;
		}
		SecPkgContext_ConnectionInfo ConnectionInfo;
		PSecHandle sc = m_sc;
		SECURITY_STATUS ss = ::QueryContextAttributes(sc, SECPKG_ATTR_CONNECTION_INFO, &ConnectionInfo);
		if (ss == SEC_E_OK)
		{
			switch(ConnectionInfo.dwProtocol)
			{
			case SP_PROT_TLS1_2_CLIENT:
				m_strSessionInfo += "TLS1_2";
				break;
			case SP_PROT_TLS1_1_CLIENT:
				m_strSessionInfo += "TLS1_1";
				break;
			case SP_PROT_TLS1_CLIENT:
				m_strSessionInfo += "TLS1";
				break;
			case SP_PROT_SSL3_CLIENT:
				m_strSessionInfo += "SSL3";
				break;
			default:
				break;
			}

			switch (ConnectionInfo.aiCipher)
			{
			case CALG_3DES:
				m_strSessionInfo += ", Cipher: 3DES";
				break;
			case CALG_DES:
				m_strSessionInfo += ", Cipher: DES";
				break;
			case CALG_RC2:
				m_strSessionInfo += ", Cipher: RC2";
				break;
			case CALG_RC4:
				m_strSessionInfo += ", Cipher: RC4";
				break;
			case CALG_AES_128:
				m_strSessionInfo += ", Cipher: AES_128";
				break;
			case CALG_AES_192:
				m_strSessionInfo += ", Cipher: AES_192";
				break;
			case CALG_AES_256:
				m_strSessionInfo += ", Cipher: AES_256";
				break;
			default:
				break;
			}

			m_strSessionInfo += (", Cipher strength: " + std::to_string(ConnectionInfo.dwCipherStrength) + " Bits");

			switch(ConnectionInfo.aiHash)
			{
			case CALG_MD5: 
				m_strSessionInfo += ", Hash: MD5";
				break;
			case CALG_SHA: 
				m_strSessionInfo += ", Hash: SHA";
				break;
			default: 
				break;
			}

			m_strSessionInfo += ", ";
			switch(ConnectionInfo.aiExch)
			{
			case CALG_RSA_KEYX: 
			case CALG_RSA_SIGN: 
				m_strSessionInfo += "Key exchange: RSA";
				break;
			case CALG_KEA_KEYX: 
				m_strSessionInfo += "Key exchange: KEA";
				break;
			case CALG_DH_EPHEM:
				m_strSessionInfo += "Key exchange: DH Ephemeral";
				break;
			default: 
				break;
			}

			m_strSessionInfo += ", Key size ";
			m_strSessionInfo += std::to_string(ConnectionInfo.dwExchStrength);
			m_strSessionInfo += " Bits";
		}
	}

	void CCertificateImpl::SetPerm() 
	{

	}

	PCCERT_CONTEXT const CCertificateImpl::GetCertContext() const {
		return m_pCertContext;
	}

	const char* const CCertificateImpl::Verify(HRESULT *errCode) const
	{
		if (errCode) {
			*errCode = E_FAIL;
		}
		const char *errMsg = "Function CertGetCertificateChain or CertVerifyCertificateChainPolicy not available";
		if (CScCert::CertGetCertificateChain && CScCert::CertVerifyCertificateChainPolicy)
		{
			PCCERT_CHAIN_CONTEXT pChainContext = nullptr;
			LPSTR rgszUsages[] = {  szOID_PKIX_KP_SERVER_AUTH,
									szOID_SERVER_GATED_CRYPTO,
									szOID_SGC_NETSCAPE };
			DWORD	cUsages = sizeof(rgszUsages) / sizeof(LPSTR);
			CERT_CHAIN_PARA ChainPara;
			::memset(&ChainPara, 0, sizeof(ChainPara));
			ChainPara.cbSize = sizeof(ChainPara);
			ChainPara.RequestedUsage.dwType = USAGE_MATCH_TYPE_AND;
			ChainPara.RequestedUsage.Usage.cUsageIdentifier = cUsages;
			ChainPara.RequestedUsage.Usage.rgpszUsageIdentifier = rgszUsages;
			do
			{
				BOOL ok = CScCert::CertGetCertificateChain(nullptr,
					m_pCertContext,
					nullptr,
					CertStore.GetCertStore(),
					&ChainPara,
					0,
					nullptr,
					&pChainContext);
				if (!ok)
				{
					if (errCode) {
						*errCode = MAKE_HRESULT(SEVERITY_ERROR, CERT_FAC, ::GetLastError());
						errMsg = "CertGetCertificateChain error found";
					}
					break;
				}

				HTTPSPolicyCallbackData  polHttps;
				CERT_CHAIN_POLICY_PARA   PolicyPara;
				CERT_CHAIN_POLICY_STATUS PolicyStatus;

				// Validate certificate chain.
				::memset(&polHttps, 0, sizeof(HTTPSPolicyCallbackData));
				polHttps.cbStruct = sizeof(HTTPSPolicyCallbackData);
				polHttps.dwAuthType = AUTHTYPE_SERVER;
				polHttps.fdwChecks = (SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE);
				polHttps.pwszServerName = (wchar_t*)m_strServerName.c_str();

				::memset(&PolicyPara, 0, sizeof(PolicyPara));
				PolicyPara.cbSize            = sizeof(PolicyPara);
				PolicyPara.pvExtraPolicyPara = &polHttps;
				PolicyPara.dwFlags = 4;

				::memset(&PolicyStatus, 0, sizeof(PolicyStatus));
				PolicyStatus.cbSize = sizeof(PolicyStatus);

				ok = CScCert::CertVerifyCertificateChainPolicy(	CERT_CHAIN_POLICY_SSL,
					pChainContext,
					&PolicyPara,
					&PolicyStatus);
				if (!ok)
				{
					if (errCode)
					{
						*errCode = MAKE_HRESULT(SEVERITY_ERROR, CERT_FAC, ::GetLastError());
						errMsg = "CertVerifyCertificateChainPolicy error found";
					}
					break;
				}
				else
				{
					if (errCode)
					{
						*errCode = (int)PolicyStatus.dwError;
					}
				}
				errMsg = DisplayErrorMessage(PolicyStatus.dwError);

			}while(false);
			if (pChainContext)
			{
				::CertFreeCertificateChain(pChainContext);
			}
		}
		return errMsg;
	}

	const char* const CCertificateImpl::DisplayErrorMessage(DWORD status)
	{
		return SC::Utilities::DisplayErrorMessage(status);
	}

	const char* const CCertificateImpl::GetCertPem() const
	{
		return m_strPerm.c_str();
	}

	bool CCertificateImpl::IsValid() const
	{
		long res = ::CertVerifyTimeValidity(nullptr, m_pCertContext->pCertInfo);
		return (res == 0);
	}

	const char* const CCertificateImpl::GetSessionInfo() const
	{
		return m_strSessionInfo.c_str();
	}

	const char* const CCertificateImpl::GetSubject() const
	{
		return m_strSubject.c_str();
	}

	const char* const CCertificateImpl::GetIssuer() const
	{
		return m_strIssuer.c_str();
	}

	const unsigned char* const CCertificateImpl::GetPublicKey(unsigned int *pKeySize) const
	{
		if (pKeySize)
		{
			*pKeySize = (unsigned int)m_vPublicKey.size();
		}
		return m_vPublicKey.data();
	}
} //namespace SC
