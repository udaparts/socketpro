
#ifndef _SECURE_COMM_CLIENT_CERTIFICATE_IMPL_H_
#define _SECURE_COMM_CLIENT_CERTIFICATE_IMPL_H_

#include "../../include/sccommclient.h"
#include "../commshared/scsspi.h"

namespace SC {

	class CCertificateImpl : public ICertificate
	{
	public:
		CCertificateImpl(CSspiPtr pSspi, const char *serverName);
		CCertificateImpl(PCCERT_CONTEXT pCertContext, const char *serverName);
		virtual ~CCertificateImpl();

	public:
		//implementation for interface ICertificate
		virtual const char* const Verify(HRESULT *errCode) const;
		virtual const char* const GetCertPem() const;
		virtual bool IsValid() const;
		virtual const char* const GetSessionInfo() const;
		virtual const char* const GetSubject() const;
		virtual const char* const GetIssuer() const;
		virtual const unsigned char* const GetPublicKey(unsigned int *pKeySize) const;
		virtual PCCERT_CONTEXT const GetCertContext() const;

	private:
		//disable copy constructor and assignment operator
		CCertificateImpl(const CCertificateImpl &cert);
		CCertificateImpl& operator=(const CCertificateImpl &cert);

		void SetPerm();
		void SetSessionInfo();
		void SetPublickey();
		static const char* const DisplayErrorMessage(DWORD status);

	public:
		static CScCert CertStore;

	private:
		PCCERT_CONTEXT m_pCertContext;
		PSecHandle m_sc;
		std::string m_strIssuer;
		std::string m_strSubject;
		std::string m_strPerm;
		std::string m_strSessionInfo;
		std::vector<unsigned char> m_vPublicKey;
		std::wstring m_strServerName;
	};

	typedef std::shared_ptr<CCertificateImpl> CCertificateImplPtr;

} //namespace SC

#endif