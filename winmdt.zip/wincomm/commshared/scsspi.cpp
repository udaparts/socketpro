
#include "stdafx.h"
#include "scsspi.h"

namespace SC {

	PCertGetCertificateChain CScCert::CertGetCertificateChain(nullptr);
	PCertVerifyCertificateChainPolicy CScCert::CertVerifyCertificateChainPolicy(nullptr);

	CCipherMap g_mapCipher;

	void CScCert::SetCertGetCertificateChainFunc()
	{
		if (!CertGetCertificateChain && !CertVerifyCertificateChainPolicy) {
			HMODULE h = ::LoadLibrary(L"crypt32.dll");
			CertGetCertificateChain = (PCertGetCertificateChain)::GetProcAddress(h, "CertGetCertificateChain");
			CertVerifyCertificateChainPolicy = (PCertVerifyCertificateChainPolicy)::GetProcAddress(h, "CertVerifyCertificateChainPolicy");
			::FreeLibrary(h);
		}
	}

	void CScCert::SetCipherMap()
	{
		//SSL_RC4_128_WITH_MD5
		//SSL_DES_192_EDE3_CBC_WITH_MD5
		//SSL_CK_DES_192_EDE3_CBC_WITH_MD5
		//SSL_RC2_CBC_128_CBC_WITH_MD5
		//SSL_DES_64_CBC_WITH_MD5
		//SSL_RC4_128_EXPORT40_WITH_MD5

		//SSL_CK_RC4_128_WITH_MD5
		//SSL_CK_RC4_128_EXPORT40_MD5
		//SSL_CK_DES_64_CBC_WITH_MD5
		//TLS_DHE_DSS_EXPORT1024_WITH_DES_CBC_SHA

		if (!g_mapCipher.size()) {
			g_mapCipher[0x0000] = "TLS_NULL_WITH_NULL_NULL";
			g_mapCipher[0x0001] = "TLS_RSA_WITH_NULL_MD5";
			g_mapCipher[0x0002] = "TLS_RSA_WITH_NULL_SHA";
			g_mapCipher[0x0003] = "TLS_RSA_EXPORT_WITH_RC4_40_MD5";
			g_mapCipher[0x0004] = "TLS_RSA_WITH_RC4_128_MD5";
			g_mapCipher[0x0005] = "TLS_RSA_WITH_RC4_128_SHA";
			g_mapCipher[0x0006] = "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5";
			g_mapCipher[0x0007] = "TLS_RSA_WITH_IDEA_CBC_SHA";
			g_mapCipher[0x0008] = "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA";
			g_mapCipher[0x0009] = "TLS_RSA_WITH_DES_CBC_SHA";
			g_mapCipher[0x000A] = "TLS_RSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x000B] = "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA";
			g_mapCipher[0x000C] = "TLS_DH_DSS_WITH_DES_CBC_SHA";
			g_mapCipher[0x000D] = "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x000E] = "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA";
			g_mapCipher[0x000F] = "TLS_DH_RSA_WITH_DES_CBC_SHA";
			g_mapCipher[0x0010] = "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x0011] = "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA";
			g_mapCipher[0x0012] = "TLS_DHE_DSS_WITH_DES_CBC_SHA";
			g_mapCipher[0x0013] = "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x0014] = "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA";
			g_mapCipher[0x0015] = "TLS_DHE_RSA_WITH_DES_CBC_SHA";
			g_mapCipher[0x0016] = "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x0017] = "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5";
			g_mapCipher[0x0018] = "TLS_DH_anon_WITH_RC4_128_MD5";
			g_mapCipher[0x0019] = "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA";
			g_mapCipher[0x001A] = "TLS_DH_anon_WITH_DES_CBC_SHA";
			g_mapCipher[0x001B] = "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x001D] = "SSL_FORTEZZA_KEA_WITH_FORTEZZA_CBC_SHA";
			g_mapCipher[0x001E] = "SSL_FORTEZZA_KEA_WITH_RC4_128_SHA";
			g_mapCipher[0x001F] = "TLS_KRB5_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x0020] = "TLS_KRB5_WITH_RC4_128_SHA";
			g_mapCipher[0x0021] = "TLS_KRB5_WITH_IDEA_CBC_SHA";
			g_mapCipher[0x0022] = "TLS_KRB5_WITH_DES_CBC_MD5";
			g_mapCipher[0x0023] = "TLS_KRB5_WITH_3DES_EDE_CBC_MD5";
			g_mapCipher[0x0024] = "TLS_KRB5_WITH_RC4_128_MD5";
			g_mapCipher[0x0025] = "TLS_KRB5_WITH_IDEA_CBC_MD5";
			g_mapCipher[0x0026] = "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA";
			g_mapCipher[0x0027] = "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA";
			g_mapCipher[0x0028] = "TLS_KRB5_EXPORT_WITH_RC4_40_SHA";
			g_mapCipher[0x0029] = "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5";
			g_mapCipher[0x002A] = "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5";
			g_mapCipher[0x002B] = "TLS_KRB5_EXPORT_WITH_RC4_40_MD5";
			g_mapCipher[0x002C] = "TLS_PSK_WITH_NULL_SHA";
			g_mapCipher[0x002D] = "TLS_DHE_PSK_WITH_NULL_SHA";
			g_mapCipher[0x002E] = "TLS_RSA_PSK_WITH_NULL_SHA";
			g_mapCipher[0x002F] = "TLS_RSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0030] = "TLS_DH_DSS_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0031] = "TLS_DH_RSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0032] = "TLS_DHE_DSS_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0033] = "TLS_DHE_RSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0034] = "TLS_DH_anon_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0035] = "TLS_RSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x0036] = "TLS_DH_DSS_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x0037] = "TLS_DH_RSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x0038] = "TLS_DHE_DSS_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x0039] = "TLS_DHE_RSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x003A] = "TLS_DH_anon_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x003B] = "TLS_RSA_WITH_NULL_SHA256";
			g_mapCipher[0x003C] = "TLS_RSA_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x003D] = "TLS_RSA_WITH_AES_256_CBC_SHA256";
			g_mapCipher[0x003E] = "TLS_DH_DSS_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x003F] = "TLS_DH_RSA_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x0040] = "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x0041] = "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA";
			g_mapCipher[0x0042] = "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA";
			g_mapCipher[0x0043] = "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA";
			g_mapCipher[0x0044] = "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA";
			g_mapCipher[0x0045] = "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA";
			g_mapCipher[0x0046] = "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA";
			g_mapCipher[0x0062] = "TLS_RSA_EXPORT1024_WITH_RC4_56_SHA";
			g_mapCipher[0x0064] = "TLS_RSA_EXPORT1024_WITH_DES_CBC_SHA";
			g_mapCipher[0x0067] = "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x0068] = "TLS_DH_DSS_WITH_AES_256_CBC_SHA256";
			g_mapCipher[0x0069] = "TLS_DH_RSA_WITH_AES_256_CBC_SHA256";
			g_mapCipher[0x006A] = "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256";
			g_mapCipher[0x006B] = "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256";
			g_mapCipher[0x006C] = "TLS_DH_anon_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x006D] = "TLS_DH_anon_WITH_AES_256_CBC_SHA256";
			g_mapCipher[0x0081] = "TLS_GOSTR341001_WITH_28147_CNT_IMIT";
			g_mapCipher[0x0083] = "TLS_GOSTR341001_WITH_NULL_GOSTR3411";
			g_mapCipher[0x0084] = "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA";
			g_mapCipher[0x0085] = "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA";
			g_mapCipher[0x0086] = "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA";
			g_mapCipher[0x0087] = "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA";
			g_mapCipher[0x0088] = "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA";
			g_mapCipher[0x0089] = "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA";
			g_mapCipher[0x008A] = "TLS_PSK_WITH_RC4_128_SHA";
			g_mapCipher[0x008B] = "TLS_PSK_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x008C] = "TLS_PSK_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x008D] = "TLS_PSK_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x008E] = "TLS_DHE_PSK_WITH_RC4_128_SHA";
			g_mapCipher[0x008F] = "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x0090] = "TLS_DHE_PSK_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0091] = "TLS_DHE_PSK_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x0092] = "TLS_RSA_PSK_WITH_RC4_128_SHA";
			g_mapCipher[0x0093] = "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0x0094] = "TLS_RSA_PSK_WITH_AES_128_CBC_SHA";
			g_mapCipher[0x0095] = "TLS_RSA_PSK_WITH_AES_256_CBC_SHA";
			g_mapCipher[0x0096] = "TLS_RSA_WITH_SEED_CBC_SHA";
			g_mapCipher[0x0097] = "TLS_DH_DSS_WITH_SEED_CBC_SHA";
			g_mapCipher[0x0098] = "TLS_DH_RSA_WITH_SEED_CBC_SHA";
			g_mapCipher[0x0099] = "TLS_DHE_DSS_WITH_SEED_CBC_SHA";
			g_mapCipher[0x009A] = "TLS_DHE_RSA_WITH_SEED_CBC_SHA";
			g_mapCipher[0x009B] = "TLS_DH_anon_WITH_SEED_CBC_SHA";
			g_mapCipher[0x009C] = "TLS_RSA_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x009D] = "TLS_RSA_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x009E] = "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x009F] = "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00A0] = "TLS_DH_RSA_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x00A1] = "TLS_DH_RSA_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00A2] = "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x00A3] = "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00A4] = "TLS_DH_DSS_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x00A5] = "TLS_DH_DSS_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00A6] = "TLS_DH_anon_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x00A7] = "TLS_DH_anon_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00A8] = "TLS_PSK_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x00A9] = "TLS_PSK_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00AA] = "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x00AB] = "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00AC] = "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0x00AD] = "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0x00AE] = "TLS_PSK_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x00AF] = "TLS_PSK_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0x00B0] = "TLS_PSK_WITH_NULL_SHA256";
			g_mapCipher[0x00B1] = "TLS_PSK_WITH_NULL_SHA384";
			g_mapCipher[0x00B2] = "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x00B3] = "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0x00B4] = "TLS_DHE_PSK_WITH_NULL_SHA256";
			g_mapCipher[0x00B5] = "TLS_DHE_PSK_WITH_NULL_SHA384";
			g_mapCipher[0x00B6] = "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0x00B7] = "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0x00B8] = "TLS_RSA_PSK_WITH_NULL_SHA256";
			g_mapCipher[0x00B9] = "TLS_RSA_PSK_WITH_NULL_SHA384";
			g_mapCipher[0x00BA] = "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0x00BB] = "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0x00BC] = "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0x00BD] = "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0x00BE] = "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0x00BF] = "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0x00C0] = "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256";
			g_mapCipher[0x00C1] = "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256";
			g_mapCipher[0x00C2] = "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256";
			g_mapCipher[0x00C3] = "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256";
			g_mapCipher[0x00C4] = "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256";
			g_mapCipher[0x00C5] = "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256";
			g_mapCipher[0x00FF] = "TLS_EMPTY_RENEGOTIATION_INFO_SCSV";
			g_mapCipher[0x5600] = "TLS_FALLBACK_SCSV";
			g_mapCipher[0xC001] = "TLS_ECDH_ECDSA_WITH_NULL_SHA";
			g_mapCipher[0xC002] = "TLS_ECDH_ECDSA_WITH_RC4_128_SHA";
			g_mapCipher[0xC003] = "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC004] = "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC005] = "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC006] = "TLS_ECDHE_ECDSA_WITH_NULL_SHA";
			g_mapCipher[0xC007] = "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA";
			g_mapCipher[0xC008] = "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC009] = "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC00A] = "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC00B] = "TLS_ECDH_RSA_WITH_NULL_SHA";
			g_mapCipher[0xC00C] = "TLS_ECDH_RSA_WITH_RC4_128_SHA";
			g_mapCipher[0xC00D] = "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC00E] = "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC00F] = "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC010] = "TLS_ECDHE_RSA_WITH_NULL_SHA";
			g_mapCipher[0xC011] = "TLS_ECDHE_RSA_WITH_RC4_128_SHA";
			g_mapCipher[0xC012] = "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC013] = "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC014] = "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC015] = "TLS_ECDH_anon_WITH_NULL_SHA";
			g_mapCipher[0xC016] = "TLS_ECDH_anon_WITH_RC4_128_SHA";
			g_mapCipher[0xC017] = "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC018] = "TLS_ECDH_anon_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC019] = "TLS_ECDH_anon_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC01A] = "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC01B] = "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC01C] = "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC01D] = "TLS_SRP_SHA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC01E] = "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC01F] = "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC020] = "TLS_SRP_SHA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC021] = "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC022] = "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC023] = "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0xC024] = "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0xC025] = "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0xC026] = "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0xC027] = "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0xC028] = "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0xC029] = "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0xC02A] = "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0xC02B] = "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0xC02C] = "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0xC02D] = "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0xC02E] = "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0xC02F] = "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0xC030] = "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0xC031] = "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256";
			g_mapCipher[0xC032] = "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384";
			g_mapCipher[0xC033] = "TLS_ECDHE_PSK_WITH_RC4_128_SHA";
			g_mapCipher[0xC034] = "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xC035] = "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA";
			g_mapCipher[0xC036] = "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA";
			g_mapCipher[0xC037] = "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256";
			g_mapCipher[0xC038] = "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384";
			g_mapCipher[0xC039] = "TLS_ECDHE_PSK_WITH_NULL_SHA";
			g_mapCipher[0xC03A] = "TLS_ECDHE_PSK_WITH_NULL_SHA256";
			g_mapCipher[0xC03B] = "TLS_ECDHE_PSK_WITH_NULL_SHA384";
			g_mapCipher[0xC03C] = "TLS_RSA_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC03D] = "TLS_RSA_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC03E] = "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC03F] = "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC040] = "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC041] = "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC042] = "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC043] = "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC044] = "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC045] = "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC046] = "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC047] = "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC048] = "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC049] = "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC04A] = "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC04B] = "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC04C] = "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC04D] = "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC04E] = "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC04F] = "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC050] = "TLS_RSA_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC051] = "TLS_RSA_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC052] = "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC053] = "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC054] = "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC055] = "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC056] = "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC057] = "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC058] = "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC059] = "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC05A] = "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC05B] = "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC05C] = "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC05D] = "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC05E] = "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC05F] = "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC060] = "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC061] = "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC062] = "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC063] = "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC064] = "TLS_PSK_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC065] = "TLS_PSK_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC066] = "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC067] = "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC068] = "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC069] = "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC06A] = "TLS_PSK_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC06B] = "TLS_PSK_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC06C] = "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC06D] = "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC06E] = "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256";
			g_mapCipher[0xC06F] = "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384";
			g_mapCipher[0xC070] = "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256";
			g_mapCipher[0xC071] = "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384";
			g_mapCipher[0xC072] = "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC073] = "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC074] = "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC075] = "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC076] = "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC077] = "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC078] = "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC079] = "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC07A] = "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC07B] = "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC07C] = "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC07D] = "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC07E] = "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC07F] = "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC080] = "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC081] = "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC082] = "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC083] = "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC084] = "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC085] = "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC086] = "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC087] = "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC088] = "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC089] = "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC08A] = "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC08B] = "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC08C] = "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC08D] = "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC08E] = "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC08F] = "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC090] = "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC091] = "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC092] = "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256";
			g_mapCipher[0xC093] = "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384";
			g_mapCipher[0xC094] = "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC095] = "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC096] = "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC097] = "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC098] = "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC099] = "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC09A] = "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256";
			g_mapCipher[0xC09B] = "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384";
			g_mapCipher[0xC09C] = "TLS_RSA_WITH_AES_128_CCM";
			g_mapCipher[0xC09D] = "TLS_RSA_WITH_AES_256_CCM";
			g_mapCipher[0xC09E] = "TLS_DHE_RSA_WITH_AES_128_CCM";
			g_mapCipher[0xC09F] = "TLS_DHE_RSA_WITH_AES_256_CCM";
			g_mapCipher[0xC0A0] = "TLS_RSA_WITH_AES_128_CCM_8";
			g_mapCipher[0xC0A1] = "TLS_RSA_WITH_AES_256_CCM_8";
			g_mapCipher[0xC0A2] = "TLS_DHE_RSA_WITH_AES_128_CCM_8";
			g_mapCipher[0xC0A3] = "TLS_DHE_RSA_WITH_AES_256_CCM_8";
			g_mapCipher[0xC0A4] = "TLS_PSK_WITH_AES_128_CCM";
			g_mapCipher[0xC0A5] = "TLS_PSK_WITH_AES_256_CCM";
			g_mapCipher[0xC0A6] = "TLS_DHE_PSK_WITH_AES_128_CCM";
			g_mapCipher[0xC0A7] = "TLS_DHE_PSK_WITH_AES_256_CCM";
			g_mapCipher[0xC0A8] = "TLS_PSK_WITH_AES_128_CCM_8";
			g_mapCipher[0xC0A9] = "TLS_PSK_WITH_AES_256_CCM_8";
			g_mapCipher[0xC0AA] = "TLS_PSK_DHE_WITH_AES_128_CCM_8";
			g_mapCipher[0xC0AB] = "TLS_PSK_DHE_WITH_AES_256_CCM_8";
			g_mapCipher[0xC0AC] = "TLS_ECDHE_ECDSA_WITH_AES_128_CCM";
			g_mapCipher[0xC0AD] = "TLS_ECDHE_ECDSA_WITH_AES_256_CCM";
			g_mapCipher[0xC0AE] = "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8";
			g_mapCipher[0xC0AF] = "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8";
			g_mapCipher[0xCCA8] = "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0xCCA9] = "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0xCCAA] = "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0xCCAB] = "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0xCCAC] = "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0xCCAD] = "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0xCCAE] = "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0x1301] = "TLS_AES_128_GCM_SHA256";
			g_mapCipher[0x1302] = "TLS_AES_256_GCM_SHA384";
			g_mapCipher[0x1303] = "TLS_CHACHA20_POLY1305_SHA256";
			g_mapCipher[0x1304] = "TLS_AES_128_CCM_SHA256";
			g_mapCipher[0x1305] = "TLS_AES_128_CCM_8_SHA256";
			g_mapCipher[0xFEFE] = "SSL_RSA_FIPS_WITH_DES_CBC_SHA";
			g_mapCipher[0xFEFF] = "SSL_RSA_FIPS_WITH_3DES_EDE_CBC_SHA";
			g_mapCipher[0xFF85] = "GOST2012-GOST8912-GOST8912";
			g_mapCipher[0xFF87] = "GOST2012-NULL-GOST12";
		}
	}

	CScCert::CScCert()
		: m_hCertStore(nullptr),
		m_cst(cstUnknown)
	{
		CScCert::SetCertGetCertificateChainFunc();
	}

	CScCert::~CScCert()
	{
		Close();
	}

	bool CScCert::IsOpened()
	{
		CAutoLock al(m_cs);
		return m_hCertStore != nullptr;
	}

	void CScCert::Close()
	{
		CAutoLock al(m_cs);
		if (m_hCertStore)
		{
			::CertCloseStore(m_hCertStore, 0);
			m_hCertStore = nullptr;
		}
		m_cst = cstUnknown;
		m_name.clear();
		m_ec.assign(0, "");
	}

	CErrCode CScCert::GetErrCode()
	{
		CAutoLock al(m_cs);
		return m_ec;
	}

	std::string CScCert::GetName()
	{
		CAutoLock al(m_cs);
		return m_name;
	}

	tagCertStoreType CScCert::GetCertStoreType() {
		CAutoLock al(m_cs);
		return m_cst;
	}

	bool CScCert::OpenFromPfxFile(const wchar_t *filePfx, const wchar_t *password)
	{
		ULONG ulRead;
		SetCipherMap();
		CAutoLock al(m_cs);
		if (m_hCertStore) {
			return true;
		}
		m_name = SC::ToUTF8(filePfx);
		if (!password) {
			password = L"";
		}
		HANDLE hfile = ::CreateFile(filePfx, FILE_READ_DATA, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0);
		if (INVALID_HANDLE_VALUE == hfile) {
			m_ec.assign(::GetLastError(), "Cannot open SSL3/TLSv1.x private key file " + m_name);
			return false;
		}
		CRYPT_DATA_BLOB blob;
		blob.cbData = GetFileSize(hfile, 0);
		blob.pbData = (BYTE*)::malloc(blob.cbData + 16);
		do
		{
			if (::ReadFile(hfile, blob.pbData, blob.cbData, &ulRead, nullptr) == FALSE) {
				break;
			}
			if (::PFXIsPFXBlob(&blob) == FALSE) {
				m_ec.assign(BAD_PFX_BLOB, "Invalid SSL3/TLSv1.x private key file " + m_name + " found");
				break;
			}
			m_hCertStore = ::PFXImportCertStore(&blob, password, CRYPT_USER_KEYSET|CRYPT_EXPORTABLE);
			if (m_hCertStore) {
				m_cst = cstPfx;
			}
			else {
				m_ec.assign(::GetLastError(), "Cannot import SSL3/TLSv1.x certificate and private key from file " + m_name + " due to wrong password");
			}
		}while (false);
		if (blob.pbData) {
			::free(blob.pbData);
		}
		::CloseHandle(hfile);
		return (m_hCertStore != nullptr);
	}

	bool CScCert::OpenStore(tagCertStoreType ct)
	{
		SetCipherMap();
		CAutoLock al(m_cs);
		if (m_hCertStore) {
			return true;
		}
		m_cst = ct;
		switch (ct)
		{
		case SC::cstRoot:
			m_name = "ROOT";
			m_hCertStore = CertOpenSystemStore(0, L"ROOT");
			break;
		case SC::cstCa:
			m_name = "CA";
			m_hCertStore = CertOpenSystemStore(0, L"CA");
			break;
		case SC::cstMy:
			m_name = "MY";
			m_hCertStore = CertOpenSystemStore(0, L"MY");
			break;
		case SC::cstSpc:
			m_name = "SPC";
			m_hCertStore = CertOpenSystemStore(0, L"SPC");
			break;
		default:
			assert(false);
			break;
		}
		if (!m_hCertStore) {
			m_ec.assign(::GetLastError(), "Cannot open certificate store " + m_name);
		}
		return (m_hCertStore != nullptr);
	}

	bool CScCert::OpenStore(const wchar_t *certFile)
	{
		CAutoLock al(m_cs);
		if (m_hCertStore)
		{
			return true;
		}
		DWORD dwStoreOpenFlag = (CERT_STORE_OPEN_EXISTING_FLAG | CERT_STORE_READONLY_FLAG);
		m_hCertStore = CertOpenStore(CERT_STORE_PROV_FILENAME_W,
			0,
			X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
			dwStoreOpenFlag,
			certFile);
		if (m_hCertStore) {
			m_cst = cstCertFile;
		}
		else {
			m_name = SC::ToUTF8(certFile);
			m_ec.assign(::GetLastError(), "Cannot open certificate store from file " + m_name);
		}
		return (m_hCertStore != nullptr);
	}

	HCERTSTORE CScCert::GetCertStore()
	{
		CAutoLock al(m_cs);
		return m_hCertStore;
	}

	CSspi::CSspi(bool client, PCredHandle pCredHandle, bool clientCertAuth)
		: m_sbIn(INITIAL_CRYPTION_BUFFER_SIZE),
		m_sbOut(INITIAL_CRYPTION_BUFFER_SIZE),
		m_client(client),
		m_pCredHandle(pCredHandle),
		m_hs(hsStart),
		m_ss(SEC_E_OK),
		m_qIn(*m_sbIn),
		m_qOut(*m_sbOut),
		m_pCertContext(nullptr),
		m_bClientReset(false),
		m_clientCertAuth(clientCertAuth)
	{
		assert(pCredHandle);
		::memset(&m_CtxHandle, 0, sizeof(m_CtxHandle));
		::memset(&m_StreamSizes, 0, sizeof(m_StreamSizes));
		::memset(&m_tsExpiry, 0, sizeof(m_tsExpiry));
		if (m_qIn.GetMaxSize() > DEFAULT_INITIAL_MEMORY_BUFFER_SIZE)
		{
			m_qIn.ReallocBuffer(DEFAULT_INITIAL_MEMORY_BUFFER_SIZE);
		}
	}

	CSspi::~CSspi()
	{
		DeleteCertContext();
		DeleteContext();
	}

	void CSspi::ResetCredHandle(PCredHandle pCredHandle) {
		assert(m_client);
		m_bClientReset = true;
		m_pCredHandle = pCredHandle;
	}

	tagSslHandshakeState CSspi::GetHandshakeState() const
	{
		return m_hs;
	}

	bool CSspi::IsInitialized() const
	{
		return ((m_CtxHandle.dwLower || m_CtxHandle.dwUpper) && m_ss != SEC_E_INCOMPLETE_MESSAGE && m_ss != SEC_I_COMPLETE_AND_CONTINUE && m_ss != SEC_I_CONTINUE_NEEDED);
	}

	PCCERT_CONTEXT CSspi::GetCertContext() const
	{
		return m_pCertContext;
	}

	PSecHandle CSspi::GetCtxHandle() const
	{
		return (PSecHandle)&m_CtxHandle;
	}

	void CSspi::DeleteCertContext()
	{
		if (m_pCertContext)
		{
			::CertFreeCertificateContext(m_pCertContext);
			m_pCertContext = nullptr;
		}
	}

	void CSspi::DeleteContext()
	{
		if (m_CtxHandle.dwLower || m_CtxHandle.dwUpper)
		{
			SECURITY_STATUS status = ::DeleteSecurityContext(&m_CtxHandle);
			::memset(&m_CtxHandle, 0, sizeof(m_CtxHandle));
		}
	}

	SECURITY_STATUS CSspi::GetLastStatus() const
	{
		return m_ss;
	}

	SECURITY_STATUS CSspi::Encrypt(const unsigned char *buffer, DWORD dwSize, CBuffer &write)
	{
		SECURITY_STATUS ss;
		assert(m_hs == hsDone);
		SecBufferDesc Message;
		SecBuffer Buffers[4];
		if (!buffer)
		{
			dwSize = 0;
		}
		do
		{
			unsigned int size = (dwSize > m_StreamSizes.cbMaximumMessage) ? m_StreamSizes.cbMaximumMessage : dwSize;
			unsigned int requiredSize = (unsigned int)(m_StreamSizes.cbHeader + m_StreamSizes.cbTrailer + size);
			if (requiredSize > m_qOut.GetMaxSize())
			{
				m_qOut.ReallocBuffer(requiredSize);
			}
			Buffers[0].pvBuffer     = (void*)m_qOut.GetBuffer();
			Buffers[0].cbBuffer     = m_StreamSizes.cbHeader;
			Buffers[0].BufferType   = SECBUFFER_STREAM_HEADER;
			::memset(Buffers[0].pvBuffer, 0, m_StreamSizes.cbHeader);
			m_qOut.SetSize((unsigned int)m_StreamSizes.cbHeader);
			m_qOut.Push(buffer, size);
			Buffers[1].pvBuffer     = (void*)m_qOut.GetBuffer(m_StreamSizes.cbHeader);
			Buffers[1].cbBuffer     = m_qOut.GetSize() - (unsigned int)m_StreamSizes.cbHeader;
			Buffers[1].BufferType   = SECBUFFER_DATA;
			Buffers[2].pvBuffer     = (void*)m_qOut.GetBuffer(m_qOut.GetSize());
			Buffers[2].cbBuffer     = m_StreamSizes.cbTrailer;
			Buffers[2].BufferType   = SECBUFFER_STREAM_TRAILER;
			::memset(Buffers[2].pvBuffer, 0, m_StreamSizes.cbTrailer);
			Buffers[3].BufferType   = SECBUFFER_EMPTY;
			Buffers[3].cbBuffer = 0;
			Buffers[3].pvBuffer = nullptr;
			m_qOut.SetSize(0);
			Message.ulVersion = SECBUFFER_VERSION;
			Message.cBuffers = sizeof(Buffers)/sizeof(SecBuffer);
			Message.pBuffers = Buffers;
			ss = ::EncryptMessage(&m_CtxHandle, 0, &Message, 0);
			if (ss != SEC_E_OK)
			{
				return ss;
			}
			assert(Buffers[0].cbBuffer == m_StreamSizes.cbHeader);
			assert(Buffers[1].cbBuffer == size);
			unsigned int obtained = (unsigned int)(Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
			write.Push(m_qOut.GetBuffer(), obtained);
			dwSize -= size;
			buffer += size;
		} while (dwSize > 0);
		return ss;
	}

	bool CSspi::Decrypt(const unsigned char *buffer, DWORD dwSize, CBuffer &read)
	{
		int i;
		bool keep;
		bool backup = false;
		assert(m_hs == hsDone);
		SecBuffer Buffers[4];
		SecBufferDesc Message;
		if (!buffer)
		{
			dwSize = 0;
		}
		m_qIn.SetHeadPosition();
		do
		{
			keep = false;
			SecBuffer *pDataBuffer = nullptr;
			SecBuffer *pExtraBuffer = nullptr;
			::memset(Buffers, 0, sizeof(Buffers));
			// Attempt to decrypt the received data.
			if (m_qIn.GetSize())
			{
				if (buffer && dwSize)
				{
					m_qIn.Push((const unsigned char*)buffer, (unsigned int)dwSize);
				}
				Buffers[0].pvBuffer = (void*)m_qIn.GetBuffer();
				Buffers[0].cbBuffer = m_qIn.GetSize();
			}
			else
			{
				Buffers[0].pvBuffer = (void*)buffer;
				Buffers[0].cbBuffer = dwSize;
				backup = true;
			}
			Buffers[0].BufferType   = SECBUFFER_DATA;
			/*
			Buffers[1].BufferType   = SECBUFFER_EMPTY;
			Buffers[2].BufferType   = SECBUFFER_EMPTY;
			Buffers[3].BufferType   = SECBUFFER_EMPTY;
			*/
			Message.ulVersion       = SECBUFFER_VERSION;
			Message.cBuffers        = sizeof(Buffers)/sizeof(SecBuffer);
			Message.pBuffers        = Buffers;

			m_ss = ::DecryptMessage(&m_CtxHandle, &Message, 0, nullptr);
			switch(m_ss)
			{
			case SEC_E_OK:
				m_qIn.SetSize(0);
				for (i=0; i<sizeof(Buffers)/sizeof(SecBuffer); ++i)
				{
					if (!pDataBuffer && Buffers[i].BufferType == SECBUFFER_DATA)
					{
						pDataBuffer = Buffers + i;
					}
					else if (!pExtraBuffer && Buffers[i].BufferType == SECBUFFER_EXTRA)
					{
						pExtraBuffer = Buffers + i;
					}
				}
				if (pDataBuffer)
				{
					read.Push((const unsigned char*)pDataBuffer->pvBuffer, (unsigned int)pDataBuffer->cbBuffer);
				}
				if (pExtraBuffer)
				{
					m_qIn.Push((const unsigned char*)pExtraBuffer->pvBuffer, (unsigned int)pExtraBuffer->cbBuffer);
				}
				if (m_qIn.GetSize() > (unsigned int)m_StreamSizes.cbHeader)
				{
					keep = true;
					buffer = nullptr;
					dwSize = 0;
				}
				break;
			case SEC_E_INCOMPLETE_MESSAGE:
				if (backup)
				{
					m_qIn.Push(buffer, dwSize);
				}
				break;
			default:
				return false;
			}
		} while(keep);
		return true;
	}

	bool CSspi::DoHandshake(const unsigned char *buffer, DWORD dwSize, CBuffer &token)
	{
		//assert(!IsInitialized());
		SecBufferDesc   InBuffer;
		SecBuffer       InBuffers[2];
		SecBufferDesc   OutBuffer;
		SecBuffer       OutBuffers[1];
		DWORD           dwSSPIOutFlags = 0;
		SECURITY_STATUS ss = SEC_E_OK;

		DWORD dwSSPIFlags;
		if (m_client) {
			dwSSPIFlags = 
				ISC_REQ_SEQUENCE_DETECT |
				ISC_REQ_MANUAL_CRED_VALIDATION |
				ISC_REQ_EXTENDED_ERROR |
				ISC_REQ_ALLOCATE_MEMORY |
				ISC_REQ_REPLAY_DETECT |
				ISC_REQ_CONFIDENTIALITY |
				ISC_REQ_STREAM;
			if (m_bClientReset) {
				dwSSPIFlags |= ISC_REQ_USE_SUPPLIED_CREDS;
			}
		}
		else {
			dwSSPIFlags = 
				ASC_REQ_SEQUENCE_DETECT |
				ASC_REQ_REPLAY_DETECT |
				ASC_REQ_CONFIDENTIALITY |
				ASC_REQ_EXTENDED_ERROR |
				ASC_REQ_ALLOCATE_MEMORY |
				ASC_REQ_STREAM;
			if (m_clientCertAuth) {
				dwSSPIFlags |= ASC_REQ_MUTUAL_AUTH;
			}
		}

		// Set up the input buffers. Buffer 0 is used to pass in data
		// received from the server. Schannel will consume some or all
		// of this. Leftover data (if any) will be placed in buffer 1 and
		// given a buffer type of SECBUFFER_EXTRA.
		InBuffers[0].pvBuffer   = (void*)buffer;
		InBuffers[0].cbBuffer   = dwSize;
		InBuffers[0].BufferType = SECBUFFER_TOKEN;

		InBuffers[1].pvBuffer   = nullptr;
		InBuffers[1].cbBuffer   = 0;
		InBuffers[1].BufferType = SECBUFFER_EMPTY;

		InBuffer.cBuffers       = 2;
		InBuffer.pBuffers       = InBuffers;
		InBuffer.ulVersion      = SECBUFFER_VERSION;

		// Set up the output buffers. These are initialized to NULL
		// so as to make it less likely we'll attempt to free random
		// garbage later.
		OutBuffers[0].pvBuffer  = nullptr;
		OutBuffers[0].BufferType= SECBUFFER_TOKEN;
		OutBuffers[0].cbBuffer  = 0;

		OutBuffer.cBuffers      = 1;
		OutBuffer.pBuffers      = OutBuffers;
		OutBuffer.ulVersion     = SECBUFFER_VERSION;

		bool bInit = (m_CtxHandle.dwLower == 0 && m_CtxHandle.dwUpper == 0);
		if (m_client) {
			m_ss = ::InitializeSecurityContext(m_pCredHandle,
				(bInit ? nullptr : &m_CtxHandle),
				nullptr,
				dwSSPIFlags,
				0,
				0,
				&InBuffer,
				0,
				(bInit ? &m_CtxHandle : nullptr),
				&OutBuffer,
				&dwSSPIOutFlags,
				&m_tsExpiry);
		}
		else {
			m_ss = ::AcceptSecurityContext(m_pCredHandle,
				(bInit ? nullptr : &m_CtxHandle),
				&InBuffer,
				dwSSPIFlags,
				SECURITY_NATIVE_DREP,
				(bInit ? &m_CtxHandle : nullptr),
				&OutBuffer,
				&dwSSPIOutFlags,
				&m_tsExpiry);
		}

		if (!bInit && !m_pCertContext && SUCCEEDED(m_ss)) {
			ss = ::QueryContextAttributes(&m_CtxHandle, SECPKG_ATTR_REMOTE_CERT_CONTEXT, &m_pCertContext);
		}
		switch (m_ss) {
		case SEC_E_OK:
			ss = ::QueryContextAttributes(&m_CtxHandle, SECPKG_ATTR_STREAM_SIZES, &m_StreamSizes);
			if (OutBuffers[0].cbBuffer && OutBuffers[0].pvBuffer) {
				token.Push((const unsigned char*)(OutBuffers[0].pvBuffer), (unsigned int)(OutBuffers[0].cbBuffer));
				ss = ::FreeContextBuffer(OutBuffers[0].pvBuffer);
			}
			m_hs = hsDone;
			break;
		case SEC_I_COMPLETE_AND_CONTINUE:
		case SEC_I_COMPLETE_NEEDED:
			m_hs = hsShaking;
			m_ss = ::CompleteAuthToken(&m_CtxHandle, &OutBuffer);
			if (OutBuffers[0].cbBuffer && OutBuffers[0].pvBuffer) {
				token.Push((const unsigned char*)(OutBuffers[0].pvBuffer), (unsigned int)(OutBuffers[0].cbBuffer));
				ss = ::FreeContextBuffer(OutBuffers[0].pvBuffer);
			}
			if (!SUCCEEDED(m_ss)) {
				return false;
			}
			break;
		case SEC_I_CONTINUE_NEEDED:
			if (OutBuffers[0].cbBuffer && OutBuffers[0].pvBuffer) {
				token.Push((const unsigned char*)(OutBuffers[0].pvBuffer), (unsigned int)(OutBuffers[0].cbBuffer));
				ss = ::FreeContextBuffer(OutBuffers[0].pvBuffer);
			}
			m_hs = hsShaking;
			break;
		case SEC_E_INCOMPLETE_MESSAGE:
			m_hs = hsShaking;
			break;
		case SEC_I_INCOMPLETE_CREDENTIALS:
			m_hs = hsShaking;
			break;
		default:
			DeleteContext();
			return false;
		}
		return true;
	}

}