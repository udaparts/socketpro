/////////////////////////////////////////////////////////////////////////
//
// This file contains the build version numbers to be compiled into the
// RC files of each personality.
//
/////////////////////////////////////////////////////////////////////////
#ifndef _MDT_BUILD_IDS_H
#define _MDT_BUILD_IDS_H

// Currently used only by NSIS Server/Client installers
#define COMPANY_BG_COLOR "FFFFFF"

////////////////////////////////////////////////////////////
// In C++ the following strings are ASCII (not unicode requiring Transformations
#define COPYRIGHT "Copyright � 2000-2020 MDT, Inc.  An unpublished work.  All rights reserved worldwide.\0"
#define COMPANY_NAME "MDT, Inc.\0"
#define COMPANY_DISPLAY_NAME "MDT Software"
#define COMPANY_TELEPHONE "+1 (678) 297-1000"

#define PRODUCT_NAME "MDT AutoSave"
#define PRODUCT_SHORT_NAME "AutoSave"
#define PRODUCT_WEB_SITE_URL "http://www.MDT-Software.com"
#define PRODUCT_WEB_SITE_NAME "www.MDT-Software.com"
//////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////
// In C++ the following are interpretted as WIDE character strings
// C++ server code should migrate to these values, but we cannot remove the ASCII ones until we drop the network client
// and all apps have switched
#define COPYRIGHT_WIDE L"Copyright � 2000-2020 MDT, Inc.  An unpublished work.  All rights reserved worldwide.\0"
#define COMPANY_NAME_WIDE L"MDT, Inc.\0"
#define COMPANY_DISPLAY_NAME_WIDE L"MDT Software"
#define COMPANY_TELEPHONE_WIDE L"+1 (678) 297-1000"
#define PRODUCT_NAME_WIDE L"MDT AutoSave"
#define PRODUCT_SHORT_NAME_WIDE L"AutoSave"
#define PRODUCT_WEB_SITE_URL_WIDE L"http://www.MDT-Software.com"
#define PRODUCT_WEB_SITE_NAME_WIDE L"www.MDT-Software.com"

#define FILEVERSION_FOR_BUILD 8,00,16,00
#define PRODUCTVERSION_FOR_BUILD 8,00,16,00
#define FILEVERSION_STR_FOR_BUILD "8.00.16.00\0"
#define PRODUCTVERSION_STR_FOR_BUILD "8.00.16.00\0"
#define VERSIONSTRING "8.00.16.00"

#define FILEVERSION_STR_FOR_BUILD_WIDE L"8.00.16.00\0"
#define PRODUCTVERSION_STR_FOR_BUILD_WIDE L"8.00.16.00\0"
#define VERSIONSTRING_WIDE L"8.00.16.00"

#define PRODUCT_BUILD_DATE		 	 "20201120"
#define PRODUCT_BUILD_DATE_WIDE		L"20201120"

#define XSL_XML_REPORT_VERSION		_T("_1812")
#endif

