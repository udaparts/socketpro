
#ifndef ___ERROR_COMM_CODE_I_H__
#define ___ERROR_COMM_CODE_I_H__

#include <string>
#include "../../include/sccomm.h"
#include <algorithm> 
#include <functional> 
#include <cctype>

namespace SC {

	class CSCError {
	public:
		CSCError(DWORD errCode, const char *errMsg) : m_errCode(errCode), m_errMsg(errMsg ? errMsg : "") {
		}
		CSCError(DWORD errCode, const std::string &errMsg) : m_errCode(errCode), m_errMsg(errMsg) {
		}
		CSCError() : m_errCode(::GetLastError()) {
			m_errMsg = GetWinSystemErrorMessageA<std::string>(m_errCode);
			std::string &s = m_errMsg;
			s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
		}

	public:
		DWORD value() const {
			return m_errCode;
		}

		const char *message() const {
			return m_errMsg.c_str();
		}

		void assign(DWORD errCode, const char *errMsg) {
			m_errCode = errCode;
			m_errMsg = errMsg ? errMsg : "";
		}

		void assign(DWORD errCode, const std::string &errMsg) {
			m_errCode = errCode;
			m_errMsg = errMsg;
		}

		void assign(DWORD errCode) {
			m_errCode = errCode;
			m_errMsg = GetWinSystemErrorMessageA<std::string>(m_errCode);
			std::string &s = m_errMsg;
			s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
		}

		operator bool() const {
			return (ERROR_SUCCESS != m_errCode);
		}

	private:
		DWORD m_errCode;
		std::string m_errMsg;
	};
	
	typedef CSCError CErrCode;
}

#endif