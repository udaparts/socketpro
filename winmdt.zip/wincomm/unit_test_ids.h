
#include "../include/sccomm.h"

#ifndef _UNIT_TESTS_REQUEST_DEFINES_H_
#define _UNIT_TESTS_REQUEST_DEFINES_H_

namespace SC
{
	static const SC_COMMUNICATION_SERVICE HELLO_WORLD_ID = 5;

	static const unsigned short idSayHello = idStartRequestId + 1;
	static const unsigned short idSleep = idSayHello + 1;
	static const unsigned short idDoException = idSleep + 1;
	static const unsigned short idSleepProgress = idDoException + 1;
};

#endif

