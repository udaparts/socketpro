
#include "stdafx.h"
#include "../commshared/scsslsocketbase.h"

namespace SC 
{
	CWinSocketStartup CWinSocketStartup::m_startup;
}
