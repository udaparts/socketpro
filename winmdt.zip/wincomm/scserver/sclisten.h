

#ifndef ___SECURE_COMM_LISTENING_SERVER_AUTOSAVE_H__
#define ___SECURE_COMM_LISTENING_SERVER_AUTOSAVE_H__

#include "sslsession.h"
#include <mswsock.h>

namespace SC {
	namespace ServerSide {

		class CListenServer
		{
		private:
			CListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog);

		public:
			~CListenServer();

		public:
			bool Run();
			void Shutdown();
			bool IsRunning() const;
			std::string GetErrorMessage() const;
			int GetErrCode() const;
			static CListenServer* CreateListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog);
			bool OpenPfx(const wchar_t *filePfx, const wchar_t *password, bool clientCertAuth);
			bool IsSecure() const;
			PCredHandle GetCredHandle();
			unsigned int GetSessionCount();
			unsigned int GetThreadCount();
			void SetCertStoreType(tagCertStoreType cst);
			const ICertificate* const GetSelfCert() const;

		private:
			//disable copy constructor and assignment operator
			CListenServer(const CListenServer &ls);
			CListenServer& operator=(const CListenServer &ls);

			void start_accept();
			void Host();
			void Recycle(CSslSession *session);
			bool CreateListeningSocket();
			void CleanListeningSocket();
			void StartIOPump();
			void SetSession();
			void CloseAcitiveSockets();
			void CleanDeadSockets();
			CSslSession* SeekByOverLapped(LPOVERLAPPED pOverlap);
			void FreeCredHandle();

		private:
			CSharedThreadPtr m_pMainThread;
			CErrCode m_ec;

			std::vector<CSslSession*> m_vTrashedSession;
			std::vector<CSslSession*> m_vAliveSession; //protected by m_csAliveSession
			DWORD m_id; //main thread id

			POnAccepted m_OnAccepted;

			bool m_v6;
			unsigned short m_port;
			unsigned int m_maxBacklog;

			LPFN_ACCEPTEX AcceptEx;
			LPFN_GETACCEPTEXSOCKADDRS GetAcceptExSockaddrs;

			SOCKET m_hSocket;
			HANDLE m_hRootIoPort;
			CSslSession *m_session;
			DWORD m_dwSockAddrSize;
			ULONG_PTR m_key;
			DWORD m_dwBytes;
			OVERLAPPED m_ol;
			bool m_reading;
			CredHandle m_hCreds;
			static CMutex m_cs;

			CMutex m_csAliveSession;
			CSender m_self;

			std::shared_ptr<CCertificateImpl> m_pSelfCert;
			bool m_clientCertAuth;
			tagCertStoreType m_cst;
			friend class CSslSession;
			friend unsigned int WINAPI ::SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName, const wchar_t* machineName);
			friend unsigned int WINAPI ::PublishMessage(const VARIANT &vtMsg, const unsigned int *topics, unsigned int count);
		};

		extern CListenServer *g_pListenServer;

	} //ScServer
} //SC

#endif