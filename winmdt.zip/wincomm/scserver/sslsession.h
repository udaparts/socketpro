#ifndef __SECURE_COMM_SSL_TLS_SESSION_H_
#define __SECURE_COMM_SSL_TLS_SESSION_H_

#include "../../include/sccommserver.h"
#include "../commshared/scsslsocketbase.h"
#include "../commshared/certificateimpl.h"

namespace SC {
	namespace ServerSide {

		typedef std::vector<unsigned int> CTopicArray;

		extern CTopicArray g_vTopic;
		class CListenServer;

		class CSslSession : public IServerSession
		{
		private:
			CSslSession();
			virtual ~CSslSession();

		public:
			const static unsigned int MAX_LEN_PER_IO_TRANS = 1024 * 4;
			const static unsigned int DEFAULT_READ_BUFFER_SIZE = 320 * 1024;
			const static unsigned int DEFAULT_READ_BUFFER_BLOCK_SIZE = 128 * 1024;
			const static unsigned int DEFAULT_WRITE_BUFFER_SIZE = 320 * 1024;
			const static unsigned int DEFAULT_WRITE_BUFFER_BLOCK_SIZE = 128 * 1024;

			//implementations for IServerSession methods
			virtual tagSessionState GetSessionState();
			virtual HRESULT GetErrCode();
			virtual bool IsDiffEndian();
			virtual void PostClose(DWORD errCode);
			virtual unsigned int GetSendingBufferSize();
			virtual unsigned int GetErrMsg(char *recv, unsigned int size);
			virtual unsigned int GetErrMsg(wchar_t *recv, unsigned int chars);
			virtual unsigned int Retrieve(unsigned char *receiver, unsigned int size);
			virtual unsigned int GetPeerName(char *name, unsigned int size);
			virtual unsigned int GetSockName(char *name, unsigned int size);
			virtual const ICertificate* const GetCertificate() const;
			virtual unsigned int Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size);
			virtual unsigned int SendException(unsigned short CurrentRequestId, int errCode, const char *errMsg, const char *stack);
			virtual bool StartThreadProcessing();
			virtual bool EndThreadProcessing();
			
			//7.02
			virtual void SetClientAppName(const wchar_t *clientAppName);
			virtual const wchar_t* GetClientAppName();
			virtual void SetUserId(const wchar_t *userId);
			virtual const wchar_t* GetUserId();
			virtual void SetClientMachineName(const wchar_t *clientMachineName);
			virtual const wchar_t* GetClientMachineName();
			virtual unsigned int SubScribe(const unsigned int *topcs, unsigned int count);
			virtual unsigned int SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName, const wchar_t* machineName);
			virtual unsigned int PublishMessage(const VARIANT &vtMsg, const unsigned int *topcs, unsigned int count);
			virtual unsigned __int64 GetServerPointer() const;

		private:
			void Start();
			bool Read();
			void Write();
			void OnCloseInternal();
			bool ProcessInternal();
			void Initialize();
			void OnLessInternal();
			void OnSlowRequestProcessed();
			void handle_read(DWORD bytes_transferred);
			void handle_write(DWORD bytes_transferred);
			bool DoHandshake(DWORD dwSize);
			bool DoDecryption(const unsigned char* buffer, DWORD dwSize);
			void ReadEx();
			bool IsThreadingProcessing();
			unsigned int SendInternal(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool messaging);

		private:
			//no copy constructor and assignment operator
			CSslSession(const CSslSession &session);
			CSslSession& operator=(const CSslSession &session);

		private:
			CMutex m_cs;
			bool m_bEndianDiff;
			std::atomic<tagSessionState> m_ss;
			CErrCode m_ec; //protected by m_cs

			//reading
			bool m_bReading;
			unsigned char *m_ReadBuffer;
			CBuffer m_qRead;

			//writing
			bool m_bWriting; //protected by m_cs
			unsigned char *m_WriteBuffer; //protected by m_cs
			CBuffer m_qWrite; //protected by m_cs

			CRequestHeader m_rh;
			ISessionCallback *m_sc;
			bool m_bThreadingProcessing; //protected by m_cs
			CConditionVariable m_cv;
			SOCKET m_hSocket;
			unsigned char m_buffAccept[128];

			//reading
			WSAOVERLAPPED m_olRead;
			WSABUF m_wsaRecv;
			DWORD m_dwBytesRecvd;
			DWORD m_dwFlagsRecvd;

			//writing
			WSABUF m_wsaSend;
			WSAOVERLAPPED m_olSent;
			DWORD m_dwBytesSent;
			CSspiPtr m_pSspi;
			bool m_bWaiting;
			CCertificateImplPtr m_pCert; //protected by m_cs

			CSSLHello m_ch;

			CSender m_client; //protected by m_cs
			std::vector<unsigned int> m_vTopic; //protected by m_cs
			friend class CListenServer;
			friend unsigned int WINAPI::SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName, const wchar_t* machineName);
			friend unsigned int WINAPI::PublishMessage(const VARIANT &vtMsg, const unsigned int *topics, unsigned int count);
		};

	} //ServerSide
} //SC

#endif;