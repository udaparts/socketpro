
#include "stdafx.h"
#include "sclisten.h"
#include <algorithm>
#include <objbase.h>

extern PThreadExceptionHandlers g_teh;

namespace SC {
	namespace ServerSide {
		CListenServer *g_pListenServer = nullptr;
		
		extern CMutex g_mutex;
		POnIdle g_onidle = nullptr;
		
		CMutex CListenServer::m_cs;

		CListenServer::CListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog)
			: m_ec(0, ""),	//remove the bug "Cannot create a file when that file already exists. Failed to start listening server.
							//Are the certificates installed and properly privileged? 
			m_id(0), 
			m_OnAccepted(OnAccepted),
			m_v6(v6),
			m_port(port),
			m_maxBacklog(maxBacklog),
			AcceptEx(nullptr),
			GetAcceptExSockaddrs(nullptr),
			m_hSocket(INVALID_SOCKET),
			m_hRootIoPort(nullptr),
			m_session(nullptr),
			m_key(0),
			m_dwBytes(0),
			m_reading(false),
			m_clientCertAuth(false),
			m_cst(cstUnknown)
		{
			assert(!g_pListenServer);
			g_pListenServer = this;
			m_dwSockAddrSize = (m_v6 ? sizeof(sockaddr_in6) : sizeof(sockaddr_in)) + 16;
			::memset(&m_hCreds, 0, sizeof(m_hCreds));

			m_self.AppName = ToWide(GetAppName().c_str());

			char str[256] = { 0 };
			::gethostname(str, sizeof(str));
			m_self.MachineName = ToWide(str);

			m_self.UserId = m_self.AppName;
			std::transform(m_self.UserId.begin(), m_self.UserId.end(), m_self.UserId.begin(), ::tolower);

			m_self.ServerPointer = 0;
		}

		CListenServer::~CListenServer()
		{
			CAutoLock al(m_cs);
			if (IsRunning())
			{
				Shutdown();
			}
			CleanDeadSockets();
			g_pListenServer = nullptr;
			CleanListeningSocket();
			FreeCredHandle();
		}

		CListenServer* CListenServer::CreateListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog)
		{
			CAutoLock al(m_cs);
			if (g_pListenServer)
			{
				return g_pListenServer;
			}
			g_pListenServer = new CListenServer(OnAccepted, port, v6, maxBacklog);
			return g_pListenServer;
		}

		void CListenServer::Recycle(CSslSession *session)
		{
			if (!session) {
				return;
			}
			m_csAliveSession.lock();
			auto it = std::find(m_vAliveSession.begin(), m_vAliveSession.end(), session);
			if (it != m_vAliveSession.end())
			{
				m_vAliveSession.erase(it);
			}
			m_csAliveSession.unlock();
			if (std::find(m_vTrashedSession.begin(), m_vTrashedSession.end(), session) == m_vTrashedSession.end()) {
				m_vTrashedSession.push_back(session);
			}
		}

		void CListenServer::Host()
		{
			if (g_teh) {
				g_teh();
			}
			BOOL ok = ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
			m_id = ::GetCurrentThreadId();
			HRESULT hr = ::CoInitializeEx(nullptr, 0);
			StartIOPump();
			::CoUninitialize();
		}

		bool CListenServer::CreateListeningSocket()
		{
			DWORD dwBytes;
			int res = 0;
			GUID guidAcceptEx = WSAID_ACCEPTEX;
			GUID guidGetAcceptExSockaddrs = WSAID_GETACCEPTEXSOCKADDRS;
			do
			{
				m_hSocket = ::WSASocket(m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_OVERLAPPED);
				if (m_hSocket == INVALID_SOCKET)
				{
					res = SOCKET_ERROR;
					break;
				}
				BOOL val = TRUE;
				res = ::setsockopt(m_hSocket, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, (char*)&val, sizeof(val));
				if (res == SOCKET_ERROR)
				{
					break;
				}
				if (m_v6)
				{
					DWORD ipv6only = 0;
					res = ::setsockopt(m_hSocket, IPPROTO_IPV6, IPV6_V6ONLY, (char*)&ipv6only, sizeof(ipv6only));
				}
				if (m_v6)
				{
					sockaddr_in6 service;
					::memset(&service,0,sizeof(service));
					service.sin6_family = AF_INET6;
					service.sin6_port = ::htons(m_port);
					res = ::bind(m_hSocket, (SOCKADDR*)&service, sizeof(service));
				}
				else
				{
					sockaddr_in service;
					::memset(&service,0,sizeof(service));
					service.sin_family = AF_INET;
					service.sin_addr.s_addr = ::htonl(INADDR_ANY);
					service.sin_port = ::htons(m_port);
					res = ::bind(m_hSocket, (SOCKADDR*)&service, sizeof(service));
				}
				if (res == SOCKET_ERROR)
				{
					m_ec.assign(::WSAGetLastError(), "Cannot bind listening socket to port " + std::to_string(m_port));
					break;
				}
				res = ::listen(m_hSocket, m_maxBacklog);
				if (res == SOCKET_ERROR)
				{
					break;
				}

				ULONG_PTR CompletionKey = (ULONG_PTR)this;
				m_hRootIoPort = ::CreateIoCompletionPort((HANDLE)m_hSocket, nullptr, CompletionKey, 1); 
				if (!m_hRootIoPort)
				{
					res = SOCKET_ERROR;
					break;
				}
				res = ::WSAIoctl(m_hSocket,
					SIO_GET_EXTENSION_FUNCTION_POINTER,
					&guidAcceptEx,
					sizeof(guidAcceptEx),
					&AcceptEx,
					sizeof(AcceptEx),
					&dwBytes,
					nullptr,
					nullptr);
				if (res == SOCKET_ERROR)
				{
					break;
				}

				res = ::WSAIoctl(m_hSocket,
					SIO_GET_EXTENSION_FUNCTION_POINTER,
					&guidGetAcceptExSockaddrs,
					sizeof(guidGetAcceptExSockaddrs),
					&GetAcceptExSockaddrs,
					sizeof(guidGetAcceptExSockaddrs),
					&dwBytes,
					nullptr,
					nullptr);

			} while(false);

			if (res == SOCKET_ERROR)
			{
				if (!m_ec.value()) {
					m_ec.assign(::WSAGetLastError());
				}
				CleanListeningSocket();
				return false;
			}
			return true;
		}

		void CListenServer::CleanListeningSocket()
		{
			if (m_hSocket != INVALID_SOCKET)
			{
				::closesocket(m_hSocket);
				m_hSocket = INVALID_SOCKET;
			}
			if (m_hRootIoPort)
			{
				::CloseHandle(m_hRootIoPort);
				m_hRootIoPort = nullptr;
			}
		}

		bool CListenServer::Run() {
			if (!CreateListeningSocket()) {
				return false;
			}
			start_accept();
			m_pMainThread.reset(new std::thread(std::bind(&CListenServer::Host, this)));
			return (!m_ec);
		}

		void CListenServer::Shutdown()
		{
			if (m_pMainThread)
			{
				CloseAcitiveSockets();
				::PostQueuedCompletionStatus(m_hRootIoPort, CK_SHUT_DOWN_IO_PORT, (ULONG_PTR)this, nullptr);
				m_pMainThread->join();
				assert(m_vAliveSession.size() == 0);
				m_pMainThread.reset();
			}
		}

		bool CListenServer::IsRunning() const
		{
			return (!!m_pMainThread);
		}

		std::string CListenServer::GetErrorMessage() const {
			if (!m_ec)
			{
				return "";
			}
			return m_ec.message();
		}

		int CListenServer::GetErrCode() const
		{
			return m_ec.value();
		}

		void CListenServer::SetCertStoreType(tagCertStoreType cst) {
			m_cst = cst;
		}

		unsigned int CListenServer::GetSessionCount() {
			m_csAliveSession.lock();
			auto size = m_vAliveSession.size();
			m_csAliveSession.unlock();
			return (unsigned int)size;
		}

		const ICertificate* const CListenServer::GetSelfCert() const {
			if (!m_pSelfCert) {
				return nullptr;
			}
			return m_pSelfCert.get();
		}

		unsigned int CListenServer::GetThreadCount() {
			int count = 0;
			m_csAliveSession.lock();
			for(auto it = m_vAliveSession.begin(), end = m_vAliveSession.end(); it != end; ++it) {
				if ((*it)->IsThreadingProcessing()) {
					++count;
				}
			}
			m_csAliveSession.unlock();
			return count;
		}

		void CListenServer::CloseAcitiveSockets()
		{
			m_csAliveSession.lock();
			for (auto it = m_vAliveSession.begin(), end = m_vAliveSession.end(); it != end; ++it)
			{
				(*it)->PostClose(0);
			}
			m_csAliveSession.unlock();
		}

		CSslSession* CListenServer::SeekByOverLapped(LPOVERLAPPED pOverlap)
		{
			CSslSession *session = nullptr;
			SC::ServerSide::CAutoLock al(m_csAliveSession);
			m_reading = false;
			for (auto it = m_vAliveSession.begin(), end = m_vAliveSession.end(); it != end; ++it)
			{
				if (pOverlap == &(*it)->m_olRead)
				{
					m_reading = true;
					session = *it;
					break;
				}
				else if (pOverlap == &(*it)->m_olSent)
				{
					session = *it;
					break;
				}
			}
			return session;
		}

		void CListenServer::CleanDeadSockets()
		{
			//clean all trashed sessions
			for(auto it = m_vTrashedSession.begin(), end = m_vTrashedSession.end(); it != end; ++it)
			{
				delete *it;
			}
			m_vTrashedSession.clear();
		}

		void CListenServer::StartIOPump()
		{
			bool killLoop = false;
			LPOVERLAPPED pOverlap = nullptr;
			do
			{
				::memset(&m_ol, 0, sizeof(m_ol));
				BOOL ok = ::GetQueuedCompletionStatus(m_hRootIoPort, &m_dwBytes, &m_key, &pOverlap, 1000);
				if (ok)
				{
					switch(m_dwBytes)
					{
					case CK_SHUT_DOWN_IO_PORT:
						killLoop = true;
						m_vTrashedSession.push_back(m_session);
						m_session = nullptr;
						CleanDeadSockets();
						{
							CAutoLock al(m_csAliveSession);
							while (m_vAliveSession.rbegin() != m_vAliveSession.rend()) {
								auto back = m_vAliveSession.rbegin();
								delete *back;
								m_vAliveSession.pop_back();
							}
						}
						break;
					case CK_SHUT_DOWN_SOCKET:
						{
							CSslSession *pSession = dynamic_cast<CSslSession*>((IServerSession*)m_key);
							if (pSession) {
								try {
									pSession->OnCloseInternal();
								}
								catch (std::exception &err) {
									CStringW outputMessage;
									outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"CK_SHUT_DOWN_SOCKET", SC::ToWide(err.what()).c_str());
									OutputDebugStringW(outputMessage);
								}
								catch (...) {
									CStringW outputMessage;
									outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"CK_SHUT_DOWN_SOCKET", L"Unknown exception");
									OutputDebugStringW(outputMessage);
								}
							}
						}
						break;
					case CK_SLOW_REQUEST_PROCESSED:
						{
							CSslSession *pSession = dynamic_cast<CSslSession*>((IServerSession*)m_key);
							if (pSession) {
								try {
									pSession->OnSlowRequestProcessed();
								}
								catch (std::exception &err) {
									CStringW outputMessage;
									outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"CK_SLOW_REQUEST_PROCESSED", SC::ToWide(err.what()).c_str());
									OutputDebugStringW(outputMessage);
								}
								catch (...) {
									CStringW outputMessage;
									outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"CK_SLOW_REQUEST_PROCESSED", L"Unknown exception");
									OutputDebugStringW(outputMessage);
								}
							}
						}
						break;
					case CH_LESS_INTERNAL:
						{
							CSslSession *pSession = dynamic_cast<CSslSession*>((IServerSession*)m_key);
							if (pSession) {
								try {
									pSession->OnLessInternal();
								}
								catch (std::exception &err) {
									CStringW outputMessage;
									outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"CH_LESS_INTERNAL", SC::ToWide(err.what()).c_str());
									OutputDebugStringW(outputMessage);
								}
								catch (...) {
									CStringW outputMessage;
									outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"CH_LESS_INTERNAL", L"Unknown exception");
									OutputDebugStringW(outputMessage);
								}
							}
						}
						break;
					default:
						if (m_key == (ULONG_PTR)this)
						{
							m_csAliveSession.lock();
							m_vAliveSession.push_back(m_session);
							m_csAliveSession.unlock();
							m_session->m_sc = m_OnAccepted(m_session);
							m_session->Start();
							start_accept();
						}
						else
						{
							CSslSession *session = SeekByOverLapped(pOverlap);
							if (session)
							{
								if (m_reading)
								{
									try {
										session->handle_read(m_dwBytes);
									}
									catch (std::exception &err) {
										CStringW outputMessage;
										outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"handle_read", SC::ToWide(err.what()).c_str());
										OutputDebugStringW(outputMessage);
									}
									catch (...) {
										CStringW outputMessage;
										outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"handle_read", L"Unknown exception");
										OutputDebugStringW(outputMessage);
									}
								}
								else
								{
									try {
										session->handle_write(m_dwBytes);
									}
									catch (std::exception &err) {
										CStringW outputMessage;
										outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"handle_write", SC::ToWide(err.what()).c_str());
										OutputDebugStringW(outputMessage);
									}
									catch (...) {
										CStringW outputMessage;
										outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"handle_write", L"Unknown exception");
										OutputDebugStringW(outputMessage);
									}
								}
							}
							else
							{
								CStringW outputMessage;
								outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"session == nullptr!", L"Unhandled error");
								OutputDebugStringW(outputMessage);
							}
						}
						break;
					}
				}
				else
				{
					DWORD res = ::GetLastError();
					switch (res)
					{
					case WAIT_TIMEOUT:
					{
						CAutoLock lg(g_mutex);
						if (g_onidle) {
							try {
								g_onidle();
							}
							catch (std::exception &err) {
								CStringW outputMessage;
								outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"WAIT_TIMEOUT", SC::ToWide(err.what()).c_str());
								OutputDebugStringW(outputMessage);
							}
							catch (...) {
								CStringW outputMessage;
								outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"WAIT_TIMEOUT", L"Unknown exception");
								OutputDebugStringW(outputMessage);
							}
						}
					}
					break;
					case ERROR_CONNECTION_ABORTED:
					case ERROR_NETNAME_DELETED:
					{
						CSslSession *session = SeekByOverLapped(pOverlap);
						if (session)
						{
							session->m_ec.assign(res);
							try {
								session->OnCloseInternal();
							}
							catch (std::exception &err) {
								CStringW outputMessage;
								outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, (ERROR_NETNAME_DELETED == res) ? L"ERROR_NETNAME_DELETED" : L"ERROR_CONNECTION_ABORTED", SC::ToWide(err.what()).c_str());
								OutputDebugStringW(outputMessage);
							}
							catch (...) {
								CStringW outputMessage;
								outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, (ERROR_NETNAME_DELETED == res) ? L"ERROR_NETNAME_DELETED" : L"ERROR_CONNECTION_ABORTED", L"Unknown exception");
								OutputDebugStringW(outputMessage);
							}
						}
					}
					break;
					default:
					{
						CStringW outputMessage;
						outputMessage.Format(L"File: %ls, func name: %ls, line number: %d, message: %ls->%ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, SC::GetWinSystemErrorMessageW<std::wstring>(res).c_str(), L"Unhandled error");
						OutputDebugStringW(outputMessage);
					}
					break;
					}
				}
			} while(!killLoop);
			if (m_pSelfCert && m_pSelfCert->GetCertContext()) {
				::CertFreeCertificateContext(m_pSelfCert->GetCertContext());
			}
			m_pSelfCert.reset();
		}

		void CListenServer::SetSession()
		{
			if (m_vTrashedSession.size())
			{
				m_session = m_vTrashedSession.back();
				m_vTrashedSession.pop_back();
			}
			else
			{
				m_session = new CSslSession();
			}
		}

		void CListenServer::start_accept()
		{
			BOOL ok;
			DWORD dwBytes;
			int res = 0;
			do
			{
				dwBytes = 0;
				::memset(&m_ol, 0, sizeof(m_ol));
				SetSession();
				::memset(m_session->m_buffAccept, 0, sizeof(m_session->m_buffAccept));
				ok = AcceptEx(m_hSocket,
					m_session->m_hSocket,
					m_session->m_buffAccept,
					0,
					m_dwSockAddrSize,
					m_dwSockAddrSize,
					&dwBytes,
					&m_ol);
				if (ok)
				{
					m_csAliveSession.lock();
					m_vAliveSession.push_back(m_session);
					m_csAliveSession.unlock();
					m_session->m_sc = m_OnAccepted(m_session);
					assert(dwBytes == 0);
					m_session->Start();
				}
			} while (ok);
			assert(dwBytes == 0);
			res = ::WSAGetLastError();
			assert(!ok && res == WSA_IO_PENDING);
		}

		void CListenServer::FreeCredHandle()
		{
			if (m_hCreds.dwLower || m_hCreds.dwUpper)
			{
				::FreeCredentialsHandle(&m_hCreds);
				::memset(&m_hCreds, 0, sizeof(m_hCreds));
			}
		}

		bool CListenServer::IsSecure() const 
		{
			return (m_hCreds.dwLower || m_hCreds.dwUpper);
		}

		PCredHandle CListenServer::GetCredHandle()
		{
			return &m_hCreds;
		}

		bool CListenServer::OpenPfx(const wchar_t *filePfx, const wchar_t *password, bool clientCertAuth)
		{
			bool ok = true;

			//if filePfx not set, we don't use secure channel
			if (!filePfx || !std::wcslen(filePfx)) {
				return true;
			}

			m_clientCertAuth = clientCertAuth;

			CString s(filePfx);
			bool bPfx = (s.Right(4).CompareNoCase(_T(".pfx")) == 0);

			FreeCredHandle();
			do {
				PCCERT_CONTEXT context = nullptr;
				if (bPfx) {
					ok = CCertificateImpl::CertStore.OpenFromPfxFile(filePfx, password);
					if (!ok) {
						m_ec = CCertificateImpl::CertStore.GetErrCode();
						break;
					}
					context = ::CertFindCertificateInStore(CCertificateImpl::CertStore.GetCertStore(), X509_ASN_ENCODING|PKCS_7_ASN_ENCODING, 0, CERT_FIND_ANY, nullptr, nullptr);
					if (!context) {
						ok = false;
						m_ec.assign(::GetLastError(), "Cannot find a certifcate from store " + CCertificateImpl::CertStore.GetName());
						break;
					}
				}
				else {
					ok = CCertificateImpl::CertStore.OpenStore(m_cst);
					if (!ok) {
						m_ec = CCertificateImpl::CertStore.GetErrCode();
						break;
					}
					context = ::CertFindCertificateInStore(CCertificateImpl::CertStore.GetCertStore(), X509_ASN_ENCODING|PKCS_7_ASN_ENCODING, 0, CERT_FIND_SUBJECT_STR, W2CT(filePfx), nullptr);
					if (!context) {
						ok = false;
						m_ec.assign(::GetLastError(), "Cannot find a certifcate from store " + CCertificateImpl::CertStore.GetName() + " for " + SC::ToUTF8(filePfx));
						break;
					}
				}
				
				m_pSelfCert.reset(new CCertificateImpl(context, ""));
				PCCERT_CONTEXT pCertContext = m_pSelfCert->GetCertContext();
				m_cst = CCertificateImpl::CertStore.GetCertStoreType();
				SCHANNEL_CRED SchannelCred;
				::memset(&SchannelCred, 0, sizeof(SchannelCred));
				SchannelCred.dwVersion  = SCHANNEL_CRED_VERSION;
				SchannelCred.cCreds = 1;
				SchannelCred.paCred = &pCertContext;
				SchannelCred.grbitEnabledProtocols = SP_PROT_TLS1_X_SERVER;  //SP_PROT_SSL3TLS1_X_SERVERS; // (SP_PROT_SSL3_SERVER | SP_PROT_TLS1_0_SERVER | SP_PROT_TLS1_1_SERVER | SP_PROT_TLS1_2_SERVER);
				//SchannelCred.hRootStore = CCertificateImpl::CertStore.GetCertStore();
				SchannelCred.dwFlags = (SCH_CRED_NO_DEFAULT_CREDS | SCH_CRED_MANUAL_CRED_VALIDATION | SCH_CRED_REVOCATION_CHECK_CHAIN | SCH_SEND_ROOT_CERT);
				SECURITY_STATUS status = ::AcquireCredentialsHandle(nullptr,
					UNISP_NAME,
					SECPKG_CRED_INBOUND,
					nullptr,
					&SchannelCred,
					nullptr,
					nullptr,
					&m_hCreds,
					nullptr);
				if (status != SEC_E_OK) {
					::memset(&m_hCreds, 0, sizeof(m_hCreds));
					ok = false;
					switch(status) {
					case SEC_E_NO_CREDENTIALS:
						//m_ec.assign(status, "No credentials are available in the security package");
						m_ec.assign(status, "No private key is associated with " + SC::ToUTF8(filePfx));
						break;
					case SEC_E_INSUFFICIENT_MEMORY:
						m_ec.assign(status, "There is insufficient memory available to complete the requested action");
						break;
					case SEC_E_INTERNAL_ERROR:
						m_ec.assign(status, "An error occurred that did not map to an SSPI error code");
						break;
					case SEC_E_NOT_OWNER:
						m_ec.assign(status, "The caller of the function does not have the necessary credentials");
						break;
					case SEC_E_SECPKG_NOT_FOUND:
						m_ec.assign(status, "The requested security package does not exist");
						break;
					case SEC_E_UNKNOWN_CREDENTIALS:
						//m_ec.assign(status, "The credentials supplied to the package were not recognized");
						m_ec.assign(status, "Reading private key from store " + CCertificateImpl::CertStore.GetName() + " not permitted because of low privilege");
						break;
					case SEC_E_ALGORITHM_MISMATCH:
						//m_ec.assign(status, "The client and server cannot communicate, because they do not possess a common algorithm");
						m_ec.assign(status, "All supported SSL/TLSv1.x protocols are disabled at " + GetAppName() + " side");
						break;
					default:
						m_ec.assign(status);
						break;
					}
				}
			} while(false);
			return ok;
		}
	} //ScServer
} //SC
