#include "stdafx.h"
#include "sslsession.h"
#include "sclisten.h"
#include "../commshared/scsslsocketbase.h"
#include <algorithm> 
#include <functional>
#include <cctype>

namespace SC {
	namespace ServerSide {

		CSslSession::CSslSession()
			: m_bEndianDiff(false),
			m_ss(ssClosed),
			m_bReading(false),
			m_ReadBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
			m_qRead(DEFAULT_READ_BUFFER_SIZE, DEFAULT_READ_BUFFER_BLOCK_SIZE),
			m_bWriting(false),
			m_WriteBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
			m_sc(nullptr),
			m_qWrite(DEFAULT_WRITE_BUFFER_SIZE, DEFAULT_WRITE_BUFFER_BLOCK_SIZE),
			m_bThreadingProcessing(false),
			m_hSocket(INVALID_SOCKET),
			m_dwBytesRecvd(0),
			m_dwFlagsRecvd(0),
			m_dwBytesSent(0),
			m_bWaiting(false)
		{
			::memset(&m_olRead, 0, sizeof(m_olRead));
			::memset(&m_olSent, 0, sizeof(m_olSent));
			::memset(&m_wsaRecv, 0, sizeof(m_wsaRecv));
			::memset(&m_wsaSend, 0, sizeof(m_wsaSend));
			m_client.ServerPointer = 0;
			m_hSocket = ::WSASocket(g_pListenServer->m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_OVERLAPPED);
		}

		CSslSession::~CSslSession()
		{
			::free(m_ReadBuffer);
			::free(m_WriteBuffer);
			if (m_hSocket != INVALID_SOCKET)
			{
				::closesocket(m_hSocket);
			}
		}

		void CSslSession::OnCloseInternal()
		{
			{
				CAutoLock al(m_cs);
				if (m_ss <= ssClosing) {
					return;
				}
				if (m_bThreadingProcessing) {
					m_ss = ssClosing;
					::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SHUT_DOWN_SOCKET, (ULONG_PTR)this, nullptr);
					return;
				}
				m_ss = ssClosed;
				int res = ::closesocket(m_hSocket);
				m_hSocket = INVALID_SOCKET;
			}
			SubScribe(nullptr, 0);
			m_cv.notify_all();
			m_sc->OnAborted();
			m_pCert.reset();
			m_hSocket = ::WSASocket(g_pListenServer->m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_OVERLAPPED);
			g_pListenServer->Recycle(this);
		}

		void CSslSession::PostClose(DWORD errCode)
		{
			m_cs.lock();
			m_ec.assign(errCode);
			m_cs.unlock();
			::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SHUT_DOWN_SOCKET, (ULONG_PTR)this, nullptr);
		}

		const ICertificate* const CSslSession::GetCertificate() const {
			return m_pCert.get();
		}

		tagSessionState CSslSession::GetSessionState()
		{
			return m_ss;
		}

		bool CSslSession::IsDiffEndian()
		{
			return m_bEndianDiff;
		}

		bool CSslSession::ProcessInternal()
		{
			if (m_bThreadingProcessing)
			{
				return false;
			}
			if (m_qRead.GetSize() < sizeof(CRequestHeader) && !m_rh.RequestId)
			{
				return false;
			}
			if (!m_rh.RequestId) {
				m_qRead >> m_rh;
				if (m_bEndianDiff) {
					CBuffer::ChangeEndian((unsigned char*)&m_rh.RequestId, sizeof(m_rh.RequestId));
					CBuffer::ChangeEndian((unsigned char*)&m_rh.Size, sizeof(m_rh.Size));
				}
			}
			if (m_qRead.GetSize() < m_rh.Size)
			{
				if (m_qRead.GetMaxSize() < m_rh.Size + sizeof(m_rh))
				{
					m_qRead.ReallocBuffer(m_rh.Size + sizeof(m_rh) + DEFAULT_READ_BUFFER_BLOCK_SIZE / 4);
				}
				return false;
			}

#if defined(BAD_COMM_ENVIRONMENT) && defined(ENABLE_RANDOM_RECEIVING_CRASH)
			srand((unsigned int)time(nullptr));
			unsigned int random = (unsigned int) rand();
			if (1 == (random % COMM_RANDOM_STRENGTH)) {
				CStringW outputMessage;
				outputMessage.Format(L"File -- %ls, function name -- %ls, line number -- %d, message = %ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"RECEIVING_CRASH_CODE");
				OutputDebugStringW(outputMessage);
				::exit(RECEIVING_CRASH_CODE);
			}
#endif
			m_sc->OnArrive(m_rh.RequestId, m_rh.Size);
			m_qRead.Pop(m_rh.Size);

			//clean all trace as early as possible for better security when a client sends sensitive data like password
			if (m_rh.RequestId == idAuthentication || m_rh.RequestId == idAuthenticationReserved)
			{
				::memset(m_ReadBuffer, 0, MAX_LEN_PER_IO_TRANS);
				m_qRead.CleanTrack();
			}

			m_rh.Reset();
			return (!m_bThreadingProcessing);
		}

		unsigned int CSslSession::Retrieve(unsigned char *receiver, unsigned int size)
		{
			//must call this within main thread!!
			if (::GetCurrentThreadId() != g_pListenServer->m_id)
			{
				return BAD_RETRIEVE_THREAD;
			}
			if (!receiver || !size)
			{
				return 0;
			}
			if (size > m_rh.Size)
			{
				size = m_rh.Size;
			}
			if (size > m_qRead.GetSize())
			{
				size = m_qRead.GetSize();
			}
			m_qRead.Pop(receiver, size);
			m_rh.Size -= size;
			return size;
		}

		unsigned int CSslSession::SendException(unsigned short RequestId, int errCode, const char *errMsg, const char *stack)
		{
			if (RequestId < idStartRequestId && RequestId != idAuthentication && RequestId != idServerInfo)
			{
				return BAD_RESULT;
			}
			CScopeBuffer sb;
			sb << RequestId << errCode << errMsg << stack;
			CRequestHeader rh;
			rh.RequestId = idServerException;
			rh.Size = sb->GetSize();
			{
				CAutoLock al(m_cs);
				if (m_qWrite.GetSize() > 64 * MAX_LEN_PER_IO_TRANS && ::GetCurrentThreadId() != g_pListenServer->m_id)
				{
					m_cv.wait(al);
				}
				if (m_ss < ssSslHandshaked)
				{
					return SESSION_CLOSED;
				}
				if (m_pSspi)
				{
					CScopeBuffer temp;
					temp << rh;
					temp->Push(sb->GetBuffer(), sb->GetSize());
					SECURITY_STATUS ss = m_pSspi->Encrypt(temp->GetBuffer(), temp->GetSize(), m_qWrite);
					if (ss != SEC_E_OK)
					{
						m_ec.assign((DWORD)ss);
						::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SHUT_DOWN_SOCKET, (ULONG_PTR)this, nullptr);
						return SESSION_CLOSED;
					}
				}
				else
				{
					m_qWrite << rh;
					m_qWrite.Push(sb->GetBuffer(), sb->GetSize());
				}
				Write();
			}
			return sb->GetSize();
		}

		unsigned int CSslSession::Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size) {
			if (RequestId < idStartRequestId && RequestId != idAuthentication && RequestId != idServerInfo) {
				return BAD_RESULT;
			}
			return SendInternal(RequestId, buffer, size, false);
		}

		unsigned int CSslSession::SendInternal(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool messaging) {
			if (!buffer)
			{
				size = 0;
			}
			CRequestHeader rh;
			rh.RequestId = RequestId;
			rh.Size = size;
			{
				CAutoLock al(m_cs);
				if (!messaging && m_qWrite.GetSize() > 128 * MAX_LEN_PER_IO_TRANS && ::GetCurrentThreadId() != g_pListenServer->m_id)
				{
					m_bWaiting = true;
					m_cv.wait(al);
					m_bWaiting = false;
				}
				if (m_ss < ssSslHandshaked)
				{
					return SESSION_CLOSED;
				}
				if (m_pSspi)
				{
					CScopeBuffer sb;
					sb << rh;
					sb->Push(buffer, size);
					SECURITY_STATUS ss = m_pSspi->Encrypt(sb->GetBuffer(), sb->GetSize(), m_qWrite);
					if (ss != SEC_E_OK)
					{
						m_ec.assign((DWORD)ss);
						::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SHUT_DOWN_SOCKET, (ULONG_PTR)this, nullptr);
						return SESSION_CLOSED;
					}
				}
				else
				{
					m_qWrite << rh;
					m_qWrite.Push(buffer, size);
				}
				Write();
			}
			return size;
		}

		unsigned int CSslSession::GetSendingBufferSize()
		{
			CAutoLock al(m_cs);
			return m_qWrite.GetSize();
		}

		HRESULT CSslSession::GetErrCode()
		{
			CAutoLock al(m_cs);
			if (m_ec.value() && m_ec.value() != WSA_IO_PENDING) {
				return MAKE_HRESULT(SEVERITY_ERROR, COMM_FAC, m_ec.value());
			}
			return S_OK;
		}

		unsigned int CSslSession::GetPeerName(char *name, unsigned int size)
		{
			SOCKADDR *lpLocalSockaddr = nullptr, *lpRemoteSockaddr = nullptr;
			int LocalSockaddrLen = 0, RemoteSockaddrLen = 0;
			g_pListenServer->GetAcceptExSockaddrs(m_buffAccept, 0, g_pListenServer->m_dwSockAddrSize, g_pListenServer->m_dwSockAddrSize, &lpLocalSockaddr, &LocalSockaddrLen, &lpRemoteSockaddr, &RemoteSockaddrLen);
			char buffer[128] = { 0 };
			int res = ::getnameinfo(lpRemoteSockaddr, RemoteSockaddrLen, buffer, sizeof(buffer), 0, 0, NI_NUMERICHOST);
			if (res == SOCKET_ERROR) {
				if (name && size) {
					name[0] = 0;
				}
				return (~0);
			}
			if (name && size > 0)
			{
				size -= 1;
				std::string s = buffer;
				if (s.length() <= size)
				{
					size = (unsigned int)s.length();
				}
				::memcpy(name, s.c_str(), size);
				name[size] = 0;
			}
			SOCKADDR_IN *si = (SOCKADDR_IN*)lpRemoteSockaddr;
			return si->sin_port;
		}

		unsigned int CSslSession::GetSockName(char *name, unsigned int size)
		{
			SOCKADDR *lpLocalSockaddr = nullptr, *lpRemoteSockaddr = nullptr;
			int LocalSockaddrLen = 0, RemoteSockaddrLen = 0;
			g_pListenServer->GetAcceptExSockaddrs(m_buffAccept, 0, g_pListenServer->m_dwSockAddrSize, g_pListenServer->m_dwSockAddrSize, &lpLocalSockaddr, &LocalSockaddrLen, &lpRemoteSockaddr, &RemoteSockaddrLen);
			char buffer[128] = { 0 };
			int res = ::getnameinfo(lpLocalSockaddr, LocalSockaddrLen, buffer, sizeof(buffer), 0, 0, NI_NUMERICHOST);
			if (res == SOCKET_ERROR) {
				if (name && size) {
					name[0] = 0;
				}
				return (~0);
			}
			if (name && size > 0)
			{
				size -= 1;
				std::string s = buffer;
				if (s.length() <= size)
				{
					size = (unsigned int)s.length();
				}
				::memcpy(name, s.c_str(), size);
				name[size] = 0;
			}
			SOCKADDR_IN *si = (SOCKADDR_IN*)lpLocalSockaddr;
			return si->sin_port;
		}

		unsigned int CSslSession::GetErrMsg(wchar_t *recv, unsigned int size) {
			if (!size || !recv)
			{
				return 0;
			}
			--size;
			if (!size)
			{
				return 0;
			}
			std::wstring str;
			m_cs.lock();
			if (m_ec && m_ec.value() != WSA_IO_PENDING) {
				str = SC::ToWide(m_ec.message());
			}
			m_cs.unlock();
			str.erase(std::find_if(str.rbegin(), str.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), str.end());
			size_t len = str.size();
			if (size > (unsigned int)len)
			{
				size = (unsigned int)len;
			}
			::memcpy(recv, str.c_str(), size * sizeof(wchar_t));
			recv[size] = L'\0';
			return size;
		}

		unsigned int CSslSession::GetErrMsg(char *recv, unsigned int size)
		{
			if (!size || !recv)
			{
				return 0;
			}
			--size;
			if (!size)
			{
				return 0;
			}
			std::string str;
			m_cs.lock();
			if (m_ec && m_ec.value() != WSA_IO_PENDING) {
				str = m_ec.message();
			}
			m_cs.unlock();
			str.erase(std::find_if(str.rbegin(), str.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), str.end());
			size_t len = str.size();
			if (size > (unsigned int)len)
			{
				size = (unsigned int)len;
			}
			::memcpy(recv, str.c_str(), size);
			recv[size] = '\0';
			return size;
		}

		bool CSslSession::StartThreadProcessing()
		{
			//must call this method from main thread
			if (::GetCurrentThreadId() != g_pListenServer->m_id)
			{
				return false;
			}
			m_cs.lock();
			m_bThreadingProcessing = true;
			m_cs.unlock();
			return true;
		}

		void CSslSession::OnSlowRequestProcessed()
		{
			if ((m_ss >= ssConnected))
			{
				while (ProcessInternal())
				{
				}
				Read();
			}
			else if (m_ss == ssClosing) {
				m_ss = ssClosed;
				int res = ::closesocket(m_hSocket);
				m_hSocket = INVALID_SOCKET;
				SubScribe(nullptr, 0);
				m_cv.notify_all();
				m_sc->OnAborted();
				m_pCert.reset();
				m_hSocket = ::WSASocket(g_pListenServer->m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_OVERLAPPED);
				g_pListenServer->Recycle(this);
			}
		}

		bool CSslSession::EndThreadProcessing()
		{
			//must call this method from worker thread
			if (::GetCurrentThreadId() == g_pListenServer->m_id) {
				return false;
			}
			m_cs.lock();
			if (m_bThreadingProcessing) {
				m_bThreadingProcessing = false;
				m_cs.unlock();
				::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SLOW_REQUEST_PROCESSED, (ULONG_PTR)this, nullptr);
				return true;
			}
			m_cs.unlock();
			return false;
		}

		bool CSslSession::IsThreadingProcessing() {
			m_cs.lock();
			bool b = m_bThreadingProcessing;
			m_cs.unlock();
			return b;
		}

		bool CSslSession::DoDecryption(const unsigned char* buffer, DWORD dwSize)
		{
			bool ok = m_pSspi->Decrypt(buffer, dwSize, m_qRead);
			if (!ok)
			{
				PostClose(m_pSspi->GetLastStatus());
			}
			return ok;
		}

		bool CSslSession::DoHandshake(DWORD dwSize)
		{
			bool ok;
			switch (m_pSspi->GetHandshakeState())
			{
			case hsStart:
			case hsShaking:
				{
					TLSHelloHeader *pTLS = nullptr;
					m_qRead.Push(m_ReadBuffer, (unsigned int)dwSize);
					if (m_ch.GetContentType() == invalid && m_qRead.GetSize() > sizeof(TLSRecord)) {
						if (CSSLHello::ParseHello(m_qRead.GetBuffer(), m_qRead.GetSize(), m_ch)) {
							m_sc->OnSslHandshake(&m_ch);
							pTLS = (TLSHelloHeader *)m_qRead.GetBuffer();
						}
					}
					ok = m_pSspi->DoHandshake(m_qRead.GetBuffer(), m_qRead.GetSize(), m_qWrite);
					if (ok && m_pSspi->GetLastStatus() != SEC_E_INCOMPLETE_MESSAGE) {
						m_qRead.SetSize(0);
						if (pTLS) {
							if (CSSLHello::ParseHello(m_qWrite.GetBuffer(), m_qWrite.GetSize(), m_ch)) {
								m_sc->OnSslHandshake(&m_ch);
							}
#ifdef BAD_COMM_ENVIRONMENT
							srand((unsigned int)time(nullptr));
							unsigned int random = (unsigned int) rand();
							unsigned int len = ((unsigned int)random % m_qWrite.GetSize());
							int res = ::send(m_hSocket, (const char*)m_qWrite.GetBuffer(), (int)len, 0);
							m_qWrite.Pop(len);
							::Sleep(len);
#endif
						}
					}
				}
				break;
			default:
				ok = false;
				assert(false); //never come here
				break;
			}
			if (ok)
			{
				Write();
			}
			return ok;
		}

		void CSslSession::handle_read(DWORD bytes_transferred)
		{
			if (!bytes_transferred)
			{
				OnCloseInternal();
				return;
			}
			if (m_pSspi)
			{
				m_bReading = false;
				if (m_pSspi->GetHandshakeState() < hsDone)
				{
					if (DoHandshake(bytes_transferred))
					{
						if (m_pSspi->GetHandshakeState() == hsDone)
						{
							assert(m_qRead.GetSize() == 0);
							if (m_pSspi->GetCertContext()) {
								m_pCert.reset(new CCertificateImpl(m_pSspi, ""));
							}
							m_ss = ssSslHandshaked;
							m_ch.Handshake.msg_type = (unsigned char)finished;
							m_sc->OnSslHandshake(&m_ch);
						}
						Read();
					}
					else
					{
						PostClose(m_pSspi->GetLastStatus());
					}
					return;
				}
				if (!DoDecryption(m_ReadBuffer, bytes_transferred))
				{
					return;
				}
			}
			else
			{
				m_qRead.Push(m_ReadBuffer, (unsigned int)bytes_transferred);
			}
			if (bytes_transferred >= MAX_LEN_PER_IO_TRANS)
			{
				ReadEx();
			}
			{
				if (m_ss < ssAuthentcated && m_qRead.GetSize() >= sizeof(m_rh))
				{
					//peek the first 8 bytes of data
					CRequestHeader *rh = (CRequestHeader*)m_qRead.GetBuffer();
					switch (rh->RequestId)
					{
					case idAuthenticationReserved:
						m_bEndianDiff = true;
					case idAuthentication:
					{
						unsigned int size = rh->Size;
						if (m_bEndianDiff)
						{
							CBuffer::ChangeEndian((unsigned char*)&size, sizeof(size));
						}
						if (rh->Size <= MAX_LEN_PER_IO_TRANS)
						{
							m_ss = ssAuthentcated;
							break;
						}
					}
					case idServerInfo:
						//give permission to this particular request without authentication
						break;
					default:
						PostClose(ERROR_ACCESS_DENIED);
						return;
						break;
					}
				}
			}
			while (ProcessInternal())
			{
			}
			m_bReading = false;
			Read();
		}

		void CSslSession::ReadEx()
		{
			int res;
			CScopeBuffer sb(DEFAULT_INITIAL_MEMORY_BUFFER_SIZE);
			while (m_qRead.GetSize() < (MAX_LEN_PER_IO_TRANS * 64 + m_rh.Size))
			{
				res = ::recv(m_hSocket, (char*)sb->GetBuffer(), (int)DEFAULT_INITIAL_MEMORY_BUFFER_SIZE, 0);
				if (res > 0)
				{
					if (m_pSspi)
					{
						if (!DoDecryption(sb->GetBuffer(), (DWORD)res))
						{
							break;
						}
					}
					else
					{
						m_qRead.Push(sb->GetBuffer(), (unsigned int)res);
					}
				}
				if (res < (int)DEFAULT_INITIAL_MEMORY_BUFFER_SIZE)
				{
					break;
				}
			}
		}

		bool CSslSession::Read()
		{
			if (m_ss < ssConnected) {
				return false;
			}
			if (m_bReading)
			{
				return true;
			}
			if (m_bThreadingProcessing && m_qRead.GetSize() > (MAX_LEN_PER_IO_TRANS * 64 + m_rh.Size))
			{
				return true;
			}
			m_bReading = true;
			m_dwBytesRecvd = 0;
			m_dwFlagsRecvd = 0;
			::memset(&m_olRead, 0, sizeof(m_olRead));
			m_wsaRecv.buf = (char*)m_ReadBuffer;
			m_wsaRecv.len = MAX_LEN_PER_IO_TRANS;
			int res = ::WSARecv(m_hSocket, &m_wsaRecv, 1, &m_dwBytesRecvd, &m_dwFlagsRecvd, &m_olRead, nullptr);
			if (res == SOCKET_ERROR) {
				int errCode = ::WSAGetLastError();
				if (errCode != WSA_IO_PENDING) {
					m_ec.assign((DWORD)errCode);
					::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SHUT_DOWN_SOCKET, (ULONG_PTR)this, nullptr);
					return false;
				}
			}
			return true;
		}

		void CSslSession::handle_write(DWORD bytes_transferred)
		{
			{
				CAutoLock al(m_cs);
				m_bWriting = false;
				Write();
			}
			Read();
		}

		void CSslSession::Write()
		{
			int res;
			if (m_bWriting)
			{
				return;
			}
			if (m_qWrite.GetSize() == 0)
			{
				return;
			}

#if defined(BAD_COMM_ENVIRONMENT) && defined(ENABLE_RANDOM_SENDING)
			const char *start = (const char*)m_qWrite.GetBuffer();
			unsigned int remaining = (int)m_qWrite.GetSize();
			unsigned int planned = (remaining <= RANDOM_SENDING_BYTE) ? remaining : RANDOM_SENDING_BYTE;
			res = ::send(m_hSocket, start, (int)planned, 0);
			int sent = res;
			while (sent > 0 && planned > 0) {
				res += sent;
				start += sent;
				remaining -= (unsigned int)sent;
				planned = (remaining <= RANDOM_SENDING_BYTE) ? remaining : RANDOM_SENDING_BYTE;
				Sleep(RANDOM_DELAY_MS);
				sent = ::send(m_hSocket, start, (int)planned, 0);
			}
#else
			//errCode == 10053
			//An established connection was aborted by the software in your host computer, possibly due to a data transmission time-out or protocol error.
			res = 0; //::send(m_hSocket, (const char*)m_qWrite.GetBuffer(), (int)m_qWrite.GetSize(), 0);
#endif

#if defined(BAD_COMM_ENVIRONMENT) && defined(ENABLE_RANDOM_SENDING_CRASH)
			srand((unsigned int)time(nullptr));
			unsigned int random = (unsigned int) rand();
			if (1 == (random % COMM_RANDOM_STRENGTH)) {
				CStringW outputMessage;
				outputMessage.Format(L"File -- %ls, function name -- %ls, line number -- %d, message = %ls\r\n", __FILEW__, __FUNCTIONW__, __LINE__, L"SENDING_CRASH_CODE");
				OutputDebugStringW(outputMessage);
				::exit(SENDING_CRASH_CODE);
			}
#endif
			if (res > 0)
			{
				m_qWrite.Pop((unsigned int)res);
			}
			unsigned int size = (m_qWrite.GetSize() > MAX_LEN_PER_IO_TRANS) ? MAX_LEN_PER_IO_TRANS : m_qWrite.GetSize();
			if (size)
			{
				m_dwBytesSent = 0;
				m_qWrite.Pop(m_WriteBuffer, size);
				m_bWriting = true;
				m_wsaSend.buf = (CHAR*)m_WriteBuffer;
				m_wsaSend.len = (ULONG)size;
				::memset(&m_olSent, 0, sizeof(m_olSent));
				res = ::WSASend(m_hSocket, &m_wsaSend, 1, &m_dwBytesSent, 0, &m_olSent, nullptr);
				if (res == SOCKET_ERROR)
				{
					int errCode = WSAGetLastError();
					if (errCode != WSA_IO_PENDING) {
						m_ec.assign((DWORD)errCode);
						::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SHUT_DOWN_SOCKET, (ULONG_PTR)this, nullptr);
						return;
					}
				}
			}

			if (m_bWaiting && m_qWrite.GetSize() < MAX_LEN_PER_IO_TRANS * 4 && ::GetCurrentThreadId() == g_pListenServer->m_id)
			{
				m_cv.notify_all();
			}
			if (m_qWrite.GetSize() == 0 && m_ss == ssAuthentcated)
			{
				if (::GetCurrentThreadId() == g_pListenServer->m_id) {
					m_sc->OnLess();
				}
				else {
					::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CH_LESS_INTERNAL, (ULONG_PTR)this, nullptr);
				}
			}
		}

		void CSslSession::OnLessInternal()
		{
			if (m_ss >= ssConnected) {
				m_sc->OnLess();
			}
		}

		void CSslSession::Initialize()
		{
			m_bWaiting = false;
			m_bEndianDiff = false;
			m_ss = ssConnected;
			m_bThreadingProcessing = false;
			m_bReading = false;
			m_bWriting = false;
			m_qRead.SetSize(0);
			m_qWrite.SetSize(0);
			m_ch.Record.version = 0;
			m_ch.Record.type = 0;
			m_ch.Handshake.msg_type = 0;
			m_ch.client_version = 0;
			m_client.AppName.clear();
			m_client.MachineName.clear();
			m_client.UserId.clear();
			::memset(&m_rh, 0, sizeof(m_rh));
			if (g_pListenServer->IsSecure())
			{
				m_pSspi.reset(new CSspi(false, g_pListenServer->GetCredHandle(), g_pListenServer->m_clientCertAuth));
			}
			u_long iMode = 1;
			int res = ::ioctlsocket(m_hSocket, FIONBIO, &iMode);
			int optValue = 256 * 1024;
			res = ::setsockopt(m_hSocket, SOL_SOCKET, SO_RCVBUF, (const char*)&optValue, sizeof(optValue));
			optValue = 1;
			res = ::setsockopt(m_hSocket, IPPROTO_TCP, TCP_NODELAY, (const char*)&optValue, sizeof(optValue));
		}

		void CSslSession::Start()
		{
			Initialize();
			if (g_pListenServer->IsSecure()) {
				m_ss = ssSslHandshaking;
			}
			LARGE_INTEGER li;
			QueryPerformanceCounter(&li);
			m_client.ServerPointer = (unsigned __int64)li.QuadPart;
			HANDLE hPort = ::CreateIoCompletionPort((HANDLE)m_hSocket, g_pListenServer->m_hRootIoPort, (ULONG_PTR)this, 1);
			assert(hPort == g_pListenServer->m_hRootIoPort);
			Read();
		}

		void CSslSession::SetClientAppName(const wchar_t *clientAppName)
		{
			CAutoLock al(m_cs);
			m_client.AppName.clear();
			if (clientAppName) {
				m_client.AppName = clientAppName;
				std::transform(m_client.AppName.begin(), m_client.AppName.end(), m_client.AppName.begin(), ::tolower);
			}
		}

		const wchar_t* CSslSession::GetClientAppName()
		{
			CAutoLock al(m_cs);
			return m_client.AppName.c_str();
		}

		void CSslSession::SetUserId(const wchar_t *userId)
		{
			CAutoLock al(m_cs);
			m_client.UserId.clear();
			if (userId) {
				m_client.UserId = userId;
				std::transform(m_client.UserId.begin(), m_client.UserId.end(), m_client.UserId.begin(), ::tolower);
			}
		}

		const wchar_t* CSslSession::GetUserId()
		{
			CAutoLock al(m_cs);
			return m_client.UserId.c_str();
		}

		void CSslSession::SetClientMachineName(const wchar_t *clientMachineName)
		{
			CAutoLock al(m_cs);
			m_client.MachineName.clear();
			if (clientMachineName) {
				m_client.MachineName = clientMachineName;
				std::transform(m_client.MachineName.begin(), m_client.MachineName.end(), m_client.MachineName.begin(), ::tolower);
			}
		}

		const wchar_t* CSslSession::GetClientMachineName()
		{
			CAutoLock al(m_cs);
			return m_client.MachineName.c_str();
		}

		unsigned int CSslSession::SubScribe(const unsigned int *topics, unsigned int count)
		{
			if (!topics) {
				count = 0;
			}
			CTopicArray vSub;
			for (unsigned int n = 0; n < count; ++n) {
				if (std::find(g_vTopic.begin(), g_vTopic.end(), topics[n]) != g_vTopic.end() && 
					std::find(vSub.begin(), vSub.end(), topics[n]) == vSub.end()) {
					vSub.push_back(topics[n]);
				}
			}
			SC::CScopeBuffer sb;
			CTopicArray vExit, vJoin;
			{
				CAutoLock al(m_cs);
				size_t total = vSub.size();
				for (size_t pos = 0; pos < total; ++pos) {
					if (std::find(m_vTopic.begin(), m_vTopic.end(), vSub[pos]) == m_vTopic.end()) {
						vJoin.push_back(vSub[pos]);
					}
				}
				total = m_vTopic.size();
				for (size_t pos = 0; pos < total; ++pos) {
					if (std::find(vSub.begin(), vSub.end(), m_vTopic[pos]) == vSub.end()) {
						vExit.push_back(m_vTopic[pos]);
					}
				}
				m_vTopic = vSub;
				sb << m_client;
			}
			unsigned int base_size = sb->GetSize();
			{
				CTopicArray v;
				CAutoLock al(g_pListenServer->m_csAliveSession);
				for (auto session : g_pListenServer->m_vAliveSession) {
					if (session == this) {
						continue;
					}
					{
						CAutoLock scl(session->m_cs);
						for (auto topic : vExit) {
							if (std::find(session->m_vTopic.begin(), session->m_vTopic.end(), topic) != session->m_vTopic.end()) {
								v.push_back(topic);
							}
						}
					}
					count = (unsigned int)v.size();
					if (count) {
						sb->SetSize(base_size);
						sb << count;
						sb->Push((const unsigned char*)v.data(), count * sizeof(unsigned int));
						session->SendInternal(idExit, sb->GetBuffer(), sb->GetSize(), true);
						v.clear();
					}

					{
						CAutoLock scl(session->m_cs);
						for (auto topic : vJoin) {
							if (std::find(session->m_vTopic.begin(), session->m_vTopic.end(), topic) != session->m_vTopic.end()) {
								v.push_back(topic);
							}
						}
					}
					count = (unsigned int)v.size();
					if (count) {
						sb->SetSize(base_size);
						sb << count;
						sb->Push((const unsigned char*)v.data(), count * sizeof(unsigned int));
						session->SendInternal(idJoin, sb->GetBuffer(), sb->GetSize(), true);
						v.clear();
					}
				}
			}
			CAutoLock al(m_cs);
			return (unsigned int)m_vTopic.size();
		}

		unsigned int CSslSession::SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName, const wchar_t* machineName) {
			if (!receiver) {
				return 0;
			}
			std::wstring recv(receiver);
			std::transform(recv.begin(), recv.end(), recv.begin(), ::tolower);
			SC::CScopeBuffer sb;
			{
				CAutoLock al(m_cs);
				sb << m_client;
			}
			sb << vtMsg;
			unsigned int count = 0;
			CAutoLock al(g_pListenServer->m_csAliveSession);
			for (auto s : g_pListenServer->m_vAliveSession) {
				if (s != this) {
					bool ok;
					do {
						CAutoLock a(s->m_cs);
						ok = (s->m_client.UserId == recv);
						if (!ok) {
							break;
						}
						if (appName) {
							std::wstring str(appName);
							std::transform(str.begin(), str.end(), str.begin(), ::tolower);
							ok = (s->m_client.AppName == str);
							if (!ok) {
								break;
							}
						}
						if (machineName) {
							std::wstring str(machineName);
							std::transform(str.begin(), str.end(), str.begin(), ::tolower);
							ok = (s->m_client.MachineName == str);
							if (!ok) {
								break;
							}
						}
					} while (false);
					if (ok) {
						s->SendInternal(idSendUserMessage, sb->GetBuffer(), sb->GetSize(), true);
						++count;
					}
				}
			}
			return count;
		}

		unsigned __int64 CSslSession::GetServerPointer() const
		{
			return m_client.ServerPointer;
		}

		unsigned int CSslSession::PublishMessage(const VARIANT &vtMsg, const unsigned int *topics, unsigned int count)
		{
			if (!topics || !count) {
				return 0;
			}
			CTopicArray vSub;
			for (unsigned int n = 0; n < count; ++n) {
				if (std::find(g_vTopic.begin(), g_vTopic.end(), topics[n]) != g_vTopic.end() &&
					std::find(vSub.begin(), vSub.end(), topics[n]) == vSub.end()) {
					vSub.push_back(topics[n]);
				}
			}
			SC::CScopeBuffer sb;
			{
				CAutoLock al(m_cs);
				sb << m_client;
			}
			sb << vtMsg;
			unsigned int base_len = sb->GetSize();
			count = 0;
			{
				CAutoLock al(g_pListenServer->m_csAliveSession);
				for (auto session : g_pListenServer->m_vAliveSession) {
					if (session == this) {
						continue;
					}
					CTopicArray v;
					{
						CAutoLock scl(session->m_cs);
						for (auto topic : vSub) {
							if (std::find(session->m_vTopic.begin(), session->m_vTopic.end(), topic) != session->m_vTopic.end()) {
								v.push_back(topic);
							}
						}
					}
					unsigned int size = (unsigned int)v.size();
					if (size) {
						sb->SetSize(base_len);
						sb << size;
						sb->Push((const unsigned char*)v.data(), size * sizeof(unsigned int));
						session->SendInternal(idPublish, sb->GetBuffer(), sb->GetSize(), true);
						++count;
					}
				}
			}
			return count;
		}

	} //ServerSide
} //SC
