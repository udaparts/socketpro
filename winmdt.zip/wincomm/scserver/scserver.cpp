
#include "stdafx.h"
#include "sclisten.h"

PThreadExceptionHandlers g_teh = nullptr;

namespace SC {
	namespace ServerSide {
		CMutex g_mutex;
		std::string g_strErrorMessage;
		extern POnIdle g_onidle;

		CTopicArray g_vTopic;
	}
}

using namespace SC::ServerSide;

void WINAPI SetThreadStackCrashHandler_Server(PThreadExceptionHandlers teh) {
	CAutoLock lg(g_mutex);
	g_teh = teh;
}

PThreadExceptionHandlers WINAPI GetThreadStackCrashHandler_Server()
{
	CAutoLock lg(g_mutex);
	return g_teh;
}

const char* WINAPI InitializeSecureCommServer(POnAccepted OnAccepted, unsigned int port, bool v6, unsigned int backlog) {
	CAutoLock lg(g_mutex);
	g_strErrorMessage.clear();
	if (g_pListenServer)
	{
		return g_strErrorMessage.c_str();
	}
	if (!OnAccepted)
	{
		g_strErrorMessage = "OnAccepted callback required";
	}
	else
	{
		SC::ServerSide::CListenServer::CreateListenServer(OnAccepted, port, v6, backlog);
	}
	return g_strErrorMessage.c_str();
}

const char* WINAPI  RunSecureCommServer(const wchar_t *filePfx, const wchar_t *password, bool clientCertAuth, SC::tagCertStoreType cst) {
	CAutoLock lg(g_mutex);
	g_strErrorMessage.clear();
	if (!g_pListenServer) {
		g_strErrorMessage = "Sc server not initialized yet";
	}
	else {
		g_pListenServer->SetCertStoreType(cst);
		if (!g_pListenServer->OpenPfx(filePfx, password, clientCertAuth) || !g_pListenServer->Run()) {
			g_strErrorMessage = g_pListenServer->GetErrorMessage();
		}
	}
	return g_strErrorMessage.c_str();
}

void WINAPI ShutdownSecureCommServer() {
	CAutoLock lg(g_mutex);
	if (g_pListenServer) {
		g_strErrorMessage.clear();
		delete g_pListenServer;
	}
}

unsigned int WINAPI GetSessionCount() {
	//CAutoLock lg(g_mutex);
	if (!g_pListenServer)
		return 0;
	return g_pListenServer->GetSessionCount();
}

unsigned int WINAPI GetThreadCount() {
	//CAutoLock lg(g_mutex);
	if (!g_pListenServer)
		return 0;
	return g_pListenServer->GetThreadCount();
}

SC::tagCertStoreType WINAPI GetServerCertStoreType() {
	//CAutoLock lg(g_mutex);
	if (!g_pListenServer)
		return SC::cstUnknown;
	return SC::CCertificateImpl::CertStore.GetCertStoreType();
}

HCERTSTORE WINAPI GetServerCertStore() {
	//CAutoLock lg(g_mutex);
	if (!g_pListenServer)
		return nullptr;
	return SC::CCertificateImpl::CertStore.GetCertStore();
}

const SC::ICertificate* const WINAPI GetServerCertificate() {
	//CAutoLock lg(g_mutex);
	if (!g_pListenServer)
		return nullptr;
	return g_pListenServer->GetSelfCert();
}

void WINAPI SetIdleFunc(POnIdle onidle)
{
	CAutoLock lg(g_mutex);
	if (!g_pListenServer)
		return;
	SC::ServerSide::g_onidle = onidle;
}

unsigned int WINAPI CreateTopics(unsigned int *topics, unsigned int count)
{
	{
		CAutoLock lg(g_mutex);
		if (!g_pListenServer || g_pListenServer->IsRunning()) {
			return (~0);
		}
		g_vTopic.clear();
	}
	if (!topics || !count)
		return 0;
	for (unsigned int n = 0; n < count; ++n) {
		if (std::find(g_vTopic.begin(), g_vTopic.end(), topics[n]) == g_vTopic.end()) {
			g_vTopic.push_back(topics[n]);
		}
	}
	return (unsigned int)g_vTopic.size();
}

unsigned int WINAPI SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName, const wchar_t* machineName)
{
	if (!g_pListenServer || !g_pListenServer->IsRunning()) {
		return (~0);
	}
	if (!receiver) {
		return 0;
	}
	std::wstring recv(receiver);
	std::transform(recv.begin(), recv.end(), recv.begin(), ::tolower);
	SC::CScopeBuffer sb;

	sb << g_pListenServer->m_self;
	sb << vtMsg;
	unsigned int count = 0;
	CAutoLock al(g_pListenServer->m_csAliveSession);
	for (auto s : g_pListenServer->m_vAliveSession) {
		bool ok;
		do {
			CAutoLock a(s->m_cs);
			ok = (s->m_client.UserId == recv);
			if (!ok) {
				break;
			}
			if (appName) {
				std::wstring str(appName);
				std::transform(str.begin(), str.end(), str.begin(), ::tolower);
				ok = (s->m_client.AppName == str);
				if (!ok) {
					break;
				}
			}
			if (machineName) {
				std::wstring str(machineName);
				std::transform(str.begin(), str.end(), str.begin(), ::tolower);
				ok = (s->m_client.MachineName == str);
				if (!ok) {
					break;
				}
			}
		} while (false);
		if (ok) {
			s->SendInternal(SC::idSendUserMessage, sb->GetBuffer(), sb->GetSize(), true);
			++count;
		}
	}
	return count;
}

unsigned int WINAPI PublishMessage(const VARIANT &vtMsg, const unsigned int *topics, unsigned int count)
{
	if (!g_pListenServer || !g_pListenServer->IsRunning()) {
		return (~0);
	}
	if (!topics || !count) {
		return 0;
	}
	CTopicArray vSub;
	for (unsigned int n = 0; n < count; ++n) {
		if (std::find(g_vTopic.begin(), g_vTopic.end(), topics[n]) != g_vTopic.end() &&
			std::find(vSub.begin(), vSub.end(), topics[n]) == vSub.end()) {
			vSub.push_back(topics[n]);
		}
	}
	SC::CScopeBuffer sb;
	sb << g_pListenServer->m_self;
	sb << vtMsg;
	unsigned int base_len = sb->GetSize();
	count = 0;
	CAutoLock al(g_pListenServer->m_csAliveSession);
	for (auto session : g_pListenServer->m_vAliveSession) {
		CTopicArray v;
		{
			CAutoLock a(session->m_cs);
			for (auto topic : vSub) {
				if (std::find(session->m_vTopic.begin(), session->m_vTopic.end(), topic) != session->m_vTopic.end()) {
					v.push_back(topic);
				}
			}
		}
		unsigned int size = (unsigned int)v.size();
		if (size) {
			sb->SetSize(base_len);
			sb << size;
			sb->Push((const unsigned char*)v.data(), size * sizeof(unsigned int));
			session->SendInternal(SC::idPublish, sb->GetBuffer(), sb->GetSize(), true);
			++count;
		}
	}
	return count;
}
