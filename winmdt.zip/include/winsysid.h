

#ifndef _MDT_WINDOW_SYSTEM_ID_H_
#define _MDT_WINDOW_SYSTEM_ID_H_

#include <atlbase.h>
#include <wbemidl.h>

namespace Utilities {

	template<typename TString>
	static TString GetSysIdW() {
        TString str;
        bool b = (CoInitializeEx(0, COINIT_MULTITHREADED) == S_OK);

        do {
            HRESULT hr = CoInitializeSecurity(nullptr,
                    -1, // COM authentication
                    nullptr, // Authentication services
                    nullptr, // Reserved
                    RPC_C_AUTHN_LEVEL_DEFAULT, // Default authentication 
                    RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
                    nullptr, // Authentication info
                    EOAC_NONE, // Additional capabilities 
                    nullptr // Reserved
                    );
            CComPtr<IWbemLocator> pIWbemLocator;
            hr = pIWbemLocator.CoCreateInstance(CLSID_WbemLocator);
            if (FAILED(hr)) {
                break;
			}
            CComPtr<IWbemServices> pIWbemServices;
            hr = pIWbemLocator->ConnectServer(CComBSTR(L"ROOT\\CIMV2"), // Object path of WMI namespace
                    nullptr, // User name. nullptr = current user
                    nullptr, // User password. nullptr = current
                    nullptr, // Locale. nullptr indicates current
                    0, // Security flags.
                    nullptr, // Authority (e.g. Kerberos)
                    nullptr, // Context object 
                    &pIWbemServices // pointer to IWbemServices proxy
                    );
            if (FAILED(hr)) {
                break;
			}
            hr = CoSetProxyBlanket(pIWbemServices, // Indicates the proxy to set
                    RPC_C_AUTHN_WINNT, // RPC_C_AUTHN_xxx
                    RPC_C_AUTHZ_NONE, // RPC_C_AUTHZ_xxx
                    nullptr, // Server principal name 
                    RPC_C_AUTHN_LEVEL_CALL, // RPC_C_AUTHN_LEVEL_xxx 
                    RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
                    nullptr, // client identity
                    EOAC_NONE // proxy capabilities 
                    );
            if (FAILED(hr)) {
                break;
			}
			ULONG res = 0;
            CComPtr<IEnumWbemClassObject> pIEnumWbemClassObject;
            hr = pIWbemServices->ExecQuery(CComBSTR("WQL"),
                    CComBSTR("SELECT * FROM Win32_BIOS"),
                    WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
                    nullptr,
                    &pIEnumWbemClassObject);
            if (!FAILED(hr)) {
                CComPtr<IWbemClassObject> pIWbemClassObject;
                hr = pIEnumWbemClassObject->Next(WBEM_INFINITE, 1, &pIWbemClassObject, &res);
                if (!FAILED(hr) && pIWbemClassObject != nullptr) {
                    CComVariant vt;
                    hr = pIWbemClassObject->Get(L"SerialNumber", 0, &vt, nullptr, nullptr);
                    if (!FAILED(hr) && vt.vt == VT_BSTR) {
                        str += vt.bstrVal;
						if (::SysStringLen(vt.bstrVal)) {
							break;
						}
					}
                }
            }
            pIEnumWbemClassObject.Release();
            hr = pIWbemServices->ExecQuery(CComBSTR("WQL"),
                    CComBSTR("SELECT * FROM Win32_BaseBoard"),
                    WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
                    nullptr,
                    &pIEnumWbemClassObject);
            if (!FAILED(hr)) {
                CComPtr<IWbemClassObject> pIWbemClassObject;
                hr = pIEnumWbemClassObject->Next(WBEM_INFINITE, 1, &pIWbemClassObject, &res);
                if (!FAILED(hr) && pIWbemClassObject != nullptr) {
                    CComVariant vt;
                    hr = pIWbemClassObject->Get(L"SerialNumber", 0, &vt, nullptr, nullptr);
                    if (!FAILED(hr) && vt.vt == VT_BSTR) {
                        str += vt.bstrVal;
						if (::SysStringLen(vt.bstrVal)) {
							break;
						}
					}
                }
            }
            pIEnumWbemClassObject.Release();
            hr = pIWbemServices->ExecQuery(CComBSTR("WQL"),
                    CComBSTR("SELECT * FROM Win32_ComputerSystemProduct"),
                    WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
                    nullptr,
                    &pIEnumWbemClassObject);
            if (!FAILED(hr)) {
                CComPtr<IWbemClassObject> pIWbemClassObject;
                hr = pIEnumWbemClassObject->Next(WBEM_INFINITE, 1, &pIWbemClassObject, &res);
                if (!FAILED(hr) && pIWbemClassObject != nullptr) {
                    CComVariant vt;
                    hr = pIWbemClassObject->Get(L"UUID", 0, &vt, nullptr, nullptr);
                    if (!FAILED(hr) && vt.vt == VT_BSTR) {
                        str += vt.bstrVal;
					}
                }
            }
        } while (false);
        if (b) {
            CoUninitialize();
		}
		return str;
	}
} //namespace Utilities

#endif