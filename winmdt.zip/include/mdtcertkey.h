
#ifndef _MDT_CERT_PRIVATE_KEY_MANAGEMENT_H_
#define _MDT_CERT_PRIVATE_KEY_MANAGEMENT_H_

#include <wbemidl.h>
#include "sha1.h"
#include "bf.h"
#include <wincrypt.h>
#include <string>
#include "compiledefinitions.h"

//CryptProtectData and CryptUnprotectData

namespace Utilities {

	namespace Server {

		static const DWORD NO_SECURE_SALT = 0;		//SSL/TLSv not used for encryption and decryption
		static const DWORD SECURE_CA_SALT = (~0);	//Secured by certificate and key with CA chain
		//Any salt other than the above two values	//Secured by self-signed certificate and key



		static std::string SavePfxSecurely(LPCTSTR pfxFile, LPCTSTR pfxPassphrase, LPCTSTR appKey, DWORD dwSalt) {
			assert(pfxFile);
			assert(dwSalt);
			assert(appKey);
			assert(::_tcslen(pfxFile));
			assert(::_tcslen(appKey));

			HANDLE hfile = INVALID_HANDLE_VALUE;
			std::string res;
			CStringW str = Internal::GetUniqeString(appKey, dwSalt);
			CSHA1 sha1;
			sha1.Update((const unsigned char*)LPCTSTR(str), (unsigned int)(str.GetLength() * sizeof(TCHAR)));
			sha1.Final();
			
			do {
				unsigned char blowfishKey[32] = {0};
				bool ok = sha1.GetHash(blowfishKey);
				if (!ok) {
					break;
				}
				hfile = ::CreateFile(pfxFile, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
				if (INVALID_HANDLE_VALUE == hfile) {
					break;
				}
				DWORD dwRead;
				DWORD dwFileSize = ::GetFileSize(hfile, nullptr);
				SC::CScopeBuffer sb(dwFileSize + 4096);	
				sb << pfxPassphrase;
				sb << (unsigned int)dwFileSize;
				if (!::ReadFile(hfile, (LPVOID)sb->GetBuffer(sb->GetSize()), dwFileSize, &dwRead, nullptr)) {
					sb->CleanTrack();
					break;
				}
				sb->SetSize(sb->GetSize() + (unsigned int)dwRead);
				
				{
					DATA_BLOB dbDataIn;
					dbDataIn.cbData = sb->GetSize();
					dbDataIn.pbData = (unsigned char*)sb->GetBuffer();
					DATA_BLOB dbSession;
					::memset(&dbSession, 0, sizeof(dbSession));
					//save both password and pfx file content in one memory buffer into window system securely
					if (!::CryptProtectData(&dbDataIn, L"MDT Software Security", nullptr, nullptr, nullptr, CRYPTPROTECT_LOCAL_MACHINE, &dbSession)) {
						sb->CleanTrack();
						break;
					}
					sb->SetSize(0);
				
					sb << (unsigned int)dbSession.cbData;
					sb->Push((const unsigned char*)dbSession.pbData, (unsigned int)dbSession.cbData);
					::memset(dbSession.pbData, 0, dbSession.cbData);
					::LocalFree(dbSession.pbData);
				}

				//blow fish requires plain text length must be dividable by 8 without remaining
				unsigned int padSize = ((sb->GetSize() % 8) == 0) ? 0 : (8 - (sb->GetSize() % 8));
				sb->CleanTrack();
				sb->SetSize(sb->GetSize() + padSize);
				
				CBF bf(blowfishKey, 20);

				//don't need blowfish key anymore now
				::memset(blowfishKey, 0, sizeof(blowfishKey));

				//inline encrypting session data
				bf.Encrypt((unsigned char*)sb->GetBuffer(), sb->GetSize());
				char temp[16] = {0};
				const unsigned char *p = sb->GetBuffer();
				for (unsigned int n = 0; n < (sb->GetSize() - padSize); ++n) {
					::sprintf_s(temp, sizeof(temp), "%02x", p[n]);
					res += temp;
				}
				res += std::to_string(padSize);
			}while(false);
			if (INVALID_HANDLE_VALUE != hfile) {
				::CloseHandle(hfile);
			}

			//returning hex string should be save into somewhere
			return res;
		}

		static CString ReadPfxSecurely(const char* dbSessionInhex, LPCTSTR pfxFile, LPCTSTR appKey, DWORD dwSalt) {
			if (!dbSessionInhex) {
				assert(false);
				return _T("");
			}
			size_t len = ::strlen(dbSessionInhex);
			if (!len || !(len % 2)) {
				assert(false);
				return _T("");
			}
			assert(pfxFile);
			assert(dwSalt);
			assert(appKey);
			assert(::_tcslen(pfxFile));
			assert(::_tcslen(appKey));

			std::string pad(dbSessionInhex + len - 1, dbSessionInhex + len);
			len -= 1;
			std::string session(dbSessionInhex, dbSessionInhex + len);
			dbSessionInhex = session.c_str();

			LPWSTR strDescription = nullptr;
			CString password;
			HANDLE hfile = INVALID_HANDLE_VALUE;
			CStringW str = Internal::GetUniqeString(appKey, dwSalt);
			CSHA1 sha1;
			sha1.Update((const unsigned char*)LPCTSTR(str), (unsigned int)(str.GetLength() * sizeof(TCHAR)));
			sha1.Final();
			do {
				unsigned char blowfishKey[32] = {0};
				if (!sha1.GetHash(blowfishKey)) {
					break;
				}
				hfile = ::CreateFile(pfxFile, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, 0, nullptr);
				if (INVALID_HANDLE_VALUE == hfile) {
					break;
				}
				SC::CScopeBuffer sb;
				char *end = nullptr;
				for (size_t pos = 0; pos < len; ) {
					std::string hex(dbSessionInhex + pos, dbSessionInhex + pos + 2);
					unsigned char byte = (unsigned char)std::strtoul(hex.c_str(), &end, 16);
					sb->Push(&byte, sizeof(byte));
					pos += 2;
				}
				if ((sb->GetSize() % 8)) {
					break;
				}
				CBF bf(blowfishKey, 20);
				//don't need blowfish key anymore now
				::memset(blowfishKey, 0, sizeof(blowfishKey));
				//inline decrypting session data
				bf.Decrypt((unsigned char*)sb->GetBuffer(), sb->GetSize());

				DATA_BLOB dbSession;
				dbSession.cbData = sb->GetSize() - std::atoi(pad.c_str());
				dbSession.pbData = (BYTE*)sb->GetBuffer();

				DATA_BLOB dbDataOut;
				::memset(&dbDataOut, 0, sizeof(dbDataOut));
				if (!::CryptUnprotectData(&dbSession, &strDescription, nullptr, nullptr, nullptr, 0, &dbDataOut)) {
					break;
				}
				sb->SetSize(0);
				sb->Push((const unsigned char*)dbDataOut.pbData, (unsigned int)dbDataOut.cbData);
				::LocalFree(dbDataOut.pbData);
				unsigned int bytes;
				sb >> password >> bytes;
				DWORD dwWritten;
				if (!::WriteFile(hfile, sb->GetBuffer(), bytes, &dwWritten, nullptr)) {
					password.Empty();
					break;
				}
				assert(bytes == dwWritten);
			}while(false);
			if (INVALID_HANDLE_VALUE != hfile) {
				::CloseHandle(hfile);
			}
			if (strDescription) {
				::LocalFree(strDescription);
			}
			return password;
		}
	}; //namespace Server
	
}; //namespace Utilities

#endif