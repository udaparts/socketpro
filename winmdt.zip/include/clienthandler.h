
#ifndef _SECURE_COMM_COMMUNICATION_ADAPTER_CLIENT_HANDLER_H_
#define _SECURE_COMM_COMMUNICATION_ADAPTER_CLIENT_HANDLER_H_

#include "sccommclient.h"
#include "cshandler.h"
#include <functional>

//Client core library does NOT use the below code
#include <deque>
namespace SC { namespace ClientSide {

	class CClientHandlerBase;
	class CAsyncResult;

	typedef std::function<void(CAsyncResult&) > ResultHandler;
	typedef std::function<bool(unsigned short, CBuffer&) > ResultHandlerEx;

	typedef std::function<void(CSender &sender, const CComVariant &msg) > DOnSendUserMessage;
	typedef std::function<void(CSender &sender, const CComVariant &msg, const unsigned int *topics, unsigned int count)> DOnPublish;
	typedef std::function<void(CSender &sender, const unsigned int *topics, unsigned int count) > DOnSubscribe;
	typedef DOnSubscribe DOnUnsubscribe;

	struct CMessageDelegates
	{
		DOnSendUserMessage OnSendUserMessage;
		DOnPublish OnPublish;
		DOnSubscribe OnSubscribe;
		DOnUnsubscribe OnUnsubscribe;
	};

	class CAsyncResult {
	private:
		CAsyncResult(CClientHandlerBase *pAsyncHandler, unsigned short ReqId, CBuffer &buffer, ResultHandler & rh)
			: AsyncHandler(pAsyncHandler), RequestId(ReqId), Buffer(buffer), CurrentAsyncResultHandler(rh) {
		}

	public:
		template<class ctype >
		CBuffer& operator >>(ctype & receiver) {
			Buffer >> receiver;
			return Buffer;
		}

	public:
		CClientHandlerBase *AsyncHandler;
		unsigned short RequestId;
		CBuffer &Buffer;
		ResultHandler &CurrentAsyncResultHandler;

	private:
		//disable copy constructor and assignment operator
		CAsyncResult(const CAsyncResult & ar);
		CAsyncResult& operator=(const CAsyncResult & ar);

		friend class CClientHandlerBase;
	};

	class CClientHandlerBase : public CHandler
	{
	protected:
		CClientHandlerBase(const char *host, unsigned int port, const char *certCN, unsigned int timedout = DEFAULT_RECV_TIMEOUT, bool autoConnecting = false, bool v6 = false)
			: CHandler(nullptr),
			m_pException(nullptr)
		{
			m_pSession = ::DoClientConnection(this, host, port, certCN, timedout, autoConnecting, v6);
			DelaySet(m_pSession);
		}

		virtual ~CClientHandlerBase() {
			Destroy();
			CAutoLock al(m_cs);
			delete m_pException;
		}

	public:
		virtual bool DoAuthentication(const wchar_t *userId, const wchar_t *pwd, const wchar_t *machineName = nullptr, SC_COMMUNICATION_SERVICE serviceId = 0, unsigned int version = SC_INITIAL_COMM_VERSION)
		{
			std::wstring mn(machineName ? machineName : L"");
			if (!mn.size()) {
				char str[256] = { 0 };
				::gethostname(str, sizeof(str));
				mn = SC::ToWide(str);
			}
			mn += SC_STRING_SEPARATOR;
			std::string appname = SC::GetAppName();
			mn += SC::ToWide(appname.c_str(), appname.size());
			CScopeBuffer sb;
			sb << version << serviceId << userId << pwd << mn;
			m_ServiceId = serviceId;
			bool ok = (SendRequest(idAuthentication, sb->GetBuffer(), sb->GetSize(), [this](CAsyncResult &ar){
				ar >> this->m_nPeerVersion;
			}) == sb->GetSize());
			//better security
			sb->SetSize(0);
			sb->CleanTrack();
			return (ok && WaitAll());
		}

		//add more arguments here if neccessary

		inline bool IsAutoConnecting() const
		{
			return m_pSession->IsAutoConnecting();
		}

		inline bool IsConnected() const
		{
			return (m_pSession->GetSessionState() >= ssConnected);
		}

		inline SC_SERVER_VERSION GetServerVersion()
		{
			return GetPeerVersion();
		}

		inline size_t GetQueuedRequestCount() const
		{
			return m_pSession->GetRequestCountQueued();
		}

		inline const ICertificate* const GetSelfCert() const {
			return m_pSession->GetSelfCert();
		}

		CException GetLastServerException(unsigned short *pExceptionRequestId = nullptr)
		{
			CAutoLock al(m_cs);
			if (pExceptionRequestId)
				*pExceptionRequestId = m_nExceptionRequestId;
			if (m_pException)
				return *m_pException;
			return CException("", "", ERROR_OK);
		}

		virtual unsigned short GetCurrentRequestId()
		{
			CAutoLock al(m_cs);
			return CHandler::GetCurrentRequestId();
		}

		void SetDelegate(ResultHandlerEx rhe)
		{
			CAutoLock al(m_cs);
			m_rhe = rhe;
		}

		ResultHandlerEx GetDelegate()
		{
			CAutoLock al(m_cs);
			return m_rhe;
		}

		void SetMessageDelegates(const CMessageDelegates &md)
		{
			CAutoLock al(m_cs);
			m_md = md;
		}

		const CMessageDelegates& GetMessageDelegates()
		{
			CAutoLock al(m_cs);
			return m_md;
		}

		bool WaitConnection(unsigned int ms = DEFAULT_CONN_TIMEOUT) {
			return m_pSession->WaitConnection(ms);
		}

		virtual unsigned int SendRequest(unsigned short reqId, const unsigned char *pBuffer, unsigned int size, const ResultHandler &rh)
		{
			CAutoLock al(m_cs);
			unsigned int res = m_pSession->Send(reqId, pBuffer, size, !rh);
			if (rh && res != SESSION_CLOSED && res != BAD_REQUEST) {
				m_qCallback.push_back(std::pair<unsigned short, ResultHandler>(reqId, rh));
			}
			return res;
		}

		virtual bool WaitAll(unsigned int ms = (~0)) const
		{
			return m_pSession->WaitAll(ms);
		}

		unsigned int SendRequest(unsigned short reqId, const ResultHandler &rh) {
			return SendRequest(reqId, (const unsigned char*)nullptr, (unsigned int)0, rh);
		}

		template<typename T0>
		std::string ProcessRequestA(unsigned short id, T0 arg0, bool oneway = false) noexcept(false)
		{
			CScopeBuffer sb;
			sb << arg0;
			return ProcessRequest<std::string>(id, sb->GetBuffer(), sb->GetSize(), oneway);
		}

		template<typename T0, typename T1>
		std::string ProcessRequestA(unsigned short id, T0 arg0, T1 arg1, bool oneway = false) noexcept(false)
		{
			CScopeBuffer sb;
			sb << arg0 << arg1;
			return ProcessRequest<std::string>(id, sb->GetBuffer(), sb->GetSize(), oneway);
		}

		std::string ProcessRequestA(unsigned short id, bool oneway = false) noexcept(false)
		{
			return ProcessRequest<std::string>(id, nullptr, (unsigned int)0, oneway);
		}

		template<typename T0>
		std::wstring ProcessRequest(unsigned short id, T0 arg0, bool oneway = false) noexcept(false)
		{
			CScopeBuffer sb;
			sb << arg0;
			return ProcessRequest<std::wstring>(id, sb->GetBuffer(), sb->GetSize(), oneway);
		}

		template<typename T0, typename T1>
		std::wstring ProcessRequest(unsigned short id, T0 arg0, T1 arg1, bool oneway = false) noexcept(false)
		{
			CScopeBuffer sb;
			sb << arg0 << arg1;
			return ProcessRequest<std::wstring>(id, sb->GetBuffer(), sb->GetSize(), oneway);
		}

		std::wstring ProcessRequest(unsigned short id, bool oneway = false) noexcept(false)
		{
			return ProcessRequest<std::wstring>(id, nullptr, (unsigned int)0, oneway);
		}

		template<typename T0, typename R>
		R ProcessRequest(unsigned short id, T0 t0, bool oneway = false) noexcept(false)
		{
			CScopeBuffer sb;
			sb << t0;
			return ProcessRequest<R>(id, sb->GetBuffer(), sb->GetSize(), oneway);
		}

		template<typename T0, typename T1, typename R>
		R ProcessRequest(unsigned short id, T0 t0, T1 t1, bool oneway = false) noexcept(false)
		{
			CScopeBuffer sb;
			sb << t0 << t1;
			return ProcessRequest<R>(id, sb->GetBuffer(), sb->GetSize(), oneway);
		}

		template<typename R>
		R ProcessRequest(unsigned short id, const unsigned char *buffer, unsigned int bytes, bool oneway = false) noexcept(false)
		{
			CScopeBuffer sb;
			bool ok = ProcessRequestSync(id, buffer, bytes, *sb, oneway);
			if (!ok) {
				//cye: this is a potential bug leading to crash if a caller forgets catching
				std::string errMsg = GetErrMsg();
				throw CExCode(errMsg.c_str(), GetErrCode()); //socket connection error exception
			}
			R res;
			if (!oneway)
			{
				sb >> res;
			}
			return res;
		}

		template<typename T0>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2, typename T3>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2 << t3;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2, typename T3, typename T4>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2 << t3 << t4;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2 << t3 << t4 << t5;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2 << t3 << t4 << t5 << t6;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const T7 &t7, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2 << t3 << t4 << t5 << t6 << t7;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const T7 &t7, const T8 &t8, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2 << t3 << t4 << t5 << t6 << t7 << t8;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

        template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9>
        unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const T7 &t7, const T8 &t8, const T9 &t9, const ResultHandler &rh) {
           CScopeBuffer sb;
            sb << t0 << t1 << t2 << t3 << t4 << t5 << t6 << t7 << t8 << t9;
            return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
        }

	protected:
		//add the following virtual function to avoid PureCallhandler under an extremely corner case/m_sc->OnSslHandshake(&m_ch);@SC::ClientSide::CSslSession::OnWritable
		virtual void OnSslHandshake(SC::ITLSProtocol *tls) {

		}

		virtual void OnArrive() {

		}

		virtual void OnServerException(const CException * const exception, bool found) {

		}

		virtual bool ProcessRequestSync(unsigned short reqId, const unsigned char *pBuffer, unsigned int size, CBuffer &res, bool oneway = false)
		{
			if (!pBuffer)
			{
				size = 0;
			}
			res.SetSize(0);
			delete m_pException;
			m_pException = nullptr;
			ResultHandler rh;
			if (!oneway)
			{
				rh = [&res](CAsyncResult &ar) {
					ar.Buffer.Swap(res);
				};
			}
			bool ok = (SendRequest(reqId, pBuffer, size, rh) == size && WaitAll());
			if (!ok) {
				//throw CExCode(GetErrMsg().c_str(), GetErrCode());
			}
			else if (m_pException) {
				//cye: this is a potential bug leading to crash if a caller forgets catching
				throw CException(*m_pException); //we find a server exception
			}
			return ok;
		}

	private:
		virtual void OnAborted() final {
			OnClosed();
			CAutoLock al(m_cs);
			m_qCallback.clear();
		}

		void Destroy() {
			if (!m_pSession) {
				return;
			}
			::DestroyClient(m_pSession);
			m_pSession = nullptr;
		}

		//don't overwrite this version Arrive from your class
		virtual void OnArrive(unsigned short RequestId, unsigned int size) final
		{
			std::pair<unsigned short, ResultHandler> rr;
			{
				CAutoLock al(m_cs);
				CHandler::OnArrive(RequestId, size);
			}

			if (RequestId != idServerException)
			{
				{
					CAutoLock al(m_cs);
					if (m_qCallback.size() && m_qCallback.front().first == RequestId)
					{
						rr = m_qCallback.front();
						m_qCallback.pop_front();
					}
				}
				if (rr.second)
				{
					CAsyncResult ar(this, RequestId, GetBuffer(), rr.second);
					rr.second(ar);
				}
				else
				{
					CBuffer &buff = GetBuffer();
					bool processed = true;
					{
						CAutoLock al(m_cs);
						switch (RequestId) {
							case idExit:
							case idJoin:
								{
									unsigned int topics;
									CSender sender;
									buff >> sender >> topics;
									if (RequestId == idJoin) {
										if (m_md.OnSubscribe) {
											m_md.OnSubscribe(sender, (const unsigned int*)buff.GetBuffer(), topics);
										}
									}
									else {
										if (m_md.OnUnsubscribe) {
											m_md.OnUnsubscribe(sender, (const unsigned int*)buff.GetBuffer(), topics);
										}
									}
									buff.SetSize(0);
								}
								break;
							case idPublish:
								{
									unsigned int topics;
									CComVariant vtMsg;
									CSender sender;
									buff >> sender >> vtMsg >> topics;
									if (m_md.OnPublish) {
										m_md.OnPublish(sender, vtMsg, (const unsigned int*)buff.GetBuffer(), topics);
									}
									buff.SetSize(0);
								}
								break;
							case idSendUserMessage:
								{
									CComVariant vtMsg;
									CSender sender;
									buff >> sender >> vtMsg;
									if (m_md.OnSendUserMessage) {
										m_md.OnSendUserMessage(sender, vtMsg);
									}
									buff.SetSize(0);
								}
								break;
							default:
								processed = false;
								if (m_rhe) {
									processed = m_rhe(RequestId, GetBuffer());
								}
								break;
						}
					}
					if (!processed) {
						OnArrive();
					}
				}
			}
			else
			{
				int errCode;
				std::string errMsg;
				std::string stack;
				GetBuffer() >> errCode >> errMsg >> stack;
				{
					CAutoLock al(m_cs);
					delete m_pException;
					m_pException = new CException(errMsg.c_str(), stack.c_str(), errCode);
					m_nExceptionRequestId = CHandler::GetCurrentRequestId();
					if (m_qCallback.size() && m_qCallback.front().first == m_nExceptionRequestId)
					{
						rr = m_qCallback.front();
						m_qCallback.pop_front();
					}
					else {
						rr.first = 0;
					}
				}
				OnServerException(m_pException, rr.first != 0);
			}
		}

		//no copy constructor and assigment operator
		CClientHandlerBase(const CClientHandlerBase &handler);
		CClientHandlerBase& operator=(const CClientHandlerBase &handler);

	private:
		IClientSession *m_pSession;
		CException *m_pException; //protected by m_cs
		unsigned short m_nExceptionRequestId; //protected by m_cs
		CMDTCriticalSection m_cs;
		typedef std::deque< std::pair<unsigned short, ResultHandler> > CRHQueue;
		CRHQueue m_qCallback; //protected by m_cs
		ResultHandlerEx m_rhe; //protected by m_cs
		CMessageDelegates m_md; //protected by mcs
	};
} //namespace ClientSide
} //namespace SC

#endif