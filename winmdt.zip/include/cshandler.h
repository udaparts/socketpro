

#ifndef _SECURE_COMMUNICATION_ADAPTER_HANDLER_BASE_H_
#define _SECURE_COMMUNICATION_ADAPTER_HANDLER_BASE_H_

#include "sccomm.h"

#include "membuffer.h"

namespace SC {

	//version control
	typedef SC_PEER_VERSION SC_CLIENT_VERSION;
	typedef SC_PEER_VERSION SC_SERVER_VERSION;
	typedef unsigned int SC_COMMUNICATION_SERVICE;
	static const unsigned int SC_INITIAL_COMM_VERSION = 1; //0 -- before 7.02, 1 -- beginning from 7.02

	//file implementation request ids
	static const unsigned short idStartDownloadFile = SC::idStartRequestId + 0x6FF0;
	static const unsigned short idStartUploadFile = idStartDownloadFile + 1;
	static const unsigned short idDataFromServerToClient = idStartUploadFile + 1;
	static const unsigned short idDataFromClientToServer = idDataFromServerToClient + 1;
	static const unsigned short idEndDownloadFile = idDataFromClientToServer + 1;
	static const unsigned short idEndUploadFile = idEndDownloadFile + 1;
	static const unsigned short idEnableMD5 = idEndUploadFile + 1; //wincomm 8.0 or later

	static const unsigned int SC_FILE_CHUNK_SIZE = 20480; //20 k

	//Server base topic ids
	static const unsigned int SERVER_BASE_TOPIC = 0x80000000; //reserved for future
	static const unsigned int AUTOSAVE_BASE_TOPIC = 0x40000000;
	static const unsigned int AGENT_BASE_TOPIC = 0x20000000;
	static const unsigned int TSC_BASE_TOPIC = 0x10000000;
	
	//server base topic ids reserved for future
	static const unsigned int SF0_BASE_TOPIC = 0x8000000;
	static const unsigned int SF1_BASE_TOPIC = 0x4000000;
	static const unsigned int SF2_BASE_TOPIC = 0x2000000;
	static const unsigned int SF3_BASE_TOPIC = 0x1000000;

	class CHandler : protected ISessionCallback
	{
	protected:
		virtual ~CHandler(){}

	public:
		inline tagSessionState GetSessionState() const
		{
			return m_s->GetSessionState();
		}

		inline void PostClose(DWORD errCode = 0) const
		{
			m_s->PostClose(errCode);
		}

		inline unsigned int GetSendingBufferSize() const
		{
			return m_s->GetSendingBufferSize();
		}

		virtual HRESULT GetErrCode()
		{
			return m_s->GetErrCode();
		}

		inline bool IsDiffEndian() const
		{
			return m_s->IsDiffEndian();
		}

		inline const ICertificate* const GetCertificate() const
		{
			return m_s->GetCertificate();
		}

		virtual std::string GetErrMsg()
		{
			CScopeBuffer sb;
			unsigned int size = m_s->GetErrMsg((char*)sb->GetBuffer(), sb->GetMaxSize());
			return (const char*)sb->GetBuffer();
		}

		virtual std::wstring GetErrMsgW()
		{
			CScopeBuffer sb;
			unsigned int size = m_s->GetErrMsg((wchar_t*)sb->GetBuffer(), sb->GetMaxSize()/sizeof(wchar_t));
			return (const wchar_t*)sb->GetBuffer();
		}

		inline std::string GetPeerName(unsigned int *port = nullptr) const
		{
			char name[128] = {0};
			unsigned int p = m_s->GetPeerName(name, sizeof(name));
			if (port) {
				*port = p;
			}
			return name;
		}

		inline std::string GetSockName(unsigned int *port = nullptr) const
		{
			char name[128] = {0};
			unsigned int p = m_s->GetSockName(name, sizeof(name));
			if (port) {
				*port = p;
			}
			return name;
		}

		virtual unsigned short GetCurrentRequestId() const
		{
			return m_nCurrentRequestId;
		}

		inline CBuffer& GetBuffer()
		{
			return m_Buffer;
		}

		inline SC_COMMUNICATION_SERVICE GetServiceId() const {
			return m_ServiceId;
		}

		virtual SC_PEER_VERSION GetPeerVersion() {
			return m_nPeerVersion;
		}

	protected:
		CHandler(ISession *session) 
			: m_ServiceId(0),
			m_nPeerVersion(SC_INITIAL_COMM_VERSION),
			m_s(session),
			m_nCurrentRequestId(0) {
		}

		virtual void OnLess() {

		}

		virtual void OnClosed() {
			
		}

		virtual void OnArrive(unsigned short RequestId, unsigned int size)
		{
			m_Buffer.SetSize(0);
			if (size > m_Buffer.GetMaxSize())
			{
				m_Buffer.ReallocBuffer(size + 16);
			}
			unsigned int res = m_s->Retrieve((unsigned char*)m_Buffer.GetBuffer(), size);
			assert(res == size);
			m_Buffer.SetSize(res);
			if (RequestId == idServerException)
			{
				GetBuffer() >> m_nCurrentRequestId;
			}
			else
			{
				m_nCurrentRequestId = RequestId;
			}
		}

		void DelaySet(ISession *session) 
		{
			m_s = session;
		}

	private:
		//disable copy constructor and assignment operator
		CHandler(const CHandler &handler);
		CHandler& operator=(const CHandler &handler);

	protected:
		SC_COMMUNICATION_SERVICE m_ServiceId;
		SC_PEER_VERSION m_nPeerVersion;

	private:
		ISession *m_s;
		unsigned short m_nCurrentRequestId;
		CBuffer m_Buffer;
	};

} //namespace SC

#endif