#ifndef _SECURE_COMM_COMMUNICATION_ADAPTER_SERVER_HANDLER_H_
#define _SECURE_COMM_COMMUNICATION_ADAPTER_SERVER_HANDLER_H_

#include "sccommserver.h"
#include "cshandler.h"
#include <deque>
#include <algorithm>
#include <iostream>

//Server core library does NOT use the below code
namespace SC { namespace ServerSide {

	class CServerHandlerBase;

	extern CMDTCriticalSection g_csHandler;
	extern std::vector<CServerHandlerBase *> g_vActiveHandler;
	extern std::deque<CServerHandlerBase *> g_vHandler;

	class CServerHandlerBase : public CHandler
	{
	protected:
		virtual ~CServerHandlerBase(){}
		CServerHandlerBase(IServerSession *session)
			: CHandler(session),
			m_pSession(session)
		{

		}

	public:

		inline void SetClientMachineName(const wchar_t *clientMachineName) const {
			m_pSession->SetClientMachineName(clientMachineName);
		}

		const wchar_t* GetClientMachineName() const {
			return m_pSession->GetClientMachineName();
		}

		std::wstring GetMachineName() const {
			return m_pSession->GetClientMachineName();
		}

		inline void SetClientAppName(const wchar_t *clientAppName) const {
			m_pSession->SetClientAppName(clientAppName);
		}

		inline const wchar_t* GetClientAppName() const {
			return m_pSession->GetClientAppName();
		}

		inline void SetUserId(const wchar_t *userId) const {
			m_pSession->SetUserId(userId);
		}

		inline unsigned __int64 GetServerPointer() const {
			return m_pSession->GetServerPointer();
		}

		inline const wchar_t* GetUserId() const {
			return m_pSession->GetUserId();
		}

		virtual unsigned int SubScribe(const unsigned int *topics, unsigned int count) {
			return m_pSession->SubScribe(topics, count);
		}

		virtual unsigned int SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName = nullptr, const wchar_t* machineName = nullptr) const {
			return m_pSession->SendUserMessage(receiver, vtMsg, appName, machineName);
		}

		virtual unsigned int PublishMessage(const VARIANT &vtMsg, const unsigned int *topics, unsigned int count) const {
			return m_pSession->PublishMessage(vtMsg, topics, count);
		}

		inline bool StartThreadProcessing() const {
			return m_pSession->StartThreadProcessing();
		}

		inline bool EndThreadProcessing() const {
			return m_pSession->EndThreadProcessing();
		}

		inline SC_CLIENT_VERSION GetClientVersion() {
			return GetPeerVersion();
		}

		virtual unsigned int Send(unsigned short reqId, const unsigned char *pBuffer, unsigned int size) const {
			return m_pSession->Send(reqId, pBuffer, size);
		}

		unsigned int Send(const unsigned char *pBuffer, unsigned int size) const
		{
			return m_pSession->Send(GetCurrentRequestId(), pBuffer, size);
		}

		unsigned int Send(unsigned short reqId) const
		{
			return m_pSession->Send(reqId, (const unsigned char *)nullptr, (unsigned int)0);
		}

		unsigned int Send() const
		{
			return m_pSession->Send(GetCurrentRequestId(), (const unsigned char *)nullptr, (unsigned int)0);
		}

		//R0 could be std::string, std::wstring, CString, CComBSTR, primitive data types ......
		template<typename R0>
		unsigned int Send(const R0 &r0) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1>
		unsigned int Send(const R0 &r0, const R1 &r1) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2, typename R3>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2, const R3 &r3) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2 << r3;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2, typename R3, typename R4>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2, const R3 &r3, const R4 &r4) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2 << r3 << r4;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2, typename R3, typename R4, typename R5>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2, const R3 &r3, const R4 &r4, const R5 &r5) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2 << r3 << r4 << r5;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2, typename R3, typename R4, typename R5, typename R6>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2, const R3 &r3, const R4 &r4, const R5 &r5, const R6 &r6) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2 << r3 << r4 << r5 << r6;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2, typename R3, typename R4, typename R5, typename R6, typename R7>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2, const R3 &r3, const R4 &r4, const R5 &r5, const R6 &r6, const R7 &r7) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2 << r3 << r4 << r5 << r6 << r7;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2, typename R3, typename R4, typename R5, typename R6, typename R7, typename R8>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2, const R3 &r3, const R4 &r4, const R5 &r5, const R6 &r6, const R7 &r7, const R8 &r8) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2 << r3 << r4 << r5 << r6 << r7 << r8;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename R0, typename R1, typename R2, typename R3, typename R4, typename R5, typename R6, typename R7, typename R8, typename R9>
		unsigned int Send(const R0 &r0, const R1 &r1, const R2 &r2, const R3 &r3, const R4 &r4, const R5 &r5, const R6 &r6, const R7 &r7, const R8 &r8, const R9 &r9) const
		{
			unsigned short reqId = GetCurrentRequestId();
			CScopeBuffer sb;
			sb << r0 << r1 << r2 << r3 << r4 << r5 << r6 << r7 << r8 << r9;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		virtual unsigned int SendException(unsigned short CurrentRequestId, int errCode, const char *const errMessage, const char *const stack) const
		{
			return m_pSession->SendException(CurrentRequestId, errCode, errMessage, stack);
		}

		inline unsigned int SendException(unsigned short CurrentRequestId, const CException &err) const
		{
			return SendException(CurrentRequestId, err.GetErrCode(), err.what(), err.GetStack());
		}

		inline const std::wstring& GetPassword() const {
			return m_password;
		}

	public:
		template <typename ServerHandler>
		static ISessionCallback* CALLBACK OnAccepted(IServerSession *session)
		{
			assert(session); //valid session pointer required!
			ServerHandler *sh = new ServerHandler(session);
			if (sh) {
				CAutoLock al(g_csHandler);
				g_vActiveHandler.push_back(sh);
			}
			return sh;
		}

		static CServerHandlerBase* Find(unsigned __int64 serverPointer) {
			CAutoLock al(g_csHandler);
			auto it = std::find_if(g_vActiveHandler.cbegin(), g_vActiveHandler.cend(), [serverPointer](CServerHandlerBase *shb)->bool {
				return (shb->GetServerPointer() == serverPointer);
			});
			if (it != g_vActiveHandler.cend()) {
				return *it;
			}
			return nullptr;
		}

	protected:
		//use this version Arrive instead for auto-tracking exception
		virtual void OnArrive() = 0;
		virtual bool IsPermitted(SC_SERVER_VERSION &serverVersion) = 0;
		
	private:
		//no copy constructor and assigment operator
		CServerHandlerBase(const CServerHandlerBase &handler);
		CServerHandlerBase& operator=(const CServerHandlerBase &handler);

		virtual void OnAborted() final
		{
			{
				CAutoLock al(g_csHandler);
				auto it = std::find(g_vActiveHandler.begin(), g_vActiveHandler.end(), this);
				if (it != g_vActiveHandler.end()) {
					g_vActiveHandler.erase(it);
				}
			}
			OnClosed();
			CAutoLock al(g_csHandler);
			g_vHandler.push_back(this);
			while (g_vHandler.size() > 3) {
				CServerHandlerBase *shb = g_vHandler.front();
				g_vHandler.pop_front();
				try {
					if (shb) {
						delete shb;
					}
				}
#ifdef _M_CEE
				catch (System::Exception ^err) { 
					System::String ^errMsg = err->Message;
					System::String ^stack = err->StackTrace;
					System::String ^strOutput = System::String::Format("Error code: {0}, message: {1}, stack: {2}", err->HResult, errMsg, stack);
					pin_ptr<const wchar_t> s = PtrToStringChars(strOutput);
					::OutputDebugStringW((const wchar_t *)s);
					std::wcout << (const wchar_t *)s << std::endl;
				}
#endif
				catch(...) { }
			}
		}

		//don't overwrite this version Arrive from your class
		virtual void OnArrive(unsigned short RequestId, unsigned int size) final {
			try {
				CHandler::OnArrive(RequestId, size);
				if (idAuthentication == RequestId) {
					try {
						std::wstring machineName, userId;
						GetBuffer() >> m_nPeerVersion >> m_ServiceId >> userId >> m_password >> machineName;
						SC_SERVER_VERSION version = SC_INITIAL_COMM_VERSION;
						size_t pos = machineName.find(SC_STRING_SEPARATOR);
						if (pos != machineName.npos) {
							std::wstring mn = machineName.substr(0, pos);
							m_pSession->SetClientMachineName(mn.c_str());
							size_t start = pos + ::wcslen(SC_STRING_SEPARATOR);
							pos = machineName.find(SC_STRING_SEPARATOR, start);
							m_pSession->SetClientAppName(machineName.substr(start, pos).c_str());
						}
						else {
							m_pSession->SetClientMachineName(machineName.c_str());
						}
						m_pSession->SetUserId(userId.c_str());
						if (!IsPermitted(version)) {
							PostClose();
						} else {
							Send(SC::idAuthentication, version);
						}
					}
					catch(...) {
						PostClose();
					}
					//for better security
					::memset((unsigned char*)m_password.data(), 0, m_password.size() * sizeof(wchar_t));
					m_password.clear();
				}
				else {
					OnArrive();
				}
			}
			catch(const CException& ex) {
				SendException(RequestId, ex);
			}
			catch(const std::exception &err) {
				CException ex(err, __FILE__, __LINE__, __FUNCTION__);
				SendException(RequestId, ex);
			}
#ifdef _M_CEE
			catch (System::Exception ^err) {
				USES_CONVERSION;
				pin_ptr<const wchar_t> str = PtrToStringChars(err->Message);
				pin_ptr<const wchar_t> stack = PtrToStringChars(err->StackTrace);
				m_pSession->SendException(RequestId, err->HResult, ToUTF8((const wchar_t*)str).c_str(), ToUTF8((const wchar_t*)stack).c_str());
			}
#endif
			catch(...)
			{
				m_pSession->SendException(RequestId, ERROR_UNKNOWN, "Unknown C++ exception error", __FUNCTION__);
			}
		}

	private:
		IServerSession *m_pSession;
		std::wstring m_userId;
		std::wstring m_password;
	};
} //namespace ServerSide
} //namespace SC

#endif