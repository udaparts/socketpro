
#ifndef __MDT_SOFTWARE_HAND_SHAKE_STAGE_H_
#define __MDT_SOFTWARE_HAND_SHAKE_STAGE_H_

#include <string>

namespace SC
{
	enum tagHandshakeType
	{
		hello_request = 0,
		client_hello = 1,
		server_hello = 2,
		new_session_ticket = 4,
		end_of_early_data = 5,
		encrypted_extensions = 8,
		certificate = 11,
		server_key_exchange = 12,
		certificate_request = 13,
		server_hello_done = 14,
		certificate_verify = 15,
		client_key_exchange = 16,
		finished = 20,
		key_update = 24,
		message_hash = 254
	};

	enum tagProtocol
	{
		SSL2_0 = 0x0002, //not supported
		SSL3_0 = 0x0300,
		TLSv1_0 = 0x0301,
		TLSv1_1 = 0x0302,
		TLSv1_2 = 0x0303,
		TLSv1_3 = 0x0304
	};

	enum tagContentType
	{
		invalid = 0,
		change_cipher_spec = 20,
		alert = 21,
		handshake = 22,
		application_data = 23
	};

	struct ITLSProtocol
	{
		virtual tagContentType GetContentType() const = 0;
		virtual tagProtocol GetProtocolVersion() const = 0;
		virtual tagHandshakeType GetHandshakeType() const = 0;
		virtual tagProtocol GetVersion() const = 0;
		virtual const char* GetCiphers() const = 0;
	};

} //namespace SC

#endif