
#ifndef	___WIN_UCOMM__UTIL_HEADER_FILE___H___
#define ___WIN_UCOMM__UTIL_HEADER_FILE___H___

#include <exception>
#include <string>
#include <sstream>

namespace SC {
	const static int ERROR_OK = 0;
	const static int ERROR_UNKNOWN = -1;
	const static int ERROR_DOTNET_EXCEPTION = -2;
	const static int ERROR_DESERIALIZATION = -3;
	const static int ERROR_NOT_SUPPORTED_DATA_TYPE = -4;
	
	static std::string ToUTF8(const wchar_t *str, size_t src_len = (~0));

	/** 
	* A class for managing SPA exception on window platforms
	* The class tracks error stack for error message, function name, line number and file name
	*/
	class CException : public std::exception {
	public:

		/**
		* Create an instance of CException
		* @param errMsg Error message
		* @param file A C/C++ file name
		* @param line Line number where the exception is created
		* @param funcName A function name string
		* @param errCode A given error code with default to -1 (ERROR_UNKNOWN)
		*/
		CException(const char * const errMsg, const char *file, unsigned int line, const char *funcName, int errCode = ERROR_UNKNOWN)
			: std::exception(errMsg ? errMsg : ""), m_errCode(errCode) {
				std::ostringstream ss;
				ss << "function: " << funcName << "@line: " << line << " of file: " << file;
				m_stack = ss.str();
		}

		/**
		* Create an instance of CException
		* @param errMsg Error message
		* @param file A C/C++ file name
		* @param line Line number where the exception is created
		* @param funcName A function name string
		* @param errCode A given error code with default to -1 (ERROR_UNKNOWN)
		*/
		CException(const wchar_t * const errMsg, const char *file, unsigned int line, const char *funcName, int errCode = ERROR_UNKNOWN)
			: std::exception(ToUTF8(errMsg ? errMsg : L"").c_str()), m_errCode(errCode) {
				std::ostringstream ss;
				ss << "function: " << funcName << "@line: " << line << " of file: " << file;
				m_stack = ss.str();
		}

		/**
		* Create an instance of CException
		* @param errMsg Error message
		* @param stack A string for error location of source file
		* @param errCode A given error code with default to -1 (unavailable)
		*/
		CException(const char * const errMsg, const char *stack = "", int errCode = ERROR_UNKNOWN)
			: std::exception(errMsg ? errMsg : ""), m_errCode(errCode), m_stack(stack ? stack : "") {

		}

		/**
		* Create an instance of CException
		* @param errMsg Error message
		* @param stack A string for error location of source file
		* @param errCode A given error code with default to -1 (unavailable)
		*/
		CException(const wchar_t * const errMsg, const char *stack = "", int errCode = ERROR_UNKNOWN)
			: std::exception(ToUTF8(errMsg ? errMsg : L"").c_str()), m_errCode(errCode), m_stack(stack ? stack : "") {

		}

		/**
		* Create an instance of CException from an instance of std::exception with no error code available
		*/
		explicit CException(const std::exception &ex, const char *file, unsigned int line, const char *funcName, int errCode = ERROR_UNKNOWN)
			: std::exception(ex),
			m_errCode(ERROR_UNKNOWN) {
			std::ostringstream ss;
			ss << "function: " << funcName << "@line: " << line << " of file: " << file;
			m_stack = ss.str();
		}

		/**
		* Create an instance of CException from an instance of CMBExption
		*/
		CException(const CException &ex)
			: std::exception(ex),
			m_errCode(ex.m_errCode),
			m_stack(ex.m_stack) {
		}

	public:

		/**
		* Copy an instance of CException from an instance of CMBExption
		*/
		CException& operator=(const CException &ex) {
			if (&ex == this)
				return *this;
			std::exception &e = *this;
			e = ex;
			m_errCode = ex.m_errCode;
			m_stack = ex.m_stack;
			return *this;
		}

		/**
		* Create an instance of CException from an instance of std::exception
		*/
		CException& operator=(const std::exception &ex) {
			std::exception &e = *this;
			e = ex;
			m_errCode = ERROR_UNKNOWN;
			m_stack.clear();
			return *this;
		}

		/**
		* Get error code, and -1 means there is no error code available
		* @return An error code
		*/
		int GetErrCode() const {
			return m_errCode;
		}

		/**
		* Get error stack
		* @return An error stack describing error location
		*/
		const char* GetStack() const {
			return m_stack.c_str();
		}

	private:
		int m_errCode;

	protected:
		std::string m_stack;
	};
};

#define CExCode(errMsg, errCode)  SC::CException(errMsg, __FILE__, __LINE__, __FUNCTION__, errCode)
#define CSEx(errMsg) CExCode(errMsg, ERROR_DESERIALIZATION)

#endif
