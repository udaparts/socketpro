
#pragma once

#include <fstream>

#ifdef SC_NET_CLIENT
namespace SCNet
{
	namespace ClientSide
	{
		ref class CScFile;
	}
};

#endif

namespace SC{ namespace ClientSide {

class CScFile {
public:
	CScFile(CClientHandlerBase &handler)
		: m_Handler(handler),
	m_nFileSize(~0),
	m_nPos(0),
	m_hFile(INVALID_HANDLE_VALUE),
	m_res(S_OK)
#ifdef _MDT_MD5_HASH_H_
	, m_bMd5(false)
	, m_bMd5Matched(TRUE)
#endif	
	{
#ifdef _MDT_MD5_HASH_H_
		MD5Init(&m_ctxMD5);
#endif
	}

	~CScFile() {
		m_Handler.SetDelegate(nullptr);
		Clean();
	}

	typedef std::function<void(CScFile*, unsigned __int64 pos) > DProgress;
	typedef std::function<void(CScFile*, int res) > DDone;

public:

#ifdef _MDT_MD5_HASH_H_
	bool EnableMD5(bool enabled = true) {
		m_cs.lock();
		m_bMd5 = enabled;
		m_cs.unlock();
		m_Handler.SendRequest(SC::idEnableMD5, enabled, [](CAsyncResult &ar) {
		});
		return enabled;
	}

	bool IsMD5Enabled()
	{
		m_cs.lock();
		bool enabled = m_bMd5;
		m_cs.unlock();
		return enabled;
	}

	BOOL IsMd5Matched()
	{
		m_cs.lock();
		bool matched = m_bMd5Matched;
		m_cs.unlock();
		return matched;
	}
#endif

	CClientHandlerBase& GetClientHandler() const {
		return m_Handler;
	}

	bool IsTransferring() {
		CAutoLock al(m_cs);
		return (m_hFile != INVALID_HANDLE_VALUE);
	}

	int UploadFile(const wchar_t *remoteFile, const wchar_t *localFile, unsigned int timeout, DDone done = nullptr)
	{
		Clean();
		int res = ERROR_SUCCESS;
		do {
			{
				CAutoLock al(m_cs);
				m_hFile = ::CreateFileW(localFile, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
				if (m_hFile == INVALID_HANDLE_VALUE) {
					res = (int)::GetLastError();
					break;
				}
				DWORD high;
				DWORD low = ::GetFileSize(m_hFile, &high);
				m_nFileSize = high;
				m_nFileSize <<= 32;
				m_nFileSize += low;
			}
			CScopeBuffer sb;
			sb << remoteFile;
#ifdef _MDT_MD5_HASH_H_
			m_cs.lock();
			if (m_bMd5) {
				MD5Init(&m_ctxMD5);
			}
			m_cs.unlock();
#endif
			unsigned int ret = m_Handler.SendRequest(idStartUploadFile, sb->GetBuffer(), sb->GetSize(), [this, done](CAsyncResult &ar) {
				int res;
				ar >> res;
				if (res) {
					m_cs.lock();
					m_res = res;
					m_cs.unlock();
					Clean();
				}
				else if (m_Handler.IsConnected()) {
					res = UploadFile(done);
					if (res) {
						Clean();
					}
				}
			});
			if (ret == SC::SESSION_CLOSED) {
				res = m_Handler.GetErrCode();
				break;
			}
		} while (false);
		m_cs.lock();
		m_res = res;
		m_cs.unlock();
		if (res) {
			Clean();
		}
		return res;
	}

	int DownloadFile(const wchar_t *remoteFile, const wchar_t *localFile, unsigned int timeout, DDone done = nullptr)
	{
		Clean();
		m_Handler.SetDelegate([this](unsigned short reqId, SC::CBuffer &buffer) -> bool {
			if (reqId != idDataFromServerToClient) {
				return false;
			}
			DWORD written = 0;
			this->m_cs.lock();
			BOOL ok = ::WriteFile(this->m_hFile, buffer.GetBuffer(), buffer.GetSize(), &written, nullptr);
			if (!ok) {
				m_res = (int)::GetLastError();
				this->m_cs.unlock();
				return false;
			}
			else {
				assert(buffer.GetSize() == written);
			}
			buffer.SetSize(0);
#ifdef _MDT_MD5_HASH_H_
			if (this->m_bMd5) {
				MD5Update(&this->m_ctxMD5, (unsigned char*)buffer.GetBuffer(), buffer.GetSize());
			}
#endif
			m_nPos += written;
			if (this->Progress) {
				unsigned __int64 pos = m_nPos;
				this->m_cs.unlock();
				this->Progress(this, pos);
			}
			else {
				this->m_cs.unlock();
			}
			return true;
		});
		int res = ERROR_SUCCESS;
		do {
			{
				CAutoLock al(m_cs);
				m_hFile = ::CreateFileW(localFile, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
				if (m_hFile == INVALID_HANDLE_VALUE) {
					res = (int)::GetLastError();
					m_res = res;
					break;
				}
				else {
					m_res = S_OK;
				}
			}
			CScopeBuffer sb;
			sb << remoteFile;
#ifdef _MDT_MD5_HASH_H_
			m_cs.lock();
			if (m_bMd5) {
				MD5Init(&m_ctxMD5);
			}
			m_cs.unlock();
#endif
			std::wstring fileMD5(localFile);
			fileMD5 += L".md5";
#ifdef _MDT_MD5_HASH_H_
			::DeleteFileW(fileMD5.c_str());
#endif
			unsigned int ret = m_Handler.SendRequest(idStartDownloadFile, sb->GetBuffer(), sb->GetSize(), [this, done, fileMD5](CAsyncResult &ar) {
				int res;
				{
					CAutoLock al(this->m_cs);
					ar >> this->m_nFileSize >> res;
					this->m_res = res;
				}
				if (res) {
					Clean();
					if (done) {
						done(this, res);
					}
				}
				else {
					unsigned int ret = m_Handler.SendRequest(idEndDownloadFile, (const unsigned char*)nullptr, (unsigned int)0, [this, done, fileMD5](CAsyncResult &ar) {
						{
							CAutoLock al(this->m_cs);
#ifdef _MDT_MD5_HASH_H_
							this->m_bMd5Matched = TRUE;
							if (this->m_bMd5 && ar.Buffer.GetSize()) {
								std::string rHash;
								ar >> rHash;
								char strMd5[MD5_HASH_STR_LEN] = {0};
								MD5FinalStr(&this->m_ctxMD5, strMd5);
								if (rHash == strMd5) {
									std::ofstream ofs(fileMD5.c_str(), std::ofstream::out | std::ofstream::app);
									if (ofs.is_open()) {
										ofs.write(strMd5, MD5_HASH_STR_LEN - 1);
									}
								}
								else {
									this->m_bMd5Matched = FALSE;
								}
							}
#endif
							::CloseHandle(this->m_hFile);
							this->m_hFile = INVALID_HANDLE_VALUE;
						}
						if (done) {
							done(this, 0);
						}
					});
					if (ret == SC::SESSION_CLOSED) {
						res = m_Handler.GetErrCode();
						m_cs.lock();
						m_res = res;
						m_cs.unlock();
						Clean();
					}
					assert(ret != SC::BAD_REQUEST);
				}
			});
			if (ret == SC::SESSION_CLOSED) {
				res = m_Handler.GetErrCode();
				m_cs.lock();
				m_res = res;
				m_cs.unlock();
				break;
			}
			assert(ret != SC::BAD_REQUEST);
		} while (false);
		if (res) {
			Clean();
		}
		return res;
	}

	inline unsigned __int64 GetFileSize() {
		CAutoLock al(m_cs);
		return m_nFileSize;
	}

	inline unsigned __int64 GetPos() {
		CAutoLock al(m_cs);
		return m_nPos;
	}

	inline int GetErrorCode()
	{
		CAutoLock al(m_cs);
		return m_res;
	}

	bool Clean() {
		bool cleaned = false;
		CAutoLock al(m_cs);
		if (m_hFile != INVALID_HANDLE_VALUE) {
#ifdef FILE_FLUSH_BEFORE_CLOSE
			BOOL ok = ::FlushFileBuffers(m_hFile);
			if (!ok) {
				DWORD errCode = ::GetLastError();
				if (ERROR_ACCESS_DENIED == errCode) {
					ok = TRUE;
				}
				else {
					assert(false);
				}
			}
			assert(ok);
#endif
			::CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
			cleaned = true;
		}
		m_nFileSize = (~0);
		m_nPos = 0;
		return cleaned;
	}

	DProgress Progress;

#ifdef SC_NET_CLIENT
	void SetProgress(SCNet::ClientSide::CScFile ^file);
	int DownloadFile(SCNet::ClientSide::CScFile ^file, System::String ^remoteFile, System::String ^localFile, unsigned int timeout);
	int UploadFile(SCNet::ClientSide::CScFile ^file, System::String ^remoteFile, System::String ^localFile, unsigned int timeout);
#endif

private:
	//disable copy constructor and assignment operator
	CScFile(const CScFile& file);
	CScFile& operator=(const CScFile& file);

	int UploadFile(DDone done) {
		unsigned int sendingBufferSize = m_Handler.GetSendingBufferSize();
		if (sendingBufferSize > 2 * SC_FILE_CHUNK_SIZE) {
			return ERROR_SUCCESS;
		}
		unsigned __int64 pos = 0;
		DWORD dw = 0;
		BOOL ok = TRUE;
		unsigned int len = 0;
		unsigned __int64 sent = 0;
		SC::CScopeBuffer sb(SC_FILE_CHUNK_SIZE + 16);
		{
			SC::CAutoLock al(m_cs);
			if (m_hFile != INVALID_HANDLE_VALUE) {
				ok = ::ReadFile(m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &dw, nullptr);
			}
			m_nPos += dw;
			unsigned int read = (unsigned int)dw;
			if (!ok) {
				m_res = ::GetLastError();
				return m_res;
			}
			else {
				m_res = S_OK;
			}
			sent += read;
			while (ok && read) {
#ifdef _MDT_MD5_HASH_H_
				if (m_bMd5) {
					MD5Update(&m_ctxMD5, (unsigned char*)sb->GetBuffer(), read);
				}
#endif
				len = m_Handler.SendRequest(idDataFromClientToServer, sb->GetBuffer(), read, [this, done](CAsyncResult &ar) {
					int res = this->UploadFile(done);
					if (res) {
						Clean();
						if (done) {
							done(this, res);
						}
					}
				});
				if (len == SC::SESSION_CLOSED) {
					m_res = m_Handler.GetErrCode();
					return m_res;
				}
				assert(len == read);
				sent += read;
				if (read < SC_FILE_CHUNK_SIZE) {
					break; //no more data to be read
				}
				sendingBufferSize = m_Handler.GetSendingBufferSize();
				if (sendingBufferSize > 10 * SC_FILE_CHUNK_SIZE) {
					break;
				}
				dw = 0;
				ok = TRUE;
				if (m_hFile != INVALID_HANDLE_VALUE) {
					ok = ::ReadFile(m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &dw, nullptr);
				}
				m_nPos += dw;
				if (!ok) {
					m_res = (int)::GetLastError();
					return m_res;
				}
				read = dw;
			}
			pos = m_nPos;
			if (sent && len != SC::SESSION_CLOSED && Progress) {
				Progress(this, pos);
			}
		}
		if (sent && pos == GetFileSize()) {
			::CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
			if (len != SC::SESSION_CLOSED) {
				sb->SetSize(0);
#ifdef _MDT_MD5_HASH_H_
				if (m_bMd5) {
					char strMd5[MD5_HASH_STR_LEN] = {0};
					MD5FinalStr(&m_ctxMD5, strMd5);
					sb << (const char *)strMd5;
				}
#endif
				//we need to inform server there is no more data to be uploaded
				m_Handler.SendRequest(idEndUploadFile, sb->GetBuffer(), sb->GetSize(), [this, done, pos](CAsyncResult &ar) {
#ifdef _MDT_MD5_HASH_H_
					this->m_cs.lock();
					if (ar.Buffer.GetSize() >= sizeof(this->m_bMd5Matched)) {
						ar.Buffer >> this->m_bMd5Matched;
					}
					else {
						this->m_bMd5Matched = TRUE;
					}
					this->m_cs.unlock();
#endif
					if (done) {
						done(this, 0);
					}
				});
			}
		}
		return ERROR_SUCCESS;
	}
	
private:
	CClientHandlerBase &m_Handler;
	unsigned __int64 m_nFileSize; //protected by m_cs
	unsigned __int64 m_nPos; //protected by m_cs
	HANDLE m_hFile; //protected by m_cs
	int m_res;
	CMDTCriticalSection m_cs;
#ifdef _MDT_MD5_HASH_H_
	MD5_CTX m_ctxMD5; //protected by m_cs;
	bool m_bMd5; //protected by m_cs;
	int m_bMd5Matched;
#endif
};

} //namespace ClientSide
} //namespace SC
