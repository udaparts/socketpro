

#ifndef _SECURE_COMMUNICATION_BASE_H_
#define _SECURE_COMMUNICATION_BASE_H_

#include <winerror.h>

#ifndef SECURITY_WIN32
#define SECURITY_WIN32
#endif

#include "storetype.h"
#include <windows.h>
#include <WinCrypt.h>
#include "handshakestage.h"

#define COMM_FAC	1100
#define CERT_FAC	1101
#define SERVER_EXCEPTION_FAC	1102
#define FILE_FAC	1103

#define SC_STRING_SEPARATOR L"~~~"

namespace SC
{

#ifdef BAD_COMM_ENVIRONMENT
	static const unsigned int COMM_RANDOM_STRENGTH = 16;
	static const unsigned int RANDOM_SENDING_BYTE = 16;
	static const unsigned int RANDOM_DELAY_MS = 1;
	static const unsigned int RANDOM_CRASH_STRENGTH = 8;
	
	static const int HANDSHAKING_CRASH_CODE = -100;
	static const int RECEIVING_CRASH_CODE = -200;
	static const int SENDING_CRASH_CODE = -400;

	static_assert(RANDOM_SENDING_BYTE >= 8, "RANDOM_SENDING_BYTE cannot be less than 2!");
	static_assert(RANDOM_CRASH_STRENGTH >= 2, "RANDOM_CRASH_STRENGTH cannot be less than 2!");
	static_assert(COMM_RANDOM_STRENGTH >= 2, "COMM_RANDOM_STRENGTH cannot be less than 2!");

	//supported MACROs: ENABLE_RANDOM_HANDSHAKING_CRASH, ENABLE_RANDOM_RECEIVING_CRASH and ENABLE_RANDOM_SENDING_CRASH
#endif

	typedef unsigned int SC_PEER_VERSION;

	//reserved request ids from 1 through 1023
	static const unsigned short idAuthentication = 1;
	static const unsigned short idServerException = 2;
	static const unsigned short idHeartBeat = 3;
	static const unsigned short idServerInfo = 4;
	static const unsigned short idAuthenticationReserved = 256;

	//predefine request ids for online messaging
	static const unsigned short idJoin = idAuthenticationReserved + 1;
	static const unsigned short idExit = idJoin + 1;
	static const unsigned short idPublish = idExit + 1;
	static const unsigned short idSendUserMessage = idPublish + 1; 

	//your request id must NOT less than this request id
	static const unsigned short idStartRequestId = 1024;
	
	//error codes for the method Retrieve of interface ISession
	//and the method Send of interfaces IClientSession and IServerSession
	//as well as the method SendException of interface IServerSession
	static const unsigned int SESSION_CLOSED = (~0); //session closed
	static const unsigned int BAD_REQUEST = SESSION_CLOSED - 1; //Unexpected request id at client side
	static const unsigned int BAD_REQUEST_ID = SESSION_CLOSED - 1; //Unexpected request id at client side 
	static const unsigned int BAD_RETRIEVE_THREAD = BAD_REQUEST - 1; //Retrieve data from wrong thread
	static const unsigned int BAD_RESULT = BAD_REQUEST; //Send result with wrong request id
	static const unsigned int BAD_RESULT_ID = BAD_REQUEST; //Send result with wrong request id
	const static int ERROR_NOT_SUPPORTED_AT_SERVER_SIDE = -4;
	const static int ERROR_BAD_NUMBER_OF_ARGUMENTS = -5;
	static const unsigned int BAD_PFX_BLOB = ((unsigned int)-6);

	typedef enum tagSessionState {
		ssClosed = 0,
		ssClosing = 1,
		ssConnecting = 2,
		ssConnected = 3,
		ssSslHandshaking = 4,
		ssSslHandshaked = 5,
		ssAuthentcated = 6
	} SessionState;

	//CSender attributes are case-insensitive strings
	struct CSender {
		std::wstring MachineName;
		std::wstring UserId;
		std::wstring AppName;
		unsigned __int64 ServerPointer;
	};

	struct ICertificate {
		virtual const char* const Verify(HRESULT *errCode) const = 0;
#ifdef USE_OPENSSL
		virtual const char* const GetCertPem() const = 0;
#endif
		virtual const char* const GetSessionInfo() const = 0;
		virtual bool IsValid() const = 0;
		virtual const char* const GetSubject() const = 0;
		virtual const char* const GetIssuer() const = 0;
		virtual const unsigned char* const GetPublicKey(unsigned int *pKeySize) const = 0;
		virtual PCCERT_CONTEXT const GetCertContext() const = 0;
	};

	struct ISession {
		virtual tagSessionState GetSessionState() = 0;
		virtual HRESULT GetErrCode() = 0;
		virtual bool IsDiffEndian() = 0;
		virtual void PostClose(DWORD errCode) = 0;

		//Check the data size in bytes to be sent to remote peer. 
		//If it returns a large vaule, it means network bandwidth is not matchable for sending speed
		virtual unsigned int GetSendingBufferSize() = 0;

		//Set a buffer recv with length size in chars to receive error message terminated by null
		virtual unsigned int GetErrMsg(char *recv, unsigned int chars) = 0;
		virtual unsigned int GetErrMsg(wchar_t *recv, unsigned int chars) = 0;

		//Set a buffer recv with length size in bytes to receive data
		//Must call this method within the thread hosting boost asio io service object
		//The method returns the actually obtained data length or BAD_RETRIEVE_THREAD
		virtual unsigned int Retrieve(unsigned char *recv, unsigned int size) = 0;

		virtual unsigned int GetPeerName(char *name, unsigned int size) = 0;
		virtual unsigned int GetSockName(char *name, unsigned int size) = 0;

		virtual const ICertificate* const GetCertificate() const = 0;
	};

	struct ISessionCallback {
		virtual void OnArrive(unsigned short RequestId, unsigned int size) = 0;
		virtual void OnAborted() = 0;
		virtual void OnLess() = 0;
		virtual void OnSslHandshake(ITLSProtocol *tls) = 0;
		virtual SC_PEER_VERSION GetPeerVersion() = 0;
	};

	static std::string GetAppName() {
		char str[1024] = { 0 };
		::GetModuleFileNameA(nullptr, str, sizeof(str));
		std::string s = str;
		auto pos = s.rfind('\\');
		return s.substr(pos + 1);
	}

	template<typename AString>
	AString GetWinSystemErrorMessageA(DWORD errCode) {
		LPSTR lpMsgBuf = nullptr;
		FormatMessageA( FORMAT_MESSAGE_ALLOCATE_BUFFER | 
						FORMAT_MESSAGE_FROM_SYSTEM,
						nullptr,
						errCode,
						MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
						(LPSTR) &lpMsgBuf,
						0,
						nullptr);
		if (lpMsgBuf) {
			AString errMsg(lpMsgBuf);
			::LocalFree(lpMsgBuf);
			return errMsg;
		}
		return AString();
	}

	template<typename WString>
	WString GetWinSystemErrorMessageW(DWORD errCode) {
		LPWSTR lpMsgBuf = nullptr;
		FormatMessageW( FORMAT_MESSAGE_ALLOCATE_BUFFER | 
						FORMAT_MESSAGE_FROM_SYSTEM,
						nullptr,
						errCode,
						MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
						(LPWSTR) &lpMsgBuf,
						0,
						nullptr);
		if (lpMsgBuf) {
			WString errMsg(lpMsgBuf);
			::LocalFree(lpMsgBuf);
			return errMsg;
		}
		return WString();
	}
} //namespace SC

//wincomm 8.0 or later
typedef void (WINAPI *PThreadExceptionHandlers)();

#endif
