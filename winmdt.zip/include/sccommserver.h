
#ifndef _SECURE_COMM_COMMUNICATION_SERVER_H_
#define _SECURE_COMM_COMMUNICATION_SERVER_H_

#include "sccomm.h"
#include <OAIdl.h>

namespace SC { namespace ServerSide {
	struct IServerSession : public ISession {
		//Send a result chunk buffer with length size onto remote client for a request RequestId
		//It returns the actually length data, SESSION_CLOSED, or BAD_RESULT
		virtual unsigned int Send(unsigned short ReqId, const unsigned char * const buffer, unsigned int size) = 0;

		//Send an exception (ec, msg and stack) onto remote client for current request CurReqtId
		//It returns the actually length data in bytes, SESSION_CLOSED, or BAD_RESULT
		virtual unsigned int SendException(unsigned short CurrReqId, int ec, const char *msg, const char *stack) = 0;

		//Tell the underlying server core library that we are going to use a worker thread for processing
		//Must call this method within main thread before starting a worker thread. Otherwise, it returns false.
		virtual bool StartThreadProcessing() = 0;

		//Tell the underlying server core library that worker thread for processing is completed
		//Must call this method from a worker thread. Otherwise, it returns false or no processing for this session.
		virtual bool EndThreadProcessing() = 0;

		//7.02
		virtual void SetClientAppName(const wchar_t *clientAppName) = 0;
		virtual const wchar_t* GetClientAppName() = 0;
		virtual void SetUserId(const wchar_t *userId) = 0;
		virtual const wchar_t* GetUserId() = 0;
		virtual void SetClientMachineName(const wchar_t *clientMachineName) = 0;
		virtual const wchar_t* GetClientMachineName() = 0;
		virtual unsigned int SubScribe(const unsigned int *topics, unsigned int count) = 0;
		virtual unsigned int SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName, const wchar_t* machineName) = 0;
		virtual unsigned int PublishMessage(const VARIANT &vtMsg, const unsigned int *topics, unsigned int count) = 0;
		virtual unsigned __int64 GetServerPointer() const = 0;

	protected:
		virtual ~IServerSession(){}
	};
} //namespace ServerSide
} //namespace SC

#ifdef __cplusplus
extern "C" {
#endif

	//session initialization event
	typedef SC::ISessionCallback* (CALLBACK *POnAccepted)(SC::ServerSide::IServerSession *session);

	const char* WINAPI InitializeSecureCommServer(POnAccepted OnAccepted, unsigned int port = 22260, bool v6 = false, unsigned int backlog = 16);

#ifdef USE_OPENSSL
	const char* WINAPI RunSecureCommServer(const char *certFile, const char *keyFile, const char *pwdForPrivateKeyFile, const char *dhFile = nullptr);
#else
	const char* WINAPI RunSecureCommServer(const wchar_t *filePfx, const wchar_t *password, bool clientCertAuth = false, SC::tagCertStoreType cst = SC::cstRoot);
#endif

	void WINAPI ShutdownSecureCommServer();

	unsigned int WINAPI GetSessionCount();

	unsigned int WINAPI GetThreadCount();

	SC::tagCertStoreType WINAPI GetServerCertStoreType();
	
	HCERTSTORE WINAPI GetServerCertStore();

	const SC::ICertificate* const WINAPI GetServerCertificate();
	
	//7.01
	typedef void (CALLBACK *POnIdle) ();
	void WINAPI SetIdleFunc(POnIdle onIdle);

	//7.02
	unsigned int WINAPI CreateTopics(unsigned int *topics, unsigned int count);
	unsigned int WINAPI SendUserMessage(const wchar_t *receiver, const VARIANT &vtMsg, const wchar_t *appName = nullptr, const wchar_t* machineName = nullptr);
	unsigned int WINAPI PublishMessage(const VARIANT &vtMsg, const unsigned int *topics, unsigned int count);


	//wincomm 8.0 or later
	void WINAPI SetThreadStackCrashHandler_Server(PThreadExceptionHandlers teh);
	PThreadExceptionHandlers WINAPI GetThreadStackCrashHandler_Server();

#ifdef __cplusplus
}
#endif

#endif