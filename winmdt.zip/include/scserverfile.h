#pragma once

#include "sccommserver.h"
#include <fstream>

#ifndef _M_CEE //<future> is not supported when compiling with /clr or /clr:pure.
#include <future>
#else
#include <vcclr.h>
#endif

namespace SC{ namespace ServerSide {

	class CScFile
	{
	public:
		CScFile(SC::ServerSide::CServerHandlerBase &handler)
			: m_Handler(handler),
			m_hFile(INVALID_HANDLE_VALUE),
			m_dwThreadId(0)
#ifdef _MDT_MD5_HASH_H_
		, m_bMd5(false)
#endif
		{
#ifdef _MDT_MD5_HASH_H_
			MD5Init(&m_ctxMD5);
#endif
		}

		virtual ~CScFile() {
			Clean();
		}

	public:
		const std::wstring GetCurrentFile() const {
			return m_filePath;
		}

#ifdef _MDT_MD5_HASH_H_
		bool EnableMD5(bool enabled = true) {
			m_cs.lock();
			m_bMd5 = enabled;
			m_cs.unlock();
			return enabled;
		}

		bool IsMD5Enabled()
		{
			m_cs.lock();
			bool enabled = m_bMd5;
			m_cs.unlock();
			return enabled;
		}
#endif

#ifdef _M_CEE
		ref class CParameters {
		public:
			CParameters(CScFile *pScFile, HANDLE hFile) 
				: m_pScFile(pScFile),
				m_hFile(hFile), m_bReady(true), m_dwError(ERROR_SUCCESS) {
			}

		public:
			bool _Is_ready() {
				m_pScFile->m_cs.lock();
				bool ready = m_bReady;
				m_pScFile->m_cs.unlock();
				return ready;
			}

			DWORD get() {
				m_pScFile->m_cs.lock();
				DWORD err = m_dwError;
				m_pScFile->m_cs.unlock();
				return err;
			}

		internal:
			CScFile *m_pScFile;
			HANDLE	m_hFile;
			bool m_bReady;
			DWORD m_dwError;
		};
		
		static void Execute(System::Object ^obj) {
			PThreadExceptionHandlers teh = GetThreadStackCrashHandler_Server();
			if (teh) {
				teh();
			}
			DWORD res = 0;
			CParameters ^parameters = (CParameters^)obj;
			CScFile *file = parameters->m_pScFile;
			file->m_cs.lock();
			file->m_dwThreadId = ::GetCurrentThreadId();
#ifdef _MDT_MD5_HASH_H_
			if (file->m_bMd5) {
				MD5Init(&file->m_ctxMD5);
			}
#endif
			file->m_cs.unlock();
			SC::CScopeBuffer sb(SC_FILE_CHUNK_SIZE);
			BOOL ok = ::ReadFile(parameters->m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
			while (ok && res) {
#ifdef _MDT_MD5_HASH_H_
				file->m_cs.lock();
				if (file->m_bMd5) {
					MD5Update(&file->m_ctxMD5, (unsigned char*)sb->GetBuffer(), (unsigned int)res);
				}
				file->m_cs.unlock();
#endif
				res = file->m_Handler.Send(idDataFromServerToClient, sb->GetBuffer(), (unsigned int)res);
				if (res == SC::SESSION_CLOSED) {
					break;
				}
				ok = ::ReadFile(parameters->m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
			}
			::CloseHandle(parameters->m_hFile);
			//must call this method at end
			file->m_Handler.EndThreadProcessing();
			file->m_cs.lock();
			file->m_dwThreadId = 0;
			file->m_hFile = INVALID_HANDLE_VALUE;
			parameters->m_bReady = true;
			if (!ok) {
				DWORD errCode = ::GetLastError();
				parameters->m_dwError = errCode;
				if (ERROR_SUCCESS != errCode) {
					res = file->m_Handler.SendException(idDataFromServerToClient, CExCode(SC::GetWinSystemErrorMessageA<std::string>(errCode).c_str(), errCode));
				}
			}
			file->m_cs.unlock();
		}
#endif

#ifdef _M_CEE
		CParameters^ StartDownloadFile() {
			CParameters ^fut = gcnew CParameters(this, INVALID_HANDLE_VALUE);
#else
		std::future<DWORD> StartDownloadFile() {
			std::future<DWORD> fut;
#endif
			DWORD err = ERROR_SUCCESS;
			unsigned __int64 fileSize = (~0);
			SC::CBuffer &buffer = m_Handler.GetBuffer();
			buffer >> m_filePath;
			CScopeBuffer sb;
			HANDLE hFile = ::CreateFileW(m_filePath.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
			if (hFile == INVALID_HANDLE_VALUE) {
				err = ::GetLastError();
				sb << fileSize << (int)err;
				m_Handler.Send(idStartDownloadFile, sb->GetBuffer(), sb->GetSize());
#ifdef _M_CEE
				fut->m_bReady = true;
				fut->m_dwError = err;
#endif
			}
			else {
				DWORD high;
				DWORD low = ::GetFileSize(hFile, &high);
				fileSize = high;
				fileSize <<= 32;
				fileSize += low;
				sb << fileSize << (int)err;
				if (SC::SESSION_CLOSED == m_Handler.Send(idStartDownloadFile, sb->GetBuffer(), sb->GetSize())) {
#ifdef _M_CEE
					fut->m_bReady = true;
					fut->m_dwError = WSAENOTCONN;
#endif
					::CloseHandle(hFile);
					return fut;
				}

				//must call this method before using a worker thread
				bool ok = m_Handler.StartThreadProcessing();
				assert(ok);

				//doing this by use of a worker thread
#ifndef _M_CEE //<future> is not supported when compiling with /clr or /clr:pure.
				fut = std::async(std::launch::async, [hFile, fileSize, this]() {
					PThreadExceptionHandlers teh = GetThreadStackCrashHandler_Server();
					if (teh) {
						teh();
					}
					this->m_cs.lock();
					this->m_dwThreadId = ::GetCurrentThreadId();
#ifdef _MDT_MD5_HASH_H_
					if (this->m_bMd5) {
						MD5Init(&this->m_ctxMD5);
					}
#endif
					this->m_cs.unlock();
					DWORD errCode = ERROR_SUCCESS;
					DWORD res = 0;
					SC::CScopeBuffer sb(SC_FILE_CHUNK_SIZE);
					BOOL ok = ::ReadFile(hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
					if (!ok) {
						errCode = ::GetLastError();
						if (ERROR_SUCCESS != errCode) {
							res = this->m_Handler.SendException(idDataFromServerToClient, CExCode(SC::GetWinSystemErrorMessageA<std::string>(errCode).c_str(), errCode));
						}
					}
					while (ok && res) {
#ifdef _MDT_MD5_HASH_H_
						this->m_cs.lock();
						if (this->m_bMd5) {
							MD5Update(&this->m_ctxMD5, (unsigned char*)sb->GetBuffer(), (unsigned int)res);
						}
						this->m_cs.unlock();
#endif
						res = this->m_Handler.Send(idDataFromServerToClient, sb->GetBuffer(), (unsigned int)res);
						if (res == SC::SESSION_CLOSED) {
							errCode = WSAENOTCONN;
							break;
						}
						ok = ::ReadFile(hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
						if (!ok) {
							errCode = ::GetLastError();
							if (ERROR_SUCCESS != errCode) {
								res = this->m_Handler.SendException(idDataFromServerToClient, CExCode(SC::GetWinSystemErrorMessageA<std::string>(errCode).c_str(), errCode));
							}
						}
					}
					::CloseHandle(hFile);
					//must call this method at end
					bool suc = this->m_Handler.EndThreadProcessing();
					assert(suc);
					this->m_cs.lock();
					this->m_dwThreadId = 0;
					this->m_cs.unlock();
					return errCode;
				});
#else
				fut->m_hFile = hFile;
				fut->m_bReady = false;
				System::Threading::Tasks::Task::Factory->StartNew(gcnew System::Action<System::Object^>(&CScFile::Execute), fut);
#endif
			}
			return fut;
		}

		DWORD StartUploadFile() {
			DWORD err = 0;
			SC::CBuffer &buffer = m_Handler.GetBuffer();
			buffer >> m_filePath;
			CScopeBuffer sb;
			m_hFile = ::CreateFileW(m_filePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
			if (m_hFile == INVALID_HANDLE_VALUE) {
				err = ::GetLastError();
				sb << (int)err;
			}
			else {
				sb << (int)0;
			}
			m_Handler.Send(idStartUploadFile, sb->GetBuffer(), sb->GetSize());
#ifdef _MDT_MD5_HASH_H_
			m_cs.lock();
			if (m_bMd5) {
				MD5Init(&m_ctxMD5);
			}
			::DeleteFileW((m_filePath + L".md5").c_str());
			m_cs.unlock();
#endif
			return err;
		}

		DWORD DataFromClientToServer()
		{
			BOOL ok = TRUE;
			DWORD errCode = ERROR_SUCCESS;
			SC::CBuffer &buffer = m_Handler.GetBuffer();
			if (m_hFile != INVALID_HANDLE_VALUE) {
				DWORD written;
				ok = ::WriteFile(m_hFile, buffer.GetBuffer(), buffer.GetSize(), &written, nullptr);
				if (!ok || buffer.GetSize() != written) {
					ok = FALSE;
					errCode = ::GetLastError();
					m_Handler.SendException(idDataFromClientToServer, CExCode(SC::GetWinSystemErrorMessageA<std::string>(errCode).c_str(), errCode));
					return errCode;
				}
			}
			if (ok) {
#ifdef _MDT_MD5_HASH_H_
				m_cs.lock();
				if (m_bMd5) {
					MD5Update(&m_ctxMD5, (unsigned char*)buffer.GetBuffer(), buffer.GetSize());
				}
				m_cs.unlock();
#endif
				m_Handler.Send();
			}
			return errCode;
		}

		void EndUploadFile() {
			int md5_matched = TRUE;
#ifdef _MDT_MD5_HASH_H_
			if (m_filePath.size() && m_hFile != INVALID_HANDLE_VALUE) {
				SC::CAutoLock al(m_cs);
				if (m_bMd5) {
					SC::CBuffer &buffer = m_Handler.GetBuffer();
					if (buffer.GetSize()) {
						std::string rHash;
						buffer >> rHash;
						char strMd5[MD5_HASH_STR_LEN] = {0};
						MD5FinalStr(&m_ctxMD5, strMd5);
						if (rHash == strMd5) {
							std::wstring fileMD5(m_filePath + L".md5");
							std::ofstream ofs(fileMD5, std::ofstream::out | std::ofstream::app);
							assert(ofs.is_open());
							if (ofs.is_open()) {
								ofs.write(strMd5, MD5_HASH_STR_LEN - 1);
							}
						}
						else {
							md5_matched = FALSE;
						}
					}
				}
			}
#endif
			//prevent the uplated file from being deleted
			m_filePath.clear();
			Clean();
			m_Handler.Send(md5_matched);
		}

		void EndDownloadFile()
		{
#ifdef _MDT_MD5_HASH_H_
			SC::CAutoLock al(m_cs);
			if (m_bMd5) {
				char strMd5[MD5_HASH_STR_LEN] = {0};
				MD5FinalStr(&m_ctxMD5, strMd5);
				m_Handler.Send((const char*)strMd5);
			}
			else {
				m_Handler.Send();
			}
#else
			m_Handler.Send();
#endif
		}

		DWORD GetWorkerThreadId() {
			m_cs.lock();
			DWORD id = m_dwThreadId;
			m_cs.unlock();
			return id;
		}

	private:
		CScFile(const CScFile &file);
		CScFile& operator=(const CScFile &file);

	public:
		void Clean() {
			if (m_hFile != INVALID_HANDLE_VALUE) {
#ifdef FILE_FLUSH_BEFORE_CLOSE
				BOOL ok = ::FlushFileBuffers(m_hFile);
				if (!ok) {
					DWORD errCode = ::GetLastError();
					if (ERROR_ACCESS_DENIED == errCode) {
						ok = TRUE;
					}
					else {
						assert(false);
					}
				}
				assert(ok);
#endif
				::CloseHandle(m_hFile);
				m_hFile = INVALID_HANDLE_VALUE;
				if (m_filePath.size()) {
					::DeleteFileW(m_filePath.c_str());
					m_filePath.clear();
				}
			}
		}

	private:
		SC::ServerSide::CServerHandlerBase &m_Handler;
		std::wstring m_filePath;
		HANDLE m_hFile;
		SC::CMDTCriticalSection m_cs;
		DWORD m_dwThreadId; //protected by m_cs;
#ifdef _MDT_MD5_HASH_H_
		MD5_CTX m_ctxMD5; //protected by m_cs;
		bool m_bMd5; //protected by m_cs;
#endif
	};

} //namespace ServerSide
} //namespace SC