

#ifndef __MDT_SOFTWARE_CERTIFICATE_UTILITIES_H_
#define __MDT_SOFTWARE_CERTIFICATE_UTILITIES_H_

#include <atlstr.h>
#include "sccomm.h"
#include <winhttp.h>
#include <assert.h>
#include <winsock2.h>
#include <ws2tcpip.h>


namespace SC { namespace Utilities {

	static const char* const DisplayErrorMessage(DWORD status) {
		char *pszName;
		switch(status) {
		case CERT_E_EXPIRED:                pszName = "CERT_E_EXPIRED";                 break;
		case CERT_E_VALIDITYPERIODNESTING:  pszName = "CERT_E_VALIDITYPERIODNESTING";   break;
		case CRYPT_E_NO_REVOCATION_CHECK:   pszName = "CRYPT_E_NO_REVOCATION_CHECK";    break;
		case CRYPT_E_REVOCATION_OFFLINE:    pszName = "CRYPT_E_REVOCATION_OFFLINE";     break;
		case CRYPT_E_SELF_SIGNED:			pszName = "CRYPT_E_SELF_SIGNED";			break;
		case CERT_E_ROLE:                   pszName = "CERT_E_ROLE";                    break;
		case CERT_E_PATHLENCONST:           pszName = "CERT_E_PATHLENCONST";            break;
		case CERT_E_INVALID_NAME:           pszName = "CERT_E_INVALID_NAME";            break;
		case CERT_E_INVALID_POLICY:         pszName = "CERT_E_INVALID_POLICY";          break;
		case TRUST_E_BASIC_CONSTRAINTS:     pszName = "TRUST_E_BASIC_CONSTRAINTS";      break;
		case CERT_E_CRITICAL:               pszName = "CERT_E_CRITICAL";                break;
		case CERT_E_PURPOSE:                pszName = "CERT_E_PURPOSE";                 break;
		case CERT_E_ISSUERCHAINING:         pszName = "CERT_E_ISSUERCHAINING";          break;
		case CERT_E_MALFORMED:              pszName = "CERT_E_MALFORMED";               break;
		case CERT_E_UNTRUSTEDROOT:          pszName = "CERT_E_UNTRUSTEDROOT";           break;
		case CERT_E_CHAINING:               pszName = "CERT_E_CHAINING";                break;
		case TRUST_E_FAIL:                  pszName = "TRUST_E_FAIL";                   break;
		case CERT_E_REVOKED:                pszName = "CERT_E_REVOKED";                 break;
		case CERT_E_UNTRUSTEDTESTROOT:      pszName = "CERT_E_UNTRUSTEDTESTROOT";       break;
		case CERT_E_REVOCATION_FAILURE:     pszName = "CERT_E_REVOCATION_FAILURE";      break;
		case CERT_E_CN_NO_MATCH:            pszName = "CERT_E_CN_NO_MATCH";             break;
		case CERT_E_WRONG_USAGE:            pszName = "CERT_E_WRONG_USAGE";             break;
		case TRUST_E_EXPLICIT_DISTRUST:     pszName = "TRUST_E_EXPLICIT_DISTRUST";      break;
		case CERT_E_UNTRUSTEDCA:            pszName = "CERT_E_UNTRUSTEDCA";             break;
		case TRUST_E_NOSIGNATURE:           pszName = "TRUST_E_NOSIGNATURE";            break;
		default:                            pszName = "";								break;
		}
		return pszName;
	}

	static HRESULT VerifyCertificate(const SC::ICertificate* const cert, HCERTSTORE hCertStore, bool &selfSigned, CStringA &errMsg) {
		assert(cert);
		assert(hCertStore);
		HRESULT errCode = S_OK;
		errMsg.Empty();
		PCCERT_CHAIN_CONTEXT pChainContext = nullptr;
		do {
			LPSTR rgszUsages[] = {  szOID_PKIX_KP_SERVER_AUTH,
				szOID_SERVER_GATED_CRYPTO,
				szOID_SGC_NETSCAPE };
			DWORD cUsages = sizeof(rgszUsages) / sizeof(LPSTR);
			CERT_CHAIN_PARA ChainPara;
			::memset(&ChainPara, 0, sizeof(ChainPara));
			ChainPara.cbSize = sizeof(ChainPara);
			ChainPara.RequestedUsage.dwType = USAGE_MATCH_TYPE_AND;
			ChainPara.RequestedUsage.Usage.cUsageIdentifier = cUsages;
			ChainPara.RequestedUsage.Usage.rgpszUsageIdentifier = rgszUsages;
			if (!::CertGetCertificateChain(nullptr, cert->GetCertContext(), nullptr, hCertStore, &ChainPara, 0, nullptr, &pChainContext)) {
				errCode = MAKE_HRESULT(SEVERITY_ERROR, CERT_FAC, ::GetLastError());
				errMsg = SC::GetWinSystemErrorMessageA<CStringA>(::GetLastError()).Trim();
				break;
			}
			HTTPSPolicyCallbackData polHttps;
			CERT_CHAIN_POLICY_PARA PolicyPara;
			CERT_CHAIN_POLICY_STATUS PolicyStatus;

			::memset(&polHttps, 0, sizeof(HTTPSPolicyCallbackData));
			polHttps.cbStruct = sizeof(HTTPSPolicyCallbackData);
			polHttps.dwAuthType = AUTHTYPE_SERVER;
			polHttps.fdwChecks = (SECURITY_FLAG_IGNORE_CERT_CN_INVALID | SECURITY_FLAG_IGNORE_CERT_WRONG_USAGE);

			::memset(&PolicyPara, 0, sizeof(PolicyPara));
			PolicyPara.cbSize = sizeof(PolicyPara);
			PolicyPara.pvExtraPolicyPara = &polHttps;
			PolicyPara.dwFlags = 4;

			::memset(&PolicyStatus, 0, sizeof(PolicyStatus));
			PolicyStatus.cbSize = sizeof(PolicyStatus);
			// validate certificate chain.
			if (!::CertVerifyCertificateChainPolicy(CERT_CHAIN_POLICY_SSL, pChainContext, &PolicyPara, &PolicyStatus)) {
				errCode = MAKE_HRESULT(SEVERITY_ERROR, CERT_FAC, ::GetLastError());
				errMsg = SC::GetWinSystemErrorMessageA<CStringA>(::GetLastError()).Trim();
				break;
			}
			errCode = (HRESULT)PolicyStatus.dwError;
			if (errCode == S_OK) {
				selfSigned = false;
				break; //certificate chain verification succeeded
			}
			else if (PolicyStatus.dwError != CERT_E_UNTRUSTEDROOT) {
				errMsg = DisplayErrorMessage(PolicyStatus.dwError);
				selfSigned = false;
				break;
			}
			else if (selfSigned) { //errCode == CERT_E_UNTRUSTEDROOT
				unsigned int keySize = 0;
				const unsigned char *publicKey = cert->GetPublicKey(&keySize);
				CERT_PUBLIC_KEY_INFO cpki;
				::memset(&cpki, 0, sizeof(cpki));
				cpki.PublicKey.cbData = keySize;
				cpki.PublicKey.pbData = (BYTE*)publicKey;
				PCCERT_CONTEXT pDesiredCert = ::CertFindCertificateInStore(hCertStore, X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 0, CERT_FIND_PUBLIC_KEY, &cpki, nullptr);
				if (pDesiredCert) {
					//the certificate indeed found at the store
					::CertFreeCertificateContext(pDesiredCert);
					errMsg.Empty();
					errCode = S_OK;
				}
				else {
					errMsg = "Certificate not found in store";
					errCode = (HRESULT)::GetLastError();
				}
			}
			else {
				selfSigned = true;
			}
		}while(false);
		if (pChainContext) {
			::CertFreeCertificateChain(pChainContext);
		}
		return errCode;
	}

	static HRESULT VerifyCertificate(const SC::ICertificate* const cert, SC::tagCertStoreType cst, bool &selfSigned, CStringA &errMsg) {
		assert(cert);
		HCERTSTORE hCertStore = nullptr;
		switch(cst)
		{
		case SC::cstRoot:
			hCertStore = ::CertOpenSystemStore(0, L"ROOT");
			break;
		case SC::cstCa:
			hCertStore = ::CertOpenSystemStore(0, L"CA");
			break;
		case SC::cstMy:
			hCertStore = ::CertOpenSystemStore(0, L"MY");
			break;
		case SC::cstSpc:
			hCertStore = ::CertOpenSystemStore(0, L"SPC");
			break;
		default:
			assert(false); //not implemented!!!!
			break;
		}
		if (!hCertStore) {
			HRESULT errCode = MAKE_HRESULT(SEVERITY_ERROR, CERT_FAC, ::GetLastError());
			errMsg = SC::GetWinSystemErrorMessageA<CStringA>(::GetLastError()).Trim();
			return errCode;
		}
		HRESULT hr = VerifyCertificate(cert, hCertStore, selfSigned, errMsg);
		::CertCloseStore(hCertStore, 0);
		return hr;
	}

	static HRESULT VerifyCertificate(const SC::ICertificate* const cert, bool &selfSigned, CStringA &errMsg) {
		assert(cert);
		HCERTSTORE hCertStore = cert->GetCertContext()->hCertStore;
		if (!hCertStore) {
			errMsg = "No memory certificate store available";
			return MAKE_HRESULT(1, CERT_FAC, ERROR_ACCESS_DENIED);
		}
		return VerifyCertificate(cert, hCertStore, selfSigned, errMsg);
	}

	static CStringA GetCN(const char* const subject_or_issuer) {
		CStringA s;
		CStringA str(subject_or_issuer);
		int start = str.Find(", CN=");
		do {
			if (start < 0) {
				break;
			}
			int end = str.Find(", ", start + 5);
			if (end < start) {
				break;
			}
			int len = end - start - 5;
			s = str.Mid(start + 5, len);
		}
		while(false);
		return s;
	}

	static bool CompareTwoRootCerts(PCCERT_CONTEXT const cert0, const CStringA &issuer0, PCCERT_CONTEXT const cert1, const CStringA& issuer1) {
		PCCERT_CONTEXT p0 = nullptr;
		PCCERT_CONTEXT p1 = nullptr;
		bool equal = false;
		do {
			if (!cert0 || !cert1) {
				break;
			}
			if (!cert0->hCertStore || !cert1->hCertStore) {
				break;
			}
			p0 = ::CertFindCertificateInStore(cert0->hCertStore, X509_ASN_ENCODING|PKCS_7_ASN_ENCODING, 0, CERT_FIND_SUBJECT_STR_A, LPCSTR(issuer0), nullptr);
			p1 = ::CertFindCertificateInStore(cert1->hCertStore, X509_ASN_ENCODING|PKCS_7_ASN_ENCODING, 0, CERT_FIND_SUBJECT_STR_A, LPCSTR(issuer1), nullptr);
			if (!p0 || !p1) {
				break;
			}
			CRYPT_BIT_BLOB &rbb0 = p0->pCertInfo->SubjectPublicKeyInfo.PublicKey;
			CRYPT_BIT_BLOB &rbb1 = p1->pCertInfo->SubjectPublicKeyInfo.PublicKey;
			if (rbb0.cbData != rbb1.cbData) {
				break;
			}
			equal = (::memcmp(rbb0.pbData, rbb1.pbData, rbb0.cbData) == 0);
		} while(false);
		if (p1) {
			::CertFreeCertificateContext(p1);
		}
		if (p0) {
			::CertFreeCertificateContext(p0);
		}
		return equal;
	}

	static CStringA GetPeerDomainOrServerName(const char *ipAddr, u_short port) {
		CStringA s(ipAddr ? ipAddr : "");
		char name[NI_MAXHOST] = {0};
		if (s == "127.0.0.1" || s == "::ffff:127.0.0.1") {
			::gethostname(name, sizeof(name));
			return name;
		}
		struct sockaddr_in saGNI;
		char servInfo[NI_MAXSERV] = {0};
		saGNI.sin_family = AF_INET;
		saGNI.sin_addr.s_addr = inet_addr(LPCSTR(s));
		saGNI.sin_port = htons(port);
		::getnameinfo((struct sockaddr *) &saGNI, sizeof (struct sockaddr), name, sizeof(name), servInfo, sizeof(servInfo), NI_NUMERICSERV);
		return name;
	}
} //namespace Utilities
} //namespace SC

#endif