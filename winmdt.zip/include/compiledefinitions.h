
#include "winsysid.h"

#ifndef _MDT_SECURE_COMMUNICATION_DEFINITIONS_H_
#define _MDT_SECURE_COMMUNICATION_DEFINITIONS_H_

namespace Utilities {

	namespace Server {
		
		static GUID MDT_PFX_SECRET = {1, 1, 1, {1, 1, 1, 1, 1, 1, 1, 1}}; 

		namespace Internal {

			static CString GetUniqeString(LPCTSTR appKey, DWORD dwSalt) {
				CString str(appKey);
				str += GetSysIdW<CString>();
				str += std::to_string(dwSalt).c_str();
				wchar_t szGuidW[64] = {0};
				StringFromGUID2(MDT_PFX_SECRET, szGuidW, sizeof(szGuidW)/sizeof(wchar_t));
				str += szGuidW;
				return str;
			}
		};
	}
}


#endif