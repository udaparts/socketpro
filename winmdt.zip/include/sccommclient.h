
#ifndef _SECURE_COMM_COMMUNICATION_CLIENT_H_
#define _SECURE_COMM_COMMUNICATION_CLIENT_H_


#include "sccomm.h"


namespace SC { namespace ClientSide {

	static const unsigned int DEFAULT_RECV_TIMEOUT = 60000; //60 seconds
	static const unsigned int DEFAULT_CONN_TIMEOUT = 30000; //30 seconds

	struct IClientSession : public ISession {
		//Wait until all queued requests are processed, timeout or session closed.
		//The method returns true only if all queued requests are processed.
		virtual bool WaitAll(unsigned int ms) = 0;

		//Send a data chunk buffer with length size onto remote server for a request RequestId
		//it returns the actually length data, SESSION_CLOSED, or BAD_REQUEST
		virtual unsigned int Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool oneWay) = 0;
		
		virtual bool IsAutoConnecting() = 0;
		virtual size_t GetRequestCountQueued() = 0;
		virtual const ICertificate* const GetSelfCert() const = 0;
		virtual bool WaitConnection(unsigned int ms) = 0;

	protected:
		virtual ~IClientSession(){}
	};
} //namespace ClientSide
} //namespace SC


#ifdef __cplusplus
extern "C" {
#endif

	//certificate verification
	int WINAPI SetCertificateVerifyFile(const char *caFile);

	//manage socket life
	SC::ClientSide::IClientSession* WINAPI DoClientConnection(SC::ISessionCallback *sc, const char *host, unsigned int port, const char *certCN, unsigned int timedout, bool autoConnecting, bool v6);
	void WINAPI DestroyClient(SC::ClientSide::IClientSession *session);
	SC::tagCertStoreType WINAPI GetClientCertStoreType();
	HCERTSTORE WINAPI GetClientCertStore();

	//wincomm 8.0 or later
	void WINAPI SetThreadStackCrashHandler_Client(PThreadExceptionHandlers teh);
	PThreadExceptionHandlers WINAPI GetThreadStackCrashHandler_Client();

#ifdef __cplusplus
}
#endif



#endif
