
#include "serverhandler.h"

namespace SC
{
	namespace ServerSide
	{
		CMDTCriticalSection g_csHandler;
		std::vector<CServerHandlerBase *> g_vActiveHandler;
		std::deque<CServerHandlerBase *> g_vHandler;
	}
}
