#include "stdafx.h"
#include "InitOpenSSL.h"

#include <openssl/err.h>
#include <openssl/ssl.h>   

#pragma comment(lib, "ssleay32.lib")
#pragma comment(lib, "libeay32.lib")

static HANDLE *s_pLocks = 0;

///////////////////////////////////////////////////////////////////////////////
// Static helper functions...
///////////////////////////////////////////////////////////////////////////////

static void LockingCallback(
   int mode, 
   int type, 
   const char *file, 
   int line);

static bool ThreadingSetup();

static void ThreadingCleanup();

///////////////////////////////////////////////////////////////////////////////
// CUsesOpenSSL
///////////////////////////////////////////////////////////////////////////////

CUsesOpenSSL::CUsesOpenSSL(bool multiThreadedUse)
   : m_weOwnLocks(multiThreadedUse ?  ThreadingSetup() : false), m_pSSLContext(NULL)
{
	SSL_load_error_strings();
	SSL_library_init();
}
      
CUsesOpenSSL::~CUsesOpenSSL()
{
	CloseSSLCtx();
	if (m_weOwnLocks)
	{
		ThreadingCleanup();
	}
	ERR_free_strings();
}

void CUsesOpenSSL::CloseSSLCtx()
{
	if(m_pSSLContext != NULL)
	{
		SSL_CTX_free(m_pSSLContext);
		m_pSSLContext = NULL;
	}
}

SSL_CTX *CUsesOpenSSL::GetSSLCtx(tagOpenSSLMethod om)
{
	if(m_pSSLContext == NULL)
	{
		SSL_METHOD *pMethod;
		switch (om)
		{
		case omSSLv3:
			pMethod = SSLv3_method();
			break;
		default:
			pMethod = TLSv1_method();
			break;
		}
		m_pSSLContext = SSL_CTX_new(pMethod);
	}
	return m_pSSLContext;
}

///////////////////////////////////////////////////////////////////////////////
// Static helper functions...
///////////////////////////////////////////////////////////////////////////////

static bool ThreadingSetup()
{
	bool ok = false;

	if (!s_pLocks)
	{
		s_pLocks = (HANDLE *)malloc(CRYPTO_num_locks() * sizeof(HANDLE));

		for (int i = 0; i < CRYPTO_num_locks(); i++)
		{
			s_pLocks[i] = ::CreateMutex(
										0,                         // Security attributes
										FALSE,                     // Initially owned
										0);                        // name
		}

		CRYPTO_set_locking_callback(LockingCallback);

		ok = true;
	}

	return ok;
}

static void ThreadingCleanup()
{
	if (s_pLocks)
	{
		CRYPTO_set_locking_callback(0);
		for (int i = 0; i < CRYPTO_num_locks(); i++)
		{
			CloseHandle(s_pLocks[i]);
		}
		free(s_pLocks);
		s_pLocks = 0;
   }
}

static void LockingCallback(
   int mode, 
   int type, 
   const char *file, 
   int line)
{
	if (mode & CRYPTO_LOCK)
	{
		::WaitForSingleObject(s_pLocks[type],INFINITE);
	}
	else
	{
		::ReleaseMutex(s_pLocks[type]);
	}
}

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////
