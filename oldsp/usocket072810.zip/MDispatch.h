// MDispatch.h: interface for the CMDispatch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDISPATCH_H__F8BC3E34_06BB_458E_89B5_00AAB91E71B5__INCLUDED_)
#define AFX_MDISPATCH_H__F8BC3E34_06BB_458E_89B5_00AAB91E71B5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "pluginbase.h"
#include "NPObjectImpBase.h"
#include "umozilla.h"
#include <shlguid.h> 
#include "COMWebItem.h"

class CMDispatch :	public CNPObjectImplBase
{
public:
	CMDispatch(const CLSID &clsid, nsPluginInstanceBase *pInstance);
	CMDispatch(IUnknown *pIUnknown, nsPluginInstanceBase *pInstance);
	~CMDispatch();
	
public:
	bool GetProperty(const CComBSTR &bstrPropertyName, CComVariant &vtData);
	bool SetProperty(const CComBSTR &strPropertyName, const CComVariant &vtData);
	bool Invoke(const CComBSTR &bstrMethodName, const VARIANT *pvtArgs, uint32_t argCount, CComVariant &vtResult);
	
protected:
	void OnInvalidate();

private:
	HRESULT InvokeVariantMethod(const DISPID dispidMethod, WORD wInvokeFlag, const VARIANT *pvtArgs, uint32_t argCount, VARIANT* pVarRet);
	void QueryAndSet(IDispatch *pIDispatch, nsPluginInstanceBase *pInstance);

private:
	CComBSTR						m_strURL;
	CComPtr<IUMozilla>				m_pIMozilla;
	CSimpleArray<CComBSTR>			m_aPropertyNamePut;
	CSimpleMap<CComBSTR, FUNCDESC>	m_mapFunc;
	CSimpleMap<CComBSTR, FUNCDESC>	m_mapPropertyGet;
	CSimpleMap<CComBSTR, FUNCDESC>	m_mapPropertyPut;
	CComObject<CCOMWebItem>			*m_pIMozillaWebItem;
	CComPtr<IDispatch>				m_pIDispatch;
};

#endif // !defined(AFX_MDISPATCH_H__F8BC3E34_06BB_458E_89B5_00AAB91E71B5__INCLUDED_)
