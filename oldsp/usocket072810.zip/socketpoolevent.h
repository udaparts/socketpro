#ifndef __U_SOCKET_EVENT_FOR_SOCKETPOOL_H__
#define __U_SOCKET_EVENT_FOR_SOCKETPOOL_H__

#define	IDC_SRCUSOCKETEVENT		2

static _ATL_FUNC_INFO OnSockEventFuncInfo = {CC_STDCALL, VT_I4, 2, {VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnSockEventWinMsgInfo = {CC_STDCALL, VT_I4, 4, {VT_I4, VT_I4, VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnDataAvailableInfo = {CC_STDCALL, VT_I4, 3, {VT_I4, VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnSendingDataInfo = {CC_STDCALL, VT_I4, 3, {VT_I4, VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnSockGetHostByAddr = {CC_STDCALL, VT_I4, 4, {VT_I4, VT_BSTR, VT_BSTR, VT_I4}};
static _ATL_FUNC_INFO OnSockGetHostByName = {CC_STDCALL, VT_I4, 5, {VT_I4, VT_BSTR, VT_BSTR, VT_BSTR, VT_I4}};
static _ATL_FUNC_INFO OnRequestProcessedInfo = {CC_STDCALL, VT_I4, 5, {VT_I4, VT_I2, VT_I4, VT_I4, VT_I2}};

class CCSEvent : public IDispEventSimpleImpl<IDC_SRCUSOCKETEVENT, CCSEvent, &__uuidof(_IUSocketEvent)>							
{
public:
	CCSEvent()
	{
		m_hEvent = NULL;
		m_lSvsID = 0;
		m_bZip = false;
		m_pIUSocket = NULL;
		m_pSocketPool = NULL;
		m_bstrPassword = NULL;
	}

BEGIN_SINK_MAP(CCSEvent)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 1, OnDataAvailable, &OnDataAvailableInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 2, OnOtherMessage, &OnSockEventWinMsgInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 3, OnSocketClosed, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 4, OnSocketConnected, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 5, OnConnecting, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 6, OnSendingData, &OnSendingDataInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 7, OnGetHostByAddr, &OnSockGetHostByAddr)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 8, OnGetHostByName, &OnSockGetHostByName)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 9, OnClosing, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 10, OnRequestProcessed, &OnRequestProcessedInfo)
END_SINK_MAP()
	virtual HRESULT __stdcall OnDataAvailable(long hSocket, long lBytes, long lError)
	{
		return S_OK;
	}
	virtual HRESULT __stdcall OnOtherMessage(long hSocket, long nMsg, long wParam, long lParam)
	{
		return S_OK;
	}
	virtual HRESULT __stdcall OnSocketClosed(long hSocket, long lError)
	{
		::SetEvent(m_hEvent);
		return S_OK;
	}
	virtual HRESULT __stdcall OnSocketConnected(long hSocket, long lError)
	{
		HRESULT hr;
		m_bFirst = true;
		if(lError == S_OK)
		{
			short sEncryption = NoEncryption;
			hr = m_pIUSocket->get_EncryptionMethod(&sEncryption);
			if(m_lSvsID != 0)
			{
				if(sEncryption == BlowFish)
				{
					hr = m_pIUSocket->put_Password(m_bstrPassword);
					hr = m_pIUSocket->SwitchTo(m_lSvsID);
					hr = m_pIUSocket->TurnOnZipAtSvr(m_bZip ? VARIANT_TRUE : VARIANT_FALSE);
				}
				else
				{
					hr = m_pIUSocket->StartBatching();
					hr = m_pIUSocket->put_Password(m_bstrPassword);
					hr = m_pIUSocket->SwitchTo(m_lSvsID);
					hr = m_pIUSocket->TurnOnZipAtSvr(m_bZip ? VARIANT_TRUE : VARIANT_FALSE);
					hr = m_pIUSocket->CommitBatching(false);
				}
			}
			else
			{
				if(m_bFirst)
				{
					::SetEvent(m_hEvent);
					m_bFirst = false;
				}
			}
		}
		if(lError == 0)
			m_pSocketPool->Fire_OnSocketPoolEvent(speConnected, m_pIUSocket);
//		ATLTRACE("speConnected called ......\n");
		return S_OK;
	}
	virtual HRESULT __stdcall OnConnecting(long hSocket, long hWnd)
	{
		return S_OK;
	}
	virtual HRESULT __stdcall OnSendingData(long hSocket, long lError, long lSent)
	{
		return S_OK;
	}
	virtual HRESULT __stdcall OnGetHostByAddr(long lHandle, BSTR bstrHostName, BSTR bstrHostAlias, long lError)
	{
		return S_OK;
	}
	virtual HRESULT __stdcall OnGetHostByName(long lHandle, BSTR bstrHostName, BSTR bstrAlias, BSTR bstrIPAddr, long lError)
	{
		return S_OK;
	}
	virtual HRESULT __stdcall OnClosing(long hSocket, long hWnd)
	{
		return S_OK;
	}
	virtual HRESULT __stdcall OnRequestProcessed(long hSocket, short nRequestID, long lLen, long lLenInBuffer, short sFlag)
	{
		if(m_bFirst && nRequestID == idSwitchTo)
		{
			long lSvsID;
			m_pIUSocket->get_CurrentSvsID(&lSvsID);
			if(lSvsID == m_lSvsID)
			{
				long lError = 0;
				m_pIUSocket->get_Rtn(&lError);
				if(lError >= 0)
				{
					::SetEvent(m_hEvent);
				}
			}
			m_bFirst = false;
		}
		return S_OK;
	}
	
public:
	HANDLE		m_hEvent;
	long		m_lSvsID;
	bool		m_bZip;
	IUSocket	*m_pIUSocket;
	CUSocketPool *m_pSocketPool;
	BSTR		m_bstrPassword;
	bool		m_bFirst;
};

#endif
