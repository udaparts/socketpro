#ifndef __4_USOCKETCP_H_
#define __4_USOCKETCP_H_

#include "USocketImp.h"

template <class T>
class CProxy_IUSocketEvent : public IConnectionPointImpl<T, &DIID__IUSocketEvent, CComDynamicUnkArray>
{
protected:
	ULONG RemoveLock()
	{
		ULONG ul = 0;
		ULONG	dwThreadID = ::GetCurrentThreadId();
		while((DWORD)m_pCS->OwningThread == dwThreadID)
		{
			ul++;
			::LeaveCriticalSection(m_pCS);
		}
		
		return ul;
	}

	void Relock(ULONG ulCount)
	{
		while(ulCount > 0)
		{
			::EnterCriticalSection(m_pCS);
			ulCount--;
		}
	}

protected:
	CRITICAL_SECTION	*m_pCS;
	//Warning this class may be recreated by the wizard.
public:
	HRESULT Fire_OnDataAvailable(LONG hSocket, LONG lBytes, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[3];
//		CComVariant* pvars = new CComVariant[3];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[2] = hSocket;
			pvars[1] = lBytes;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnDataAvailable"), pvars, 3, varResult);
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnDataAvailable");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {3, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = lBytes;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = lError;
				pvt[2].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {5, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 1;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = lBytes;
				pvt[3].vt = VT_I4;
				pvt[4].lVal = lError;
				pvt[4].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[2] = hSocket;
				pvars[1] = lBytes;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 3, 0 };
				pDispatch->Invoke(0x1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnOtherMessage(LONG hSocket, LONG nMsg, LONG wParam, LONG lParam)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[4];
//		CComVariant* pvars = new CComVariant[4];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[3] = hSocket;
			pvars[2] = nMsg;
			pvars[1] = wParam;
			pvars[0] = lParam;
			pT->Invoke(CComBSTR(L"OnOtherMessage"), pvars, 4, varResult);
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnOtherMessage");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {4, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = nMsg;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = wParam;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = lParam;
				pvt[3].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {6, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 2;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = nMsg;
				pvt[3].vt = VT_I4;
				pvt[4].lVal = wParam;
				pvt[4].vt = VT_I4;
				pvt[5].lVal = lParam;
				pvt[5].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[3] = hSocket;
				pvars[2] = nMsg;
				pvars[1] = wParam;
				pvars[0] = lParam;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				pDispatch->Invoke(0x2, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSocketClosed(LONG hSocket, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnSocketClosed"), pvars, 2, varResult);
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnSocketClosed");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {2, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = lError;
				pvt[1].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {4, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 3;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = lError;
				pvt[3].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x3, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSocketConnected(LONG hSocket, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = lError;
			bool b = pT->Invoke(CComBSTR(L"OnSocketConnected"), pvars, 2, varResult);
			b = false;
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnSocketConnected");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {2, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = lError;
				pvt[1].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}

/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {4, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 4;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = lError;
				pvt[3].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				HRESULT hr = pDispatch->Invoke(0x4, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
				hr = S_OK;
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnConnecting(LONG hSocket, LONG hWnd)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = hWnd;
			pT->Invoke(CComBSTR(L"OnConnecting"), pvars, 2, varResult);
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnConnecting");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {2, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = hWnd;
				pvt[1].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {4, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 5;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = hWnd;
				pvt[3].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}

		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = hWnd;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x5, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSendingData(LONG hSocket, LONG lError, LONG lSent)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[3];
		CComVariant pvars[3];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[2] = hSocket;
			pvars[1] = lError;
			pvars[0] = lSent;
			pT->Invoke(CComBSTR(L"OnSendingData"), pvars, 3, varResult);
			varResult.Clear();
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnSendingData");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {3, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = lError;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = lSent;
				pvt[2].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {5, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 6;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = lError;
				pvt[3].vt = VT_I4;
				pvt[4].lVal = lSent;
				pvt[4].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[2] = hSocket;
				pvars[1] = lError;
				pvars[0] = lSent;
				DISPPARAMS disp = { pvars, NULL, 3, 0 };
				pDispatch->Invoke(0x6, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnGetHostByAddr(LONG hHandle, BSTR bstrHostName, BSTR bstrHostAlias, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[4];
		CComVariant pvars[4];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[3] = hHandle;
			pvars[2] = bstrHostName;
			pvars[1] = bstrHostAlias;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnGetHostByAddr"), pvars, 4, varResult);
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnGetHostByAddr");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {4, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hHandle;
				pvt[0].vt = VT_I4;
				if(bstrHostName != NULL)
				{
					pvt[1].bstrVal = ::SysAllocString(bstrHostName);
					pvt[1].vt = VT_BSTR;
				}
				if(bstrHostAlias != NULL)
				{
					pvt[2].bstrVal = ::SysAllocString(bstrHostAlias);
					pvt[2].vt = VT_BSTR;
				}
				pvt[3].lVal = lError;
				pvt[3].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {6, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 7;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hHandle;
				pvt[2].vt = VT_I4;
				if(bstrHostName != NULL)
				{
					pvt[3].bstrVal = ::SysAllocString(bstrHostName);
					pvt[3].vt = VT_BSTR;
				}
				if(bstrHostAlias != NULL)
				{
					pvt[4].bstrVal = ::SysAllocString(bstrHostAlias);
					pvt[4].vt = VT_BSTR;
				}
				pvt[5].lVal = lError;
				pvt[5].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}	*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[3] = hHandle;
				pvars[2] = bstrHostName;
				pvars[1] = bstrHostAlias;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				pDispatch->Invoke(0x7, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnGetHostByName(LONG hHandle, BSTR bstrHostName, BSTR bstrAlias, BSTR bstrIPAddr, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[5];
		CComVariant pvars[5];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[4] = hHandle;
			pvars[3] = bstrHostName;
			pvars[2] = bstrAlias;
			pvars[1] = bstrIPAddr;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnGetHostByName"), pvars, 5, varResult);
			varResult.Clear();
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnGetHostByName");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {5, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hHandle;
				pvt[0].vt = VT_I4;
				if(bstrHostName != NULL)
				{
					pvt[1].bstrVal = ::SysAllocString(bstrHostName);
					pvt[1].vt = VT_BSTR;
				}
				if(bstrAlias != NULL)
				{
					pvt[2].bstrVal = ::SysAllocString(bstrAlias);
					pvt[2].vt = VT_BSTR;
				}
				if(bstrIPAddr != NULL)
				{
					pvt[3].bstrVal = ::SysAllocString(bstrIPAddr);
					pvt[3].vt = VT_BSTR;
				}
				pvt[4].lVal = lError;
				pvt[4].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}

/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {7, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 8;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hHandle;
				pvt[2].vt = VT_I4;
				if(bstrHostName != NULL)
				{
					pvt[3].bstrVal = ::SysAllocString(bstrHostName);
					pvt[3].vt = VT_BSTR;
				}
				if(bstrAlias != NULL)
				{
					pvt[4].bstrVal = ::SysAllocString(bstrAlias);
					pvt[4].vt = VT_BSTR;
				}
				if(bstrIPAddr != NULL)
				{
					pvt[5].bstrVal = ::SysAllocString(bstrIPAddr);
					pvt[5].vt = VT_BSTR;
				}
				pvt[6].lVal = lError;
				pvt[6].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[4] = hHandle;
				pvars[3] = bstrHostName;
				pvars[2] = bstrAlias;
				pvars[1] = bstrIPAddr;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 5, 0 };
				pDispatch->Invoke(0x8, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnClosing(LONG hSocket, LONG hWnd)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spBrowser != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = hWnd;
			pT->Invoke(CComBSTR(L"OnClosing"), pvars, 2, varResult);
		}
		else if(pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnClosing");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {2, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = hWnd;
				pvt[1].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {4, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 9;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = hWnd;
				pvt[3].vt = VT_I4;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = hWnd;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x9, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	}

	HRESULT Fire_OnRequestProcessed(LONG hSocket, SHORT nRequestID, LONG lLen, LONG lLenInBuffer, SHORT sFlag)
	{
		((CUSocket*)this)->m_sLastRequestID = nRequestID;
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[5];
		CComVariant pvars[5];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(sFlag == rfCompleted && pT->m_spBrowser != NULL)
		{
			pvars[4] = hSocket;
			pvars[3] = nRequestID;	
			lLen = pT->m_USAttr.m_curRcvStreamHeader.m_ulLen;
			pvars[2] = lLen;
			lLenInBuffer = pT->m_rcvQueue.GetSize();
			if((ULONG)lLenInBuffer > (ULONG)lLen)
				lLenInBuffer = lLen;
			if(lLenInBuffer != 0)
			{
				pT->m_pJSSerialization->m_UQueue.Push(pT->m_rcvQueue.GetBuffer(), (ULONG)lLenInBuffer);
				pT->m_rcvQueue.Pop((ULONG)lLenInBuffer);
			}
			pvars[1] = lLenInBuffer;
			pvars[0] = sFlag;
			pT->Invoke(CComBSTR(L"OnRequestProcessed"), pvars, 5, varResult);
		}
		else if(sFlag == rfCompleted && pT->m_pMWindow != NULL && pT->m_vtJSObject.vt == VT_UNKNOWN)
		{
			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComQIPtr<IMozillaWebItem> pIMozillaWebItem(pT->m_vtJSObject.punkVal);
			CComBSTR bstrMethodName(L"OnRequestProcessed");
			hr = pIMozillaWebItem->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {5, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = hSocket;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = nRequestID;
				pvt[1].vt = VT_I2;
				pvt[2].lVal = lLen;
				pvt[2].vt = VT_I4;
				lLenInBuffer = pT->m_rcvQueue.GetSize();
				if((ULONG)lLenInBuffer > (ULONG)lLen)
					lLenInBuffer = lLen;
				if(lLenInBuffer != 0)
				{
					pT->m_pJSSerialization->m_UQueue.Push(pT->m_rcvQueue.GetBuffer(), (ULONG)lLenInBuffer);
					pT->m_rcvQueue.Pop((ULONG)lLenInBuffer);
				}
				pvt[3].lVal = lLenInBuffer;
				pvt[3].vt = VT_I4;
				pvt[4].lVal = sFlag;
				pvt[4].vt = VT_I2;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrMethodName, vtParameters, &varResult);
			}
/*			HRESULT hr;
			VARIANT_BOOL bHas = 0;
			CComBSTR bstrMethodName(L"g_OnUSocketEventMozilla");
			hr = pT->m_pMWindow->HasMethod(bstrMethodName, &bHas);
			if(bHas != VARIANT_FALSE)
			{
				pT->m_pJSSerialization->m_UQueue.SetSize(0);
				VARIANT *pvt = NULL;
				CComVariant vtParameters;
				SAFEARRAYBOUND sab[1] = {7, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				pvt[0].lVal = pT->m_vtJSObject.lVal;
				pvt[0].vt = VT_I4;
				pvt[1].lVal = 10;
				pvt[1].vt = VT_I4;
				pvt[2].lVal = hSocket;
				pvt[2].vt = VT_I4;
				pvt[3].lVal = nRequestID;
				pvt[3].vt = VT_I2;
				pvt[4].lVal = lLen;
				pvt[4].vt = VT_I4;
				lLenInBuffer = pT->m_rcvQueue.GetSize();
				if((ULONG)lLenInBuffer > (ULONG)lLen)
					lLenInBuffer = lLen;
				if(lLenInBuffer != 0)
				{
					pT->m_pJSSerialization->m_UQueue.Push(pT->m_rcvQueue.GetBuffer(), (ULONG)lLenInBuffer);
					pT->m_rcvQueue.Pop((ULONG)lLenInBuffer);
				}
				pvt[5].lVal = lLenInBuffer;
				pvt[5].vt = VT_I4;
				pvt[6].lVal = sFlag;
				pvt[6].vt = VT_I2;
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pT->m_pMWindow->Invoke(bstrMethodName, vtParameters, &varResult);
			}*/	
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[4] = hSocket;
				pvars[3] = nRequestID;	
				lLen = ((CUSocket*)this)->m_USAttr.m_curRcvStreamHeader.m_ulLen;
				pvars[2] = lLen;
				lLenInBuffer = ((CUSocket*)this)->m_rcvQueue.GetSize();
				if((ULONG)lLenInBuffer > (ULONG)lLen)
					lLenInBuffer = lLen;
				pvars[1] = lLenInBuffer;
				pvars[0] = sFlag;
				DISPPARAMS disp = { pvars, NULL, 5, 0 };
				try
				{
					pDispatch->Invoke(0xa, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
				}
				catch(...)
				{
				}
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
};


template <class T>
class CProxy_IUSocketPoolEvents : public IConnectionPointImpl<T, &DIID__IUSocketPoolEvents, CComDynamicUnkArray>
{
	//Warning this class may be recreated by the wizard.
public:
	HRESULT Fire_OnSocketPoolEvent(tagSocketPoolEvent spe, IUSocket * pIUSocket)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[2];
		CComVariant pvars[2];
		int nConnections = m_vec.GetSize();
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = spe;
				pvars[0] = (IDispatch*)pIUSocket;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
};
#endif