#ifndef __UDAPARTS_USE_OPENSSL_H__
#define __UDAPARTS_USE_OPENSSL_H__

///////////////////////////////////////////////////////////////////////////////
// CUsesOpenSSL
///////////////////////////////////////////////////////////////////////////////
#include <openssl/ssl.h> 

enum tagOpenSSLMethod
{
	omSSLv3 = 0,
	omTLSv1,
	omDTLSv1,
};

class CUsesOpenSSL
{
public:
	CUsesOpenSSL(bool multiThreadedUse);
	~CUsesOpenSSL();

public:
	SSL_CTX *GetSSLCtx(tagOpenSSLMethod om = omSSLv3);
	void CloseSSLCtx();

private :
	const bool	m_weOwnLocks;
	SSL_CTX		*m_pSSLContext;

	// No copies do not implement
	CUsesOpenSSL(const CUsesOpenSSL &rhs);
	CUsesOpenSSL &operator=(const CUsesOpenSSL &rhs);
};

#endif //__UDAPARTS_USE_OPENSSL_H__

