/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Feb 16 22:27:48 2007
 */
/* Compiler settings for E:\uskt\usocket\USocket.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __USocket_h__
#define __USocket_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ISocketBase_FWD_DEFINED__
#define __ISocketBase_FWD_DEFINED__
typedef interface ISocketBase ISocketBase;
#endif 	/* __ISocketBase_FWD_DEFINED__ */


#ifndef __IUSocket_FWD_DEFINED__
#define __IUSocket_FWD_DEFINED__
typedef interface IUSocket IUSocket;
#endif 	/* __IUSocket_FWD_DEFINED__ */


#ifndef __IUChat_FWD_DEFINED__
#define __IUChat_FWD_DEFINED__
typedef interface IUChat IUChat;
#endif 	/* __IUChat_FWD_DEFINED__ */


#ifndef __IUFast_FWD_DEFINED__
#define __IUFast_FWD_DEFINED__
typedef interface IUFast IUFast;
#endif 	/* __IUFast_FWD_DEFINED__ */


#ifndef __IUZip_FWD_DEFINED__
#define __IUZip_FWD_DEFINED__
typedef interface IUZip IUZip;
#endif 	/* __IUZip_FWD_DEFINED__ */


#ifndef __IUCert_FWD_DEFINED__
#define __IUCert_FWD_DEFINED__
typedef interface IUCert IUCert;
#endif 	/* __IUCert_FWD_DEFINED__ */


#ifndef ___IUSocketEvent_FWD_DEFINED__
#define ___IUSocketEvent_FWD_DEFINED__
typedef interface _IUSocketEvent _IUSocketEvent;
#endif 	/* ___IUSocketEvent_FWD_DEFINED__ */


#ifndef __IUSocketPool_FWD_DEFINED__
#define __IUSocketPool_FWD_DEFINED__
typedef interface IUSocketPool IUSocketPool;
#endif 	/* __IUSocketPool_FWD_DEFINED__ */


#ifndef __USocket_FWD_DEFINED__
#define __USocket_FWD_DEFINED__

#ifdef __cplusplus
typedef class USocket USocket;
#else
typedef struct USocket USocket;
#endif /* __cplusplus */

#endif 	/* __USocket_FWD_DEFINED__ */


#ifndef ___IUSocketPoolEvents_FWD_DEFINED__
#define ___IUSocketPoolEvents_FWD_DEFINED__
typedef interface _IUSocketPoolEvents _IUSocketPoolEvents;
#endif 	/* ___IUSocketPoolEvents_FWD_DEFINED__ */


#ifndef __USocketPool_FWD_DEFINED__
#define __USocketPool_FWD_DEFINED__

#ifdef __cplusplus
typedef class USocketPool USocketPool;
#else
typedef struct USocketPool USocketPool;
#endif /* __cplusplus */

#endif 	/* __USocketPool_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __USOCKETLib_LIBRARY_DEFINED__
#define __USOCKETLib_LIBRARY_DEFINED__

/* library USOCKETLib */
/* [helpstring][version][uuid] */ 


enum tagAddressFamily
    {	afUnix	= 1,
	afINet	= 2,
	afImpLink	= 3,
	afPup	= 4,
	afChaos	= 5,
	afNS	= 6,
	afIPX	= afNS,
	afISO	= 7,
	afOSI	= afISO,
	afECMA	= 8,
	afDataKit	= 9,
	afCCITT	= 10,
	afSNA	= 11,
	afDECnet	= 12,
	afDLI	= 13,
	afLAT	= 14,
	afHyLink	= 15,
	afAppleTalk	= 16,
	afNetBIOS	= 17,
	afVoiceView	= 18,
	afFireFox	= 19,
	afUnknown1	= 20,
	afBan	= 21,
	afATM	= 22,
	afINet6	= 23,
	afCluster	= 24,
	af12844	= 25,
	afMax	= 26
    };

enum tagSocketType
    {	stSTREAM	= 1,
	stDGRAM	= 2,
	stRAW	= 3,
	stRDM	= 4,
	stSEQPACKET	= 5
    };

enum tagSocketProtocol
    {	spIP	= 0,
	spICMP	= 1,
	spIGMP	= 2,
	spTCP	= 6,
	spUDP	= 17
    };

enum tagSocketLevel
    {	slTcp	= 0x6,
	slSocket	= 0xffff
    };

enum tagSocketOption
    {	soTcpNoDelay	= 0x1,
	soDebug	= 0x1,
	soAcceptConn	= 0x2,
	soReuseAddr	= 0x4,
	soKeepAlive	= 0x8,
	soDontRoute	= 0x10,
	soBroadcast	= 0x20,
	soUseLoopback	= 0x40,
	soLinger	= 0x80,
	soOOBInLine	= 0x100,
	soSndBuf	= 0x1001,
	soRcvBuf	= 0x1002,
	soSndLowAt	= 0x1003,
	soRcvLowAt	= 0x1004,
	soSndTimeout	= 0x1005,
	soRcvTimeout	= 0x1006,
	soError	= 0x1007,
	soType	= 0x1008,
	soGroupID	= 0x2001,
	soGroupPriority	= 0x2002,
	soMaxMsgSize	= 0x2003
    };

enum tagSocketError
    {	seSSLError	= 1,
	seSSLWantRead	= 2,
	seSSLWantWrite	= 3,
	seSSLWantX509Lookup	= 4,
	seSSLSysCall	= 5,
	seSSLZeroReturn	= 6,
	seSSLWantConnect	= 7,
	seSSLWantAccept	= 8,
	seClientAuthenticationError	= 9,
	seBase	= 10000,
	seWouldBlock	= seBase + 35,
	seInProgress	= seWouldBlock + 1,
	seAlready	= seInProgress + 1,
	seNotSock	= seAlready + 1,
	seDestAddrReq	= seNotSock + 1,
	seMsgSize	= seDestAddrReq + 1,
	seProtoType	= seMsgSize + 1,
	seNoProtoOpt	= seProtoType + 1,
	seProtoNoSupport	= seNoProtoOpt + 1,
	seSocktNoSupport	= seProtoNoSupport + 1,
	seOpNotSupp	= seSocktNoSupport + 1,
	sePFNoSupport	= seOpNotSupp + 1,
	seAFNoSupport	= sePFNoSupport + 1,
	seAddrInUse	= seAFNoSupport + 1,
	seAddrNotAvail	= seAddrInUse + 1,
	seNetDown	= seAddrNotAvail + 1,
	seNetUnreach	= seNetDown + 1,
	setNetReset	= seNetUnreach + 1,
	seConnAborted	= setNetReset + 1,
	seConnReset	= seConnAborted + 1,
	seNoBufs	= seConnReset + 1,
	seIsConn	= seNoBufs + 1,
	seNotConn	= seIsConn + 1,
	seShutDown	= seNotConn + 1,
	seTooManyRefs	= seShutDown + 1,
	seTimedOut	= seTooManyRefs + 1,
	seConnRefused	= seTimedOut + 1,
	seLoop	= seConnRefused + 1,
	seNameTooLong	= seLoop + 1,
	seHostDown	= seNameTooLong + 1,
	seHostUnreach	= seHostDown + 1,
	seNotEmpty	= seHostUnreach + 1,
	seProclim	= seNotEmpty + 1,
	seUsers	= seProclim + 1,
	seDquot	= seUsers + 1,
	seStale	= seDquot + 1,
	seRemote	= seStale + 1
    };

enum tagSpecialSocket
    {	ssInvalidSocket	= -1
    };

enum tagEncryptionMethod
    {	NoEncryption	= 0,
	BlowFish	= 1,
	SSL23	= 2,
	MSSSL	= 3,
	TLSv1	= 4,
	MSTLSv1	= 5
    };

enum tagSSLEvent
    {	ssleHandshakeStarted	= 0x10,
	ssleHandshakeDone	= 0x20,
	ssleHandshakeLoop	= 0x1001,
	ssleHandshakeExit	= 0x1002,
	ssleReadAlert	= 0x4004,
	ssleWriteAlert	= 0x4008,
	ssleDoSSLConnect	= 0x811f
    };

enum tagHowtoShutdown
    {	hsReceive	= 0,
	hsSend	= 0x1,
	hsBoth	= 0x2
    };

enum tagIOCommand
    {	iocRead	= 0x4004667f,
	iocOOB	= 0x40047307,
	iocBIO	= 0x8004667e
    };

enum tagInterfaceType
    {	itOther	= 1,
	itEthernet	= 6,
	itTokenRing	= 9,
	itFDDI	= 15,
	itPPP	= 23,
	itLoopback	= 24,
	itSlip	= 28
    };

enum tagNetPerformance
    {	npUnknown	= 0,
	npVerySlow	= npUnknown + 1,
	npSlow	= npVerySlow + 1,
	npMiddle	= npSlow + 1,
	npFast	= npMiddle + 1,
	npSuper	= npFast + 1
    };

enum tagClientMessage
    {	msgSocketEvent	= 0x781,
	msgAsyncGetHostByName	= msgSocketEvent + 1,
	msgWSAGetHostByName	= msgAsyncGetHostByName + 1,
	msgWSAGetHostByAddr	= msgWSAGetHostByName + 1,
	msgSSLEvent	= msgWSAGetHostByAddr + 1
    };

enum tagReturnFlag
    {	rfUnknown	= 0,
	rfComing	= 1,
	rfReceiving	= 2,
	rfDecrypted	= 4,
	rfUnzipped	= 16,
	rfCompleted	= 32,
	rfDataComing	= 64
    };

enum tagBaseRequestID
    {	idUnknown	= 0,
	idSwitchTo	= 1,
	idPublicKeyFromSvr	= idSwitchTo + 1,
	idEncrypted	= idPublicKeyFromSvr + 1,
	idBatchZipped	= idEncrypted + 1,
	idCancel	= idBatchZipped + 1,
	idGetSockOptAtSvr	= idCancel + 1,
	idSetSockOptAtSvr	= idGetSockOptAtSvr + 1,
	idDoEcho	= idSetSockOptAtSvr + 1,
	idTurnOnZipAtSvr	= idDoEcho + 1,
	idStartBatching	= idTurnOnZipAtSvr + 1,
	idCommitBatching	= idStartBatching + 1,
	idShrinkMemoryAtSvr	= idCommitBatching + 1,
	idEchoFromSvr	= idShrinkMemoryAtSvr + 1,
	idPing	= idEchoFromSvr + 1,
	idSendingTooFast	= idPing + 1,
	idSendMySpecificBytes	= idSendingTooFast + 1,
	idCleanTrack	= idSendMySpecificBytes + 1,
	idVerifySalt	= idCleanTrack + 1,
	idSetZipLevelAtSvr	= idVerifySalt + 1,
	idReservedOne	= 0x100,
	idReservedTwo	= 0x200
    };

enum tagChatRequestID
    {	idEnter	= 31,
	idExit	= idEnter + 1,
	idGetAllGroups	= idExit + 1,
	idGetAllListeners	= idGetAllGroups + 1,
	idSpeak	= idGetAllListeners + 1,
	idSpeakTo	= idSpeak + 1,
	idGetAllClients	= idSpeakTo + 1,
	idSpeakEx	= idGetAllClients + 1,
	idSpeakToEx	= idSpeakEx + 1,
	idSendUserMessage	= idSpeakToEx + 1,
	idSendUserMessageEx	= idSendUserMessage + 1
    };

enum tagServiceID
    {	sidStartup	= 0x100,
	sidChat	= sidStartup + 1,
	sidWinFile	= sidChat + 1,
	sidStdIO	= sidWinFile + 1,
	sidOleDB	= sidStdIO + 1,
	sidODBC	= sidOleDB + 1,
	sidADODotNet	= sidODBC + 1,
	sidOracleOCI	= sidADODotNet + 1,
	sidJDBC	= sidOracleOCI + 1,
	sidRemoteAdmin	= sidJDBC + 1
    };

enum tagUErrorCode
    {	uecOK	= 0,
	uecSvrNotRegistered	= 0x1,
	uecUnexpected	= 0x8f000000,
	uecSvsNotAvailable	= 0x8f100001,
	uecAuthenticationFailed	= 0x8f100002,
	uecClientRejected	= 0x8f100003,
	uecFailedInLoadingSSL	= 0x8f100004,
	uecFailedInStartingSSL	= 0x8f100005,
	uecNotImplemented	= 0x8f100006,
	uecFail	= 0x8f100007,
	uecFailedInZip	= 0x8f100008,
	uecFailedInUnzip	= 0x8f100009,
	uecFailedInEncrypt	= 0x8f10000a,
	uecFailedInDecrypt	= 0x8f10000b,
	uecReadOnly	= 0x8f10000c,
	uecNoMoreData	= 0x8f10000d,
	uecExceptionCatched	= 0x8f10000e,
	uecRequestCanceled	= 0x8f10000f,
	uecNotFound	= 0x8f100010,
	uecFailedInLoadingMsSSPI	= 0x8f100011
    };

enum tagSocketPoolErrorCode
    {	specUnexpected	= 0x8f200000,
	specWrongApartment	= 0x8f200001,
	specLockTimeOut	= 0x8f200002,
	specNotPooledSocket	= 0x8f200003,
	specNoOpenedSocket	= 0x8f200004,
	specNotUSocket	= 0x8f200005,
	specNoFreeSocket	= 0x8f200006,
	specTooManySockets	= 0x8f200007,
	specPoolNotStarted	= 0x8f200008,
	specSocketOpenedAlready	= 0x8f200009,
	specLockingInterrupted	= 0x8f20000a,
	specLockingAbandoned	= 0x8f20000b
    };

enum tagOtherDefine
    {	odFastZip	= 0x40,
	odZipped	= 0x80,
	odUserRequestIDMin	= 0x2001,
	odUserRequestIDMax	= 0xffff,
	odUserServiceIDMin	= 0x10000000,
	odUserServiceIDMax	= 0xffffffff,
	odCancelAll	= 0xffffffff,
	odAllGroups	= 0xffffffff
    };

enum tagOperationSystem
    {	osUnknown	= 0,
	osWin9XMe	= 1,
	osWinNT	= 2,
	osWinCE	= 3,
	osLinux	= 64,
	osJava	= 128
    };
typedef /* [public][public][public][public][public] */ 
enum __MIDL___MIDL_itf_USocket_0000_0001
    {	zlDefault	= 0,
	zlBestSpeed	= 1,
	zlBestCompression	= 2
    }	tagZipLevel;


enum tagAuthenticationMethod
    {	amOwn	= 0,
	amMixed	= amOwn + 1,
	amIntegrated	= amMixed + 1,
	amTrusted	= amIntegrated + 1
    };
typedef 
enum tagSocketPoolEvent
    {	speUnknown	= -1,
	speStarted	= speUnknown + 1,
	speCreatingThread	= speStarted + 1,
	speThreadCreated	= speCreatingThread + 1,
	speConnecting	= speThreadCreated + 1,
	speConnected	= speConnecting + 1,
	speKillingThread	= speConnected + 1,
	speShutdown	= speKillingThread + 1
    }	tagSocketPoolEvent;

#pragma pack(push,1)
struct  CSwitchInfo
    {
    unsigned long m_ulSvsID;
    unsigned short m_usVerMajor;
    unsigned short m_usVerMinor;
    unsigned short m_usUSockMajor;
    unsigned short m_usUSockMinor;
    unsigned long m_ulParam1;
    unsigned long m_ulParam2;
    unsigned long m_ulParam3;
    unsigned long m_ulParam4;
    unsigned long m_ulParam5;
    };
#pragma pack(pop)

EXTERN_C const IID LIBID_USOCKETLib;

#ifndef __ISocketBase_INTERFACE_DEFINED__
#define __ISocketBase_INTERFACE_DEFINED__

/* interface ISocketBase */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISocketBase;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1084FB17-4EDB-42F1-A4A8-129D70A0A8FA")
    ISocketBase : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Connect( 
            /* [in] */ BSTR bstrHostAddress,
            /* [in] */ long lHostPort,
            /* [defaultvalue][in] */ VARIANT_BOOL bSynConnecting = 0,
            /* [defaultvalue][in] */ long lSocketType = stSTREAM,
            /* [defaultvalue][in] */ long lAddrFormat = afINet,
            /* [defaultvalue][in] */ long lProtocol = spIP,
            /* [defaultvalue][in] */ long lLocalPort = 0) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Disconnect( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Shutdown( 
            /* [defaultvalue][in] */ long lHow = hsSend) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetSockOpt( 
            /* [in] */ long lOptName,
            /* [in] */ long lOptValue,
            /* [defaultvalue][in] */ long lLevel = slSocket) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetSockOpt( 
            /* [in] */ long lOptName,
            /* [defaultvalue][in] */ long lLevel,
            /* [retval][out] */ long __RPC_FAR *plOptValue) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Send( 
            /* [in] */ VARIANT vtData,
            /* [retval][out] */ long __RPC_FAR *plSent) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Recv( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvtData) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IOCtl( 
            /* [defaultvalue][in] */ long lCommand,
            /* [retval][out] */ long __RPC_FAR *plArgment) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetInterfaceAttributes( 
            /* [out] */ long __RPC_FAR *lpMTU,
            /* [out] */ long __RPC_FAR *plMaxSpeed,
            /* [out] */ long __RPC_FAR *plIType,
            /* [out] */ BSTR __RPC_FAR *pbstrMask,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrDesc) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPeerName( 
            /* [out] */ long __RPC_FAR *plPeerPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrPeerName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetLocalName( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrLocalName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetHostByName( 
            /* [in] */ BSTR bstrHost,
            /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
            /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrIPAddr,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetHostByAddr( 
            /* [in] */ BSTR bstrIPAddr,
            /* [defaultvalue][in] */ long lAddrFormat,
            /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
            /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetProcAddress( 
            /* [in] */ BSTR bstrOpenSSLFuncName,
            /* [retval][out] */ long __RPC_FAR *plProcAddr) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetSockAddr( 
            /* [out] */ long __RPC_FAR *plPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrSockAddr) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetBytesSent( 
            /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetBytesReceived( 
            /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ConnTimeout( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ConnTimeout( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Socket( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EncryptionMethod( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EncryptionMethod( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SSLHandle( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_PeerCertificate( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_UseBaseSocketOnly( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_UseBaseSocketOnly( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_hWnd( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISocketBaseVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISocketBase __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISocketBase __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISocketBase __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Connect )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ BSTR bstrHostAddress,
            /* [in] */ long lHostPort,
            /* [defaultvalue][in] */ VARIANT_BOOL bSynConnecting,
            /* [defaultvalue][in] */ long lSocketType,
            /* [defaultvalue][in] */ long lAddrFormat,
            /* [defaultvalue][in] */ long lProtocol,
            /* [defaultvalue][in] */ long lLocalPort);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Disconnect )( 
            ISocketBase __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Shutdown )( 
            ISocketBase __RPC_FAR * This,
            /* [defaultvalue][in] */ long lHow);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSockOpt )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ long lOptName,
            /* [in] */ long lOptValue,
            /* [defaultvalue][in] */ long lLevel);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSockOpt )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ long lOptName,
            /* [defaultvalue][in] */ long lLevel,
            /* [retval][out] */ long __RPC_FAR *plOptValue);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Send )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ VARIANT vtData,
            /* [retval][out] */ long __RPC_FAR *plSent);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Recv )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvtData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IOCtl )( 
            ISocketBase __RPC_FAR * This,
            /* [defaultvalue][in] */ long lCommand,
            /* [retval][out] */ long __RPC_FAR *plArgment);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetInterfaceAttributes )( 
            ISocketBase __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *lpMTU,
            /* [out] */ long __RPC_FAR *plMaxSpeed,
            /* [out] */ long __RPC_FAR *plIType,
            /* [out] */ BSTR __RPC_FAR *pbstrMask,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrDesc);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPeerName )( 
            ISocketBase __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *plPeerPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrPeerName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetLocalName )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrLocalName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHostByName )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ BSTR bstrHost,
            /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
            /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrIPAddr,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHostByAddr )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ BSTR bstrIPAddr,
            /* [defaultvalue][in] */ long lAddrFormat,
            /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
            /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetProcAddress )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ BSTR bstrOpenSSLFuncName,
            /* [retval][out] */ long __RPC_FAR *plProcAddr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSockAddr )( 
            ISocketBase __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *plPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrSockAddr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBytesSent )( 
            ISocketBase __RPC_FAR * This,
            /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBytesReceived )( 
            ISocketBase __RPC_FAR * This,
            /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ConnTimeout )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ConnTimeout )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Socket )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_EncryptionMethod )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_EncryptionMethod )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SSLHandle )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PeerCertificate )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_UseBaseSocketOnly )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_UseBaseSocketOnly )( 
            ISocketBase __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_hWnd )( 
            ISocketBase __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } ISocketBaseVtbl;

    interface ISocketBase
    {
        CONST_VTBL struct ISocketBaseVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISocketBase_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISocketBase_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISocketBase_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISocketBase_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISocketBase_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISocketBase_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISocketBase_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISocketBase_Connect(This,bstrHostAddress,lHostPort,bSynConnecting,lSocketType,lAddrFormat,lProtocol,lLocalPort)	\
    (This)->lpVtbl -> Connect(This,bstrHostAddress,lHostPort,bSynConnecting,lSocketType,lAddrFormat,lProtocol,lLocalPort)

#define ISocketBase_Disconnect(This)	\
    (This)->lpVtbl -> Disconnect(This)

#define ISocketBase_Shutdown(This,lHow)	\
    (This)->lpVtbl -> Shutdown(This,lHow)

#define ISocketBase_SetSockOpt(This,lOptName,lOptValue,lLevel)	\
    (This)->lpVtbl -> SetSockOpt(This,lOptName,lOptValue,lLevel)

#define ISocketBase_GetSockOpt(This,lOptName,lLevel,plOptValue)	\
    (This)->lpVtbl -> GetSockOpt(This,lOptName,lLevel,plOptValue)

#define ISocketBase_Send(This,vtData,plSent)	\
    (This)->lpVtbl -> Send(This,vtData,plSent)

#define ISocketBase_Recv(This,pvtData)	\
    (This)->lpVtbl -> Recv(This,pvtData)

#define ISocketBase_IOCtl(This,lCommand,plArgment)	\
    (This)->lpVtbl -> IOCtl(This,lCommand,plArgment)

#define ISocketBase_GetInterfaceAttributes(This,lpMTU,plMaxSpeed,plIType,pbstrMask,pbstrDesc)	\
    (This)->lpVtbl -> GetInterfaceAttributes(This,lpMTU,plMaxSpeed,plIType,pbstrMask,pbstrDesc)

#define ISocketBase_GetPeerName(This,plPeerPort,pbstrPeerName)	\
    (This)->lpVtbl -> GetPeerName(This,plPeerPort,pbstrPeerName)

#define ISocketBase_GetLocalName(This,pbstrLocalName)	\
    (This)->lpVtbl -> GetLocalName(This,pbstrLocalName)

#define ISocketBase_GetHostByName(This,bstrHost,bBlocking,phHandle,pbstrIPAddr,pbstrAlias,pbstrHostName)	\
    (This)->lpVtbl -> GetHostByName(This,bstrHost,bBlocking,phHandle,pbstrIPAddr,pbstrAlias,pbstrHostName)

#define ISocketBase_GetHostByAddr(This,bstrIPAddr,lAddrFormat,bBlocking,phHandle,pbstrAlias,pbstrHostName)	\
    (This)->lpVtbl -> GetHostByAddr(This,bstrIPAddr,lAddrFormat,bBlocking,phHandle,pbstrAlias,pbstrHostName)

#define ISocketBase_GetProcAddress(This,bstrOpenSSLFuncName,plProcAddr)	\
    (This)->lpVtbl -> GetProcAddress(This,bstrOpenSSLFuncName,plProcAddr)

#define ISocketBase_GetSockAddr(This,plPort,pbstrSockAddr)	\
    (This)->lpVtbl -> GetSockAddr(This,plPort,pbstrSockAddr)

#define ISocketBase_GetBytesSent(This,plHigh,pVal)	\
    (This)->lpVtbl -> GetBytesSent(This,plHigh,pVal)

#define ISocketBase_GetBytesReceived(This,plHigh,pVal)	\
    (This)->lpVtbl -> GetBytesReceived(This,plHigh,pVal)

#define ISocketBase_get_ConnTimeout(This,pVal)	\
    (This)->lpVtbl -> get_ConnTimeout(This,pVal)

#define ISocketBase_put_ConnTimeout(This,newVal)	\
    (This)->lpVtbl -> put_ConnTimeout(This,newVal)

#define ISocketBase_get_Socket(This,pVal)	\
    (This)->lpVtbl -> get_Socket(This,pVal)

#define ISocketBase_get_EncryptionMethod(This,pVal)	\
    (This)->lpVtbl -> get_EncryptionMethod(This,pVal)

#define ISocketBase_put_EncryptionMethod(This,newVal)	\
    (This)->lpVtbl -> put_EncryptionMethod(This,newVal)

#define ISocketBase_get_SSLHandle(This,pVal)	\
    (This)->lpVtbl -> get_SSLHandle(This,pVal)

#define ISocketBase_get_PeerCertificate(This,pVal)	\
    (This)->lpVtbl -> get_PeerCertificate(This,pVal)

#define ISocketBase_get_UseBaseSocketOnly(This,pVal)	\
    (This)->lpVtbl -> get_UseBaseSocketOnly(This,pVal)

#define ISocketBase_put_UseBaseSocketOnly(This,newVal)	\
    (This)->lpVtbl -> put_UseBaseSocketOnly(This,newVal)

#define ISocketBase_get_hWnd(This,pVal)	\
    (This)->lpVtbl -> get_hWnd(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_Connect_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ BSTR bstrHostAddress,
    /* [in] */ long lHostPort,
    /* [defaultvalue][in] */ VARIANT_BOOL bSynConnecting,
    /* [defaultvalue][in] */ long lSocketType,
    /* [defaultvalue][in] */ long lAddrFormat,
    /* [defaultvalue][in] */ long lProtocol,
    /* [defaultvalue][in] */ long lLocalPort);


void __RPC_STUB ISocketBase_Connect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_Disconnect_Proxy( 
    ISocketBase __RPC_FAR * This);


void __RPC_STUB ISocketBase_Disconnect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_Shutdown_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [defaultvalue][in] */ long lHow);


void __RPC_STUB ISocketBase_Shutdown_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_SetSockOpt_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ long lOptName,
    /* [in] */ long lOptValue,
    /* [defaultvalue][in] */ long lLevel);


void __RPC_STUB ISocketBase_SetSockOpt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetSockOpt_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ long lOptName,
    /* [defaultvalue][in] */ long lLevel,
    /* [retval][out] */ long __RPC_FAR *plOptValue);


void __RPC_STUB ISocketBase_GetSockOpt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_Send_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ VARIANT vtData,
    /* [retval][out] */ long __RPC_FAR *plSent);


void __RPC_STUB ISocketBase_Send_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_Recv_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvtData);


void __RPC_STUB ISocketBase_Recv_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_IOCtl_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [defaultvalue][in] */ long lCommand,
    /* [retval][out] */ long __RPC_FAR *plArgment);


void __RPC_STUB ISocketBase_IOCtl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetInterfaceAttributes_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *lpMTU,
    /* [out] */ long __RPC_FAR *plMaxSpeed,
    /* [out] */ long __RPC_FAR *plIType,
    /* [out] */ BSTR __RPC_FAR *pbstrMask,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrDesc);


void __RPC_STUB ISocketBase_GetInterfaceAttributes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetPeerName_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *plPeerPort,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrPeerName);


void __RPC_STUB ISocketBase_GetPeerName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetLocalName_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrLocalName);


void __RPC_STUB ISocketBase_GetLocalName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetHostByName_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ BSTR bstrHost,
    /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
    /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
    /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrIPAddr,
    /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName);


void __RPC_STUB ISocketBase_GetHostByName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetHostByAddr_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ BSTR bstrIPAddr,
    /* [defaultvalue][in] */ long lAddrFormat,
    /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
    /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
    /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName);


void __RPC_STUB ISocketBase_GetHostByAddr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetProcAddress_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ BSTR bstrOpenSSLFuncName,
    /* [retval][out] */ long __RPC_FAR *plProcAddr);


void __RPC_STUB ISocketBase_GetProcAddress_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetSockAddr_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *plPort,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrSockAddr);


void __RPC_STUB ISocketBase_GetSockAddr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetBytesSent_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_GetBytesSent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISocketBase_GetBytesReceived_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_GetBytesReceived_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISocketBase_get_ConnTimeout_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_get_ConnTimeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISocketBase_put_ConnTimeout_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ISocketBase_put_ConnTimeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISocketBase_get_Socket_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_get_Socket_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISocketBase_get_EncryptionMethod_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_get_EncryptionMethod_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISocketBase_put_EncryptionMethod_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB ISocketBase_put_EncryptionMethod_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISocketBase_get_SSLHandle_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_get_SSLHandle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISocketBase_get_PeerCertificate_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_get_PeerCertificate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISocketBase_get_UseBaseSocketOnly_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_get_UseBaseSocketOnly_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISocketBase_put_UseBaseSocketOnly_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB ISocketBase_put_UseBaseSocketOnly_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISocketBase_get_hWnd_Proxy( 
    ISocketBase __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISocketBase_get_hWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISocketBase_INTERFACE_DEFINED__ */


#ifndef __IUSocket_INTERFACE_DEFINED__
#define __IUSocket_INTERFACE_DEFINED__

/* interface IUSocket */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUSocket;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1B84FB17-40DB-42F1-A4A8-129D70A0A8FA")
    IUSocket : public ISocketBase
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SwitchTo( 
            /* [in] */ long lSvsID) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE StartBatching( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CommitBatching( 
            /* [defaultvalue][in] */ VARIANT_BOOL bSvrBatching = 0) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AbortBatching( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WaitAll( 
            /* [in] */ long lTimeOut,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbTimeout) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DoEcho( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetRequestsInQueue( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvtRequests) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendRequest( 
            /* [in] */ short nRequestID,
            /* [in] */ VARIANT vtData,
            /* [defaultvalue][in] */ VARIANT_BOOL bKeepVTFormat = 0) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetRtnBuffer( 
            /* [in] */ long nLen,
            /* [retval][out] */ VARIANT __RPC_FAR *pvtData) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Cancel( 
            /* [defaultvalue][in] */ long lRequests = odCancelAll) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetSockOptAtSvr( 
            /* [in] */ long lOptName,
            /* [in] */ long lOptValue,
            /* [defaultvalue][in] */ long lLevel = slSocket) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetSockOptAtSvr( 
            /* [in] */ long lOptName,
            /* [defaultvalue][in] */ long lLevel = slSocket) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetOptValueAtSvr( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetClientVersion( 
            /* [in] */ short nMinor,
            /* [in] */ short nMajor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TurnOnZipAtSvr( 
            /* [defaultvalue][in] */ VARIANT_BOOL bZipOn = -1) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetClientVersion( 
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [retval][out] */ short __RPC_FAR *pnMajor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetServerVersion( 
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [out] */ short __RPC_FAR *pnMajor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShrinkMemory( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShrinkMemoryAtSvr( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetClientUSockVersion( 
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [retval][out] */ short __RPC_FAR *pnMajor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetServerUSockVersion( 
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [retval][out] */ short __RPC_FAR *pnMajor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DetectNetPerformance( 
            /* [retval][out] */ short __RPC_FAR *psNetPerformance) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IgnorePendingRequests( 
            /* [defaultvalue][in] */ long lRequests = -1,
            /* [defaultvalue][in] */ long lStartWith = 0) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMySpecificBytes( 
            /* [in] */ VARIANT vtBytes) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ErrorMsg( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorMsg) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Key( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Key( 
            /* [in] */ VARIANT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ZipIsOn( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ZipIsOn( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_UserID( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_UserID( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Password( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Password( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RcvMemory( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SndMemory( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Syn( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Syn( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ClientParams( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ClientParams( 
            /* [in] */ VARIANT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ServerParams( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RecvTimeout( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_RecvTimeout( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SendTimeout( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SendTimeout( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_KeyFromSvr( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RequestsCanceled( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Frozen( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Frozen( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BytesInSndMemory( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BytesInRcvMemory( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ReturnEvents( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ReturnEvents( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MaxRtns( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MaxRtns( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RtnsInQueue( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CurrentSvsID( 
            /* [retval][out] */ long __RPC_FAR *plSvsID) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ZipOnAtSvr( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Rtn( 
            /* [retval][out] */ long __RPC_FAR *plRtn) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_IsSameEndian( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BytesBatched( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Wait( 
            /* [in] */ short sRequestID,
            /* [in] */ long lTimeout,
            /* [defaultvalue][in] */ long lSvsID,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbTimeout) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CountOfRequestsInQueue( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_IsBatching( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CleanTrack( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LastRequestID( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUSocketVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUSocket __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUSocket __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Connect )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ BSTR bstrHostAddress,
            /* [in] */ long lHostPort,
            /* [defaultvalue][in] */ VARIANT_BOOL bSynConnecting,
            /* [defaultvalue][in] */ long lSocketType,
            /* [defaultvalue][in] */ long lAddrFormat,
            /* [defaultvalue][in] */ long lProtocol,
            /* [defaultvalue][in] */ long lLocalPort);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Disconnect )( 
            IUSocket __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Shutdown )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][in] */ long lHow);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSockOpt )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long lOptName,
            /* [in] */ long lOptValue,
            /* [defaultvalue][in] */ long lLevel);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSockOpt )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long lOptName,
            /* [defaultvalue][in] */ long lLevel,
            /* [retval][out] */ long __RPC_FAR *plOptValue);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Send )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT vtData,
            /* [retval][out] */ long __RPC_FAR *plSent);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Recv )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvtData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IOCtl )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][in] */ long lCommand,
            /* [retval][out] */ long __RPC_FAR *plArgment);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetInterfaceAttributes )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *lpMTU,
            /* [out] */ long __RPC_FAR *plMaxSpeed,
            /* [out] */ long __RPC_FAR *plIType,
            /* [out] */ BSTR __RPC_FAR *pbstrMask,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrDesc);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPeerName )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *plPeerPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrPeerName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetLocalName )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrLocalName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHostByName )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ BSTR bstrHost,
            /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
            /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrIPAddr,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHostByAddr )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ BSTR bstrIPAddr,
            /* [defaultvalue][in] */ long lAddrFormat,
            /* [defaultvalue][in] */ VARIANT_BOOL bBlocking,
            /* [defaultvalue][out] */ long __RPC_FAR *phHandle,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrAlias,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrHostName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetProcAddress )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ BSTR bstrOpenSSLFuncName,
            /* [retval][out] */ long __RPC_FAR *plProcAddr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSockAddr )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *plPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrSockAddr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBytesSent )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBytesReceived )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][out] */ long __RPC_FAR *plHigh,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ConnTimeout )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ConnTimeout )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Socket )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_EncryptionMethod )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_EncryptionMethod )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SSLHandle )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PeerCertificate )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_UseBaseSocketOnly )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_UseBaseSocketOnly )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_hWnd )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SwitchTo )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long lSvsID);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StartBatching )( 
            IUSocket __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CommitBatching )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bSvrBatching);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AbortBatching )( 
            IUSocket __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WaitAll )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long lTimeOut,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbTimeout);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DoEcho )( 
            IUSocket __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRequestsInQueue )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvtRequests);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendRequest )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ short nRequestID,
            /* [in] */ VARIANT vtData,
            /* [defaultvalue][in] */ VARIANT_BOOL bKeepVTFormat);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRtnBuffer )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long nLen,
            /* [retval][out] */ VARIANT __RPC_FAR *pvtData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Cancel )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][in] */ long lRequests);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSockOptAtSvr )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long lOptName,
            /* [in] */ long lOptValue,
            /* [defaultvalue][in] */ long lLevel);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSockOptAtSvr )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long lOptName,
            /* [defaultvalue][in] */ long lLevel);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetOptValueAtSvr )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetClientVersion )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ short nMinor,
            /* [in] */ short nMajor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TurnOnZipAtSvr )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bZipOn);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetClientVersion )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [retval][out] */ short __RPC_FAR *pnMajor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetServerVersion )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [out] */ short __RPC_FAR *pnMajor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShrinkMemory )( 
            IUSocket __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShrinkMemoryAtSvr )( 
            IUSocket __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetClientUSockVersion )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [retval][out] */ short __RPC_FAR *pnMajor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetServerUSockVersion )( 
            IUSocket __RPC_FAR * This,
            /* [out] */ short __RPC_FAR *pnMinor,
            /* [retval][out] */ short __RPC_FAR *pnMajor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DetectNetPerformance )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *psNetPerformance);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IgnorePendingRequests )( 
            IUSocket __RPC_FAR * This,
            /* [defaultvalue][in] */ long lRequests,
            /* [defaultvalue][in] */ long lStartWith);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendMySpecificBytes )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT vtBytes);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ErrorMsg )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorMsg);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Key )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Key )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ZipIsOn )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ZipIsOn )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_UserID )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_UserID )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Password )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Password )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RcvMemory )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SndMemory )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Syn )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Syn )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ClientParams )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ClientParams )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ServerParams )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RecvTimeout )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_RecvTimeout )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SendTimeout )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SendTimeout )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_KeyFromSvr )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RequestsCanceled )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Frozen )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Frozen )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BytesInSndMemory )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BytesInRcvMemory )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ReturnEvents )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ReturnEvents )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_MaxRtns )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_MaxRtns )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RtnsInQueue )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CurrentSvsID )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plSvsID);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ZipOnAtSvr )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Rtn )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plRtn);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsSameEndian )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BytesBatched )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Wait )( 
            IUSocket __RPC_FAR * This,
            /* [in] */ short sRequestID,
            /* [in] */ long lTimeout,
            /* [defaultvalue][in] */ long lSvsID,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbTimeout);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CountOfRequestsInQueue )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsBatching )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CleanTrack )( 
            IUSocket __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LastRequestID )( 
            IUSocket __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        END_INTERFACE
    } IUSocketVtbl;

    interface IUSocket
    {
        CONST_VTBL struct IUSocketVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUSocket_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUSocket_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUSocket_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUSocket_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUSocket_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUSocket_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUSocket_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUSocket_Connect(This,bstrHostAddress,lHostPort,bSynConnecting,lSocketType,lAddrFormat,lProtocol,lLocalPort)	\
    (This)->lpVtbl -> Connect(This,bstrHostAddress,lHostPort,bSynConnecting,lSocketType,lAddrFormat,lProtocol,lLocalPort)

#define IUSocket_Disconnect(This)	\
    (This)->lpVtbl -> Disconnect(This)

#define IUSocket_Shutdown(This,lHow)	\
    (This)->lpVtbl -> Shutdown(This,lHow)

#define IUSocket_SetSockOpt(This,lOptName,lOptValue,lLevel)	\
    (This)->lpVtbl -> SetSockOpt(This,lOptName,lOptValue,lLevel)

#define IUSocket_GetSockOpt(This,lOptName,lLevel,plOptValue)	\
    (This)->lpVtbl -> GetSockOpt(This,lOptName,lLevel,plOptValue)

#define IUSocket_Send(This,vtData,plSent)	\
    (This)->lpVtbl -> Send(This,vtData,plSent)

#define IUSocket_Recv(This,pvtData)	\
    (This)->lpVtbl -> Recv(This,pvtData)

#define IUSocket_IOCtl(This,lCommand,plArgment)	\
    (This)->lpVtbl -> IOCtl(This,lCommand,plArgment)

#define IUSocket_GetInterfaceAttributes(This,lpMTU,plMaxSpeed,plIType,pbstrMask,pbstrDesc)	\
    (This)->lpVtbl -> GetInterfaceAttributes(This,lpMTU,plMaxSpeed,plIType,pbstrMask,pbstrDesc)

#define IUSocket_GetPeerName(This,plPeerPort,pbstrPeerName)	\
    (This)->lpVtbl -> GetPeerName(This,plPeerPort,pbstrPeerName)

#define IUSocket_GetLocalName(This,pbstrLocalName)	\
    (This)->lpVtbl -> GetLocalName(This,pbstrLocalName)

#define IUSocket_GetHostByName(This,bstrHost,bBlocking,phHandle,pbstrIPAddr,pbstrAlias,pbstrHostName)	\
    (This)->lpVtbl -> GetHostByName(This,bstrHost,bBlocking,phHandle,pbstrIPAddr,pbstrAlias,pbstrHostName)

#define IUSocket_GetHostByAddr(This,bstrIPAddr,lAddrFormat,bBlocking,phHandle,pbstrAlias,pbstrHostName)	\
    (This)->lpVtbl -> GetHostByAddr(This,bstrIPAddr,lAddrFormat,bBlocking,phHandle,pbstrAlias,pbstrHostName)

#define IUSocket_GetProcAddress(This,bstrOpenSSLFuncName,plProcAddr)	\
    (This)->lpVtbl -> GetProcAddress(This,bstrOpenSSLFuncName,plProcAddr)

#define IUSocket_GetSockAddr(This,plPort,pbstrSockAddr)	\
    (This)->lpVtbl -> GetSockAddr(This,plPort,pbstrSockAddr)

#define IUSocket_GetBytesSent(This,plHigh,pVal)	\
    (This)->lpVtbl -> GetBytesSent(This,plHigh,pVal)

#define IUSocket_GetBytesReceived(This,plHigh,pVal)	\
    (This)->lpVtbl -> GetBytesReceived(This,plHigh,pVal)

#define IUSocket_get_ConnTimeout(This,pVal)	\
    (This)->lpVtbl -> get_ConnTimeout(This,pVal)

#define IUSocket_put_ConnTimeout(This,newVal)	\
    (This)->lpVtbl -> put_ConnTimeout(This,newVal)

#define IUSocket_get_Socket(This,pVal)	\
    (This)->lpVtbl -> get_Socket(This,pVal)

#define IUSocket_get_EncryptionMethod(This,pVal)	\
    (This)->lpVtbl -> get_EncryptionMethod(This,pVal)

#define IUSocket_put_EncryptionMethod(This,newVal)	\
    (This)->lpVtbl -> put_EncryptionMethod(This,newVal)

#define IUSocket_get_SSLHandle(This,pVal)	\
    (This)->lpVtbl -> get_SSLHandle(This,pVal)

#define IUSocket_get_PeerCertificate(This,pVal)	\
    (This)->lpVtbl -> get_PeerCertificate(This,pVal)

#define IUSocket_get_UseBaseSocketOnly(This,pVal)	\
    (This)->lpVtbl -> get_UseBaseSocketOnly(This,pVal)

#define IUSocket_put_UseBaseSocketOnly(This,newVal)	\
    (This)->lpVtbl -> put_UseBaseSocketOnly(This,newVal)

#define IUSocket_get_hWnd(This,pVal)	\
    (This)->lpVtbl -> get_hWnd(This,pVal)


#define IUSocket_SwitchTo(This,lSvsID)	\
    (This)->lpVtbl -> SwitchTo(This,lSvsID)

#define IUSocket_StartBatching(This)	\
    (This)->lpVtbl -> StartBatching(This)

#define IUSocket_CommitBatching(This,bSvrBatching)	\
    (This)->lpVtbl -> CommitBatching(This,bSvrBatching)

#define IUSocket_AbortBatching(This)	\
    (This)->lpVtbl -> AbortBatching(This)

#define IUSocket_WaitAll(This,lTimeOut,pbTimeout)	\
    (This)->lpVtbl -> WaitAll(This,lTimeOut,pbTimeout)

#define IUSocket_DoEcho(This)	\
    (This)->lpVtbl -> DoEcho(This)

#define IUSocket_GetRequestsInQueue(This,pvtRequests)	\
    (This)->lpVtbl -> GetRequestsInQueue(This,pvtRequests)

#define IUSocket_SendRequest(This,nRequestID,vtData,bKeepVTFormat)	\
    (This)->lpVtbl -> SendRequest(This,nRequestID,vtData,bKeepVTFormat)

#define IUSocket_GetRtnBuffer(This,nLen,pvtData)	\
    (This)->lpVtbl -> GetRtnBuffer(This,nLen,pvtData)

#define IUSocket_Cancel(This,lRequests)	\
    (This)->lpVtbl -> Cancel(This,lRequests)

#define IUSocket_SetSockOptAtSvr(This,lOptName,lOptValue,lLevel)	\
    (This)->lpVtbl -> SetSockOptAtSvr(This,lOptName,lOptValue,lLevel)

#define IUSocket_GetSockOptAtSvr(This,lOptName,lLevel)	\
    (This)->lpVtbl -> GetSockOptAtSvr(This,lOptName,lLevel)

#define IUSocket_GetOptValueAtSvr(This,pVal)	\
    (This)->lpVtbl -> GetOptValueAtSvr(This,pVal)

#define IUSocket_SetClientVersion(This,nMinor,nMajor)	\
    (This)->lpVtbl -> SetClientVersion(This,nMinor,nMajor)

#define IUSocket_TurnOnZipAtSvr(This,bZipOn)	\
    (This)->lpVtbl -> TurnOnZipAtSvr(This,bZipOn)

#define IUSocket_GetClientVersion(This,pnMinor,pnMajor)	\
    (This)->lpVtbl -> GetClientVersion(This,pnMinor,pnMajor)

#define IUSocket_GetServerVersion(This,pnMinor,pnMajor)	\
    (This)->lpVtbl -> GetServerVersion(This,pnMinor,pnMajor)

#define IUSocket_ShrinkMemory(This)	\
    (This)->lpVtbl -> ShrinkMemory(This)

#define IUSocket_ShrinkMemoryAtSvr(This)	\
    (This)->lpVtbl -> ShrinkMemoryAtSvr(This)

#define IUSocket_GetClientUSockVersion(This,pnMinor,pnMajor)	\
    (This)->lpVtbl -> GetClientUSockVersion(This,pnMinor,pnMajor)

#define IUSocket_GetServerUSockVersion(This,pnMinor,pnMajor)	\
    (This)->lpVtbl -> GetServerUSockVersion(This,pnMinor,pnMajor)

#define IUSocket_DetectNetPerformance(This,psNetPerformance)	\
    (This)->lpVtbl -> DetectNetPerformance(This,psNetPerformance)

#define IUSocket_IgnorePendingRequests(This,lRequests,lStartWith)	\
    (This)->lpVtbl -> IgnorePendingRequests(This,lRequests,lStartWith)

#define IUSocket_SendMySpecificBytes(This,vtBytes)	\
    (This)->lpVtbl -> SendMySpecificBytes(This,vtBytes)

#define IUSocket_get_ErrorMsg(This,pbstrErrorMsg)	\
    (This)->lpVtbl -> get_ErrorMsg(This,pbstrErrorMsg)

#define IUSocket_get_Key(This,pVal)	\
    (This)->lpVtbl -> get_Key(This,pVal)

#define IUSocket_put_Key(This,newVal)	\
    (This)->lpVtbl -> put_Key(This,newVal)

#define IUSocket_get_ZipIsOn(This,pVal)	\
    (This)->lpVtbl -> get_ZipIsOn(This,pVal)

#define IUSocket_put_ZipIsOn(This,newVal)	\
    (This)->lpVtbl -> put_ZipIsOn(This,newVal)

#define IUSocket_get_UserID(This,pVal)	\
    (This)->lpVtbl -> get_UserID(This,pVal)

#define IUSocket_put_UserID(This,newVal)	\
    (This)->lpVtbl -> put_UserID(This,newVal)

#define IUSocket_get_Password(This,pVal)	\
    (This)->lpVtbl -> get_Password(This,pVal)

#define IUSocket_put_Password(This,newVal)	\
    (This)->lpVtbl -> put_Password(This,newVal)

#define IUSocket_get_RcvMemory(This,pVal)	\
    (This)->lpVtbl -> get_RcvMemory(This,pVal)

#define IUSocket_get_SndMemory(This,pVal)	\
    (This)->lpVtbl -> get_SndMemory(This,pVal)

#define IUSocket_get_Syn(This,pVal)	\
    (This)->lpVtbl -> get_Syn(This,pVal)

#define IUSocket_put_Syn(This,newVal)	\
    (This)->lpVtbl -> put_Syn(This,newVal)

#define IUSocket_get_ClientParams(This,pVal)	\
    (This)->lpVtbl -> get_ClientParams(This,pVal)

#define IUSocket_put_ClientParams(This,newVal)	\
    (This)->lpVtbl -> put_ClientParams(This,newVal)

#define IUSocket_get_ServerParams(This,pVal)	\
    (This)->lpVtbl -> get_ServerParams(This,pVal)

#define IUSocket_get_RecvTimeout(This,pVal)	\
    (This)->lpVtbl -> get_RecvTimeout(This,pVal)

#define IUSocket_put_RecvTimeout(This,newVal)	\
    (This)->lpVtbl -> put_RecvTimeout(This,newVal)

#define IUSocket_get_SendTimeout(This,pVal)	\
    (This)->lpVtbl -> get_SendTimeout(This,pVal)

#define IUSocket_put_SendTimeout(This,newVal)	\
    (This)->lpVtbl -> put_SendTimeout(This,newVal)

#define IUSocket_get_KeyFromSvr(This,pVal)	\
    (This)->lpVtbl -> get_KeyFromSvr(This,pVal)

#define IUSocket_get_RequestsCanceled(This,pVal)	\
    (This)->lpVtbl -> get_RequestsCanceled(This,pVal)

#define IUSocket_get_Frozen(This,pVal)	\
    (This)->lpVtbl -> get_Frozen(This,pVal)

#define IUSocket_put_Frozen(This,newVal)	\
    (This)->lpVtbl -> put_Frozen(This,newVal)

#define IUSocket_get_BytesInSndMemory(This,pVal)	\
    (This)->lpVtbl -> get_BytesInSndMemory(This,pVal)

#define IUSocket_get_BytesInRcvMemory(This,pVal)	\
    (This)->lpVtbl -> get_BytesInRcvMemory(This,pVal)

#define IUSocket_get_ReturnEvents(This,pVal)	\
    (This)->lpVtbl -> get_ReturnEvents(This,pVal)

#define IUSocket_put_ReturnEvents(This,newVal)	\
    (This)->lpVtbl -> put_ReturnEvents(This,newVal)

#define IUSocket_get_MaxRtns(This,pVal)	\
    (This)->lpVtbl -> get_MaxRtns(This,pVal)

#define IUSocket_put_MaxRtns(This,newVal)	\
    (This)->lpVtbl -> put_MaxRtns(This,newVal)

#define IUSocket_get_RtnsInQueue(This,pVal)	\
    (This)->lpVtbl -> get_RtnsInQueue(This,pVal)

#define IUSocket_get_CurrentSvsID(This,plSvsID)	\
    (This)->lpVtbl -> get_CurrentSvsID(This,plSvsID)

#define IUSocket_get_ZipOnAtSvr(This,pVal)	\
    (This)->lpVtbl -> get_ZipOnAtSvr(This,pVal)

#define IUSocket_get_Rtn(This,plRtn)	\
    (This)->lpVtbl -> get_Rtn(This,plRtn)

#define IUSocket_get_IsSameEndian(This,pVal)	\
    (This)->lpVtbl -> get_IsSameEndian(This,pVal)

#define IUSocket_get_BytesBatched(This,pVal)	\
    (This)->lpVtbl -> get_BytesBatched(This,pVal)

#define IUSocket_Wait(This,sRequestID,lTimeout,lSvsID,pbTimeout)	\
    (This)->lpVtbl -> Wait(This,sRequestID,lTimeout,lSvsID,pbTimeout)

#define IUSocket_get_CountOfRequestsInQueue(This,pVal)	\
    (This)->lpVtbl -> get_CountOfRequestsInQueue(This,pVal)

#define IUSocket_get_IsBatching(This,pVal)	\
    (This)->lpVtbl -> get_IsBatching(This,pVal)

#define IUSocket_CleanTrack(This)	\
    (This)->lpVtbl -> CleanTrack(This)

#define IUSocket_get_LastRequestID(This,pVal)	\
    (This)->lpVtbl -> get_LastRequestID(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_SwitchTo_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ long lSvsID);


void __RPC_STUB IUSocket_SwitchTo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_StartBatching_Proxy( 
    IUSocket __RPC_FAR * This);


void __RPC_STUB IUSocket_StartBatching_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_CommitBatching_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [defaultvalue][in] */ VARIANT_BOOL bSvrBatching);


void __RPC_STUB IUSocket_CommitBatching_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_AbortBatching_Proxy( 
    IUSocket __RPC_FAR * This);


void __RPC_STUB IUSocket_AbortBatching_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_WaitAll_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ long lTimeOut,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbTimeout);


void __RPC_STUB IUSocket_WaitAll_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_DoEcho_Proxy( 
    IUSocket __RPC_FAR * This);


void __RPC_STUB IUSocket_DoEcho_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetRequestsInQueue_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvtRequests);


void __RPC_STUB IUSocket_GetRequestsInQueue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_SendRequest_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ short nRequestID,
    /* [in] */ VARIANT vtData,
    /* [defaultvalue][in] */ VARIANT_BOOL bKeepVTFormat);


void __RPC_STUB IUSocket_SendRequest_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetRtnBuffer_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ long nLen,
    /* [retval][out] */ VARIANT __RPC_FAR *pvtData);


void __RPC_STUB IUSocket_GetRtnBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_Cancel_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [defaultvalue][in] */ long lRequests);


void __RPC_STUB IUSocket_Cancel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_SetSockOptAtSvr_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ long lOptName,
    /* [in] */ long lOptValue,
    /* [defaultvalue][in] */ long lLevel);


void __RPC_STUB IUSocket_SetSockOptAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetSockOptAtSvr_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ long lOptName,
    /* [defaultvalue][in] */ long lLevel);


void __RPC_STUB IUSocket_GetSockOptAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetOptValueAtSvr_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_GetOptValueAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_SetClientVersion_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ short nMinor,
    /* [in] */ short nMajor);


void __RPC_STUB IUSocket_SetClientVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_TurnOnZipAtSvr_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [defaultvalue][in] */ VARIANT_BOOL bZipOn);


void __RPC_STUB IUSocket_TurnOnZipAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetClientVersion_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [out] */ short __RPC_FAR *pnMinor,
    /* [retval][out] */ short __RPC_FAR *pnMajor);


void __RPC_STUB IUSocket_GetClientVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetServerVersion_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [out] */ short __RPC_FAR *pnMinor,
    /* [out] */ short __RPC_FAR *pnMajor);


void __RPC_STUB IUSocket_GetServerVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_ShrinkMemory_Proxy( 
    IUSocket __RPC_FAR * This);


void __RPC_STUB IUSocket_ShrinkMemory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_ShrinkMemoryAtSvr_Proxy( 
    IUSocket __RPC_FAR * This);


void __RPC_STUB IUSocket_ShrinkMemoryAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetClientUSockVersion_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [out] */ short __RPC_FAR *pnMinor,
    /* [retval][out] */ short __RPC_FAR *pnMajor);


void __RPC_STUB IUSocket_GetClientUSockVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_GetServerUSockVersion_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [out] */ short __RPC_FAR *pnMinor,
    /* [retval][out] */ short __RPC_FAR *pnMajor);


void __RPC_STUB IUSocket_GetServerUSockVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_DetectNetPerformance_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *psNetPerformance);


void __RPC_STUB IUSocket_DetectNetPerformance_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_IgnorePendingRequests_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [defaultvalue][in] */ long lRequests,
    /* [defaultvalue][in] */ long lStartWith);


void __RPC_STUB IUSocket_IgnorePendingRequests_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_SendMySpecificBytes_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ VARIANT vtBytes);


void __RPC_STUB IUSocket_SendMySpecificBytes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_ErrorMsg_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorMsg);


void __RPC_STUB IUSocket_get_ErrorMsg_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_Key_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_Key_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_Key_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ VARIANT newVal);


void __RPC_STUB IUSocket_put_Key_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_ZipIsOn_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_ZipIsOn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_ZipIsOn_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IUSocket_put_ZipIsOn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_UserID_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_UserID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_UserID_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUSocket_put_UserID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_Password_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_Password_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_Password_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUSocket_put_Password_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_RcvMemory_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_RcvMemory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_SndMemory_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_SndMemory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_Syn_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_Syn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_Syn_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IUSocket_put_Syn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_ClientParams_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_ClientParams_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_ClientParams_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ VARIANT newVal);


void __RPC_STUB IUSocket_put_ClientParams_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_ServerParams_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_ServerParams_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_RecvTimeout_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_RecvTimeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_RecvTimeout_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IUSocket_put_RecvTimeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_SendTimeout_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_SendTimeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_SendTimeout_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IUSocket_put_SendTimeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_KeyFromSvr_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_KeyFromSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_RequestsCanceled_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_RequestsCanceled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_Frozen_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_Frozen_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_Frozen_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IUSocket_put_Frozen_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_BytesInSndMemory_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_BytesInSndMemory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_BytesInRcvMemory_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_BytesInRcvMemory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_ReturnEvents_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_ReturnEvents_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_ReturnEvents_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB IUSocket_put_ReturnEvents_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_MaxRtns_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_MaxRtns_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUSocket_put_MaxRtns_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB IUSocket_put_MaxRtns_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_RtnsInQueue_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_RtnsInQueue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_CurrentSvsID_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plSvsID);


void __RPC_STUB IUSocket_get_CurrentSvsID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_ZipOnAtSvr_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_ZipOnAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_Rtn_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plRtn);


void __RPC_STUB IUSocket_get_Rtn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_IsSameEndian_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_IsSameEndian_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_BytesBatched_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_BytesBatched_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_Wait_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [in] */ short sRequestID,
    /* [in] */ long lTimeout,
    /* [defaultvalue][in] */ long lSvsID,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbTimeout);


void __RPC_STUB IUSocket_Wait_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_CountOfRequestsInQueue_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_CountOfRequestsInQueue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_IsBatching_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_IsBatching_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocket_CleanTrack_Proxy( 
    IUSocket __RPC_FAR * This);


void __RPC_STUB IUSocket_CleanTrack_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocket_get_LastRequestID_Proxy( 
    IUSocket __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IUSocket_get_LastRequestID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUSocket_INTERFACE_DEFINED__ */


#ifndef __IUChat_INTERFACE_DEFINED__
#define __IUChat_INTERFACE_DEFINED__

/* interface IUChat */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUChat;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2AFB8C2E-792C-10D6-B1D1-0010B5EC005B")
    IUChat : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Enter( 
            /* [in] */ long lGroups) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Exit( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Speak( 
            /* [in] */ VARIANT vtMsg,
            /* [defaultvalue][in] */ long lGroups = odAllGroups) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SpeakTo( 
            /* [in] */ BSTR bstrIPAddr,
            /* [in] */ long lPort,
            /* [in] */ VARIANT vtMsg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAllGroups( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAllListeners( 
            /* [defaultvalue][in] */ long lGroups = odAllGroups) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAllClients( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetGroupInfo( 
            /* [in] */ long lIndex,
            /* [out] */ long __RPC_FAR *plGroup,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrDescription) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetInfo( 
            /* [in] */ long lIndex,
            /* [out] */ long __RPC_FAR *plGroup,
            /* [out] */ BSTR __RPC_FAR *pbstrUID,
            /* [out] */ long __RPC_FAR *plSvsID,
            /* [out] */ long __RPC_FAR *plPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrIPAddress) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Listeners( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Message( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Groups( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendUserMessage( 
            /* [in] */ BSTR bstrUserID,
            /* [in] */ VARIANT vtMsg) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUChatVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUChat __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUChat __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUChat __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IUChat __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IUChat __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IUChat __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IUChat __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Enter )( 
            IUChat __RPC_FAR * This,
            /* [in] */ long lGroups);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Exit )( 
            IUChat __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Speak )( 
            IUChat __RPC_FAR * This,
            /* [in] */ VARIANT vtMsg,
            /* [defaultvalue][in] */ long lGroups);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SpeakTo )( 
            IUChat __RPC_FAR * This,
            /* [in] */ BSTR bstrIPAddr,
            /* [in] */ long lPort,
            /* [in] */ VARIANT vtMsg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllGroups )( 
            IUChat __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllListeners )( 
            IUChat __RPC_FAR * This,
            /* [defaultvalue][in] */ long lGroups);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllClients )( 
            IUChat __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetGroupInfo )( 
            IUChat __RPC_FAR * This,
            /* [in] */ long lIndex,
            /* [out] */ long __RPC_FAR *plGroup,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrDescription);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetInfo )( 
            IUChat __RPC_FAR * This,
            /* [in] */ long lIndex,
            /* [out] */ long __RPC_FAR *plGroup,
            /* [out] */ BSTR __RPC_FAR *pbstrUID,
            /* [out] */ long __RPC_FAR *plSvsID,
            /* [out] */ long __RPC_FAR *plPort,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrIPAddress);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Listeners )( 
            IUChat __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Message )( 
            IUChat __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Groups )( 
            IUChat __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendUserMessage )( 
            IUChat __RPC_FAR * This,
            /* [in] */ BSTR bstrUserID,
            /* [in] */ VARIANT vtMsg);
        
        END_INTERFACE
    } IUChatVtbl;

    interface IUChat
    {
        CONST_VTBL struct IUChatVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUChat_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUChat_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUChat_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUChat_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUChat_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUChat_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUChat_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUChat_Enter(This,lGroups)	\
    (This)->lpVtbl -> Enter(This,lGroups)

#define IUChat_Exit(This)	\
    (This)->lpVtbl -> Exit(This)

#define IUChat_Speak(This,vtMsg,lGroups)	\
    (This)->lpVtbl -> Speak(This,vtMsg,lGroups)

#define IUChat_SpeakTo(This,bstrIPAddr,lPort,vtMsg)	\
    (This)->lpVtbl -> SpeakTo(This,bstrIPAddr,lPort,vtMsg)

#define IUChat_GetAllGroups(This)	\
    (This)->lpVtbl -> GetAllGroups(This)

#define IUChat_GetAllListeners(This,lGroups)	\
    (This)->lpVtbl -> GetAllListeners(This,lGroups)

#define IUChat_GetAllClients(This)	\
    (This)->lpVtbl -> GetAllClients(This)

#define IUChat_GetGroupInfo(This,lIndex,plGroup,pbstrDescription)	\
    (This)->lpVtbl -> GetGroupInfo(This,lIndex,plGroup,pbstrDescription)

#define IUChat_GetInfo(This,lIndex,plGroup,pbstrUID,plSvsID,plPort,pbstrIPAddress)	\
    (This)->lpVtbl -> GetInfo(This,lIndex,plGroup,pbstrUID,plSvsID,plPort,pbstrIPAddress)

#define IUChat_get_Listeners(This,pVal)	\
    (This)->lpVtbl -> get_Listeners(This,pVal)

#define IUChat_get_Message(This,pVal)	\
    (This)->lpVtbl -> get_Message(This,pVal)

#define IUChat_get_Groups(This,pVal)	\
    (This)->lpVtbl -> get_Groups(This,pVal)

#define IUChat_SendUserMessage(This,bstrUserID,vtMsg)	\
    (This)->lpVtbl -> SendUserMessage(This,bstrUserID,vtMsg)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_Enter_Proxy( 
    IUChat __RPC_FAR * This,
    /* [in] */ long lGroups);


void __RPC_STUB IUChat_Enter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_Exit_Proxy( 
    IUChat __RPC_FAR * This);


void __RPC_STUB IUChat_Exit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_Speak_Proxy( 
    IUChat __RPC_FAR * This,
    /* [in] */ VARIANT vtMsg,
    /* [defaultvalue][in] */ long lGroups);


void __RPC_STUB IUChat_Speak_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_SpeakTo_Proxy( 
    IUChat __RPC_FAR * This,
    /* [in] */ BSTR bstrIPAddr,
    /* [in] */ long lPort,
    /* [in] */ VARIANT vtMsg);


void __RPC_STUB IUChat_SpeakTo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_GetAllGroups_Proxy( 
    IUChat __RPC_FAR * This);


void __RPC_STUB IUChat_GetAllGroups_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_GetAllListeners_Proxy( 
    IUChat __RPC_FAR * This,
    /* [defaultvalue][in] */ long lGroups);


void __RPC_STUB IUChat_GetAllListeners_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_GetAllClients_Proxy( 
    IUChat __RPC_FAR * This);


void __RPC_STUB IUChat_GetAllClients_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_GetGroupInfo_Proxy( 
    IUChat __RPC_FAR * This,
    /* [in] */ long lIndex,
    /* [out] */ long __RPC_FAR *plGroup,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrDescription);


void __RPC_STUB IUChat_GetGroupInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_GetInfo_Proxy( 
    IUChat __RPC_FAR * This,
    /* [in] */ long lIndex,
    /* [out] */ long __RPC_FAR *plGroup,
    /* [out] */ BSTR __RPC_FAR *pbstrUID,
    /* [out] */ long __RPC_FAR *plSvsID,
    /* [out] */ long __RPC_FAR *plPort,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrIPAddress);


void __RPC_STUB IUChat_GetInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUChat_get_Listeners_Proxy( 
    IUChat __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUChat_get_Listeners_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUChat_get_Message_Proxy( 
    IUChat __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUChat_get_Message_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUChat_get_Groups_Proxy( 
    IUChat __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUChat_get_Groups_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUChat_SendUserMessage_Proxy( 
    IUChat __RPC_FAR * This,
    /* [in] */ BSTR bstrUserID,
    /* [in] */ VARIANT vtMsg);


void __RPC_STUB IUChat_SendUserMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUChat_INTERFACE_DEFINED__ */


#ifndef __IUFast_INTERFACE_DEFINED__
#define __IUFast_INTERFACE_DEFINED__

/* interface IUFast */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IUFast;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2AFB8C2A-792C-15D6-B1D1-1010B5EC1C5B")
    IUFast : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetRtnBufferEx( 
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pBuffer[  ],
            /* [retval][out] */ unsigned long __RPC_FAR *plRtnSize) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SendRequestEx( 
            /* [in] */ unsigned short usRequestID,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pBuffer[  ]) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SpeakEx( 
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ],
            /* [in] */ unsigned long ulGroups) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SpeakToEx( 
            /* [in] */ BSTR bstrIPAddr,
            /* [in] */ long lPort,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ]) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SendUserMessageEx( 
            /* [in] */ BSTR bstrUserID,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ]) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUFastVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUFast __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUFast __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUFast __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRtnBufferEx )( 
            IUFast __RPC_FAR * This,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pBuffer[  ],
            /* [retval][out] */ unsigned long __RPC_FAR *plRtnSize);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendRequestEx )( 
            IUFast __RPC_FAR * This,
            /* [in] */ unsigned short usRequestID,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pBuffer[  ]);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SpeakEx )( 
            IUFast __RPC_FAR * This,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ],
            /* [in] */ unsigned long ulGroups);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SpeakToEx )( 
            IUFast __RPC_FAR * This,
            /* [in] */ BSTR bstrIPAddr,
            /* [in] */ long lPort,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ]);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendUserMessageEx )( 
            IUFast __RPC_FAR * This,
            /* [in] */ BSTR bstrUserID,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ]);
        
        END_INTERFACE
    } IUFastVtbl;

    interface IUFast
    {
        CONST_VTBL struct IUFastVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUFast_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUFast_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUFast_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUFast_GetRtnBufferEx(This,ulLen,pBuffer,plRtnSize)	\
    (This)->lpVtbl -> GetRtnBufferEx(This,ulLen,pBuffer,plRtnSize)

#define IUFast_SendRequestEx(This,usRequestID,ulLen,pBuffer)	\
    (This)->lpVtbl -> SendRequestEx(This,usRequestID,ulLen,pBuffer)

#define IUFast_SpeakEx(This,ulLen,pMessage,ulGroups)	\
    (This)->lpVtbl -> SpeakEx(This,ulLen,pMessage,ulGroups)

#define IUFast_SpeakToEx(This,bstrIPAddr,lPort,ulLen,pMessage)	\
    (This)->lpVtbl -> SpeakToEx(This,bstrIPAddr,lPort,ulLen,pMessage)

#define IUFast_SendUserMessageEx(This,bstrUserID,ulLen,pMessage)	\
    (This)->lpVtbl -> SendUserMessageEx(This,bstrUserID,ulLen,pMessage)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUFast_GetRtnBufferEx_Proxy( 
    IUFast __RPC_FAR * This,
    /* [in] */ unsigned long ulLen,
    /* [size_is][in] */ BYTE __RPC_FAR pBuffer[  ],
    /* [retval][out] */ unsigned long __RPC_FAR *plRtnSize);


void __RPC_STUB IUFast_GetRtnBufferEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUFast_SendRequestEx_Proxy( 
    IUFast __RPC_FAR * This,
    /* [in] */ unsigned short usRequestID,
    /* [in] */ unsigned long ulLen,
    /* [size_is][in] */ BYTE __RPC_FAR pBuffer[  ]);


void __RPC_STUB IUFast_SendRequestEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUFast_SpeakEx_Proxy( 
    IUFast __RPC_FAR * This,
    /* [in] */ unsigned long ulLen,
    /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ],
    /* [in] */ unsigned long ulGroups);


void __RPC_STUB IUFast_SpeakEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUFast_SpeakToEx_Proxy( 
    IUFast __RPC_FAR * This,
    /* [in] */ BSTR bstrIPAddr,
    /* [in] */ long lPort,
    /* [in] */ unsigned long ulLen,
    /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ]);


void __RPC_STUB IUFast_SpeakToEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUFast_SendUserMessageEx_Proxy( 
    IUFast __RPC_FAR * This,
    /* [in] */ BSTR bstrUserID,
    /* [in] */ unsigned long ulLen,
    /* [size_is][in] */ BYTE __RPC_FAR pMessage[  ]);


void __RPC_STUB IUFast_SendUserMessageEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUFast_INTERFACE_DEFINED__ */


#ifndef __IUZip_INTERFACE_DEFINED__
#define __IUZip_INTERFACE_DEFINED__

/* interface IUZip */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUZip;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2A0B8C2E-702C-1AD6-B1D1-2010B5EC0158")
    IUZip : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetZipLevelAtSvr( 
            /* [in] */ tagZipLevel zipLevel) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ZipLevel( 
            /* [retval][out] */ tagZipLevel __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ZipLevel( 
            /* [in] */ tagZipLevel newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ZipLevelAtSvr( 
            /* [retval][out] */ tagZipLevel __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUZipVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUZip __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUZip __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUZip __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IUZip __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IUZip __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IUZip __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IUZip __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetZipLevelAtSvr )( 
            IUZip __RPC_FAR * This,
            /* [in] */ tagZipLevel zipLevel);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ZipLevel )( 
            IUZip __RPC_FAR * This,
            /* [retval][out] */ tagZipLevel __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ZipLevel )( 
            IUZip __RPC_FAR * This,
            /* [in] */ tagZipLevel newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ZipLevelAtSvr )( 
            IUZip __RPC_FAR * This,
            /* [retval][out] */ tagZipLevel __RPC_FAR *pVal);
        
        END_INTERFACE
    } IUZipVtbl;

    interface IUZip
    {
        CONST_VTBL struct IUZipVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUZip_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUZip_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUZip_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUZip_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUZip_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUZip_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUZip_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUZip_SetZipLevelAtSvr(This,zipLevel)	\
    (This)->lpVtbl -> SetZipLevelAtSvr(This,zipLevel)

#define IUZip_get_ZipLevel(This,pVal)	\
    (This)->lpVtbl -> get_ZipLevel(This,pVal)

#define IUZip_put_ZipLevel(This,newVal)	\
    (This)->lpVtbl -> put_ZipLevel(This,newVal)

#define IUZip_get_ZipLevelAtSvr(This,pVal)	\
    (This)->lpVtbl -> get_ZipLevelAtSvr(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUZip_SetZipLevelAtSvr_Proxy( 
    IUZip __RPC_FAR * This,
    /* [in] */ tagZipLevel zipLevel);


void __RPC_STUB IUZip_SetZipLevelAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUZip_get_ZipLevel_Proxy( 
    IUZip __RPC_FAR * This,
    /* [retval][out] */ tagZipLevel __RPC_FAR *pVal);


void __RPC_STUB IUZip_get_ZipLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUZip_put_ZipLevel_Proxy( 
    IUZip __RPC_FAR * This,
    /* [in] */ tagZipLevel newVal);


void __RPC_STUB IUZip_put_ZipLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUZip_get_ZipLevelAtSvr_Proxy( 
    IUZip __RPC_FAR * This,
    /* [retval][out] */ tagZipLevel __RPC_FAR *pVal);


void __RPC_STUB IUZip_get_ZipLevelAtSvr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUZip_INTERFACE_DEFINED__ */


#ifndef __IUCert_INTERFACE_DEFINED__
#define __IUCert_INTERFACE_DEFINED__

/* interface IUCert */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUCert;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2FFB8C2E-702C-1AD6-B1D1-0010B5EC015B")
    IUCert : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CompareDomain( 
            /* [out] */ BSTR __RPC_FAR *pbstrDomain,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrHost,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbMatchable) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Verify( 
            /* [out] */ long __RPC_FAR *plErrorCode,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorMsg) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Issuer( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Subject( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Validity( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NotBefore( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NotAfter( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SigAlg( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SerialNumber( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Algorithm( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_PublicKey( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_IssuerUID( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SubjectUID( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CertPem( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_VerifyLocation( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_VerifyLocation( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SessionInfo( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddCertificateToStore( 
            /* [defaultvalue][in] */ VARIANT_BOOL bRoot = 0) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUCertVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUCert __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUCert __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUCert __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IUCert __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IUCert __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IUCert __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IUCert __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CompareDomain )( 
            IUCert __RPC_FAR * This,
            /* [out] */ BSTR __RPC_FAR *pbstrDomain,
            /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrHost,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbMatchable);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Verify )( 
            IUCert __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *plErrorCode,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorMsg);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Issuer )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Subject )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Validity )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NotBefore )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NotAfter )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SigAlg )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SerialNumber )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Algorithm )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PublicKey )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IssuerUID )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SubjectUID )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CertPem )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_VerifyLocation )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_VerifyLocation )( 
            IUCert __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SessionInfo )( 
            IUCert __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddCertificateToStore )( 
            IUCert __RPC_FAR * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bRoot);
        
        END_INTERFACE
    } IUCertVtbl;

    interface IUCert
    {
        CONST_VTBL struct IUCertVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUCert_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUCert_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUCert_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUCert_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUCert_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUCert_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUCert_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUCert_CompareDomain(This,pbstrDomain,pbstrHost,pbMatchable)	\
    (This)->lpVtbl -> CompareDomain(This,pbstrDomain,pbstrHost,pbMatchable)

#define IUCert_Verify(This,plErrorCode,pbstrErrorMsg)	\
    (This)->lpVtbl -> Verify(This,plErrorCode,pbstrErrorMsg)

#define IUCert_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#define IUCert_get_Issuer(This,pVal)	\
    (This)->lpVtbl -> get_Issuer(This,pVal)

#define IUCert_get_Subject(This,pVal)	\
    (This)->lpVtbl -> get_Subject(This,pVal)

#define IUCert_get_Validity(This,pVal)	\
    (This)->lpVtbl -> get_Validity(This,pVal)

#define IUCert_get_NotBefore(This,pVal)	\
    (This)->lpVtbl -> get_NotBefore(This,pVal)

#define IUCert_get_NotAfter(This,pVal)	\
    (This)->lpVtbl -> get_NotAfter(This,pVal)

#define IUCert_get_SigAlg(This,pVal)	\
    (This)->lpVtbl -> get_SigAlg(This,pVal)

#define IUCert_get_SerialNumber(This,pVal)	\
    (This)->lpVtbl -> get_SerialNumber(This,pVal)

#define IUCert_get_Algorithm(This,pVal)	\
    (This)->lpVtbl -> get_Algorithm(This,pVal)

#define IUCert_get_PublicKey(This,pVal)	\
    (This)->lpVtbl -> get_PublicKey(This,pVal)

#define IUCert_get_IssuerUID(This,pVal)	\
    (This)->lpVtbl -> get_IssuerUID(This,pVal)

#define IUCert_get_SubjectUID(This,pVal)	\
    (This)->lpVtbl -> get_SubjectUID(This,pVal)

#define IUCert_get_CertPem(This,pVal)	\
    (This)->lpVtbl -> get_CertPem(This,pVal)

#define IUCert_get_VerifyLocation(This,pVal)	\
    (This)->lpVtbl -> get_VerifyLocation(This,pVal)

#define IUCert_put_VerifyLocation(This,newVal)	\
    (This)->lpVtbl -> put_VerifyLocation(This,newVal)

#define IUCert_get_SessionInfo(This,pVal)	\
    (This)->lpVtbl -> get_SessionInfo(This,pVal)

#define IUCert_AddCertificateToStore(This,bRoot)	\
    (This)->lpVtbl -> AddCertificateToStore(This,bRoot)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUCert_CompareDomain_Proxy( 
    IUCert __RPC_FAR * This,
    /* [out] */ BSTR __RPC_FAR *pbstrDomain,
    /* [defaultvalue][out] */ BSTR __RPC_FAR *pbstrHost,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbMatchable);


void __RPC_STUB IUCert_CompareDomain_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUCert_Verify_Proxy( 
    IUCert __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *plErrorCode,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorMsg);


void __RPC_STUB IUCert_Verify_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_Version_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_Issuer_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_Issuer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_Subject_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_Subject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_Validity_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_Validity_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_NotBefore_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_NotBefore_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_NotAfter_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_NotAfter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_SigAlg_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_SigAlg_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_SerialNumber_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_SerialNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_Algorithm_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_Algorithm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_PublicKey_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_PublicKey_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_IssuerUID_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_IssuerUID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_SubjectUID_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_SubjectUID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_CertPem_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_CertPem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_VerifyLocation_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_VerifyLocation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUCert_put_VerifyLocation_Proxy( 
    IUCert __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUCert_put_VerifyLocation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUCert_get_SessionInfo_Proxy( 
    IUCert __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUCert_get_SessionInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUCert_AddCertificateToStore_Proxy( 
    IUCert __RPC_FAR * This,
    /* [defaultvalue][in] */ VARIANT_BOOL bRoot);


void __RPC_STUB IUCert_AddCertificateToStore_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUCert_INTERFACE_DEFINED__ */


#ifndef ___IUSocketEvent_DISPINTERFACE_DEFINED__
#define ___IUSocketEvent_DISPINTERFACE_DEFINED__

/* dispinterface _IUSocketEvent */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IUSocketEvent;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("F80A0F37-147E-4C43-B889-1D4C9A612BB9")
    _IUSocketEvent : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IUSocketEventVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IUSocketEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IUSocketEvent __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IUSocketEvent __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IUSocketEvent __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IUSocketEvent __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IUSocketEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IUSocketEvent __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IUSocketEventVtbl;

    interface _IUSocketEvent
    {
        CONST_VTBL struct _IUSocketEventVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IUSocketEvent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IUSocketEvent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IUSocketEvent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IUSocketEvent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IUSocketEvent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IUSocketEvent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IUSocketEvent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IUSocketEvent_DISPINTERFACE_DEFINED__ */


#ifndef __IUSocketPool_INTERFACE_DEFINED__
#define __IUSocketPool_INTERFACE_DEFINED__

/* interface IUSocketPool */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUSocketPool;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("148F6E9F-756D-4B8E-96F5-7AE8CC4697E6")
    IUSocketPool : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE StartPool( 
            /* [in] */ BYTE bThreadCount,
            /* [in] */ BYTE bSocketsPerThread) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShutdownPool( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LockASocket( 
            /* [in] */ long lTimeout,
            /* [in] */ IUSocket __RPC_FAR *pIUSocketSameThreadWith,
            /* [retval][out] */ IUSocket __RPC_FAR *__RPC_FAR *ppIUSocket) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UnlockASocket( 
            /* [in] */ IUSocket __RPC_FAR *pIUSocket) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ConnectAll( 
            /* [in] */ BSTR bstrHost,
            /* [in] */ long lPort,
            /* [in] */ long lInitialSvsID,
            /* [in] */ BSTR bstrUID,
            /* [in] */ BSTR bstrPWD,
            /* [in] */ short EncryptionMethod,
            /* [defaultvalue][in] */ VARIANT_BOOL bEnableZip = -1) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DisconnectAll( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DisconnectedSockets( 
            /* [retval][out] */ BYTE __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ConnectedSockets( 
            /* [retval][out] */ BYTE __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_IdleSockets( 
            /* [retval][out] */ BYTE __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LockedSockets( 
            /* [retval][out] */ BYTE __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ThreadCounts( 
            /* [retval][out] */ BYTE __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindAClosedSocket( 
            /* [retval][out] */ IUSocket __RPC_FAR *__RPC_FAR *ppIUSocket) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Connect( 
            /* [in] */ IUSocket __RPC_FAR *pIUSocket,
            /* [in] */ BSTR bstrHost,
            /* [in] */ long lPort,
            /* [in] */ long lInitialSvsID,
            /* [in] */ BSTR bstrUID,
            /* [in] */ BSTR bstrPWD,
            /* [in] */ short EncryptionMethod,
            /* [defaultvalue][in] */ VARIANT_BOOL bEnableZip = -1) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUSocketPoolVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUSocketPool __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUSocketPool __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IUSocketPool __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StartPool )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ BYTE bThreadCount,
            /* [in] */ BYTE bSocketsPerThread);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShutdownPool )( 
            IUSocketPool __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LockASocket )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ long lTimeout,
            /* [in] */ IUSocket __RPC_FAR *pIUSocketSameThreadWith,
            /* [retval][out] */ IUSocket __RPC_FAR *__RPC_FAR *ppIUSocket);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UnlockASocket )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ IUSocket __RPC_FAR *pIUSocket);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ConnectAll )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ BSTR bstrHost,
            /* [in] */ long lPort,
            /* [in] */ long lInitialSvsID,
            /* [in] */ BSTR bstrUID,
            /* [in] */ BSTR bstrPWD,
            /* [in] */ short EncryptionMethod,
            /* [defaultvalue][in] */ VARIANT_BOOL bEnableZip);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DisconnectAll )( 
            IUSocketPool __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DisconnectedSockets )( 
            IUSocketPool __RPC_FAR * This,
            /* [retval][out] */ BYTE __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ConnectedSockets )( 
            IUSocketPool __RPC_FAR * This,
            /* [retval][out] */ BYTE __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IdleSockets )( 
            IUSocketPool __RPC_FAR * This,
            /* [retval][out] */ BYTE __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LockedSockets )( 
            IUSocketPool __RPC_FAR * This,
            /* [retval][out] */ BYTE __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ThreadCounts )( 
            IUSocketPool __RPC_FAR * This,
            /* [retval][out] */ BYTE __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindAClosedSocket )( 
            IUSocketPool __RPC_FAR * This,
            /* [retval][out] */ IUSocket __RPC_FAR *__RPC_FAR *ppIUSocket);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Connect )( 
            IUSocketPool __RPC_FAR * This,
            /* [in] */ IUSocket __RPC_FAR *pIUSocket,
            /* [in] */ BSTR bstrHost,
            /* [in] */ long lPort,
            /* [in] */ long lInitialSvsID,
            /* [in] */ BSTR bstrUID,
            /* [in] */ BSTR bstrPWD,
            /* [in] */ short EncryptionMethod,
            /* [defaultvalue][in] */ VARIANT_BOOL bEnableZip);
        
        END_INTERFACE
    } IUSocketPoolVtbl;

    interface IUSocketPool
    {
        CONST_VTBL struct IUSocketPoolVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUSocketPool_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUSocketPool_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUSocketPool_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUSocketPool_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUSocketPool_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUSocketPool_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUSocketPool_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUSocketPool_StartPool(This,bThreadCount,bSocketsPerThread)	\
    (This)->lpVtbl -> StartPool(This,bThreadCount,bSocketsPerThread)

#define IUSocketPool_ShutdownPool(This)	\
    (This)->lpVtbl -> ShutdownPool(This)

#define IUSocketPool_LockASocket(This,lTimeout,pIUSocketSameThreadWith,ppIUSocket)	\
    (This)->lpVtbl -> LockASocket(This,lTimeout,pIUSocketSameThreadWith,ppIUSocket)

#define IUSocketPool_UnlockASocket(This,pIUSocket)	\
    (This)->lpVtbl -> UnlockASocket(This,pIUSocket)

#define IUSocketPool_ConnectAll(This,bstrHost,lPort,lInitialSvsID,bstrUID,bstrPWD,EncryptionMethod,bEnableZip)	\
    (This)->lpVtbl -> ConnectAll(This,bstrHost,lPort,lInitialSvsID,bstrUID,bstrPWD,EncryptionMethod,bEnableZip)

#define IUSocketPool_DisconnectAll(This)	\
    (This)->lpVtbl -> DisconnectAll(This)

#define IUSocketPool_get_DisconnectedSockets(This,pVal)	\
    (This)->lpVtbl -> get_DisconnectedSockets(This,pVal)

#define IUSocketPool_get_ConnectedSockets(This,pVal)	\
    (This)->lpVtbl -> get_ConnectedSockets(This,pVal)

#define IUSocketPool_get_IdleSockets(This,pVal)	\
    (This)->lpVtbl -> get_IdleSockets(This,pVal)

#define IUSocketPool_get_LockedSockets(This,pVal)	\
    (This)->lpVtbl -> get_LockedSockets(This,pVal)

#define IUSocketPool_get_ThreadCounts(This,pVal)	\
    (This)->lpVtbl -> get_ThreadCounts(This,pVal)

#define IUSocketPool_FindAClosedSocket(This,ppIUSocket)	\
    (This)->lpVtbl -> FindAClosedSocket(This,ppIUSocket)

#define IUSocketPool_Connect(This,pIUSocket,bstrHost,lPort,lInitialSvsID,bstrUID,bstrPWD,EncryptionMethod,bEnableZip)	\
    (This)->lpVtbl -> Connect(This,pIUSocket,bstrHost,lPort,lInitialSvsID,bstrUID,bstrPWD,EncryptionMethod,bEnableZip)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_StartPool_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [in] */ BYTE bThreadCount,
    /* [in] */ BYTE bSocketsPerThread);


void __RPC_STUB IUSocketPool_StartPool_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_ShutdownPool_Proxy( 
    IUSocketPool __RPC_FAR * This);


void __RPC_STUB IUSocketPool_ShutdownPool_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_LockASocket_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [in] */ long lTimeout,
    /* [in] */ IUSocket __RPC_FAR *pIUSocketSameThreadWith,
    /* [retval][out] */ IUSocket __RPC_FAR *__RPC_FAR *ppIUSocket);


void __RPC_STUB IUSocketPool_LockASocket_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_UnlockASocket_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [in] */ IUSocket __RPC_FAR *pIUSocket);


void __RPC_STUB IUSocketPool_UnlockASocket_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_ConnectAll_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [in] */ BSTR bstrHost,
    /* [in] */ long lPort,
    /* [in] */ long lInitialSvsID,
    /* [in] */ BSTR bstrUID,
    /* [in] */ BSTR bstrPWD,
    /* [in] */ short EncryptionMethod,
    /* [defaultvalue][in] */ VARIANT_BOOL bEnableZip);


void __RPC_STUB IUSocketPool_ConnectAll_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_DisconnectAll_Proxy( 
    IUSocketPool __RPC_FAR * This);


void __RPC_STUB IUSocketPool_DisconnectAll_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocketPool_get_DisconnectedSockets_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [retval][out] */ BYTE __RPC_FAR *pVal);


void __RPC_STUB IUSocketPool_get_DisconnectedSockets_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocketPool_get_ConnectedSockets_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [retval][out] */ BYTE __RPC_FAR *pVal);


void __RPC_STUB IUSocketPool_get_ConnectedSockets_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocketPool_get_IdleSockets_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [retval][out] */ BYTE __RPC_FAR *pVal);


void __RPC_STUB IUSocketPool_get_IdleSockets_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocketPool_get_LockedSockets_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [retval][out] */ BYTE __RPC_FAR *pVal);


void __RPC_STUB IUSocketPool_get_LockedSockets_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUSocketPool_get_ThreadCounts_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [retval][out] */ BYTE __RPC_FAR *pVal);


void __RPC_STUB IUSocketPool_get_ThreadCounts_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_FindAClosedSocket_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [retval][out] */ IUSocket __RPC_FAR *__RPC_FAR *ppIUSocket);


void __RPC_STUB IUSocketPool_FindAClosedSocket_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUSocketPool_Connect_Proxy( 
    IUSocketPool __RPC_FAR * This,
    /* [in] */ IUSocket __RPC_FAR *pIUSocket,
    /* [in] */ BSTR bstrHost,
    /* [in] */ long lPort,
    /* [in] */ long lInitialSvsID,
    /* [in] */ BSTR bstrUID,
    /* [in] */ BSTR bstrPWD,
    /* [in] */ short EncryptionMethod,
    /* [defaultvalue][in] */ VARIANT_BOOL bEnableZip);


void __RPC_STUB IUSocketPool_Connect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUSocketPool_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_USocket;

#ifdef __cplusplus

class DECLSPEC_UUID("AAD83433-CC8D-4F6D-9C62-E224DCA81358")
USocket;
#endif

#ifndef ___IUSocketPoolEvents_DISPINTERFACE_DEFINED__
#define ___IUSocketPoolEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IUSocketPoolEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IUSocketPoolEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("2CC0BCFE-0361-4788-96E5-76A64D2B11BE")
    _IUSocketPoolEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IUSocketPoolEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IUSocketPoolEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IUSocketPoolEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IUSocketPoolEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IUSocketPoolEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IUSocketPoolEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IUSocketPoolEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IUSocketPoolEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IUSocketPoolEventsVtbl;

    interface _IUSocketPoolEvents
    {
        CONST_VTBL struct _IUSocketPoolEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IUSocketPoolEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IUSocketPoolEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IUSocketPoolEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IUSocketPoolEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IUSocketPoolEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IUSocketPoolEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IUSocketPoolEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IUSocketPoolEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_USocketPool;

#ifdef __cplusplus

class DECLSPEC_UUID("0A3CD705-6C31-4C9C-91BE-BDFF4EECF8CB")
USocketPool;
#endif
#endif /* __USOCKETLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
