// UZip.h: interface for the CUZip class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UZIP_H__B59C2E40_E0E9_4BA2_BD53_C400520A2DAB__INCLUDED_)
#define AFX_UZIP_H__B59C2E40_E0E9_4BA2_BD53_C400520A2DAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "zlib.h"
#include "quick.h"
#include "USocket.h"

class CUZip  
{
public:
	CUZip();
	~CUZip();

public:
	bool Compress(void *pSource, unsigned long ulSrcSize, void *pDestination, unsigned long &ulDesSize);
	bool Decompress(void *pSource, unsigned long ulSrcSize, void *pDestination, unsigned long &ulDesSize);
	
	
public:	
	tagZipLevel		m_ZipLevel;

private:
	bool		m_bDeflateInit;
	z_stream	m_Deflate;
	bool		m_bInflateInit;
	z_stream	m_Inflate;
};

#endif // !defined(AFX_UZIP_H__B59C2E40_E0E9_4BA2_BD53_C400520A2DAB__INCLUDED_)
