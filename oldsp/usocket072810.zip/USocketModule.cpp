// USocketModule.cpp: implementation of the CUSocketModule class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "USocketModule.h"
#include "WSAStartup.h"

extern CWSAStartup	g_WSAStartup;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CUSocketModule::CUSocketModule()
{
	m_bSuc = g_WSAStartup.Startup();
}

CUSocketModule::~CUSocketModule()
{
//	g_tempQueue.Empty();
	if(m_bSuc)
		g_WSAStartup.Cleanup();
}
