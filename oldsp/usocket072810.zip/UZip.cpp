// UZip.cpp: implementation of the CUZip class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UZip.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUZip::CUZip()
{
	m_bDeflateInit = false;
	m_Deflate.zalloc = (alloc_func)0;
	m_Deflate.zfree = (free_func)0;
    m_Deflate.opaque = (voidpf)0;
	
	m_bInflateInit = false;
	m_Inflate.zalloc = (alloc_func)0;
    m_Inflate.zfree = (free_func)0;

	m_ZipLevel = zlDefault;
}

CUZip::~CUZip()
{
	int err;
	if(m_bInflateInit)
	{
		err = inflateEnd(&m_Inflate);
	}

	if(m_bDeflateInit)
	{
		err = deflateEnd(&m_Deflate);
	}
}

bool CUZip::Decompress(void *pSource, unsigned long ulSrcSize, void *pDestination, unsigned long &ulDesSize)
{
	bool bSuc;
	if(pSource == NULL || ulSrcSize == 0)
	{
		ulDesSize = 0;
		return true;
	}

	if(pDestination == NULL || ulDesSize == 0)
		return false;

	if(m_ZipLevel == zlBestSpeed)
	{
		ulDesSize = qlz_decompress((const char*)pSource, (char *)pDestination);
		bSuc = (ulDesSize > 0) ? true : false;
	}
	else if(m_ZipLevel == zlDefault)
	{
		int err;
		if(!m_bInflateInit)
		{
			err = inflateInit(&m_Inflate);
			if (err != Z_OK) 
				return false;
			m_bInflateInit  = true;
		}

		m_Inflate.next_in = (Bytef*)pSource;
		m_Inflate.avail_in = (uInt)ulSrcSize;

		m_Inflate.next_out = (unsigned char *)pDestination;
		m_Inflate.avail_out = (uInt)ulDesSize;

		err = inflate(&m_Inflate, Z_FINISH);
		bSuc = (err == Z_STREAM_END);

		ulDesSize = m_Inflate.total_out;

		err = inflateReset (&m_Inflate);
	}
	else if(m_ZipLevel == zlBestCompression)
	{
		ATLASSERT(FALSE);
	}
	else
	{
		ATLASSERT(FALSE);
	}

	return true;
}

bool CUZip::Compress(void *pSource, unsigned long ulSrcSize, void *pDestination, unsigned long &ulDesSize)
{
	bool bSuc;
	if(pSource == NULL || ulSrcSize == 0)
	{
		ulDesSize = 0;
		return true;
	}
	
	if(pDestination == NULL || ulDesSize == 0)
		return false;

	if(m_ZipLevel == zlBestSpeed)
	{
		if(ulDesSize < (ulSrcSize + 36000))
			return false;
		ulDesSize = qlz_compress((const void*)pSource, (char *)pDestination, ulSrcSize);
		bSuc = (ulDesSize > 0) ? true : false;
	}
	else if(m_ZipLevel == zlDefault)
	{
		int err;
		unsigned long ul = (unsigned long)(1.1*ulSrcSize) + 15;
		if(ul > ulDesSize)
			return false;

		if(!m_bDeflateInit)
		{
			err = deflateInit(&m_Deflate, Z_DEFAULT_COMPRESSION);
			if (err != Z_OK) 
				return false;
			m_bDeflateInit  = true;
		}

		m_Deflate.next_in = (Bytef*)pSource;
		m_Deflate.avail_in = (uInt)ulSrcSize;

		m_Deflate.next_out = (unsigned char *)pDestination;
		m_Deflate.avail_out = (uInt)ulDesSize;

		err = deflate(&m_Deflate, Z_FINISH);
		bSuc = (err == Z_STREAM_END);
		ulDesSize = m_Deflate.total_out;

		err =  deflateReset(&m_Deflate);
	}
	else if(m_ZipLevel == zlBestCompression)
	{
		ATLASSERT(FALSE);
	}
	else
	{
		ATLASSERT(FALSE);
	}

	return bSuc;
}
