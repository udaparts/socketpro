// NPObjectImpBase.h: interface for the CNPObjectImpBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NPOBJECTIMPBASE_H__00B0A0A2_82FE_4C16_90D5_A5FB545A7AAB__INCLUDED_)
#define AFX_NPOBJECTIMPBASE_H__00B0A0A2_82FE_4C16_90D5_A5FB545A7AAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "npapi.h"
#include "npruntime.h"

#include <atlbase.h>


NPObject* NPAllocateFunction(NPP npp, NPClass *aClass);
void NPDeallocateFunction(NPObject *npobj);
void NPInvalidateFunction(NPObject *npobj);
bool NPRemovePropertyFunction(NPObject *npobj, NPIdentifier name);
bool NPSetPropertyFunction(NPObject *npobj, NPIdentifier name,
                                         const NPVariant *value);
bool NPGetPropertyFunction(NPObject *npobj, NPIdentifier name,
                                         NPVariant *result);
bool NPHasPropertyFunction(NPObject *npobj, NPIdentifier name);
bool NPInvokeDefaultFunction(NPObject *npobj,
                                           const NPVariant *args,
                                           uint32_t argCount,
                                           NPVariant *result);
bool NPHasMethodFunction(NPObject *npobj, NPIdentifier name);
bool NPInvokeFunction (NPObject *npobj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);


bool Variant2NPVariant(const VARIANT &vtSource, NPVariant *pnpvOut);
bool NPVariant2Variant(const NPVariant &vnpSource, VARIANT *pvtOut);
bool BSTR2NPVariant(const BSTR bstr, NPVariant *pnpvOut);


VARIANT& operator<<(VARIANT &vtOut, const NPVariant& vnpIn);
NPVariant& operator<<(NPVariant &vnpOut, const VARIANT& vtIn);

VARIANT& operator>>(const NPVariant& vnpIn, VARIANT &vtOut);
NPVariant& operator>>(const VARIANT& vtIn, NPVariant &vnpOut);

NPVariant& operator<<(NPVariant &vnpOut, const BSTR bstrIn);
NPVariant& operator>>(const BSTR bstrIn, NPVariant &vnpOut);

NPVariant& operator<<(NPVariant &vnpOut, long lIn);
NPVariant& operator>>(long lIn, NPVariant &vnpOut);

class CNPObjectImplBase : public NPObject  
{
public:
	CNPObjectImplBase();
	virtual ~CNPObjectImplBase();


protected:
	virtual void OnInvalidate();
	virtual void OnDeallocate();

public:
	virtual bool GetProperty(const NPUTF8 *strPropertyName, NPVariant *pvData);
	virtual bool SetProperty(const NPUTF8 *strPropertyName, const NPVariant *vData);
	virtual bool Invoke(const NPUTF8 *strMethodName, const NPVariant *args, uint32_t argCount, NPVariant *pvResult);
	virtual bool GetProperty(const CComBSTR &bstrPropertyName, CComVariant &vtData);
	virtual bool SetProperty(const CComBSTR &strPropertyName, const CComVariant &vtData);
	virtual bool Invoke(const CComBSTR &bstrMethodName, const VARIANT *pvtArgs, uint32_t argCount, CComVariant &vtResult);

	virtual bool InvokeDefault(const NPVariant *args, uint32_t argCount, NPVariant *pvResult)
	{
		return false;
	}

	bool HasProperty(int32_t nPropertyIndex);
	bool HasMethod(int32_t nMethodIndex);
	bool RemoveProperty(const NPUTF8 *strPropertyName);
	nsPluginInstanceBase *GetPlugin() const;

protected:
	CSimpleArray<CComBSTR>	m_aPropertyName;
	CSimpleArray<CComBSTR>	m_aMethodName;
	nsPluginInstanceBase	*m_pPlugin;

private:
	friend	void NPDeallocateFunction(NPObject *npobj);
	friend  void NPInvalidateFunction(NPObject *npobj);
	friend	bool NPHasPropertyFunction(NPObject *npobj, NPIdentifier name);
	friend	bool NPHasMethodFunction(NPObject *npobj, NPIdentifier name);
	friend	bool NPGetPropertyFunction(NPObject *npobj, NPIdentifier name, NPVariant *result);
	friend	bool NPSetPropertyFunction(NPObject *npobj, NPIdentifier name, const NPVariant *value);
	friend	bool NPInvokeFunction (NPObject *npobj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
	friend	NPObject* NPAllocateFunction(NPP npp, NPClass *aClass);
	bool ConvertComplexObject(VARIANT &vtData, NPVariant *pRtn);
	bool ConvertDate(VARIANT &vtData, NPVariant *pRtn);
	bool ToVariant(NPObject *pNPObject, VARIANT &vtOut);
};


class CWebItem
{
public:
	CWebItem(NPP pInstance = NULL);
	CWebItem(const CWebItem &WebItem);
	CWebItem(const NPObject &WebItem);
	~CWebItem();

public:
	CWebItem& operator=(const NPObject &WebItem);
	CWebItem& operator=(const CWebItem &WebItem);
	bool GetProperty(int nIndex, VARIANT &vtProperty);
	bool GetProperty(const NPUTF8 *strPropertyName, CWebItem &WebItem);
	bool GetProperty(const NPUTF8 *strPropertyName, VARIANT &vtProperty);
	bool SetProperty(const NPUTF8 *strPropertyName, const VARIANT &vtData);
	bool Invoke(const NPUTF8 *strMethodName, const VARIANT *pArgs, ULONG ulArgCount, VARIANT &vtResult);
	bool Invoke(const NPUTF8 *strMethodName, const VARIANT *pArgs, ULONG ulArgCount, CWebItem &WebItem);
	bool Invoke(const NPUTF8 *strMethodName, const NPVariant *pArgs, ULONG ulArgCount, VARIANT &vtResult);
	bool Invoke(const NPUTF8 *strMethodName, const NPVariant *pArgs, ULONG ulArgCount, CWebItem &WebItem);
	bool InvokeDefault(const VARIANT *pArgs, ULONG ulArgCount, VARIANT &vtResult);
	bool InvokeDefault(const NPVariant *pArgs, ULONG ulArgCount, VARIANT &vtResult);
	bool InvokeDefault(const NPVariant *pArgs, ULONG ulArgCount, CWebItem &WebItem);
	bool HasProperty(const NPUTF8 *strPropertyName);
	bool HasMethod(const NPUTF8 *strMethodName);
	bool HasProperty(int32_t nPropertyIndex);
	bool HasMethod(int32_t nMethodIndex);
	bool RemoveProperty(const NPUTF8 *strPropertyName);
	void SetException(const NPUTF8 *strExceptionMessage);
	void Release();
	bool IsAttached();
	nsPluginInstanceBase *GetPlugin() const;
	NPUTF8* GetMethodName(int32_t nMethodIndex);
	NPUTF8* GetPropertyName(int32_t nPropertyIndex);
	void Attach(NPObject *pNPObject);
	NPObject *Detach();
	static bool GetBrowserWindow(CWebItem &Browser);
	static bool GetPlugin(CWebItem &Plugin);
	int IncreaseRef();
	int DecreaseRef();

public:
	NPP			m_pInstance;
	bool		m_bJSObject;
	NPObject	*m_pNPObject;

private:
	NPUTF8* UTF8FromIdentifier(NPIdentifier identifier);
	void Set(const NPObject *pNPObject);
	
};


#endif // !defined(AFX_NPOBJECTIMPBASE_H__00B0A0A2_82FE_4C16_90D5_A5FB545A7AAB__INCLUDED_)
