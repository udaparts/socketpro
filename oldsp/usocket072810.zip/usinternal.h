/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed May 09 08:49:10 2007
 */
/* Compiler settings for usinternal.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __usinternal_h__
#define __usinternal_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IUSocketInternal_FWD_DEFINED__
#define __IUSocketInternal_FWD_DEFINED__
typedef interface IUSocketInternal IUSocketInternal;
#endif 	/* __IUSocketInternal_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IUSocketInternal_INTERFACE_DEFINED__
#define __IUSocketInternal_INTERFACE_DEFINED__

/* interface IUSocketInternal */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IUSocketInternal;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("29FB4C2A-792C-15D6-B1D1-1E1DB5EC1C59")
    IUSocketInternal : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetEvent( 
            /* [in] */ long hEvent) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE OnSClosed( 
            /* [in] */ long lError) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE OnSWrite( 
            /* [in] */ long lError) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE OnSRead( 
            /* [in] */ long lError) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Notify( 
            /* [in] */ long lInfo) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE IsWaiting( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUSocketInternalVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUSocketInternal __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUSocketInternal __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUSocketInternal __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetEvent )( 
            IUSocketInternal __RPC_FAR * This,
            /* [in] */ long hEvent);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OnSClosed )( 
            IUSocketInternal __RPC_FAR * This,
            /* [in] */ long lError);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OnSWrite )( 
            IUSocketInternal __RPC_FAR * This,
            /* [in] */ long lError);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OnSRead )( 
            IUSocketInternal __RPC_FAR * This,
            /* [in] */ long lError);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Notify )( 
            IUSocketInternal __RPC_FAR * This,
            /* [in] */ long lInfo);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IsWaiting )( 
            IUSocketInternal __RPC_FAR * This);
        
        END_INTERFACE
    } IUSocketInternalVtbl;

    interface IUSocketInternal
    {
        CONST_VTBL struct IUSocketInternalVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUSocketInternal_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUSocketInternal_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUSocketInternal_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUSocketInternal_SetEvent(This,hEvent)	\
    (This)->lpVtbl -> SetEvent(This,hEvent)

#define IUSocketInternal_OnSClosed(This,lError)	\
    (This)->lpVtbl -> OnSClosed(This,lError)

#define IUSocketInternal_OnSWrite(This,lError)	\
    (This)->lpVtbl -> OnSWrite(This,lError)

#define IUSocketInternal_OnSRead(This,lError)	\
    (This)->lpVtbl -> OnSRead(This,lError)

#define IUSocketInternal_Notify(This,lInfo)	\
    (This)->lpVtbl -> Notify(This,lInfo)

#define IUSocketInternal_IsWaiting(This)	\
    (This)->lpVtbl -> IsWaiting(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUSocketInternal_SetEvent_Proxy( 
    IUSocketInternal __RPC_FAR * This,
    /* [in] */ long hEvent);


void __RPC_STUB IUSocketInternal_SetEvent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUSocketInternal_OnSClosed_Proxy( 
    IUSocketInternal __RPC_FAR * This,
    /* [in] */ long lError);


void __RPC_STUB IUSocketInternal_OnSClosed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUSocketInternal_OnSWrite_Proxy( 
    IUSocketInternal __RPC_FAR * This,
    /* [in] */ long lError);


void __RPC_STUB IUSocketInternal_OnSWrite_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUSocketInternal_OnSRead_Proxy( 
    IUSocketInternal __RPC_FAR * This,
    /* [in] */ long lError);


void __RPC_STUB IUSocketInternal_OnSRead_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUSocketInternal_Notify_Proxy( 
    IUSocketInternal __RPC_FAR * This,
    /* [in] */ long lInfo);


void __RPC_STUB IUSocketInternal_Notify_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUSocketInternal_IsWaiting_Proxy( 
    IUSocketInternal __RPC_FAR * This);


void __RPC_STUB IUSocketInternal_IsWaiting_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUSocketInternal_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
