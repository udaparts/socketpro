#ifndef _WIN64

#include "plugin.h"
#include "MDispatch.h"
#include "usocket.h"

#define COMClassID	_T("classid")
#define COMProgID	_T("progid")

nsPluginInstanceBase * NS_NewPluginInstance(nsPluginCreateData *pCreateDataStruct)
{
	if(!pCreateDataStruct)
		return NULL;
	CPluginInstance *plugin = new CPluginInstance();
	if(plugin != NULL)
	{
		CComBSTR bstr;
		int16 n;
		for(n=0; n<pCreateDataStruct->argc; n++)
		{
			bstr = pCreateDataStruct->argn[n];
			if(bstr == COMProgID)
			{
				plugin->m_bstrCOMProgID = pCreateDataStruct->argv[n];
			}
			else if(bstr == COMClassID)
			{
				plugin->m_bstrCOMClassID = pCreateDataStruct->argv[n];
			}
		}
	}

	return plugin;
}

void NS_DestroyPluginInstance(nsPluginInstanceBase *pPlugin)
{
	if(pPlugin)
	{
		delete pPlugin;
	}
}


CNPObjectImplBase* CPluginInstance::GetObject()
{
/*	
	CLSID clsid;
	memset(&clsid, 0, sizeof(clsid));
	HRESULT hr = E_FAIL;
	if(m_bstrCOMClassID.Length() > 0)
	{
		hr = CLSIDFromString(m_bstrCOMClassID, &clsid);
	}
	if(hr != S_OK)
	{
		hr = CLSIDFromProgID(m_bstrCOMProgID, &clsid);
	}*/
	return new CMDispatch(__uuidof(USocket), this);
}

CNPObjectImplBase* CPluginInstance::GetObject(IUnknown *pIUnknown)
{
	return new CMDispatch(pIUnknown, this);
}



#endif //_WIN64


