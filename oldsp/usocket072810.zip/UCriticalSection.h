// UCriticalSection.h: interface for the CUCriticalSection class.
//
//////////////////////////////////////////////////////////////////////

#ifndef ___UDAPARTS_CRITICAL_SECTION_H__
#define ___UDAPARTS_CRITICAL_SECTION_H__

class CUCriticalSection  
{
public:
	CUCriticalSection(unsigned int nSpinMax = 0) 
		: m_nLockFails(0), m_dwOwningThread(0), m_nCount(-1), m_nRecursionCount(0)
	{
		m_hEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
		if(nSpinMax != 0)
		{
			SYSTEM_INFO info;
			GetSystemInfo(&info);
			if(info.dwNumberOfProcessors > 1)
				m_nSpinMax = nSpinMax;
			else
				m_nSpinMax = 0;
		}
		else
			m_nSpinMax = 0;
	}

	virtual ~CUCriticalSection()
	{
		::CloseHandle(m_hEvent);
	}

	// disable copy constructor
	CUCriticalSection(const CUCriticalSection&);
	
public:
	inline bool Lock(unsigned long dwTimeout = INFINITE)
	{
		if (m_dwOwningThread == ::GetCurrentThreadId())
		{
			ATLASSERT(m_nRecursionCount > 0);
			++m_nRecursionCount;
			return true;
		}
		if(m_nSpinMax > 0 && Spin(m_nSpinMax))
			return true;
		if(::InterlockedIncrement(&m_nCount) != 0)
		{
			if(dwTimeout == 0)
			{
				::InterlockedIncrement(&m_nLockFails);
				::InterlockedDecrement(&m_nCount);
				OnLockFailed(0);
				return false;
			}
			DWORD dwPrev = ::GetTickCount();
			OnLocking();
			if(::WaitForSingleObject(m_hEvent, dwTimeout) != WAIT_OBJECT_0)
			{
				::InterlockedIncrement(&m_nLockFails);
				::InterlockedDecrement(&m_nCount);
				OnLockFailed(dwTimeout);
				return false;
			}
			else
			{
				m_dwOwningThread = ::GetCurrentThreadId();
				m_nRecursionCount = 1;
				unsigned long dwDelay = ::GetTickCount();
				OnLocked( (dwDelay > dwPrev) ? (dwDelay - dwPrev) : 0);
				return true;
			}
		}
		m_dwOwningThread = ::GetCurrentThreadId();
		m_nRecursionCount = 1;
		return true;
	}

	inline bool TryLock()
	{
		if (m_dwOwningThread == ::GetCurrentThreadId())
		{
			ATLASSERT(m_nRecursionCount > 0);
			++m_nRecursionCount;
			return true;
		}
		return Spin(m_nSpinMax);
	}

	inline bool Unlock()
	{
		if(m_dwOwningThread == ::GetCurrentThreadId())
		{
			ATLASSERT(m_nRecursionCount > 0);
			if((--m_nRecursionCount) == 0)
			{
				m_dwOwningThread = 0; 
				if(::InterlockedDecrement(&m_nCount) >= 0)
				{
					::SetEvent(m_hEvent);
				}
			}
			return true;
		}
		return false;
	}

	inline unsigned long StackUnlock()
	{
		unsigned long ul = 0;
		while(Unlock())
		{
			++ul;
		}
		return ul;
	}

	inline void StackRelock(unsigned long dwRecursionCount)
	{
		while(dwRecursionCount > 0)
		{
			Lock();
			--dwRecursionCount;
		}
	}

	inline unsigned long GetWaiters()
	{
		return (unsigned long)(m_nRecursionCount ? m_nCount : 0);
	}

	inline unsigned long GetLockFails()
	{
		return (unsigned long)m_nLockFails;
	}

	inline unsigned long GetOwningThreadId()
	{
		return m_nRecursionCount;
	}

	inline unsigned long GetRecursionCount()
	{
		return m_nRecursionCount;
	}
	
	//disable assignment
	CUCriticalSection& operator = (const CUCriticalSection&);

protected:
	virtual void OnLocking()
	{
		//This virtual function is called only if this critical section is owned by another thread
	}

	virtual void OnLockFailed(unsigned long dwTimeout)
	{
		//This virtual function is called only if this critical section is owned by another thread
	}

	virtual void OnLocked(unsigned long dwDelay)
	{
		//This virtual function is called only if this critical section is owned by another thread
	}

private:
	bool Spin(int nCount)
	{
		int nSpin;
		for (nSpin = 0; nSpin < nCount; nSpin++)
		{
			if(::InterlockedCompareExchange(&m_nCount, 0, -1) == -1)
			{
				m_dwOwningThread = ::GetCurrentThreadId();
				m_nRecursionCount = 1;
				return true;
			}
		}
		return false;
	}

private:
	volatile long	m_nCount;
	unsigned long	m_dwOwningThread;
	unsigned int	m_nRecursionCount;
	HANDLE			m_hEvent;
	int				m_nSpinMax;
	volatile long	m_nLockFails;
};

#endif // !defined(AFX_UCRITICALSECTION_H__75FEE573_19B2_413D_B251_7285C5248F0C__INCLUDED_)
