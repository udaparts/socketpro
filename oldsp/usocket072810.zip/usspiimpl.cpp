#include "stdafx.h"
#include "usspiimpl.h"

HMODULE CSspiClient::m_hSecurity = NULL;
PSecurityFunctionTable CSspiClient::m_pSSPI = NULL;
//HCERTSTORE CSspiClient::m_hMyCertStore = NULL;
OSVERSIONINFOA CSspiClient::m_VersionInfo;

CSspiClient::CSspiClient(void)
{
	ZeroMemory(&m_hContext, sizeof(m_hContext));
	ZeroMemory(&m_hCreds, sizeof(m_hCreds));
	m_pRemoteCertContext = NULL;
	m_SSLState = ssUnknown;
	ZeroMemory(&m_Sizes, sizeof(m_Sizes));
}

CSspiClient::~CSspiClient(void)
{
	FreeResource();
}

bool CSspiClient::IsLoaded()
{
	return (m_hSecurity != NULL);
}

void CSspiClient::FreeResource()
{
	if(m_pRemoteCertContext != NULL)
	{
		::CertFreeCertificateContext(m_pRemoteCertContext);
        m_pRemoteCertContext = NULL;
	}

	if(m_hContext.dwLower != 0 || m_hContext.dwUpper != 0)
	{
		ATLASSERT(IsLoaded());
		m_pSSPI->DeleteSecurityContext(&m_hContext);
		ZeroMemory(&m_hContext, sizeof(m_hContext));
	}

	if(m_hCreds.dwLower != 0 || m_hCreds.dwUpper != 0)
	{
		ATLASSERT(IsLoaded());
		m_pSSPI->FreeCredentialsHandle(&m_hCreds);
		ZeroMemory(&m_hCreds, sizeof(m_hCreds));
	}
}

SECURITY_STATUS CSspiClient::ClientHandshakeLoop(SOCKET hSocket)
{
	SECURITY_STATUS scRet = SEC_E_OK;

	SecBufferDesc   InBuffer;
    SecBuffer       InBuffers[2];
    SecBufferDesc   OutBuffer;
    SecBuffer       OutBuffers[1];
    DWORD           dwSSPIFlags = 0;
    DWORD           dwSSPIOutFlags = 0;
    TimeStamp       tsExpiry;
    int				nData;
	PUCHAR          IoBuffer[IO_BUFFER_SIZE] = {0};

    dwSSPIFlags = ISC_REQ_SEQUENCE_DETECT   |
                  ISC_REQ_REPLAY_DETECT     |
                  ISC_REQ_CONFIDENTIALITY   |
                  ISC_RET_EXTENDED_ERROR    |
                  ISC_REQ_ALLOCATE_MEMORY   |
                  ISC_REQ_STREAM;
	
	scRet = SEC_I_CONTINUE_NEEDED;
	while(scRet == SEC_I_CONTINUE_NEEDED        ||
          scRet == SEC_E_INCOMPLETE_MESSAGE     ||
          scRet == SEC_I_INCOMPLETE_CREDENTIALS) 
	{
		m_SSLState = ssHandshaking;
		do
		{
			//Read data from server.
			nData = ::recv(hSocket, (char*)IoBuffer, sizeof(IoBuffer), 0);
			if(nData > 0)
			{
				m_UQueueSend.Push((BYTE*)IoBuffer, nData);
			}
		}while(nData > 0);

		if(m_UQueueSend.GetSize() == 0)
		{
			return SEC_E_OK;
		}
		
		// Set up the input buffers. Buffer 0 is used to pass in data
		// received from the server. Schannel will consume some or all
		// of this. Leftover data (if any) will be placed in buffer 1 and
		// given a buffer type of SECBUFFER_EXTRA.
		InBuffers[0].pvBuffer   = (void*)m_UQueueSend.GetBuffer();
		InBuffers[0].cbBuffer   = m_UQueueSend.GetSize();
		InBuffers[0].BufferType = SECBUFFER_TOKEN;

		InBuffers[1].pvBuffer   = NULL;
		InBuffers[1].cbBuffer   = 0;
		InBuffers[1].BufferType = SECBUFFER_EMPTY;

		InBuffer.cBuffers       = 2;
		InBuffer.pBuffers       = InBuffers;
		InBuffer.ulVersion      = SECBUFFER_VERSION;

		// Set up the output buffers. These are initialized to NULL
		// so as to make it less likely we'll attempt to free random
		// garbage later.
		OutBuffers[0].pvBuffer  = NULL;
		OutBuffers[0].BufferType= SECBUFFER_TOKEN;
		OutBuffers[0].cbBuffer  = 0;

		OutBuffer.cBuffers      = 1;
		OutBuffer.pBuffers      = OutBuffers;
		OutBuffer.ulVersion     = SECBUFFER_VERSION;

		scRet = m_pSSPI->InitializeSecurityContextA(&m_hCreds,
											&m_hContext,
											NULL,
											dwSSPIFlags,
											0,
											0, //SECURITY_NATIVE_DREP, Not used with Digest or Schannel. Specify zero.
											&InBuffer,
											0,
											NULL,
											&OutBuffer,
											&dwSSPIOutFlags,
											&tsExpiry);

		// If InitializeSecurityContext was successful (or if the error was 
		// one of the special extended ones), send the contends of the output
		// buffer to the server.
		if(scRet == SEC_E_OK || scRet == SEC_I_CONTINUE_NEEDED ||
			FAILED(scRet) && (dwSSPIOutFlags & ISC_RET_EXTENDED_ERROR))
		{
			if(OutBuffers[0].cbBuffer != 0 && OutBuffers[0].pvBuffer != NULL)
			{
				nData = ::send(hSocket,
								(char*)OutBuffers[0].pvBuffer,
								OutBuffers[0].cbBuffer,
								0);
				m_pSSPI->FreeContextBuffer(OutBuffers[0].pvBuffer);
				if(nData == SOCKET_ERROR || nData == 0)
				{
					scRet = SEC_E_INTERNAL_ERROR;
					break;
				}
				OutBuffers[0].pvBuffer = NULL;
			}
		}

		if(scRet == SEC_E_INCOMPLETE_MESSAGE)
        {
            continue;
        }
		// If InitializeSecurityContext returned SEC_E_OK, then the 
		// handshake completed successfully.
		if(scRet == SEC_E_OK)
		{
			m_SSLState = ssFinished;
			if(m_SchannelCred.paCred == NULL)
			{
				if(m_pRemoteCertContext != NULL)
				{
					::CertFreeCertificateContext(m_pRemoteCertContext);
					m_pRemoteCertContext = NULL;
				}
				scRet = m_pSSPI->QueryContextAttributesA(&m_hContext,
                                             SECPKG_ATTR_REMOTE_CERT_CONTEXT,
                                             (PVOID)&m_pRemoteCertContext);
			}
		}

		if(InBuffers[1].BufferType == SECBUFFER_EXTRA )
        {
			ATLASSERT(m_UQueueSend.GetSize() > InBuffers[1].cbBuffer);
			ULONG ulSent = m_UQueueSend.GetSize() - InBuffers[1].cbBuffer;
			m_UQueueSend.Pop(ulSent);
        }
        else
        {
            m_UQueueSend.SetSize(0);
        }
	}
	if(FAILED(scRet))
	{
		m_pSSPI->DeleteSecurityContext(&m_hContext);
		ZeroMemory(&m_hContext, sizeof(m_hContext));
	}
	return scRet;
}


/*
	Set optimization to either Maximize speed or default!!!!
	Can't set it to minimize!!!!
	Otherwise, it will give out Message Altered error.
*/

SECURITY_STATUS CSspiClient::GetData(SOCKET hSocket, CUQueue &UQueue, ULONG ulMaxAllowed)
{
	int nRcv;
	int i;
	bool bContinue = true;
	ATLASSERT(m_SSLState == ssFinished);
	ULONG ulStart = UQueue.GetSize();
	SecBuffer		*pDataBuffer;
    SecBuffer		*pExtraBuffer;
	SecBuffer       Buffers[4];
	SecBufferDesc   Message;
	char strBuffer[8*1024];
	SECURITY_STATUS scRet = SEC_E_OK;
	while(true)
    {
		
		do
		{
			if(m_UQueueRecv.GetSize() > (GetMaxSize() + 1024))
				break;
			nRcv = recv(hSocket, 
							strBuffer, 
							sizeof(strBuffer), 
							0);
			if(nRcv > 0)
			{
				bContinue = true;
				m_UQueueRecv.Push((BYTE*)strBuffer, nRcv);
			}
			else if(nRcv == -1)
			{
				int nError = WSAGetLastError();
				if(nError == WSAEWOULDBLOCK)
				{
					scRet = SEC_E_OK;
					break;
				}
				else
				{
					scRet = SEC_E_INTERNAL_ERROR;
					break;
				}
			}
			else
			{
				break;
			}
		}while(scRet == SEC_E_OK && m_UQueueRecv.GetSize() < m_Sizes.cbMaximumMessage);

		if(m_UQueueRecv.GetSize() == 0)
		{
			break;
		}

//		ATLTRACE("m_UQueueRecv data size = %d\n", m_UQueueRecv.GetSize());

        // Attempt to decrypt the received data.
        Buffers[0].pvBuffer     = (BYTE*)m_UQueueRecv.GetBuffer();
        Buffers[0].cbBuffer     = m_UQueueRecv.GetSize();
        Buffers[0].BufferType   = SECBUFFER_DATA;

        Buffers[1].BufferType   = SECBUFFER_EMPTY;
        Buffers[2].BufferType   = SECBUFFER_EMPTY;
        Buffers[3].BufferType   = SECBUFFER_EMPTY;

        Message.ulVersion       = SECBUFFER_VERSION;
        Message.cBuffers        = 4;
        Message.pBuffers        = Buffers;

		if(m_VersionInfo.dwMajorVersion == 4 && m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
			scRet = ((DECRYPT_MESSAGE_FN)m_pSSPI->Reserved4)(&m_hContext, &Message, 0, NULL);
		else
			scRet = m_pSSPI->DecryptMessage(&m_hContext, &Message, 0, NULL);

        if(scRet == SEC_E_INCOMPLETE_MESSAGE)
        {
			scRet = SEC_E_OK;
			if(bContinue)
			{
				bContinue = false;
				continue;
			}
			else
			{
				break;
			}
        }
		
		 // Server signalled end of session
        if(scRet == SEC_I_CONTEXT_EXPIRED)
		{
            break;
		}

		if( scRet != SEC_E_OK && 
            scRet != SEC_I_RENEGOTIATE && 
            scRet != SEC_I_CONTEXT_EXPIRED
			)
        {
//			scRet = SEC_E_INTERNAL_ERROR;
			::SetLastError(scRet);
            break;
        }

		// Locate data and (optional) extra buffers.
        pDataBuffer  = NULL;
        pExtraBuffer = NULL;
        for(i = 1; i < 4; i++)
        {
            if(pDataBuffer == NULL && Buffers[i].BufferType == SECBUFFER_DATA)
            {
                pDataBuffer = Buffers + i;
//                printf("Buffers[%d].BufferType = SECBUFFER_DATA\n",i);
            }
            if(pExtraBuffer == NULL && Buffers[i].BufferType == SECBUFFER_EXTRA)
            {
                pExtraBuffer = Buffers + i;
            }
        }

		// Display or otherwise process the decrypted data.
        if(pDataBuffer)
        {
			UQueue.Push((BYTE*)pDataBuffer->pvBuffer, pDataBuffer->cbBuffer);
        }
		
		m_UQueueRecv.SetSize(0);
		// Move any "extra" data to the input buffer.
        if(pExtraBuffer && pExtraBuffer->BufferType == SECBUFFER_EXTRA)
        {
			m_UQueueRecv.Push((BYTE*)pExtraBuffer->pvBuffer, pExtraBuffer->cbBuffer);
//			ATLTRACE("There is an extra with size = %d\n", pExtraBuffer->cbBuffer);
        }

		if(scRet == SEC_I_RENEGOTIATE)
		{
			ClientHandshakeLoop(hSocket);
			scRet = SEC_E_OK;
			break;
		}

		if((UQueue.GetSize() - ulStart) > ulMaxAllowed)
		{
			scRet = SEC_E_OK;
			break;
		}
	}
	if(scRet == SEC_I_CONTEXT_EXPIRED)
	{
		m_UQueueRecv.SetSize(0);
		scRet = SEC_E_OK;
	}
	m_UQueueRecv.CleanTrack();
	return scRet;
}

ULONG CSspiClient::GetDataInBuffer()
{
	return m_UQueueSend.GetSize();
}

ULONG CSspiClient::GetMaxSize()
{
	if(m_Sizes.cbMaximumMessage == 0)
	{
		SECURITY_STATUS scRet = m_pSSPI->QueryContextAttributesA(&m_hContext,
                SECPKG_ATTR_STREAM_SIZES, &m_Sizes);
		if(scRet != SEC_E_OK)
		{
//			TCHAR strMessage[128] = {0};
//			::_stprintf(strMessage, _T("%X, Message size = %X"), scRet, m_Sizes.cbMaximumMessage);
//			MessageBox(NULL, strMessage, _T("SocketPro"), MB_ICONERROR);
			return scRet;
		}
		ULONG ulTotal = m_Sizes.cbMaximumMessage + m_Sizes.cbHeader + m_Sizes.cbTrailer;
		if(m_UQueueSend.GetMaxSize() < ulTotal)
		{
			m_UQueueSend.ReallocBuffer(ulTotal);
		}
	}
	return m_Sizes.cbMaximumMessage;
}

int CSspiClient::SendData(SOCKET hSocket, const BYTE *pData, ULONG ulLen)
{
	int nRtn;
	ATLASSERT(m_SSLState == ssFinished);
	SecBufferDesc   Message;
    SECURITY_STATUS scRet;
	SecBuffer       Buffers[4];

#ifdef _DEBUG
	SecBuffer		*pDataBuffer;
	SecBuffer		*pExtraBuffer;
#endif
	
	while(m_UQueueSend.GetSize() > 0)
	{
		nRtn = ::send(hSocket,
				  (char*)m_UQueueSend.GetBuffer(),
				  m_UQueueSend.GetSize(),
				  0);
		if(nRtn > 0)
		{
			m_UQueueSend.Pop(nRtn);
		}
		else if(nRtn == -1)
		{
			return -1;
		}
	}

	GetMaxSize();
	ATLASSERT(ulLen <= m_Sizes.cbMaximumMessage);
	Buffers[0].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(0);
    Buffers[0].cbBuffer     = m_Sizes.cbHeader;
    Buffers[0].BufferType   = SECBUFFER_STREAM_HEADER;
	::memset(Buffers[0].pvBuffer, 0, m_Sizes.cbHeader);
	m_UQueueSend.SetSize(m_Sizes.cbHeader);
	m_UQueueSend.Push(pData, ulLen);
	Buffers[1].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(m_Sizes.cbHeader);
    Buffers[1].cbBuffer     = ulLen;
    Buffers[1].BufferType   = SECBUFFER_DATA;
	Buffers[2].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(m_UQueueSend.GetSize());
    Buffers[2].cbBuffer     = m_Sizes.cbTrailer;
    Buffers[2].BufferType   = SECBUFFER_STREAM_TRAILER;
	::memset(Buffers[2].pvBuffer, 0, m_Sizes.cbTrailer);
	Buffers[3].BufferType   = SECBUFFER_EMPTY;
    Message.ulVersion       = SECBUFFER_VERSION;
    Message.cBuffers        = 4;
    Message.pBuffers        = Buffers;
	if(m_VersionInfo.dwMajorVersion == 4 && m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
		scRet = ((ENCRYPT_MESSAGE_FN)(m_pSSPI->Reserved3))(&m_hContext, 0, &Message, 0);
	else
		scRet = m_pSSPI->EncryptMessage(&m_hContext, 0, &Message, 0);
	if(FAILED(scRet))
    {
        return -1;
    }

#ifdef _DEBUG
	pDataBuffer  = NULL;
	pExtraBuffer = NULL;
	for (int i = 1; i < 4; i++) 
	{
		if (pDataBuffer == NULL && Buffers[i].BufferType == SECBUFFER_DATA) 
		{
			pDataBuffer = &Buffers[i];
		}
		if (pExtraBuffer == NULL && Buffers[i].BufferType == SECBUFFER_EXTRA) 
		{
			pExtraBuffer = &Buffers[i];
		}
	}
	ATLASSERT(pExtraBuffer == NULL);
#endif

	m_UQueueSend.SetSize(Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
	ATLASSERT(m_Sizes.cbHeader == Buffers[0].cbBuffer);
	ATLASSERT(ulLen == Buffers[1].cbBuffer);
//	ATLASSERT(Buffers[2].cbBuffer == m_Sizes.cbTrailer);

	do
	{
		nRtn = ::send(hSocket,
                  (char*)m_UQueueSend.GetBuffer(),
                  m_UQueueSend.GetSize(),
                  0);
		if(nRtn > 0)
		{
			m_UQueueSend.Pop(nRtn);
		}
		else if(nRtn == -1)
		{
			int nError = WSAGetLastError();
			if(nError != WSAEWOULDBLOCK)
			{
				return -1;
			}
			else
			{
				return ulLen;
			}
		}
		else
		{
			ATLASSERT(FALSE);
			return 0;
		}
	}while(m_UQueueSend.GetSize() > 0);
	m_UQueueSend.CleanTrack();
	return ulLen;
}


SECURITY_STATUS CSspiClient::PerformClientHandshake(SOCKET hSocket, LPCTSTR strServerName)
{
	ATLASSERT(IsLoaded());

	m_SSLState = ssUnknown;
	m_UQueueSend.SetSize(0);
	m_UQueueRecv.SetSize(0);

	SecBufferDesc   OutBuffer;
    SecBuffer       OutBuffers[1];
    DWORD           dwSSPIFlags = 0;
    DWORD           dwSSPIOutFlags = 0;

	TimeStamp       tsExpiry;
    SECURITY_STATUS scRet = SEC_E_OK;
    int				nSent = 0;

	dwSSPIFlags = (	ISC_REQ_SEQUENCE_DETECT   |
					ISC_REQ_REPLAY_DETECT     |
					ISC_REQ_CONFIDENTIALITY   |
					ISC_RET_EXTENDED_ERROR    |
					ISC_REQ_ALLOCATE_MEMORY   |
					ISC_REQ_STREAM);

	OutBuffers[0].pvBuffer   = NULL;
    OutBuffers[0].BufferType = SECBUFFER_TOKEN;
    OutBuffers[0].cbBuffer   = 0;

    OutBuffer.cBuffers = 1;
    OutBuffer.pBuffers = OutBuffers;
    OutBuffer.ulVersion = SECBUFFER_VERSION;

	if(m_hContext.dwLower != 0 || m_hContext.dwUpper != 0)
	{
		m_pSSPI->DeleteSecurityContext(&m_hContext);
		ZeroMemory(&m_hContext, sizeof(m_hContext));
	}
	
	//Initiate a ClientHello message and generate a token.
    scRet = m_pSSPI->InitializeSecurityContextA(
                    &m_hCreds,
                    NULL,
                    (LPSTR)strServerName,
                    dwSSPIFlags,
                    0,
                    0, //SECURITY_NATIVE_DREP, Not used with Digest or Schannel. Specify zero.
                    NULL,
                    0,
                    &m_hContext,
                    &OutBuffer,
                    &dwSSPIOutFlags,
                    &tsExpiry);

	if(scRet != SEC_I_CONTINUE_NEEDED)
	{
//		TCHAR strMessage[128] = {0};
//		::_stprintf(strMessage, _T("%X"), scRet);
//		MessageBox(NULL, strMessage, _T("SocketPro"), MB_ICONERROR);
		ZeroMemory(&m_hContext, sizeof(m_hContext));
		return scRet;
	}

	if(OutBuffers[0].cbBuffer != 0 && OutBuffers[0].pvBuffer != NULL)
    {
		nSent = send(hSocket,
                      (char*)OutBuffers[0].pvBuffer,
                      OutBuffers[0].cbBuffer,
                      0);
        if(nSent == SOCKET_ERROR || nSent == 0)
        {
            m_pSSPI->FreeContextBuffer(OutBuffers[0].pvBuffer);
            m_pSSPI->DeleteSecurityContext(&m_hContext);
			ZeroMemory(&m_hContext, sizeof(m_hContext));
            return SEC_E_INTERNAL_ERROR;
        }

        // Free output buffer.
        m_pSSPI->FreeContextBuffer(OutBuffers[0].pvBuffer);
        OutBuffers[0].pvBuffer = NULL;
    }
	
	m_SSLState = ssClientHello;
	return SEC_E_OK;
}

tagSSLState	CSspiClient::GetSSLState()
{
	return m_SSLState;
}

DWORD CSspiClient::VerifyServerCertificate(LPCTSTR pszServerName, long lPolicy, DWORD dwPolicyFlags, DWORD dwCertFlags)
{
	USES_CONVERSION;
    HTTPSPolicyCallbackData  polHttps;
    CERT_CHAIN_POLICY_PARA   PolicyPara;
    CERT_CHAIN_POLICY_STATUS PolicyStatus;
    CERT_CHAIN_PARA          ChainPara;
    PCCERT_CHAIN_CONTEXT     pChainContext = NULL;

    LPTSTR rgszUsages[] = {  szOID_PKIX_KP_SERVER_AUTH,
                            szOID_SERVER_GATED_CRYPTO,
                            szOID_SGC_NETSCAPE };
    DWORD	cUsages = sizeof(rgszUsages) / sizeof(LPSTR);
    DWORD   Status;

	if(m_pRemoteCertContext == NULL)
	{
		return SEC_E_WRONG_PRINCIPAL;
	}

    // Convert server name to unicode.
	if(pszServerName == NULL || ::_tcslen(pszServerName) == 0)
    {
        return SEC_E_WRONG_PRINCIPAL;
    }

    // Build certificate chain.
    ZeroMemory(&ChainPara, sizeof(ChainPara));
    ChainPara.cbSize = sizeof(ChainPara);
    ChainPara.RequestedUsage.dwType = USAGE_MATCH_TYPE_OR;
    ChainPara.RequestedUsage.Usage.cUsageIdentifier     = cUsages;
    ChainPara.RequestedUsage.Usage.rgpszUsageIdentifier = rgszUsages;

    if(!CertGetCertificateChain(
                            NULL,
                            m_pRemoteCertContext,
                            NULL,
                            m_pRemoteCertContext->hCertStore,
                            &ChainPara,
                            0,
                            NULL,
                            &pChainContext))
    {
        Status = GetLastError();
        return Status;
    }


    // Validate certificate chain.
    ZeroMemory(&polHttps, sizeof(HTTPSPolicyCallbackData));
    polHttps.cbStruct           = sizeof(HTTPSPolicyCallbackData);
    polHttps.dwAuthType         = AUTHTYPE_SERVER;
    polHttps.fdwChecks          = dwCertFlags;
    polHttps.pwszServerName     = T2OLE(pszServerName);

    memset(&PolicyPara, 0, sizeof(PolicyPara));
    PolicyPara.cbSize            = sizeof(PolicyPara);
    PolicyPara.pvExtraPolicyPara = &polHttps;
	PolicyPara.dwFlags = dwPolicyFlags;

    memset(&PolicyStatus, 0, sizeof(PolicyStatus));
    PolicyStatus.cbSize = sizeof(PolicyStatus);
	
    if(!CertVerifyCertificateChainPolicy(
                            (LPCSTR)lPolicy, //CERT_CHAIN_POLICY_BASE, CERT_CHAIN_POLICY_SSL
                            pChainContext,
                            &PolicyPara,
                            &PolicyStatus))
    {
        Status = GetLastError();
    }
	else
	{
		Status = PolicyStatus.dwError;
	}
	
	ATLTRACE("Verify server certificate with error code = %d\n", Status);

    if(pChainContext)
    {
        CertFreeCertificateChain(pChainContext);
    }
    return Status;
}

CComBSTR CSspiClient::DisplayWinVerifyTrustError(DWORD Status)
{
	LPSTR pszName;
    switch(Status)
    {
    case CERT_E_EXPIRED:                pszName = "CERT_E_EXPIRED";                 break;
    case CERT_E_VALIDITYPERIODNESTING:  pszName = "CERT_E_VALIDITYPERIODNESTING";   break;
    case CERT_E_ROLE:                   pszName = "CERT_E_ROLE";                    break;
    case CERT_E_PATHLENCONST:           pszName = "CERT_E_PATHLENCONST";            break;
    case CERT_E_CRITICAL:               pszName = "CERT_E_CRITICAL";                break;
    case CERT_E_PURPOSE:                pszName = "CERT_E_PURPOSE";                 break;
    case CERT_E_ISSUERCHAINING:         pszName = "CERT_E_ISSUERCHAINING";          break;
    case CERT_E_MALFORMED:              pszName = "CERT_E_MALFORMED";               break;
    case CERT_E_UNTRUSTEDROOT:          pszName = "CERT_E_UNTRUSTEDROOT";           break;
    case CERT_E_CHAINING:               pszName = "CERT_E_CHAINING";                break;
    case TRUST_E_FAIL:                  pszName = "TRUST_E_FAIL";                   break;
    case CERT_E_REVOKED:                pszName = "CERT_E_REVOKED";                 break;
    case CERT_E_UNTRUSTEDTESTROOT:      pszName = "CERT_E_UNTRUSTEDTESTROOT";       break;
    case CERT_E_REVOCATION_FAILURE:     pszName = "CERT_E_REVOCATION_FAILURE";      break;
    case CERT_E_CN_NO_MATCH:            pszName = "CERT_E_CN_NO_MATCH";             break;
    case CERT_E_WRONG_USAGE:            pszName = "CERT_E_WRONG_USAGE";             break;
    default:                            pszName = NULL;								break;
    }
   return pszName;
}

SECURITY_STATUS CSspiClient::Open(DWORD dwProtocol, LPCTSTR strUserName)
{
	ATLASSERT(IsLoaded());

	TimeStamp       tsExpiry;
    SECURITY_STATUS Status = SEC_E_OK;
    PCCERT_CONTEXT  pCertContext = NULL;
	m_UQueueSend.SetSize(0);
	m_UQueueRecv.SetSize(0);
	ZeroMemory(&m_SchannelCred, sizeof(m_SchannelCred));
/*	if(strUserName != NULL && ::_tcslen(strUserName) > 0)
	{
		pCertContext = ::CertFindCertificateInStore(m_hMyCertStore, 
                                                  X509_ASN_ENCODING, 
                                                  0,
                                                  (sizeof(TCHAR) > 1) ? CERT_FIND_SUBJECT_STR_W : CERT_FIND_SUBJECT_STR_A,
                                                  strUserName,
                                                  NULL);
		if(pCertContext == NULL)
        {
            return SEC_E_NO_CREDENTIALS;
        }
	}*/
	
    m_SchannelCred.dwVersion  = SCHANNEL_CRED_VERSION;
    if(pCertContext)
    {
        m_SchannelCred.cCreds = 1;
        m_SchannelCred.paCred = &pCertContext;
    }
	else
	{
		m_SchannelCred.cCreds = 0;
        m_SchannelCred.paCred = NULL;
	}

    m_SchannelCred.grbitEnabledProtocols = dwProtocol;
    m_SchannelCred.dwFlags = (SCH_CRED_NO_DEFAULT_CREDS | SCH_CRED_MANUAL_CRED_VALIDATION | SCH_CRED_REVOCATION_CHECK_CHAIN);
	
	if(m_hCreds.dwLower != 0 || m_hCreds.dwUpper != 0)
	{
		m_pSSPI->FreeCredentialsHandle(&m_hCreds);
		ZeroMemory(&m_hCreds, sizeof(m_hCreds));
	}

	Status = m_pSSPI->AcquireCredentialsHandleA(
                        NULL,                   // Name of principal    
                        UNISP_NAME,				// Name of package UNISP_NAME for the Schannel SSP
                        SECPKG_CRED_OUTBOUND,   // Flags indicating use
                        NULL,                   // Pointer to logon ID
                        &m_SchannelCred,        // Package specific data
                        NULL,                   // Pointer to GetKey() func
                        NULL,                   // Value to pass to GetKey()
                        &m_hCreds,              // (out) Cred Handle
                        &tsExpiry);  
	ATLASSERT(Status == SEC_E_OK);

	if(Status != SEC_E_OK)
	{
//		TCHAR strMessage[128] = {0};
//		::_stprintf(strMessage, _T("%X"), Status);
//		MessageBox(NULL, strMessage, _T("SocketPro"), MB_ICONERROR);
	}

	if(pCertContext)
    {
		::CertFreeCertificateContext(pCertContext);
    }

	return Status;
}

void CSspiClient::Close(SOCKET hSocket)
{
	m_SSLState = ssUnknown;
	if(m_hContext.dwLower != 0 || m_hContext.dwUpper != 0)
	{
		ATLASSERT(IsLoaded());
		do
		{
			DWORD           dwType;
			char			*pbMessage;
			DWORD           cbMessage;
			SecBufferDesc   OutBuffer;
			SecBuffer       OutBuffers[1];
			DWORD           dwSSPIFlags;
			DWORD           dwSSPIOutFlags;
			TimeStamp       tsExpiry;
			DWORD           Status;
			dwType = SCHANNEL_SHUTDOWN;
			OutBuffers[0].pvBuffer   = &dwType;
			OutBuffers[0].BufferType = SECBUFFER_TOKEN;
			OutBuffers[0].cbBuffer   = sizeof(dwType);

			OutBuffer.cBuffers  = 1;
			OutBuffer.pBuffers  = OutBuffers;
			OutBuffer.ulVersion = SECBUFFER_VERSION;
			Status = m_pSSPI->ApplyControlToken(&m_hContext, &OutBuffer);
			if(FAILED(Status))
				break;
			dwSSPIFlags = ISC_REQ_SEQUENCE_DETECT   |
					ISC_REQ_REPLAY_DETECT     |
					ISC_REQ_CONFIDENTIALITY   |
					ISC_RET_EXTENDED_ERROR    |
					ISC_REQ_ALLOCATE_MEMORY   |
					ISC_REQ_STREAM;

			OutBuffers[0].pvBuffer   = NULL;
			OutBuffers[0].BufferType = SECBUFFER_TOKEN;
			OutBuffers[0].cbBuffer   = 0;

			OutBuffer.cBuffers  = 1;
			OutBuffer.pBuffers  = OutBuffers;
			OutBuffer.ulVersion = SECBUFFER_VERSION;

			Status = m_pSSPI->InitializeSecurityContextA(
							&m_hCreds,
							&m_hContext,
							NULL,
							dwSSPIFlags,
							0,
							SECURITY_NATIVE_DREP,
							NULL,
							0,
							&m_hContext,
							&OutBuffer,
							&dwSSPIOutFlags,
							&tsExpiry);
			if(FAILED(Status) || hSocket <= 0)
				break;
			pbMessage = (char*)OutBuffers[0].pvBuffer;
			cbMessage = OutBuffers[0].cbBuffer;
			if(pbMessage != NULL && cbMessage != 0)
			{
				int cbData = ::send(hSocket, pbMessage, cbMessage, 0);
				// Free output buffer.
				m_pSSPI->FreeContextBuffer(pbMessage);
				if(cbData <= 0)
				{
					break;
				}
			}
		}while(false);
	}

	FreeResource();
	ZeroMemory(&m_Sizes, sizeof(m_Sizes));
	m_UQueueSend.SetSize(0);
}

bool CSspiClient::LoadSecurityLibraryAndOpenStore()
{
	ATLASSERT(sizeof(TCHAR) == 1);

	if(IsLoaded())
		return true;

	INIT_SECURITY_INTERFACE         pInitSecurityInterface;

    TCHAR			lpszDLL[MAX_PATH];
    m_VersionInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
    if (!GetVersionExA(&m_VersionInfo))   
    {
        return false;
    }

    if (m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT 
        && m_VersionInfo.dwMajorVersion == 4)
    {
		::_tcscpy(lpszDLL, NT4_DLL_NAME);
    }
    else /*if (VerInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS ||
          VerInfo.dwPlatformId == VER_PLATFORM_WIN32_NT )*/
    {
		::_tcscpy(lpszDLL, DLL_NAME);
    }
  
    m_hSecurity = LoadLibrary(lpszDLL);
    if(m_hSecurity == NULL)
    {
        return false;
    }

    pInitSecurityInterface = (INIT_SECURITY_INTERFACE)GetProcAddress(
                                    m_hSecurity,
                                    "InitSecurityInterfaceA");
    if(pInitSecurityInterface == NULL)
    {
		CloseStoreAndUnloadSecurityLibrary();
        return false;
    }

    m_pSSPI = pInitSecurityInterface();
    if(m_pSSPI == NULL)
    {
		CloseStoreAndUnloadSecurityLibrary();
        return false;
    }

/*	m_hMyCertStore = ::CertOpenSystemStoreA(0, "MY"); 
	if(m_hMyCertStore == NULL)
	{
		CloseStoreAndUnloadSecurityLibrary();
        return false;
	}*/

	return true;
}

void CSspiClient::CloseStoreAndUnloadSecurityLibrary()
{
/*	if(m_hMyCertStore != NULL)
	{
		::CertCloseStore(m_hMyCertStore, 0);
		m_hMyCertStore = NULL;
	}*/

	if(m_hSecurity != NULL)
	{
		::FreeLibrary(m_hSecurity);
		m_hSecurity = NULL;
	}

    m_pSSPI = NULL;
}