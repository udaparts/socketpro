// COMWebItem.cpp: implementation of the CCOMWebItem class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _WIN64

#include "COMWebItem.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCOMWebItem::CCOMWebItem()
{
	m_bWnd = false;
}

CCOMWebItem::~CCOMWebItem()
{
	if(m_bWnd)
	{
		CWebItem::Detach(); //prevent it from crashing
	}
	else
	{
		CWebItem::Release();
	}
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::HasProperty(BSTR bstrPropertyName, VARIANT_BOOL *pVal)
{
	if(pVal != NULL)
	{
		USES_CONVERSION;
		if(bstrPropertyName == NULL || !IsAttached())
			return E_FAIL;
		*pVal = CWebItem::HasProperty(OLE2A(bstrPropertyName)) ? VARIANT_TRUE : VARIANT_FALSE;
	}
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::HasMethod(BSTR bstrMethodName, VARIANT_BOOL *pVal)
{
	if(pVal != NULL)
	{
		USES_CONVERSION;
		if(bstrMethodName == NULL || !IsAttached())
			return E_FAIL;
		*pVal = CWebItem::HasMethod(OLE2A(bstrMethodName)) ? VARIANT_TRUE : VARIANT_FALSE;
	}
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::Invoke(BSTR bstrMethodName, VARIANT vtParameters, VARIANT *pvtResult)
{
	USES_CONVERSION;
	if(bstrMethodName == NULL || !IsAttached())
		return E_FAIL;
	ULONG ulArgCount = 0;
	VARIANT *pvtArgs = NULL;
	CComVariant vtResult;
	if(pvtResult == NULL)
	{
		pvtResult = &vtResult;
	}
	if(vtParameters.vt == VT_NULL || vtParameters.vt == VT_EMPTY)
	{
	}
	else if(vtParameters.vt == (VT_ARRAY|VT_VARIANT))
	{
		ulArgCount = vtParameters.parray->rgsabound[0].cElements;
		::SafeArrayAccessData(vtParameters.parray, (void**)&pvtArgs);
	}
	else
	{
		return E_FAIL;
	}
	bool bSuc = CWebItem::Invoke(OLE2A(bstrMethodName), pvtArgs, ulArgCount, *pvtResult);
	if(pvtArgs != NULL)
	{
		::SafeArrayUnaccessData(vtParameters.parray);
	}
	return bSuc ? S_OK : E_FAIL;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::InvokeWebItem(BSTR bstrMethodName, VARIANT vtParameters, IMozillaWebItem **ppIMozillaWebItem)
{
	if(bstrMethodName == NULL || !IsAttached())
		return E_FAIL;
	if(ppIMozillaWebItem == NULL)
		return E_FAIL;
	*ppIMozillaWebItem = NULL;
	ULONG ulArgCount = 0;
	VARIANT *pvtArgs = NULL;
	if(vtParameters.vt == VT_NULL || vtParameters.vt == VT_EMPTY)
	{
	}
	else if(vtParameters.vt == (VT_ARRAY|VT_VARIANT))
	{
		ulArgCount = vtParameters.parray->rgsabound[0].cElements;
		::SafeArrayAccessData(vtParameters.parray, (void**)&pvtArgs);
	}
	else
	{
		return E_FAIL;
	}

	CComObject<CCOMWebItem> *pIMozillaWebItem = NULL;
	HRESULT hr = CComObject<CCOMWebItem>::CreateInstance(&pIMozillaWebItem);
	if(pIMozillaWebItem != NULL)
	{
		USES_CONVERSION;
		pIMozillaWebItem->AddRef();
		hr = CWebItem::Invoke(OLE2A(bstrMethodName), pvtArgs, ulArgCount, *pIMozillaWebItem) ? S_OK : E_FAIL;
		if(hr == S_OK)
			*ppIMozillaWebItem = (IMozillaWebItem*)pIMozillaWebItem;
		else
		{
			pIMozillaWebItem->Release();
		}
	}
	if(pvtArgs != NULL)
	{
		::SafeArrayUnaccessData(vtParameters.parray);
	}
	return hr;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::SetException(BSTR bstrExceptionMessage)
{
	if(bstrExceptionMessage != NULL)
	{
		USES_CONVERSION;
		CWebItem::SetException(OLE2A(bstrExceptionMessage));
	}
	else
	{
		CWebItem::SetException(NULL);
	}
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::SetProperty(BSTR bstrPropertyName, VARIANT vtNewValue)
{
	USES_CONVERSION;
	if(bstrPropertyName == NULL || !IsAttached())
		return E_FAIL;
	bool bSuc = CWebItem::SetProperty(OLE2A(bstrPropertyName), vtNewValue);
	return bSuc ? S_OK : E_FAIL;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::GetPropertyByIndex(long lIndex, VARIANT *pvtValue)
{
	if(pvtValue != NULL)
	{
		USES_CONVERSION;
		if(!IsAttached())
			return E_FAIL;
		bool bSuc = CWebItem::GetProperty(lIndex, *pvtValue);
		return bSuc ? S_OK : E_FAIL;
	}
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::GetProperty(BSTR bstrPropertyName, VARIANT *pvtValue)
{
	if(pvtValue != NULL)
	{
		USES_CONVERSION;
		if(bstrPropertyName == NULL || !IsAttached())
			return E_FAIL;
		bool bSuc = CWebItem::GetProperty(OLE2A(bstrPropertyName), *pvtValue);
		return bSuc ? S_OK : E_FAIL;
	}
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::GetPropertyWebItem(BSTR bstrPropertyName, IMozillaWebItem **ppIMozillaWebItem)
{
	if(bstrPropertyName == NULL || !IsAttached())
		return E_FAIL;
	if(ppIMozillaWebItem == NULL)
		return S_OK;
	*ppIMozillaWebItem = NULL;
	CComObject<CCOMWebItem> *pIMozillaWebItem = NULL;
	HRESULT hr = CComObject<CCOMWebItem>::CreateInstance(&pIMozillaWebItem);
	if(pIMozillaWebItem != NULL)
	{
		USES_CONVERSION;
		pIMozillaWebItem->AddRef();
		hr = CWebItem::GetProperty(OLE2A(bstrPropertyName), *pIMozillaWebItem) ? S_OK : E_FAIL;
		if(hr == S_OK)
			*ppIMozillaWebItem = (IMozillaWebItem*)pIMozillaWebItem;
		else
		{
			pIMozillaWebItem->Release();
		}
	}
	return hr;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::Detach()
{
	if(m_bWnd) 
	{
		CWebItem::Detach(); //prevent it from crashing
	}
	else
	{
		CWebItem::Release();
	}
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CCOMWebItem::get_Attached(VARIANT_BOOL *pVal)
{
	if(pVal != NULL)
	{
		*pVal = IsAttached() ? VARIANT_TRUE : VARIANT_FALSE;
	}
	return S_OK;
}

STDMETHODIMP CCOMWebItem::get_WindowHandle(long *pVal)
{
	nsPluginInstanceBase *pPlugin = GetPlugin();
	if(pPlugin == NULL)
		return E_FAIL;
	if(pVal != NULL)
	{
		*pVal = (long)pPlugin->m_hWnd;
	}
	return S_OK;
}

STDMETHODIMP CCOMWebItem::get_CreateDataStructure(VARIANT *pVal)
{
	if(pVal == NULL)
		return S_OK;
	try
	{
		::VariantClear(pVal);
	}
	catch(...)
	{
	}
	nsPluginInstanceBase *pPlugin = GetPlugin();
	if(pPlugin == NULL)
		return E_FAIL;
	return ::VariantCopy(pVal, &pPlugin->m_vtCreateDataStructure);
}

#endif //_WIN64