// NPObjectImpBase.cpp: implementation of the CNPObjectImpBase class.
//
//////////////////////////////////////////////////////////////////////
#ifndef _WIN64

#include "npupp.h"
#include "pluginbase.h"
#include "NPObjectImpBase.h"
#include "COMWebItem.h"

NPClass						g_NPClass;
extern NPNetscapeFuncs		NPNFuncs;

extern char *strGetDate;
extern char *strGetArray;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//#define MAX_MOZILA_INT32	1073000000


bool Variant2NPVariant(const VARIANT &vtSource, NPVariant *pnpvOut)
{
	if(pnpvOut == NULL)
		return false;
	if(pnpvOut->type == NPVariantType_String || pnpvOut->type == NPVariantType_Object)
	{
		if(NPNFuncs.releasevariantvalue != NULL)
		{
			try
			{
				NPNFuncs.releasevariantvalue(pnpvOut);
			}
			catch(...)
			{
			}
		}
	}
	
	pnpvOut->type = NPVariantType_Void;

	switch(vtSource.vt)
	{
	case VT_NULL:
		NULL_TO_NPVARIANT(*pnpvOut);
		break;
	case VT_EMPTY:
		VOID_TO_NPVARIANT(*pnpvOut);
		break;
	case VT_I1:
		INT32_TO_NPVARIANT(vtSource.cVal, *pnpvOut);
		break;
	case VT_UI1:
		INT32_TO_NPVARIANT(vtSource.bVal, *pnpvOut);
		break;
	case VT_I2:
		INT32_TO_NPVARIANT(vtSource.iVal, *pnpvOut);
		break;
	case VT_UI2:
		INT32_TO_NPVARIANT(vtSource.uiVal, *pnpvOut);
		break;
	case VT_BOOL:
		BOOLEAN_TO_NPVARIANT(vtSource.boolVal ? true : false, *pnpvOut);
		break;

	/*
		When an integer is larger than 1073000000, javascript will get a negative data.
		To correct this mozilla bug, we convert an integer into double.
	*/
	case VT_I4: //I4 -> double
		DOUBLE_TO_NPVARIANT(vtSource.lVal, *pnpvOut);
		break;
	case VT_UI4: //UI4 -> double
		DOUBLE_TO_NPVARIANT(vtSource.ulVal, *pnpvOut);
		break;
	case VT_INT: //INT -> double
		DOUBLE_TO_NPVARIANT(vtSource.intVal, *pnpvOut);
		break;
	case VT_UINT: //UINT -> double
		DOUBLE_TO_NPVARIANT(vtSource.uintVal, *pnpvOut);
		break;
	case VT_I8: //I8 -> double
		DOUBLE_TO_NPVARIANT(vtSource.llVal, *pnpvOut);
		break;
	case VT_UI8: //UI8 -> double
		DOUBLE_TO_NPVARIANT(vtSource.llVal, *pnpvOut);
		break;
	case VT_R4:
		DOUBLE_TO_NPVARIANT(vtSource.fltVal, *pnpvOut);
		break;
	case VT_R8:
		DOUBLE_TO_NPVARIANT(vtSource.dblVal, *pnpvOut);
		break;
	case VT_CY:
	case VT_DECIMAL:
		{
			CComVariant vtDouble;
			::VariantChangeType(&vtDouble, (VARIANT*)&vtSource, VARIANT_NOVALUEPROP, VT_R8);
			DOUBLE_TO_NPVARIANT(vtDouble.dblVal, *pnpvOut);
		}
		break;
	case VT_BSTR:
		{
			int nBytes = ::WideCharToMultiByte(CP_UTF8, 0, vtSource.bstrVal, -1, NULL, 0, NULL, NULL);
			NPUTF8 *str = (NPUTF8 *)NPN_MemAlloc(nBytes);
			nBytes = ::WideCharToMultiByte(CP_UTF8, 0, vtSource.bstrVal, -1, str, nBytes, NULL, NULL);
			if(nBytes != 0)
			{
				pnpvOut->type = NPVariantType_String;
				pnpvOut->value.stringValue.utf8characters = (const NPUTF8 *)str;
				pnpvOut->value.stringValue.utf8length = (uint32_t)(nBytes - 1);
			}
			else
			{
				return false;
			}
		}
		break;
	case VT_UNKNOWN:
	case VT_DISPATCH:
		return false;
		break;
	default:
		{
			CComVariant vtBSTR;
			if(::VariantChangeType(&vtBSTR, (VARIANT*)&vtSource, VARIANT_NOVALUEPROP, VT_BSTR) != S_OK)
				return false;
			return Variant2NPVariant(vtBSTR, pnpvOut);
		}
		break;
	}
	return true;
}

bool BSTR2NPVariant(const BSTR bstr, NPVariant *pnpvOut)
{
	VARIANT vtIn;
	::VariantInit(&vtIn);
	if(bstr != NULL)
	{
		vtIn.vt = VT_BSTR;
		vtIn.bstrVal = bstr;
	}
	return Variant2NPVariant(vtIn, pnpvOut);
}

bool NPVariant2Variant(const NPVariant &vnpSource, VARIANT *pvtOut)
{
	if(pvtOut == NULL)
	{
		return false;
	}

	try
	{
		::VariantClear(pvtOut);
	}
	catch(...)
	{
	}
	switch(vnpSource.type)
	{
	case NPVariantType_Void:
		pvtOut->vt = VT_EMPTY;
		break;
    case NPVariantType_Null:
		pvtOut->vt = VT_NULL;
		break;
    case NPVariantType_Bool:
		pvtOut->vt = VT_BOOL;
		pvtOut->boolVal = vnpSource.value.boolValue ? VARIANT_TRUE : VARIANT_FALSE;
		break;
    case NPVariantType_Int32:
		pvtOut->vt = VT_I4;
		pvtOut->lVal = vnpSource.value.intValue;
		break;
    case NPVariantType_Double:
		pvtOut->vt = VT_R8;
		pvtOut->dblVal = vnpSource.value.doubleValue;
		break;
    case NPVariantType_String:
		{
			BSTR str = NULL;
			int nConvertedLen = MultiByteToWideChar(CP_UTF8, 0, vnpSource.value.stringValue.utf8characters,
				vnpSource.value.stringValue.utf8length, NULL, NULL); // - 1; ????
			str = ::SysAllocStringLen(NULL, nConvertedLen);
			if (str != NULL)
			{
				MultiByteToWideChar(CP_UTF8, 0, vnpSource.value.stringValue.utf8characters, vnpSource.value.stringValue.utf8length,
					str, nConvertedLen);
				pvtOut->vt = VT_BSTR;
				pvtOut->bstrVal = str;
			}
			else
			{
				return false;
			}
		}

		break;
	default:
		return false;
		break;
	}

	return true;
}

NPError NS_PluginInitialize()
{
	memset(&g_NPClass, 0, sizeof(g_NPClass));
	g_NPClass.allocate = NPAllocateFunction;
	g_NPClass.deallocate = NPDeallocateFunction;
	g_NPClass.invalidate = NPInvalidateFunction;
	g_NPClass.invoke = NPInvokeFunction;
	g_NPClass.hasMethod = NPHasMethodFunction;
	g_NPClass.invokeDefault = NPInvokeDefaultFunction;
	g_NPClass.hasProperty = NPHasPropertyFunction;
	g_NPClass.getProperty = NPGetPropertyFunction;
	g_NPClass.setProperty = NPSetPropertyFunction;
	g_NPClass.removeProperty = NPRemovePropertyFunction;
	g_NPClass.structVersion = NP_CLASS_STRUCT_VERSION;

	return NPERR_NO_ERROR;
}

void NS_PluginShutdown()
{
	
}

NPObject* NPAllocateFunction(NPP npp, NPClass *aClass)
{
	ATLASSERT(npp != NULL);
	nsPluginInstanceBase *plugin = (nsPluginInstanceBase *)npp->pdata;
	ATLASSERT(plugin != NULL);
	ATLASSERT(aClass == &g_NPClass);
	CNPObjectImplBase *pNPObject = plugin->GetObject();
	if(pNPObject != NULL)
	{
		pNPObject->m_pPlugin = plugin;
	}
	return pNPObject;
}

void NPDeallocateFunction(NPObject *npobj)
{
	if(npobj != NULL)
	{
		CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
		p->OnDeallocate();
		delete p;
	}
}

void NPInvalidateFunction(NPObject *npobj)
{
	if(npobj != NULL)
	{
		CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
		p->OnInvalidate();
	}
}


bool NPHasMethodFunction(NPObject *npobj, NPIdentifier name)
{
	if(npobj == NULL)
		return false;
	if(NPNFuncs.identifierisstring == NULL)
		return false;
	CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
	bool bSuc = false;
	if(NPNFuncs.identifierisstring(name))
	{
		if(NPNFuncs.utf8fromidentifier == NULL)
			return false;
		NPUTF8* strName = NPNFuncs.utf8fromidentifier(name);
		int n;
		for(n=0; n<p->m_aMethodName.GetSize(); n++)
		{
			if(p->m_aMethodName[n] == strName)
			{
				bSuc = true;
				break;
			}
		}
		if(strName != NULL)
		{
			NPN_MemFree(strName);
		}
	}
	else
	{
		if(NPNFuncs.intfromidentifier == NULL)
			return false;
		int32_t nIndex = NPNFuncs.intfromidentifier(name);
		bSuc = p->HasMethod(nIndex);
	}
	return bSuc;
}

bool NPInvokeDefaultFunction(NPObject *npobj,
                                           const NPVariant *args,
                                           uint32_t argCount,
                                           NPVariant *result)
{
	if(npobj == NULL)
		return false;
	CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
	return p->InvokeDefault(args, argCount, result);
}

bool NPHasPropertyFunction(NPObject *npobj, NPIdentifier name)
{
	if(npobj == NULL)
		return false;
	if(NPNFuncs.identifierisstring == NULL)
		return false;
	CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
	bool bSuc = false;
	if(NPNFuncs.identifierisstring(name))
	{
		if(NPNFuncs.utf8fromidentifier == NULL)
			return false;
		NPUTF8* strName = NPNFuncs.utf8fromidentifier(name);
		int n;
		for(n=0; n<p->m_aPropertyName.GetSize(); n++)
		{
			if(p->m_aPropertyName[n] == strName)
			{
				bSuc = true;
				break;
			}
		}
		if(strName != NULL)
		{
			NPN_MemFree(strName);
		}
	}
	else
	{
		if(NPNFuncs.intfromidentifier == NULL)
			return false;
		int32_t nIndex = NPNFuncs.intfromidentifier(name);
		bSuc = p->HasProperty(nIndex);
	}
	return bSuc;
}

bool NPGetPropertyFunction(NPObject *npobj, NPIdentifier name,
                                         NPVariant *result)
{
	if(npobj == NULL)
		return false;
	if(NPNFuncs.identifierisstring == NULL)
		return false;
	CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
	bool bSuc = false;
	if(NPNFuncs.identifierisstring(name))
	{
		if(NPNFuncs.utf8fromidentifier == NULL)
			return false;
		NPUTF8* strName = NPNFuncs.utf8fromidentifier(name);
		int n;
		for(n=0; n<p->m_aPropertyName.GetSize(); n++)
		{
			if(p->m_aPropertyName[n] == strName)
			{
				bSuc = true;
				break;
			}
		}
		if(bSuc)
		{
			bSuc = p->GetProperty(strName, result);
		}
		if(strName != NULL)
		{
			NPN_MemFree(strName);
		}
	}
	return bSuc;
}

bool NPSetPropertyFunction(NPObject *npobj, NPIdentifier name, const NPVariant *value)
{
	if(npobj == NULL)
		return false;
	if(NPNFuncs.identifierisstring == NULL)
		return false;
	CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
	bool bSuc = false;
	if(NPNFuncs.identifierisstring(name))
	{
		if(NPNFuncs.utf8fromidentifier == NULL)
			return false;
		NPUTF8* strName = NPNFuncs.utf8fromidentifier(name);
		int n;
		for(n=0; n<p->m_aPropertyName.GetSize(); n++)
		{
			if(p->m_aPropertyName[n] == strName)
			{
				bSuc = true;
				break;
			}
		}
		if(bSuc)
		{
			bSuc = p->SetProperty(strName, value);
		}
		if(strName != NULL)
		{
			NPN_MemFree(strName);
		}
	}
	return bSuc;
}

bool NPRemovePropertyFunction(NPObject *npobj,
                                            NPIdentifier name)
{
	if(npobj == NULL)
		return false;
	if(NPNFuncs.identifierisstring == NULL)
		return false;
	CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
	bool bSuc = false;
	if(NPNFuncs.identifierisstring(name))
	{
		if(NPNFuncs.utf8fromidentifier == NULL)
			return false;
		NPUTF8* strName = NPNFuncs.utf8fromidentifier(name);
		bSuc = p->RemoveProperty(strName);
		if(strName != NULL)
		{
			NPN_MemFree(strName);
		}
	}
	return bSuc;
}

bool NPInvokeFunction (NPObject *npobj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result)
{
	if(npobj == NULL)
		return false;
	if(NPNFuncs.identifierisstring == NULL)
		return false;
	CNPObjectImplBase *p = (CNPObjectImplBase *)npobj;
	bool bSuc = false;
	if(NPNFuncs.identifierisstring(name))
	{
		if(NPNFuncs.utf8fromidentifier == NULL)
			return false;
		NPUTF8* strName = NPNFuncs.utf8fromidentifier(name);
		bSuc = true;
/*		int n;
		for(n=0; n<p->m_aMethodName.GetSize(); n++)
		{
			if(p->m_aMethodName[n] == strName)
			{
				bSuc = true;
				break;
			}
		}*/
		if(bSuc)
		{
			bSuc = p->Invoke(strName, args, argCount, result);
		}
		if(strName != NULL)
		{
			NPN_MemFree(strName);
		}
	}
	return bSuc;
}


CNPObjectImplBase::CNPObjectImplBase()
{
	referenceCount = 0;
	_class = &g_NPClass;
	m_pPlugin = NULL;
}

CNPObjectImplBase::~CNPObjectImplBase()
{

}

void CNPObjectImplBase::OnInvalidate()
{

}

void CNPObjectImplBase::OnDeallocate()
{

}

bool CNPObjectImplBase::GetProperty(const CComBSTR &bstrPropertyName, CComVariant &vtData)
{
	ATLASSERT(FALSE); //not implemented
	return false;
}

bool CNPObjectImplBase::SetProperty(const CComBSTR &strPropertyName, const CComVariant &vtData)
{
	ATLASSERT(FALSE); //not implemented
	return false;
}

bool CNPObjectImplBase::Invoke(const CComBSTR &bstrMethodName, const VARIANT *pvtArgs, uint32_t argCount, CComVariant &vtResult)
{
	ATLASSERT(FALSE); //not implemented
	return false;
}

bool CNPObjectImplBase::GetProperty(const NPUTF8 *strPropertyName, NPVariant *pvData)
{
	if(pvData == NULL)
		return true;
	CComBSTR bstrPropertyName(strPropertyName);
	CComVariant vtData;
	bool bSuc = GetProperty(bstrPropertyName, vtData);
	if(bSuc)
	{
		if(m_pPlugin == NULL)
		{
			ATLASSERT(FALSE);
			return false;
		}

		if(pvData->type == NPVariantType_String || pvData->type == NPVariantType_Object)
		{
			if(NPNFuncs.releasevariantvalue != NULL)
			{
				try
				{
					NPNFuncs.releasevariantvalue(pvData);
				}
				catch(...)
				{
				}
			}
		}
		
		if(vtData.vt == VT_UNKNOWN || vtData.vt == VT_DISPATCH)
		{
			IUnknown *pIUnknown = vtData.punkVal;
			if(vtData.vt == VT_DISPATCH)
			{
				pIUnknown = vtData.pdispVal;
			}
			CNPObjectImplBase *pNPObjectImplBase = m_pPlugin->GetObject(pIUnknown);
			if(pNPObjectImplBase != NULL)
			{
				pvData->value.objectValue = pNPObjectImplBase;
				pvData->type = NPVariantType_Object;
				pvData->value.objectValue->_class = &g_NPClass;
				pvData->value.objectValue->referenceCount = 1;
				pNPObjectImplBase->m_pPlugin = m_pPlugin;
				bSuc = true;
			}
			else
			{
				bSuc = false;
			}
		}
		else if(vtData.vt == VT_FILETIME || (vtData.vt & VT_ARRAY) == VT_ARRAY)
		{
			bSuc = ConvertComplexObject(vtData, pvData);
		}
		else
		{
			bSuc = Variant2NPVariant(vtData, pvData);
		}
	}
	return bSuc;
}

bool CNPObjectImplBase::SetProperty(const NPUTF8 *strPropertyName, const NPVariant *pvData)
{
	CComBSTR bstrPropertyName(strPropertyName);
	CComVariant vtData;
	if(pvData != NULL)
	{
		if(pvData->type == NPVariantType_Object)
		{
			CComObject<CCOMWebItem> *pIMozillaWebItem = NULL;
			HRESULT hr = CComObject<CCOMWebItem>::CreateInstance(&pIMozillaWebItem);
			pIMozillaWebItem->Attach(pvData->value.objectValue);
			pIMozillaWebItem->m_pInstance = m_pPlugin->m_pInstance;
			pIMozillaWebItem->IncreaseRef();
			pIMozillaWebItem->AddRef(); //IUnknown::AddRef
			vtData = pIMozillaWebItem;
			pIMozillaWebItem->m_bWnd = true;	
		}
		else
		{
			*pvData >> vtData;
		}
	}
	return SetProperty(bstrPropertyName, vtData);
}

bool CNPObjectImplBase::ToVariant(NPObject *pNPObject, VARIANT &vtOut)
{
	char *strGetTime = "getTime";
	NPIdentifier pID = NPNFuncs.getstringidentifier(strGetTime);
	bool bSuc = NPNFuncs.hasmethod(m_pPlugin->m_pInstance, pNPObject, pID);
	if(bSuc) //date
	{
		NPVariant	vNPResult;
		memset(&vNPResult, 0, sizeof(vNPResult));
		bSuc = NPNFuncs.invoke(m_pPlugin->m_pInstance, pNPObject, pID, NULL, 0, &vNPResult);
		if(!bSuc)
			return false;
		vtOut.vt = VT_FILETIME;
		double dTime = vNPResult.value.doubleValue;
		dTime *= 10000;
		dTime += 116444556000000000;
		__int64 myTime = (__int64)dTime;
		vtOut.llVal = myTime;
		return true;
	}
	
	char *strLength = "length";
	pID = NPNFuncs.getstringidentifier(strLength);
	char *strPush = "shift";
	NPIdentifier pIDShift = NPNFuncs.getstringidentifier(strPush);
	if(NPNFuncs.hasmethod(m_pPlugin->m_pInstance, pNPObject, pIDShift) &&
		NPNFuncs.hasproperty(m_pPlugin->m_pInstance, pNPObject, pID)) //array
	{
		unsigned int j;
		NPVariant	vNP;
		NPVariant	vNPResult;
		::memset(&vNP, 0, sizeof(vNP));
		bSuc = NPNFuncs.getproperty(m_pPlugin->m_pInstance, pNPObject, pID, &vNP);
		if(!bSuc)
			return false;
		unsigned int nCount = 0;
		if(vNP.type == NPVariantType_Int32)
		{
			nCount = vNP.value.intValue;
		}
		else if(vNP.type == NPVariantType_Double)
		{
			nCount = (unsigned int)vNP.value.doubleValue;
		}

		if(nCount == 0)
			return false;
		VARIANT *pvt;
		::SAFEARRAYBOUND sab[1] = {nCount, 0};
		vtOut.vt = (VT_ARRAY|VT_VARIANT);
		vtOut.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
		::SafeArrayAccessData(vtOut.parray, (void**)&pvt);
		for(j=0; j<nCount; j++)
		{
			pID = NPNFuncs.getintidentifier(j);
			memset(&vNPResult, 0, sizeof(vNPResult));
			NPNFuncs.getproperty(m_pPlugin->m_pInstance, pNPObject, pID, &vNPResult);
			if(vNPResult.type == NPVariantType_Object)
			{
				bSuc = ToVariant(vNPResult.value.objectValue, pvt[j]);
			}
			else
			{
				NPVariant2Variant(vNPResult, pvt + j);
			}
			NPNFuncs.releasevariantvalue(&vNPResult);
			if(!bSuc)
				break;
		}
		::SafeArrayUnaccessData(vtOut.parray);
		return bSuc;
	}

	return false;
}

bool CNPObjectImplBase::Invoke(const NPUTF8 *strMethodName, const NPVariant *args, uint32_t argCount, NPVariant *pvResult)
{
	bool bSuc = true;
	CComBSTR bstrMethodName(strMethodName);
	CComVariant *pvtData = NULL;
	CComVariant vtResult;
	if(args != NULL && argCount != 0)
	{
		pvtData = new CComVariant[argCount];
		uint32_t n;
		for(n=0; n<argCount; n++)
		{
			if(args[n].type == NPVariantType_Object)
			{
				bSuc = ToVariant(args[n].value.objectValue, pvtData[n]);
/*
				CComObject<CCOMWebItem> *pIMozillaWebItem = NULL;
				HRESULT hr = CComObject<CCOMWebItem>::CreateInstance(&pIMozillaWebItem);
				pIMozillaWebItem->Attach(args[n].value.objectValue);
				pIMozillaWebItem->m_pInstance = m_pPlugin->m_pInstance;
				pIMozillaWebItem->AddRef(); //IUnknown::AddRef	
				pvtData[n] = pIMozillaWebItem;
				pIMozillaWebItem->m_bWnd = true;*/
			}
			else
				args[n] >> pvtData[n];
		}
	}
	else
	{
		argCount = 0;
	}
	if(bSuc)
		bSuc = Invoke(bstrMethodName, pvtData, argCount, vtResult);
	if(bSuc && pvResult != NULL)
	{
		if(m_pPlugin == NULL)
		{
			ATLASSERT(FALSE);
			return false;
		}

		if(pvResult->type == NPVariantType_String || pvResult->type == NPVariantType_Object)
		{
			if(NPNFuncs.releasevariantvalue != NULL)
			{
				try
				{
					NPNFuncs.releasevariantvalue(pvResult);
				}
				catch(...)
				{
				}
			}
		}
		
		if(vtResult.vt == VT_UNKNOWN || vtResult.vt == VT_DISPATCH)
		{
			IUnknown *pIUnknown = vtResult.punkVal;
			if(vtResult.vt == VT_DISPATCH)
			{
				pIUnknown = vtResult.pdispVal;
			}
			CNPObjectImplBase *pNPObjectImplBase = m_pPlugin->GetObject(pIUnknown);
			if(pNPObjectImplBase != NULL)
			{
				pvResult->value.objectValue = pNPObjectImplBase;
				pvResult->type = NPVariantType_Object;
				pvResult->value.objectValue->_class = &g_NPClass;
				pvResult->value.objectValue->referenceCount = 1;
				pNPObjectImplBase->m_pPlugin = m_pPlugin;
				bSuc = true;
			}
			else
			{
				bSuc = false;
			}
		}
		else if(vtResult.vt == VT_FILETIME || (vtResult.vt & VT_ARRAY) == VT_ARRAY)
		{
			bSuc = ConvertComplexObject(vtResult, pvResult);
		}
		else
		{
			bSuc = Variant2NPVariant(vtResult, pvResult);
		}
	}
	if(pvtData != NULL)
	{
		delete []pvtData;
	}
	return bSuc;
}

bool CNPObjectImplBase::ConvertDate(VARIANT &vtData, NPVariant *pRtn)
{
	bool bSuc = false;
	double dtDate;
	NPString str;
	str.utf8characters = strGetDate;
	str.utf8length = strlen(strGetDate);
	bSuc = NPNFuncs.evaluate(m_pPlugin->m_pInstance, m_pPlugin->m_Window.m_pNPObject, &str, pRtn);
	dtDate = (double)vtData.llVal;		
	dtDate -= 116444556000000000;
	dtDate /= 10000;
	NPVariant	vNPResult;
	memset(&vNPResult, 0, sizeof(vNPResult));
	NPIdentifier pID = NPNFuncs.getstringidentifier("setTime");
	NPVariant NPArgs;
	NPArgs.type = NPVariantType_Double;
	NPArgs.value.doubleValue = dtDate;
	bSuc = NPNFuncs.invoke(m_pPlugin->m_pInstance, pRtn->value.objectValue, pID, &NPArgs, 1, &vNPResult);
	return bSuc;
}

bool CNPObjectImplBase::ConvertComplexObject(VARIANT &vtData, NPVariant *pRtn)
{
	bool bSuc = false;
	if(vtData.vt == VT_FILETIME)
	{
		return ConvertDate(vtData, pRtn);
	}
	else if(vtData.vt == (VT_ARRAY|VT_VARIANT))
	{
		VARIANT *pvt;
		unsigned long n;
		NPString str;
		unsigned long nLen = vtData.parray->rgsabound[0].cElements;
		str.utf8characters = strGetArray;
		str.utf8length = strlen(strGetArray);
		bSuc = NPNFuncs.evaluate(m_pPlugin->m_pInstance, m_pPlugin->m_Window.m_pNPObject, &str, pRtn);
		::SafeArrayAccessData(vtData.parray, (void**)&pvt);
		for(n=0; n<nLen; n++)
		{
			NPVariant NPArgs;
			memset(&NPArgs, 0, sizeof(NPArgs));
			NPVariant	vNPResult;
			memset(&vNPResult, 0, sizeof(vNPResult));
			if(pvt[n].vt == VT_FILETIME || pvt[n].vt == (VT_ARRAY|VT_VARIANT))
			{
				NPVariant vtNewArray;
				bSuc = ConvertComplexObject(pvt[n], &vtNewArray);
				NPArgs.type = NPVariantType_Object;
				NPArgs.value.objectValue = vtNewArray.value.objectValue;
			}
			else
			{
				bSuc = Variant2NPVariant(pvt[n], &NPArgs);
			}
			if(!bSuc)
				break;
			NPIdentifier pID = NPNFuncs.getstringidentifier("push");
			bSuc = NPNFuncs.invoke(m_pPlugin->m_pInstance, pRtn->value.objectValue, pID, &NPArgs, 1, &vNPResult);
		}
		::SafeArrayUnaccessData(vtData.parray);
		
	}
	return bSuc;
}

bool CNPObjectImplBase::HasProperty(int32_t nPropertyIndex)
{
	if(nPropertyIndex >= 0 && nPropertyIndex < m_aPropertyName.GetSize())
	{
		return true;
	}
	return false;
}

bool CNPObjectImplBase::HasMethod(int32_t nMethodIndex)
{
	if(nMethodIndex >= 0 && nMethodIndex < m_aMethodName.GetSize())
	{
		return true;
	}
	return false;
}

bool CNPObjectImplBase::RemoveProperty(const NPUTF8 *strPropertyName)
{
	int n;
	for(n=0; n<m_aPropertyName.GetSize(); n++)
	{
		if(m_aPropertyName[n] == strPropertyName)
		{
			return (m_aPropertyName.RemoveAt(n) ? true : false);
		}
	}
	return false;
}

nsPluginInstanceBase* CNPObjectImplBase::GetPlugin() const
{
	return m_pPlugin;
}


CWebItem::CWebItem(NPP pInstance)
{
	m_bJSObject = false;
	m_pNPObject = NULL;
	m_pInstance = pInstance;
}

CWebItem::~CWebItem()
{
	Release();	
}

void CWebItem::Set(const NPObject *pNPObject)
{
	ATLASSERT(pNPObject != NULL);
	m_pNPObject = (NPObject *)pNPObject;
	if(NPNFuncs.retainobject != NULL && m_pNPObject)
	{
		NPNFuncs.retainobject(m_pNPObject);
	}
}

CWebItem::CWebItem(const CWebItem &WebItem)
{
	Set(WebItem.m_pNPObject);
	m_pInstance = WebItem.m_pInstance;
	m_bJSObject = WebItem.m_bJSObject;
}

CWebItem::CWebItem(const NPObject &WebItem)
{
	Set(&WebItem);
	m_pInstance = NULL;
	m_bJSObject = false;
}

CWebItem& CWebItem::operator=(const NPObject &WebItem)
{
	Release();
	Set(&WebItem);
	m_pInstance = NULL;
	return *this;
}

CWebItem& CWebItem::operator=(const CWebItem &WebItem)
{
	Release();
	Set(WebItem.m_pNPObject);
	m_pInstance = WebItem.m_pInstance;
	return *this;
}

int CWebItem::DecreaseRef()
{
	if(m_pNPObject != NULL)
	{
		if(NPNFuncs.releaseobject != NULL)
		{
			NPNFuncs.releaseobject(m_pNPObject);
			return m_pNPObject->referenceCount;
		}
	}
	return 0;
}

int CWebItem::IncreaseRef()
{
	if(m_pNPObject != NULL)
	{
		if(NPNFuncs.releaseobject != NULL)
		{
			NPNFuncs.retainobject(m_pNPObject);
			return m_pNPObject->referenceCount;
		}
	}
	return 0;
}

void CWebItem::Release()
{
	if(m_pNPObject != NULL)
	{
		if(NPNFuncs.releaseobject != NULL)
		{
			NPNFuncs.releaseobject(m_pNPObject);
		}
		m_pNPObject = NULL;
	}
}

bool CWebItem::IsAttached()
{
	return (m_pNPObject != NULL);
}

NPUTF8* CWebItem::UTF8FromIdentifier(NPIdentifier identifier)
{
	NPUTF8 *strName = NULL;
	
	if(NPNFuncs.utf8fromidentifier != NULL)
	{
		return NPNFuncs.utf8fromidentifier(identifier);
	}

	return strName;
}

NPUTF8* CWebItem::GetMethodName(int32_t nMethodIndex)
{
	NPUTF8 *strName = NULL;
	
	if(NPNFuncs.getintidentifier != NULL && HasMethod(nMethodIndex))
	{
		NPIdentifier identifier = NPNFuncs.getintidentifier(nMethodIndex);
		return UTF8FromIdentifier(identifier);
	}
	return strName;
}

NPUTF8* CWebItem::GetPropertyName(int32_t nPropertyIndex)
{
	NPUTF8 *strName = NULL;
	if(NPNFuncs.getintidentifier != NULL && HasProperty(nPropertyIndex))
	{
		NPIdentifier identifier = NPNFuncs.getintidentifier(nPropertyIndex);
		return UTF8FromIdentifier(identifier);
	}
	return strName;
}

bool CWebItem::HasProperty(const NPUTF8 *strPropertyName)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting m_pInstance
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.hasproperty != NULL && NPNFuncs.getstringidentifier != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strPropertyName);
		if(pID != NULL)
		{
			bSuc = NPNFuncs.hasproperty(m_pInstance, m_pNPObject, pID);
		}
	}
	return bSuc;
}

bool CWebItem::HasMethod(const NPUTF8 *strMethodName)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.hasmethod != NULL && NPNFuncs.getstringidentifier != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strMethodName);
		if(pID != NULL)
		{
			bSuc = NPNFuncs.hasmethod(m_pInstance, m_pNPObject, pID);
		}
	}
	return bSuc;
}

bool CWebItem::GetProperty(const NPUTF8 *strPropertyName, CWebItem &WebItem)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	WebItem.Release();
	if(IsAttached() && NPNFuncs.getstringidentifier != NULL && NPNFuncs.getproperty != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strPropertyName);
		if(pID != NULL)
		{
			NPVariant	vNP;
			::memset(&vNP, 0, sizeof(vNP));
			bSuc = NPNFuncs.getproperty(m_pInstance, m_pNPObject, pID, &vNP);
			if(bSuc)
			{
				WebItem.Attach(vNP.value.objectValue);
				WebItem.m_pInstance = m_pInstance;
			}
		}
	}
	return bSuc;
}

bool CWebItem::GetProperty(const NPUTF8 *strPropertyName, VARIANT &vtProperty)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	try
	{
		::VariantClear(&vtProperty);
	}
	catch(...)
	{
	}
	if(IsAttached() && NPNFuncs.getstringidentifier != NULL && NPNFuncs.getproperty != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strPropertyName);
		if(pID != NULL)
		{
			NPVariant	vNP;
			::memset(&vNP, 0, sizeof(vNP));
			bSuc = NPNFuncs.getproperty(m_pInstance, m_pNPObject, pID, &vNP);
			if(bSuc)
			{
				ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
				NPVariant2Variant(vNP, &vtProperty);
				NPNFuncs.releasevariantvalue(&vNP);
			}
		}
	}
	return bSuc;
}

bool CWebItem::SetProperty(const NPUTF8 *strPropertyName, const VARIANT &vtData)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.getstringidentifier != NULL && NPNFuncs.setproperty != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strPropertyName);
		if(pID != NULL)
		{
			NPVariant	vNP;
			::memset(&vNP, 0, sizeof(vNP));
			if(!Variant2NPVariant(vtData, &vNP))
				return false;
			bSuc = NPNFuncs.setproperty(m_pInstance, m_pNPObject, pID, &vNP);
			ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
			NPNFuncs.releasevariantvalue(&vNP);
		}
	}
	return bSuc;
}

bool CWebItem::Invoke(const NPUTF8 *strMethodName, const VARIANT *pArgs, ULONG ulArgCount, CWebItem &WebItem)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	WebItem.Release();
	if(IsAttached() && NPNFuncs.getstringidentifier != NULL && NPNFuncs.invoke != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strMethodName);
		if(pID != NULL)
		{
			ULONG ul;
			NPVariant *pNPArgs = NULL;
			if(pArgs != NULL && ulArgCount != 0)
			{
				pNPArgs = new NPVariant [ulArgCount];
				::memset(pNPArgs, 0, sizeof(NPVariant)*ulArgCount);
				
				for(ul=0; ul<ulArgCount; ul++)
				{
					Variant2NPVariant(pArgs[ul], pNPArgs + ul);
				}
			}
			else
			{
				ulArgCount = 0;
			}
			
			NPVariant	vNPResult;
			memset(&vNPResult, 0, sizeof(vNPResult));

			bSuc = NPNFuncs.invoke(m_pInstance, m_pNPObject, pID, pNPArgs, ulArgCount, &vNPResult);
			if(bSuc && vNPResult.type == NPVariantType_Object)
			{
				WebItem.Attach(vNPResult.value.objectValue);
				WebItem.m_pInstance = m_pInstance;
			}
			else
			{
				ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
				NPNFuncs.releasevariantvalue(&vNPResult);
				bSuc = false;
			}
			
			if(pNPArgs != NULL)
			{
				ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
				for(ul=0; ul<ulArgCount; ul++)
				{
					NPNFuncs.releasevariantvalue(pNPArgs + ul);
				}
				delete []pNPArgs;
			}
		}
	}
	return bSuc;
}

void CWebItem::SetException(const NPUTF8 *strExceptionMessage)
{
	ATLASSERT(IsAttached());
	if(NPNFuncs.setexception != NULL)
	{
		NPNFuncs.setexception(m_pNPObject, strExceptionMessage);
	}
}

bool CWebItem::Invoke(const NPUTF8 *strMethodName, const VARIANT *pArgs, ULONG ulArgCount, VARIANT &vtResult)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	try
	{
		::VariantClear(&vtResult);
	}
	catch(...)
	{
	}
	if(IsAttached() && NPNFuncs.getstringidentifier != NULL && NPNFuncs.invoke != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strMethodName);
		if(pID != NULL)
		{
			ULONG ul;
			NPVariant *pNPArgs = NULL;
			if(pArgs != NULL && ulArgCount != 0)
			{
				pNPArgs = new NPVariant [ulArgCount];
				::memset(pNPArgs, 0, sizeof(NPVariant)*ulArgCount);
				
				for(ul=0; ul<ulArgCount; ul++)
				{
					Variant2NPVariant(pArgs[ul], pNPArgs + ul);
				}
			}
			else
			{
				ulArgCount = 0;
			}
			
			NPVariant	vNPResult;
			memset(&vNPResult, 0, sizeof(vNPResult));

			bSuc = NPNFuncs.invoke(m_pInstance, m_pNPObject, pID, pNPArgs, ulArgCount, &vNPResult);
			if(bSuc)
			{
				ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
				NPVariant2Variant(vNPResult, &vtResult);
				NPNFuncs.releasevariantvalue(&vNPResult);
			}
			
			if(pNPArgs != NULL)
			{
				ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
				for(ul=0; ul<ulArgCount; ul++)
				{
					NPNFuncs.releasevariantvalue(pNPArgs + ul);
				}
				delete []pNPArgs;
			}
		}
	}
	return bSuc;
}

bool CWebItem::Invoke(const NPUTF8 *strMethodName, const NPVariant *pArgs, ULONG ulArgCount, VARIANT &vtResult)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	try
	{
		::VariantClear(&vtResult);
	}
	catch(...)
	{
	}
	if(IsAttached() && NPNFuncs.invoke != NULL && NPNFuncs.getstringidentifier != NULL)
	{
		NPVariant	vNPResult;
		memset(&vNPResult, 0, sizeof(vNPResult));
		NPIdentifier methodName = NPNFuncs.getstringidentifier(strMethodName);
		bSuc = NPNFuncs.invoke(m_pInstance, m_pNPObject, methodName, pArgs, ulArgCount, &vNPResult);
		if(bSuc)
		{
			ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
			NPVariant2Variant(vNPResult, &vtResult);
			NPNFuncs.releasevariantvalue(&vNPResult);
		}
	}
	return bSuc;
}

bool CWebItem::Invoke(const NPUTF8 *strMethodName, const NPVariant *pArgs, ULONG ulArgCount, CWebItem &WebItem)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	WebItem.Release();
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.invoke != NULL && NPNFuncs.getstringidentifier != NULL)
	{
		NPVariant	vNPResult;
		memset(&vNPResult, 0, sizeof(vNPResult));
		NPIdentifier methodName = NPNFuncs.getstringidentifier(strMethodName);
		bSuc = NPNFuncs.invoke(m_pInstance, m_pNPObject, methodName, pArgs, ulArgCount, &vNPResult);
		if(bSuc && vNPResult.type == NPVariantType_Object)
		{
			WebItem.Attach(vNPResult.value.objectValue);
			WebItem.m_pInstance = m_pInstance;
		}
		bSuc = WebItem.IsAttached();
	}
	return bSuc;
}

bool CWebItem::InvokeDefault(const NPVariant *pArgs, ULONG ulArgCount, VARIANT &vtResult)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	try
	{
		::VariantClear(&vtResult);
	}
	catch(...)
	{
	}
	if(IsAttached() && NPNFuncs.invokeDefault != NULL)
	{
		NPVariant	vNPResult;
		memset(&vNPResult, 0, sizeof(vNPResult));
		bSuc = NPNFuncs.invokeDefault(m_pInstance, m_pNPObject, pArgs, ulArgCount, &vNPResult);
		if(bSuc)
		{
			ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
			NPVariant2Variant(vNPResult, &vtResult);
			NPNFuncs.releasevariantvalue(&vNPResult);
		}
	}
	return bSuc;
}

bool CWebItem::InvokeDefault(const NPVariant *pArgs, ULONG ulArgCount, CWebItem &WebItem)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	WebItem.Release();
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.invokeDefault != NULL)
	{
		NPVariant	vNPResult;
		memset(&vNPResult, 0, sizeof(vNPResult));
		bSuc = NPNFuncs.invokeDefault(m_pInstance, m_pNPObject, pArgs, ulArgCount, &vNPResult);
		if(bSuc && vNPResult.type == NPVariantType_Object)
		{
			WebItem.Attach(vNPResult.value.objectValue);
			WebItem.m_pInstance = m_pInstance;
		}
		bSuc = WebItem.IsAttached();
	}
	return bSuc;
}

bool CWebItem::InvokeDefault(const VARIANT *pArgs, ULONG ulArgCount, VARIANT &vtResult)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	try
	{
		::VariantClear(&vtResult);
	}
	catch(...)
	{
	}
	if(IsAttached() && NPNFuncs.invokeDefault != NULL)
	{
		ULONG ul;
		NPVariant *pNPArgs = NULL;
		if(pArgs != NULL && ulArgCount != 0)
		{
			pNPArgs = new NPVariant [ulArgCount];
			::memset(pNPArgs, 0, sizeof(NPVariant)*ulArgCount);
			
			for(ul=0; ul<ulArgCount; ul++)
			{
				Variant2NPVariant(pArgs[ul], pNPArgs + ul);
			}
		}
		else
		{
			ulArgCount = 0;
		}
		
		NPVariant	vNPResult;
		memset(&vNPResult, 0, sizeof(vNPResult));

		bSuc = NPNFuncs.invokeDefault(m_pInstance, m_pNPObject, pNPArgs, ulArgCount, &vNPResult);
		if(bSuc)
		{
			ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
			NPVariant2Variant(vNPResult, &vtResult);
			NPNFuncs.releasevariantvalue(&vNPResult);
		}
		
		if(pNPArgs != NULL)
		{
			ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
			for(ul=0; ul<ulArgCount; ul++)
			{
				NPNFuncs.releasevariantvalue(pNPArgs + ul);
			}
			delete []pNPArgs;
		}
	}
	return bSuc;
}

bool CWebItem::GetProperty(int nIndex, VARIANT &vtProperty)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	try
	{
		::VariantClear(&vtProperty);
	}
	catch(...)
	{
	}
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.getproperty != NULL && NPNFuncs.getintidentifier != NULL)
	{
		NPIdentifier pID = NPNFuncs.getintidentifier(nIndex);
		if(pID != NULL)
		{
			NPVariant	vNP;
			::memset(&vNP, 0, sizeof(vNP));
			bSuc = NPNFuncs.getproperty(m_pInstance, m_pNPObject, pID, &vNP);
			if(bSuc)
			{
				ATLASSERT(NPNFuncs.releasevariantvalue != NULL);
				if(vNP.type == NPVariantType_Object)
				{
					CComObject<CCOMWebItem> *pIMozillaWebItem = NULL;
					HRESULT hr = CComObject<CCOMWebItem>::CreateInstance(&pIMozillaWebItem);
					pIMozillaWebItem->Attach(vNP.value.objectValue);
					pIMozillaWebItem->m_pInstance = m_pInstance;
					pIMozillaWebItem->AddRef(); //IUnknown::AddRef
					pIMozillaWebItem->AddRef(); //IUnknown::AddRef
					vtProperty.vt = VT_UNKNOWN;
					vtProperty.punkVal = pIMozillaWebItem;
					pIMozillaWebItem->m_bWnd = true;
				}
				else
				{
					NPVariant2Variant(vNP, &vtProperty);
				}
				NPNFuncs.releasevariantvalue(&vNP);
			}
		}
	}
	return bSuc;
}

bool CWebItem::HasProperty(int32_t nPropertyIndex)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.hasproperty != NULL && NPNFuncs.getintidentifier != NULL)
	{
		NPIdentifier pID = NPNFuncs.getintidentifier(nPropertyIndex);
		if(pID != NULL)
		{
			bSuc = NPNFuncs.hasproperty(m_pInstance, m_pNPObject, pID);
		}
	}
	return bSuc;
}

bool CWebItem::HasMethod(int32_t nMethodIndex)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.hasmethod != NULL && NPNFuncs.getintidentifier != NULL)
	{
		NPIdentifier pID = NPNFuncs.getintidentifier(nMethodIndex);
		if(pID != NULL)
		{
			bSuc = NPNFuncs.hasmethod(m_pInstance, m_pNPObject, pID);
		}
	}
	return bSuc;
}

bool CWebItem::RemoveProperty(const NPUTF8 *strPropertyName)
{
	ATLASSERT(m_pInstance != NULL); //don't forget setting NPP instance!!!
	bool bSuc = false;
	if(IsAttached() && NPNFuncs.getstringidentifier != NULL && NPNFuncs.removeproperty != NULL)
	{
		NPIdentifier pID = NPNFuncs.getstringidentifier(strPropertyName);
		if(pID != NULL)
		{
			bSuc = NPNFuncs.removeproperty(m_pInstance, m_pNPObject, pID);
		}
	}
	return bSuc;
}

void CWebItem::Attach(NPObject *pNPObject)
{
	Release();
	if(pNPObject != NULL)
	{
		m_pNPObject = pNPObject;
	}
	m_pInstance = NULL;
}

NPObject *CWebItem::Detach()
{
	NPObject *p = m_pNPObject;
	m_pNPObject = NULL;
	m_pInstance = NULL;
	return p;
}

bool CWebItem::GetBrowserWindow(CWebItem &Browser)
{
	ATLASSERT(Browser.m_pInstance != NULL); //don't forget setting NPP instance!!!
	NPP pInstance = Browser.m_pInstance;
	Browser.Release();
	NPObject *pBrowser = NULL;
	NPError err = NPN_GetValue(pInstance, NPNVWindowNPObject, &pBrowser);
	if(err != NPERR_NO_ERROR || pBrowser == NULL)
		return false;
	Browser.Attach(pBrowser);
	Browser.m_pInstance = pInstance;
	return true;
}

nsPluginInstanceBase* CWebItem::GetPlugin() const
{
	if(m_pInstance == NULL)
		return NULL;
	return (nsPluginInstanceBase *)m_pInstance->pdata;
}

bool CWebItem::GetPlugin(CWebItem &Plugin)
{
	ATLASSERT(Plugin.m_pInstance != NULL); //don't forget setting NPP instance!!!
	NPP pInstance = Plugin.m_pInstance;
	Plugin.Release();
	NPObject *pPlugin = NULL;
	NPError err = NPN_GetValue(pInstance, NPNVPluginElementNPObject, &pPlugin);
	if(err != NPERR_NO_ERROR || pPlugin == NULL)
		return false;
	Plugin.Attach(pPlugin);
	Plugin.m_pInstance = pInstance;
	return true;
}

VARIANT& operator<<(VARIANT &vtOut, const NPVariant& vnpIn)
{
	NPVariant2Variant(vnpIn, &vtOut);
	return vtOut;
}

NPVariant& operator<<(NPVariant &vnpOut, const VARIANT& vtIn)
{
	Variant2NPVariant(vtIn, &vnpOut);
	return vnpOut;
}

VARIANT& operator>>(const NPVariant& vnpIn, VARIANT &vtOut)
{
	NPVariant2Variant(vnpIn, &vtOut);
	return vtOut;
}

NPVariant& operator>>(const VARIANT& vtIn, NPVariant &vnpOut)
{
	Variant2NPVariant(vtIn, &vnpOut);
	return vnpOut;
}

NPVariant& operator<<(NPVariant &vnpOut, const BSTR bstrIn)
{
	BSTR2NPVariant(bstrIn, &vnpOut);
	return vnpOut;
}

NPVariant& operator>>(const BSTR bstrIn, NPVariant &vnpOut)
{
	BSTR2NPVariant(bstrIn, &vnpOut);
	return vnpOut;
}

NPVariant& operator<<(NPVariant &vnpOut, long lIn)
{
	CComVariant vtLong(lIn);
	vtLong >> vnpOut;
	return vnpOut;
}

NPVariant& operator>>(long lIn, NPVariant &vnpOut)
{
	CComVariant vtLong(lIn);
	vtLong >> vnpOut;
	return vnpOut;
}

#endif
