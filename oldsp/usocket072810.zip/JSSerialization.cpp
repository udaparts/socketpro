// JSSerialization.cpp : Implementation of CJSSerialization
#include "stdafx.h"
#include "USocket.h"
#include "JSSerialization.h"
#include <time.h>
#include <math.h>
#include <MsHTML.h>

char *strGetDateIE = "function GetDate(){return new Date();}";
extern char *strGetArray;


const CLSID CLSID_JSSerialization = {0x02A1A27E,0x417C,0x4186,{0x95,0x5B,0x1C,0xE6,0xFB,0x28,0xDE,0x2C}};

/////////////////////////////////////////////////////////////////////////////
// CJSSerialization

HRESULT CJSSerialization::FinalConstruct()
{
	return S_OK;
}

void CJSSerialization::FinalRelease()
{
	m_UQueue.Empty();
}

void CJSSerialization::SetMaps(IDispatch *pIDispatch)
{
	m_mapFunc.RemoveAll();
	if(pIDispatch != NULL)
	{
		UINT n;
		USES_CONVERSION;
		UINT nCount = 0;
		CComBSTR bstrName;
		CComPtr<ITypeInfo> pITypeInfo;
		pIDispatch->GetTypeInfoCount(&nCount);
		for(n=0; n<nCount; n++)
		{
			pIDispatch->GetTypeInfo(n, LOCALE_SYSTEM_DEFAULT, &pITypeInfo);
			if(pITypeInfo.p == NULL)
				continue;

			TYPEATTR *pTypeAttr = NULL;
			pITypeInfo->GetTypeAttr(&pTypeAttr);
			if(pTypeAttr == NULL)
				continue;

			WORD w; 

			//QueryInterface, AddRef, Release, GetTypeInfoCount, GetTypeInfo, GetIDsOfNames and Invoke ignored
			for(w=0; w<pTypeAttr->cFuncs; w++)
			{
				FUNCDESC *pFuncDesc = NULL;
				pITypeInfo->GetFuncDesc(w, &pFuncDesc);

				if(pFuncDesc == NULL)
					continue;
				unsigned int nNames;
				bstrName.Empty();
				pITypeInfo->GetNames(pFuncDesc->memid, &bstrName, 1, &nNames);
				
				ATLTRACE("Method == %s\n", OLE2A(bstrName));
				switch(pFuncDesc->invkind)
				{
				case INVOKE_FUNC:
//					m_aMethodName.Add(bstrName);
					m_mapFunc.Add(bstrName, *pFuncDesc);
					break;
				case INVOKE_PROPERTYGET:
					if(pFuncDesc->cParams == 0)
					{
	//					m_aPropertyName.Add(bstrName);
	//					m_mapPropertyGet.Add(bstrName, *pFuncDesc);
					}
					else //for STDMETHODIMP CAcnts::get_Item(long lIndex, VARIANT *pvtValue)
					{
	//					m_aMethodName.Add(bstrName);
	//					m_mapFunc.Add(bstrName, *pFuncDesc);
					}
					break;
				case INVOKE_PROPERTYPUT:
					if(pFuncDesc->cParams == 1)
					{
	//					m_aPropertyNamePut.Add(bstrName);
	//					m_mapPropertyPut.Add(bstrName, *pFuncDesc);
	//					if(m_mapPropertyGet.FindKey(bstrName) == -1)
	//					{
	//						m_aPropertyName.Add(bstrName);
	//						m_mapPropertyGet.Add(bstrName, *pFuncDesc);
	//					}
					}
					else if(pFuncDesc->cParams == 2)//for STDMETHODIMP CAcnts::put_Item(long lIndex, VARIANT vtValue)
					{
	//					m_aMethodName.Add(bstrName);
	//					m_mapFunc.Add(bstrName, *pFuncDesc);
					}
					else
					{
					}
					break;
				case INVOKE_PROPERTYPUTREF:
					//not supported with NPObject
					ATLASSERT(FALSE);
					break;
				default:
					break;
				}
				if(pFuncDesc != NULL)
				{
					pITypeInfo->ReleaseFuncDesc(pFuncDesc);
				}
			}
			pITypeInfo->ReleaseTypeAttr(pTypeAttr);
			pITypeInfo.Release();
		}
	}
}

STDMETHODIMP CJSSerialization::save(VARIANT vtData)
{
	m_hr = S_OK;
/*
	if(vtData.vt == VT_UNKNOWN)
	{
		CComQIPtr<IMozillaWebItem> pIMozillaWebItem(vtData.punkVal);
		CComBSTR bstr("getTime");
		VARIANT_BOOL b = 0;
		pIMozillaWebItem->HasMethod(bstr, &b);
		if(b)
		{
			short type = VT_FILETIME;
			m_UQueue << type;
			return saveDate(vtData);
		}

		b = 0;
		bstr = L"length";
		pIMozillaWebItem->HasProperty(bstr, &b);
		VARIANT_BOOL bPush = 0;
		CComBSTR bstrPush(L"push");
		pIMozillaWebItem->HasMethod(bstrPush, &bPush);
		VARIANT_BOOL bShift = 0;
		CComBSTR bstrShift(L"shift");
		pIMozillaWebItem->HasMethod(bstrShift, &bShift);
		if(b && bShift && bPush)
		{
			HRESULT hr;
			int n;
			short vt = (VT_ARRAY | VT_VARIANT);
			m_UQueue << vt;
			pIMozillaWebItem->GetProperty(bstr, &vtData);
			int nLen = vtData.lVal;
			m_UQueue << nLen;
			CComVariant vtData;
			for(n=0; n<nLen; n++)
			{
				hr = pIMozillaWebItem->GetPropertyByIndex(n, &vtData);
				if(vtData.vt == VT_UNKNOWN)
				{
					m_hr = uecNotImplemented;
					return m_hr;
				}
				if(save(vtData) != S_OK)
					return m_hr;
				vtData.Clear();
			}
			
			short vt;
			CComVariant vtParameters;
			vt = (VT_ARRAY | VT_VARIANT);
			m_UQueue << vt;
			CComVariant vtNull;
			CComVariant vtData;
			pIMozillaWebItem->GetProperty(bstr, &vtData);
			int nLen = vtData.lVal;
			m_UQueue << nLen;
			while(nLen > 0)
			{
				vtData.Clear();
				hr = pIMozillaWebItem->Invoke(bstrShift, vtNull, &vtData);
				if(save(vtData) != S_OK)
				{
					m_hr = uecNotImplemented;
					return m_hr;
				}
				VARIANT *pvt = NULL;
				SAFEARRAYBOUND sab[1] = {1, 0};
				vtParameters.vt = (VT_ARRAY|VT_VARIANT);
				vtParameters.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
				::SafeArrayAccessData(vtParameters.parray, (void**)&pvt);
				vtData.Detach(pvt);
				::SafeArrayUnaccessData(vtParameters.parray);
				hr = pIMozillaWebItem->Invoke(bstrPush, vtParameters, &vtNull);
				vtParameters.Clear();
				vtNull.Clear();
				--nLen;
			}
			return m_hr;
		}
		m_hr = uecNotImplemented;
		return m_hr;
	}*/

	if(vtData.vt == VT_DISPATCH)
	{
		short vt;
		UINT nError = 0;
		CComVariant vtResult;
		DISPPARAMS disp;
		DISPID   dispid = 0;
		LPOLESTR strName = L"getTime";
		CComQIPtr<IDispatch> pIDispatch(vtData.pdispVal);
		m_hr = pIDispatch->GetIDsOfNames(IID_NULL, &strName, 1, LOCALE_SYSTEM_DEFAULT, &dispid);
		if(m_hr == S_OK)
		{
			vt = VT_FILETIME;
			m_UQueue << vt;
			return saveDate(vtData);
		}
		dispid = 0;
		DISPID idPush = 0;
		DISPID idShift = 0;
		strName = L"length";
		m_hr = pIDispatch->GetIDsOfNames(IID_NULL, &strName, 1, LOCALE_SYSTEM_DEFAULT, &dispid);
		strName = L"push";
		m_hr = pIDispatch->GetIDsOfNames(IID_NULL, &strName, 1, LOCALE_SYSTEM_DEFAULT, &idPush);
		strName = L"shift";
		m_hr = pIDispatch->GetIDsOfNames(IID_NULL, &strName, 1, LOCALE_SYSTEM_DEFAULT, &idShift);
		if(dispid && idPush && idShift)
		{
			CComVariant vtRtn;
			int nLen;
			vt = (VT_ARRAY | VT_VARIANT);
			m_UQueue << vt;
			vtResult.Clear();
			disp.cArgs = 0;
			disp.rgvarg = NULL;
			disp.rgdispidNamedArgs = NULL;
			disp.cNamedArgs = 0;
			m_hr = pIDispatch->Invoke(dispid, IID_NULL, LOCALE_USER_DEFAULT, INVOKE_PROPERTYGET, &disp, &vtResult, NULL, &nError);
			nLen = vtResult.lVal;
			m_UQueue << nLen;
			while(nLen > 0)
			{
				vtResult.Clear();
				//shift
				m_hr = pIDispatch->Invoke(idShift, IID_NULL, LOCALE_USER_DEFAULT, INVOKE_FUNC, &disp, &vtResult, NULL, &nError);
/*				if(vtResult.vt == VT_DISPATCH)
				{
					m_hr = uecNotImplemented;
					return m_hr;
				}*/
				if(save(vtResult) != S_OK)
					return m_hr;

				disp.cArgs = 1;
				disp.rgvarg = &vtResult;
				//push
				m_hr = pIDispatch->Invoke(idPush, IID_NULL, LOCALE_USER_DEFAULT, INVOKE_FUNC, &disp, &vtRtn, NULL, &nError);
				--nLen;
			}
			return m_hr;
		}
		m_hr = uecNotImplemented;
		return m_hr;
	}
	m_UQueue.PushVT(vtData);
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveGuid(BSTR bstrGuid)
{
	GUID guid = {0};
	m_hr = CLSIDFromString(bstrGuid, &guid);
	m_UQueue << guid;
	return m_hr;
}

STDMETHODIMP CJSSerialization::saveBool(VARIANT_BOOL bData)
{
	bool b = (bData != 0);
	m_UQueue << b;
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveByte(BYTE bData)
{
	m_UQueue.Push(&bData, 1);
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveInt16(short sData)
{

	m_UQueue << sData;
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveInt32(long nData)
{

	m_UQueue << nData;
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveFloat(float fData)
{
	
	m_UQueue << fData;
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveDouble(double dData)
{
	m_UQueue << dData;
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveString(BSTR bstrData)
{
	m_UQueue << (LPCWSTR)bstrData;
	return S_OK;
}

STDMETHODIMP CJSSerialization::load(VARIANT *pvtData)
{
	m_hr = S_OK;
	CComVariant vtData;
	if(pvtData != NULL)
	{
		CComVariant vtTemp;
		if(m_UQueue.GetSize() < 2)
		{
			m_hr = uecBadData;
			return m_hr;
		}
		m_UQueue.PopVT(vtTemp);
		
		if(m_spBrowser != NULL)
		{
			m_hr = ConvertVariant(vtTemp, vtData);
			if(!FAILED(m_hr) && !LoadWeb(vtData, *pvtData))
			{
				m_hr = uecBadData;
			}
		}
		else
		{
			m_hr = ConvertVariant(vtTemp, *pvtData);
		}
	}
	else
	{
		m_UQueue.PopVT(vtData);
	}
	return S_OK;
}

STDMETHODIMP CJSSerialization::loadBool(VARIANT_BOOL *pbData)
{
	m_hr = S_OK;
	if(pbData)
	{
		if(m_UQueue.GetSize() < 1)
		{
			m_hr = uecBadData;
			return m_hr;
		}
		bool bData;
		m_UQueue.Pop(&bData, sizeof(bData));
		*pbData = bData ? VARIANT_TRUE : VARIANT_FALSE;
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(bool));
	}
	return S_OK;
}

STDMETHODIMP CJSSerialization::loadByte(BYTE *pbData)
{
	m_hr = S_OK;
	if(pbData)
	{
		if(m_UQueue.GetSize() < 1)
		{
			m_hr = uecBadData;
			return m_hr;
		}
		m_UQueue.Pop(pbData, sizeof(BYTE));
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(BYTE));
	}
	return S_OK;
}

STDMETHODIMP CJSSerialization::loadInt16(short *psData)
{
	m_hr = S_OK;
	if(psData)
	{
		if(m_UQueue.GetSize() < sizeof(short))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		m_UQueue.Pop((BYTE*)psData, sizeof(short));
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(short));
	}
	return S_OK;
}

STDMETHODIMP CJSSerialization::loadInt32(long *pnData)
{
	m_hr = S_OK;
	if(pnData)
	{
		if(m_UQueue.GetSize() < sizeof(int))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		m_UQueue.Pop((BYTE*)pnData, sizeof(long));
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(long));
	}

	return S_OK;
}

STDMETHODIMP CJSSerialization::loadFloat(float *pfData)
{
	m_hr = S_OK;
	if(pfData)
	{
		if(m_UQueue.GetSize() < sizeof(float))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		m_UQueue.Pop((BYTE*)pfData, sizeof(float));
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(float));
	}
	return S_OK;
}

STDMETHODIMP CJSSerialization::loadDouble(double *pdData)
{
	m_hr = S_OK;
	if(pdData)
	{
		if(m_UQueue.GetSize() < sizeof(double))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		m_UQueue.Pop((BYTE*)pdData, sizeof(double));
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(double));
	}

	return S_OK;
}

STDMETHODIMP CJSSerialization::loadString(BSTR *pbstrData)
{
	m_hr = S_OK;
	if(pbstrData != NULL)
	{
		if(m_UQueue.GetSize() < sizeof(int))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		unsigned long len;
		m_UQueue >> len;
		if(len == (~0))
			*pbstrData = NULL;
		else
		{
			if(m_UQueue.GetSize() < len)
			{
				m_hr = uecBadData;
				return m_hr;
			}
			*pbstrData = ::SysAllocStringLen((LPOLESTR)m_UQueue.GetBuffer(), len/sizeof(WCHAR));
			if(len)
				m_UQueue.Pop(len);
		}
	}

	return S_OK;
}

STDMETHODIMP CJSSerialization::loadGuid(BSTR *pbstrGuid)
{
	m_hr = S_OK;
	if(pbstrGuid != NULL)
	{
		if(m_UQueue.GetSize() < sizeof(GUID))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		WCHAR *str = NULL;
		GUID guid = {0};
		m_UQueue >> guid;
		StringFromCLSID(guid, &str);
		*pbstrGuid = ::SysAllocString(str);
		if(str != NULL)
			CoTaskMemFree(str);
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(GUID));
	}

	return S_OK;
}

STDMETHODIMP CJSSerialization::get_size(long *pVal)
{
	if(pVal != NULL)
		*pVal = m_UQueue.GetSize();
	return S_OK;
}

STDMETHODIMP CJSSerialization::put_size(long newVal)
{
	m_UQueue.SetHeadPosition();
	if((unsigned long)newVal > m_UQueue.GetMaxSize())
	{
		m_UQueue.ReallocBuffer((unsigned long)newVal + m_UQueue.GetBlockSize());
	}
	m_UQueue.SetSize((unsigned long)newVal);
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveDecimal(double dDecimal)
{
	DECIMAL dec = {0};
	BYTE bScale = 0;
	int nDiff;
	char str[128] = {0};
	::sprintf(str, "%.15f", dDecimal);
	int len = ::strlen(str);
	while(str[len - 1] == '0')
	{
		--len;
		str[len] = 0;
	}
	if(dDecimal < 0)
		dec.sign = 1;
	char *pos = strchr(str, '.');
	if(pos != NULL)
	{
		nDiff = pos - str;
	}
	dec.scale = (BYTE)(len - nDiff - 1);
	double d = ::pow((double)10, dec.scale);
	if(dDecimal >= 0)
	{
		dDecimal *= d;
	}
	else
	{
		dDecimal *= (d * (-1));
	}
	dDecimal += 0.1;
	__int64 llData = (__int64)dDecimal;
	dec.Lo64 = (unsigned __int64)llData;
	m_UQueue << dec;
	return S_OK;
}

STDMETHODIMP CJSSerialization::loadDecimal(double *pdDecimal)
{
	m_hr = S_OK;
	if(pdDecimal != NULL)
	{
		if(m_UQueue.GetSize() < sizeof(DECIMAL))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		DECIMAL dec;
		m_UQueue >> dec;
		__int64 llData = (__int64)dec.Lo64;
		*pdDecimal = (double)llData;
		double d = ::pow((double)10, dec.scale);
		*pdDecimal /=d;
		if(dec.sign > 0 && *pdDecimal > 0)
			*pdDecimal *= (-1);
	}
	else
	{
		m_UQueue.Pop((unsigned long)sizeof(DECIMAL));
	}
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveInt64(double dInt64)
{
	__int64 llData = (__int64)dInt64;
	m_UQueue << llData;
	return S_OK;
}

STDMETHODIMP CJSSerialization::loadInt64(double *pdInt64)
{
	m_hr = S_OK;
	if(pdInt64)
	{
		if(m_UQueue.GetSize() < sizeof(__int64))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		__int64 llData;
		m_UQueue >> llData;
		*pdInt64 = (double)llData;	
	}
	else
	{
		m_UQueue.Pop((unsigned long)8);
	}
	return S_OK;
}

STDMETHODIMP CJSSerialization::saveDate(VARIANT vtDate)
{
	m_hr = S_OK;
	CComVariant vtTime;
	double dTime;

/*
	if(vtDate.vt == VT_UNKNOWN)
	{
		CComQIPtr<IMozillaWebItem> pIMozillaWebItem(vtDate.punkVal);
		if(pIMozillaWebItem == NULL)
		{
			m_hr = uecBadData;
			return m_hr;
		}
		m_hr = pIMozillaWebItem->Invoke(CComBSTR(L"getTime"), vtTime, &vtTime);
		if(FAILED(m_hr))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		dTime = vtTime.dblVal;
	}
	else */if(vtDate.vt == VT_DISPATCH)
	{
		DISPID dispid;
		CComQIPtr<IDispatch> pIDispatch(vtDate.pdispVal);
		LPOLESTR strGetTime = L"getTime";
		HRESULT hr = pIDispatch->GetIDsOfNames(IID_NULL, &strGetTime, 1, LOCALE_SYSTEM_DEFAULT, &dispid);
		if(FAILED(hr))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		DISPPARAMS disp;
		disp.cArgs = 0;
		disp.rgvarg = NULL;
		disp.rgdispidNamedArgs = NULL;
		disp.cNamedArgs = 0;
		UINT nError = 0;
		hr = pIDispatch->Invoke(dispid, IID_NULL, LOCALE_USER_DEFAULT, INVOKE_FUNC, &disp, &vtTime, NULL, &nError);
		if(FAILED(hr))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		dTime = vtTime.dblVal;
	}
	else if(vtDate.vt == VT_FILETIME)
	{
		m_UQueue << vtDate.llVal;
		return m_hr;
	}
	else 
	{
		m_hr = uecBadData;
		return m_hr;
	}

	dTime *= 10000;
	dTime += 116444556000000000;
	__int64 myTime = (__int64)dTime;
//	ATLASSERT(myTime == llTime);
	m_UQueue << myTime;
	return m_hr;
}

STDMETHODIMP CJSSerialization::loadDate(VARIANT *pvtDate)
{
	m_hr = S_OK;
	if(pvtDate)
	{
		if(m_UQueue.GetSize() < sizeof(FILETIME))
		{
			m_hr = uecBadData;
			return m_hr;
		}
		if(m_spBrowser != NULL)
		{
			CComVariant vtFileTime;
			m_UQueue >> vtFileTime.llVal;
			vtFileTime.vt = VT_FILETIME;
			if(!LoadWeb(vtFileTime, *pvtDate))
			{
				m_hr = uecBadData;
				return m_hr;
			}
		}
		else
		{
			m_UQueue >> pvtDate->llVal;
			pvtDate->vt = VT_FILETIME;
		}
	}
	else
	{
		m_UQueue.Pop((unsigned long)8);
	}
	return m_hr;
}

STDMETHODIMP CJSSerialization::get_errorCode(long *pVal)
{
	if(pVal)
		*pVal = m_hr;
	return S_OK;
}

STDMETHODIMP CJSSerialization::get_errorMessage(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	switch(m_hr)
	{
	case uecOK:
		*pVal = ::SysAllocString(L"No error.");
		break;
	case uecNotImplemented:
		*pVal = ::SysAllocString(L"Not implemented or supported.");
		break;
	case uecBadData:
		*pVal = ::SysAllocString(L"Bad serialization or de-serilization.");
		break;
	default:
		*pVal = ::SysAllocString(L"Unknown error.");
		break;
	}
	return S_OK;
}

bool CJSSerialization::SetArray(IDispatch *pIArray, VARIANT& vtArray)
{
	unsigned long n;
	HRESULT hr = S_OK;
	VARIANT *pvt;
	unsigned long nLen = vtArray.parray->rgsabound[0].cElements;
	do
	{
		hr = ::SafeArrayAccessData(vtArray.parray, (void**)&pvt);
		if(FAILED(hr))
			break;
		for(n=0; n<nLen; n++)
		{
			if(pvt[n].vt == VT_FILETIME)
			{
				CComVariant vtDate;
				if(!CreateInitJSObject(L"new Date()", vtDate))
				{
					hr = -1;
					break;
				}
				if(!setTime(vtDate.pdispVal, pvt[n]))
				{
					hr = -1;
					break;
				}
				if(!push(pIArray, vtDate))
				{
					hr = -1;
					break;
				}
			}
			else if(pvt[n].vt == (VT_ARRAY|VT_VARIANT))
			{
				CComVariant vtNewArray;
				if(!CreateInitJSObject(L"new Array()", vtNewArray))
				{
					hr = -1;
					break;
				}
				if(!SetArray(vtNewArray.pdispVal, pvt[n]))
				{
					hr = -1;
					break;
				}
				if(!push(pIArray, vtNewArray))
				{
					hr = -1;
					break;
				}
			}
			else
			{
				if(!push(pIArray, pvt[n]))
				{
					hr = -1;
					break;
				}
			}
		}
		::SafeArrayUnaccessData(vtArray.parray);
	}while(0);
	return (!FAILED(hr));
}

bool CJSSerialization::LoadWeb(VARIANT &vtSrc, VARIANT& vtWeb)
{
	HRESULT hr = S_OK;;
	if(vtSrc.vt == VT_FILETIME)
	{
		if(!CreateInitJSObject(L"new Date()", vtWeb))
			return false;
		if(!setTime(vtWeb.pdispVal, vtSrc))
		{
			return false;
		}
	}
	else if(vtSrc.vt == (VT_ARRAY|VT_VARIANT))
	{
		if(!CreateInitJSObject(L"new Array()", vtWeb))
			return false;
		if(!SetArray(vtWeb.pdispVal, vtSrc))
			return false;
	}
	else
	{
		hr = ::VariantCopy(&vtWeb, &vtSrc);
	}
	return (!FAILED(hr));
}

HRESULT CJSSerialization::EnsureAllVariants(VARIANT& vtSrc)
{
	HRESULT hr;
	do
	{
		VARIANT *pvt = NULL;
		VARIANT vtTemp = {0};
		unsigned long n;
		unsigned long nLen = vtSrc.parray->rgsabound[0].cElements;
		hr = ::SafeArrayAccessData(vtSrc.parray, (void**)&pvt);
		if(FAILED(hr))
			break;
		for(n=0; n<nLen; n++)
		{
			hr = ConvertVariant(pvt[n], vtTemp);
			if(FAILED(hr))
				break;
			if(pvt[n].vt == VT_BSTR || (pvt[n].vt & VT_ARRAY) == VT_ARRAY)
			{
				::VariantClear(pvt + n);
			}
			pvt[n] = vtTemp;
			vtTemp.vt = VT_EMPTY;
		}
		::SafeArrayUnaccessData(vtSrc.parray);
	}while(0);
	return hr;
}

HRESULT CJSSerialization::ChangeArrayOntoVariantArray(VARIANT &vtSrc, VARIANT &vtOut)
{
	unsigned long n;
	void *pData;
	VARIANT *pvt;
	HRESULT hr;
	unsigned long nLen = vtSrc.parray->rgsabound[0].cElements;
	VARTYPE vt = (vtSrc.vt & (~VT_ARRAY));
	do
	{
		SAFEARRAYBOUND sab[1] = {nLen, 0};
		vtOut.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
		vtOut.vt = (VT_ARRAY|VT_VARIANT);
		hr = ::SafeArrayAccessData(vtOut.parray, (void**)&pvt);
		hr = ::SafeArrayAccessData(vtSrc.parray, (void**)&pData);
		for(n=0; n<nLen; n++)
		{
			switch(vt)
			{
			case VT_EMPTY:
				pvt[n].vt = VT_EMPTY;
				break;
			case VT_NULL:
				pvt[n].vt = VT_NULL;
				break;
			case VT_I4:
				pvt[n].vt = VT_I4;
				pvt[n].lVal = ((long*)pData)[n];
				break;
			case VT_R8:
				pvt[n].vt = VT_R8;
				pvt[n].dblVal = ((double*)pData)[n];
				break;
			case VT_BOOL:
				pvt[n].vt = VT_BOOL;
				pvt[n].boolVal = ((VARIANT_BOOL*)pData)[n];
				break;
			case VT_FILETIME:
				pvt[n].vt = VT_FILETIME;
				::memcpy(&(pvt[n].llVal), (FILETIME*)pData + n, sizeof(FILETIME));
				break;
			case VT_I1:
				pvt[n].vt = VT_I4;
				pvt[n].lVal = ((char*)pData)[n];
				break;
			case VT_I2:
				pvt[n].vt = VT_I4;
				pvt[n].lVal = ((short*)pData)[n];
				break;
			case VT_UI1:
				pvt[n].vt = VT_I4;
				pvt[n].lVal = ((unsigned char*)pData)[n];
				break;
			case VT_UI2:
				pvt[n].vt = VT_I4;
				pvt[n].lVal = ((unsigned short*)pData)[n];
				break;
			case VT_INT:
				pvt[n].vt = VT_I4;
				pvt[n].lVal = ((int*)pData)[n];
				break;
			case VT_DECIMAL:
				{
					CComVariant vtDec;
					vtDec.vt = VT_DECIMAL;
					vtDec.decVal = ((DECIMAL*)pData)[n];
					hr = ::VariantChangeType(pvt + n, &vtDec, 0, VT_R8);
				}
				break;
			case VT_CY:
				{
					CComVariant vtCy;
					vtCy.vt = VT_CY;
					vtCy.cyVal = ((CY*)pData)[n];
					::VariantChangeType(pvt + n, &vtCy, 0, VT_R8);
				}
				break;
			case VT_R4:
				pvt[n].vt = VT_R8;
				pvt[n].dblVal = ((float*)pData)[n];
				break;
			case VT_UI4:
				pvt[n].vt = VT_R8;
				pvt[n].dblVal = ((unsigned long*)pData)[n];
				break;
			case VT_I8:
				pvt[n].vt = VT_R8;
				pvt[n].dblVal = (double)(((LONGLONG*)pData)[n]);
				break;
			case VT_UI8:
				pvt[n].vt = VT_R8;
				pvt[n].dblVal = (double)(((LONGLONG*)pData)[n]);
				break;
			case VT_UINT:
				pvt[n].vt = VT_R8;
				pvt[n].dblVal = ((unsigned int*)pData)[n];
				break;
			case VT_DATE:
				{
					SYSTEMTIME st;
					FILETIME ft;
					::VariantTimeToSystemTime(((double*)pData)[n], &st);
					::SystemTimeToFileTime(&st, &ft);
					pvt[n].vt = VT_FILETIME;
					memcpy(&(pvt[n].llVal), &ft, sizeof(ft));
				}
				break;
			case VT_BSTR:
				if(((BSTR*)pData)[n] != NULL)
				{
					pvt[n].vt = VT_BSTR;
					UINT nLen = ::SysStringLen(((BSTR*)pData)[n]);
					pvt[n].bstrVal = ::SysAllocStringLen(((BSTR*)pData)[n], nLen);
				}
				else
				{
					pvt[n].vt = VT_EMPTY;
				}
				break;
			default:
				hr = -1;
				break;
			}
			if(FAILED(hr))
				break;
		}
		::SafeArrayUnaccessData(vtSrc.parray);
		::SafeArrayUnaccessData(vtOut.parray);
	}while(0);
	return hr;
}

HRESULT CJSSerialization::CopyArrayVariant(VARIANT &vtSrc, VARIANT &vtDestination)
{
	HRESULT hr;
	unsigned n;
	VARIANT *pvtSrc;
	VARIANT *pvtDes;
	unsigned long nLen = vtSrc.parray->rgsabound[0].cElements;
	SAFEARRAYBOUND sab[1] = {nLen, 0};
	hr = ::SafeArrayAccessData(vtSrc.parray, (void**)&pvtSrc);
	if(FAILED(hr))
		return hr;
	vtDestination.vt = (VT_ARRAY|VT_VARIANT);
	vtDestination.parray = ::SafeArrayCreate(VT_VARIANT, 1, sab);
	::SafeArrayAccessData(vtDestination.parray, (void**)&pvtDes);
	do
	{
		for(n=0; n<nLen; n++)
		{
			if(pvtSrc[n].vt == VT_BSTR)
			{
				::VariantCopy(pvtDes + n, pvtSrc + n);
			}
			else if(pvtSrc[n].vt == (VT_VARIANT|VT_ARRAY))
			{
				CopyArrayVariant(pvtSrc[n], pvtDes[n]);
			}
			else if((pvtSrc[n].vt & VT_ARRAY) == VT_ARRAY)
			{
				::VariantCopy(pvtDes + n, pvtSrc + n);
			}
			else
			{
				pvtDes[n] = pvtSrc[n];
			}
		}
	}while(0);
	
	::SafeArrayUnaccessData(vtDestination.parray);
	::SafeArrayUnaccessData(vtSrc.parray);
	return hr;
}

HRESULT CJSSerialization::ConvertVariant(VARIANT &vtSrc, VARIANT &vtOut)
{
	HRESULT hr = S_OK;
	vtOut.vt = VT_EMPTY;
	switch(vtSrc.vt)
	{
	case VT_EMPTY:
	case VT_NULL:
	case VT_I4:
	case VT_R8:
	case VT_BOOL:
	case VT_FILETIME:
		vtOut = vtSrc;
		break;
	case VT_I1:
	case VT_I2:
	case VT_UI1:
	case VT_UI2:
	case VT_INT:
		hr = ::VariantChangeType(&vtOut, &vtSrc, 0, VT_I4);
		break;
	case VT_DECIMAL:
	case VT_R4:
	case VT_UI4:
	case VT_CY:
	case VT_I8:
	case VT_UI8:
	case VT_UINT:
		hr = ::VariantChangeType(&vtOut, &vtSrc, 0, VT_R8);
		break;
	case VT_DATE:
		{
			SYSTEMTIME st;
			FILETIME ft;
			::VariantTimeToSystemTime(vtSrc.date, &st);
			::SystemTimeToFileTime(&st, &ft);
			vtOut.vt = VT_FILETIME;
			memcpy(&vtOut.llVal, &ft, sizeof(ft));
		}
		break;
	case VT_BSTR:
		hr = ::VariantCopy(&vtOut, &vtSrc);
		break;
	case (VT_ARRAY|VT_VARIANT):
//		hr = ::VariantCopy(&vtOut, &vtSrc);
		hr = CopyArrayVariant(vtSrc, vtOut);
		if(FAILED(hr))
			break;
		hr = EnsureAllVariants(vtOut);
		break;
	default:
		if((vtSrc.vt & VT_ARRAY) == VT_ARRAY)
		{
			hr = ChangeArrayOntoVariantArray(vtSrc, vtOut);
		}
		else
			hr = -1;
		break;
	}
	return hr;
}

bool CJSSerialization::setTime(IDispatch *pIScriptDate, const VARIANT &vtObject)
{
	ATLASSERT(vtObject.vt == VT_FILETIME);
	do
	{
		CComVariant vtParameter;
		double dTime = (double)vtObject.llVal;
		dTime -= 116444556000000000;
		dTime /= 10000;
		vtParameter.vt = VT_R8;
		vtParameter.dblVal = dTime;
		DISPID   dispid;
		LPOLESTR strSetTime = L"setTime";
		HRESULT hr = pIScriptDate->GetIDsOfNames(IID_NULL, &strSetTime, 1, LOCALE_SYSTEM_DEFAULT, &dispid);
		if(FAILED(hr))
			return false;
		DISPPARAMS disp;
		disp.cArgs = 1;
		disp.rgvarg = &vtParameter;
		disp.rgdispidNamedArgs = NULL;
		disp.cNamedArgs = 0;
		CComVariant vtResult;
		UINT nError = 0;
		hr = pIScriptDate->Invoke(dispid, IID_NULL, LOCALE_USER_DEFAULT, INVOKE_FUNC, &disp, &vtResult, NULL, &nError);
		if(FAILED(hr))
			return false;
	}while(0);
	return true;
}

bool CJSSerialization::push(IDispatch *pIScriptArray, const VARIANT &vtObject)
{
	do
	{
		DISPID   dispid;
		LPOLESTR strPush = L"push";
		HRESULT hr = pIScriptArray->GetIDsOfNames(IID_NULL, &strPush, 1, LOCALE_SYSTEM_DEFAULT, &dispid);
		if(FAILED(hr))
			return false;
		DISPPARAMS disp;
		disp.cArgs = 1;
		disp.rgvarg = (VARIANT*)&vtObject;
		disp.rgdispidNamedArgs = NULL;
		disp.cNamedArgs = 0;
		CComVariant vtResult;
		UINT nError = 0;
		hr = pIScriptArray->Invoke(dispid, IID_NULL, LOCALE_USER_DEFAULT, INVOKE_FUNC, &disp, &vtResult, NULL, &nError);
		if(FAILED(hr))
			return false;
	}while(0);
	return true;
}

bool CJSSerialization::CreateInitJSObject(LPOLESTR strCmd, VARIANT &vtObject)
{
	do
	{
		LPOLESTR strEval = L"eval";
		DISPID   dispid;
		CComPtr<IDispatch> pDocument;
		m_spBrowser->get_Document(&pDocument);
		if(pDocument == NULL)
			return false;
		CComQIPtr<IHTMLDocument2> pIHTMLDocument2(pDocument);
		if(pIHTMLDocument2 == NULL)
			return false;
		CComPtr<IDispatch> pIScript;
		HRESULT hr = pIHTMLDocument2->get_Script(&pIScript);
		if(pIScript == NULL)
			return false;
		DISPPARAMS disp;
		disp.rgdispidNamedArgs = NULL;
		disp.cNamedArgs = 0;
		UINT nError = 0;
		hr = pIScript->GetIDsOfNames(IID_NULL, &strEval, 1, LOCALE_SYSTEM_DEFAULT, &dispid);
		if(FAILED(hr))
			return false;
		CComVariant vtParameters[1];
		vtParameters[0] = strCmd;
		disp.rgvarg = vtParameters;
		disp.cArgs = 1;
		hr = pIScript->Invoke(dispid, IID_NULL, LOCALE_USER_DEFAULT, INVOKE_FUNC, &disp, &vtObject, NULL, &nError);
		if(FAILED(hr))
			return false;
	}while(0);
	return true;
}
