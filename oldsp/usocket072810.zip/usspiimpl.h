#ifndef ___UDAPARTS_SSPI_HELPER_H__
#define ___UDAPARTS_SSPI_HELPER_H__

#include "sspiinclude.h"

class CSspiClient
{
public:
	CSspiClient();
	virtual ~CSspiClient();

public:
	static bool LoadSecurityLibraryAndOpenStore();
	static void CloseStoreAndUnloadSecurityLibrary();
	static bool IsLoaded();

public:
	SECURITY_STATUS Open(DWORD dwProtocol, LPCTSTR strUserName = NULL);
	void Close(SOCKET hSocket);

	SECURITY_STATUS PerformClientHandshake(SOCKET hSocket, LPCTSTR strServerName);
	SECURITY_STATUS ClientHandshakeLoop(SOCKET hSocket);
	CComBSTR DisplayWinVerifyTrustError(DWORD Status);
	DWORD VerifyServerCertificate(LPCTSTR pszServerName, long lPolicy = 1, DWORD dwPolicyFlags = 0, DWORD dwCertFlags = 0);
	tagSSLState	GetSSLState();
	int SendData(SOCKET hSocket, const BYTE *pData, ULONG ulLen);
	SECURITY_STATUS GetData(SOCKET hSocket, CUQueue &UQueue, ULONG ulMaxAllowed);
	ULONG GetMaxSize();
	ULONG GetDataInBuffer();

public:
	CredHandle						m_hCreds;
	CtxtHandle						m_hContext;
	PCCERT_CONTEXT					m_pRemoteCertContext;
	static PSecurityFunctionTableA	m_pSSPI;
	CUQueue							m_UQueueSend;
	CUQueue							m_UQueueRecv;

private:
	tagSSLState						m_SSLState;
	
	SCHANNEL_CRED					m_SchannelCred;
	SecPkgContext_StreamSizes		m_Sizes;

	static HMODULE					m_hSecurity;
//	static HCERTSTORE				m_hMyCertStore;
	static OSVERSIONINFOA			m_VersionInfo;
	void FreeResource();
};

#endif
