// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__6DDC1F71_7B06_4DE0_8DEB_A1888AF2DFA2__INCLUDED_)
#define AFX_STDAFX_H__6DDC1F71_7B06_4DE0_8DEB_A1888AF2DFA2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0500
#endif

//#define _ATL_DEBUG_INTERFACES

#define _ATL_FREE_THREADED

#include <winsock2.h>

//#define _ATL_APARTMENT_THREADED
#include <atlbase.h>


//extern DWORD	g_dwCountSockets;

#include "USocketModule.h"

//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
extern CUSocketModule _Module;
extern CComAutoCriticalSection	g_ucs;

#include <atlcom.h>

void CALLBACK UTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime);

#include "sockutil.h"
#include "streamhead.h"

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#include "zlib.h"


#include "WSAStartup.h"

#include <iphlpapi.h>

//#define FOR_DEBUG_INFO

void Char2Hex(const unsigned char ch, char* szHex);
void CharStr2HexStr(const unsigned char* pucCharStr, char* pszHexStr, int iSize);
void Hex2Char(const char* szHex, unsigned char& rch);
void HexStr2CharStr(const char* pszHexStr, unsigned char* pucCharStr, int iSize);

#include "uqueue.h"
using namespace SocketProAdapter;

//extern CUQueue	g_tempQueue;
extern DWORD	g_dwUsedWithDotNet;

#include "usinternal.h"
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__6DDC1F71_7B06_4DE0_8DEB_A1888AF2DFA2__INCLUDED)
