#ifndef __U_SOCKET_EVENT_FILE_H__
#define __U_SOCKET_EVENT_FILE_H__

#define	IDC_SRCUSOCKETEVENT		1

static _ATL_FUNC_INFO OnSockEventFuncInfo = {CC_STDCALL, VT_I4, 2, {VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnSockEventWinMsgInfo = {CC_STDCALL, VT_I4, 3, {VT_I4, VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnDataAvailableInfo = {CC_STDCALL, VT_I4, 3, {VT_I4, VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnSendingDataInfo = {CC_STDCALL, VT_I4, 3, {VT_I4, VT_I4, VT_I4}};
static _ATL_FUNC_INFO OnSockGetHostByAddr = {CC_STDCALL, VT_I4, 4, {VT_I4, VT_BSTR, VT_BSTR, VT_I4}};
static _ATL_FUNC_INFO OnSockGetHostByName = {CC_STDCALL, VT_I4, 5, {VT_I4, VT_BSTR, VT_BSTR, VT_BSTR, VT_I4}};
static _ATL_FUNC_INFO OnRequestProcessedInfo = {CC_STDCALL, VT_I4, 4, {VT_I2, VT_I4, VT_I4, VT_I2}};

class CClientSocketEvent : public IDispEventSimpleImpl<IDC_SRCUSOCKETEVENT, CClientSocketEvent, &__uuidof(_IUSocketEvent)>							
{
public:
	
BEGIN_SINK_MAP(CClientSocketEvent)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 1, OnDataAvailable, &OnDataAvailableInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 2, OnOtherMessage, &OnSockEventWinMsgInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 3, OnSocketClosed, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 4, OnSocketConnected, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 5, OnConnecting, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 6, OnSendingData, &OnSendingDataInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 7, OnGetHostByAddr, &OnSockGetHostByAddr)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 8, OnGetHostByName, &OnSockGetHostByName)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 9, OnClosing, &OnSockEventFuncInfo)
	SINK_ENTRY_INFO(IDC_SRCUSOCKETEVENT, __uuidof(_IUSocketEvent), 10, OnRequestProcessed, &OnRequestProcessedInfo)
END_SINK_MAP()
	virtual HRESULT __stdcall OnDataAvailable(long hSocket, long lBytes, long lError)=0;
	virtual HRESULT __stdcall OnOtherMessage(long nMsg, long wParam, long lParam)=0;
	virtual HRESULT __stdcall OnSocketClosed(long hSocket, long lError)=0;
	virtual HRESULT __stdcall OnSocketConnected(long hSocket, long lError)=0;
	virtual HRESULT __stdcall OnConnecting(long hSocket, long hWnd)=0;
	virtual HRESULT __stdcall OnSendingData(long hSocket, long lError, long lSent)=0;
	virtual HRESULT __stdcall OnGetHostByAddr(LONG nHandle, BSTR bstrHostName, BSTR bstrHostAlias, LONG lError)=0;
	virtual HRESULT __stdcall OnGetHostByName(LONG hHandle, BSTR bstrHostName, BSTR bstrAlias, BSTR bstrIPAddr, LONG lError)=0;
	virtual HRESULT __stdcall OnClosing(long hSocket, long hWnd)=0;
	virtual HRESULT __stdcall OnRequestProcessed(short nRequestID, long lLen, long lLenInBuffer, short sFlag)=0;
};

#endif