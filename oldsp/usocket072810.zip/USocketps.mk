
USocketps.dll: dlldata.obj USocket_p.obj USocket_i.obj
	link /dll /out:USocketps.dll /def:USocketps.def /entry:DllMain dlldata.obj USocket_p.obj USocket_i.obj \
		kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib \

.c.obj:
	cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL \
		$<

clean:
	@del USocketps.dll
	@del USocketps.lib
	@del USocketps.exp
	@del dlldata.obj
	@del USocket_p.obj
	@del USocket_i.obj
