// MDispatch.cpp: implementation of the CMDispatch class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _WIN64

#include "MDispatch.h"
#include "umozilla.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMDispatch::CMDispatch(IUnknown *pIUnknown, nsPluginInstanceBase *pInstance)
{
	ATLASSERT(pInstance != NULL);
	m_pIMozillaWebItem = NULL;
	m_pIMozilla = NULL;
	if(pIUnknown != NULL)
	{
		pIUnknown->QueryInterface(&m_pIDispatch);
	}
	if(m_pIDispatch.p != NULL)
	{
		QueryAndSet(m_pIDispatch.p, pInstance);
	}
}

void CMDispatch::QueryAndSet(IDispatch *pIDispatch, nsPluginInstanceBase *pInstance)
{
	UINT n;
	HRESULT hr;
	ATLASSERT(pIDispatch != NULL);
	UINT nCount = 0;
	CComBSTR bstrName;
	CComPtr<ITypeInfo> pITypeInfo;
	pIDispatch->GetTypeInfoCount(&nCount);
	for(n=0; n<nCount; n++)
	{
		hr = pIDispatch->GetTypeInfo(n, LOCALE_SYSTEM_DEFAULT, &pITypeInfo);
		if(pITypeInfo.p == NULL)
		{
/*			TCHAR strErrMsg[256];
			_stprintf_s(strErrMsg, _T("GetTypeInfo Error code = 0x%x"), hr);
			::MessageBox(NULL, strErrMsg, _T("Debug"), MB_OK);*/
			continue;
		}

		TYPEATTR *pTypeAttr = NULL;
		hr = pITypeInfo->GetTypeAttr(&pTypeAttr);
		if(pTypeAttr == NULL)
		{
/*			TCHAR strErrMsg[256];
			_stprintf_s(strErrMsg, _T("GetTypeAttr Error code = 0x%x"), hr);
			::MessageBox(NULL, strErrMsg, _T("Debug"), MB_OK);*/
			continue;
		}

		WORD w; 

		//QueryInterface, AddRef, Release, GetTypeInfoCount, GetTypeInfo, GetIDsOfNames and Invoke ignored
		for(w=7; w<pTypeAttr->cFuncs; w++)
		{
			FUNCDESC *pFuncDesc = NULL;
			pITypeInfo->GetFuncDesc(w, &pFuncDesc);

			if(pFuncDesc == NULL)
				continue;
			unsigned int nNames;
			bstrName.Empty();
			pITypeInfo->GetNames(pFuncDesc->memid, &bstrName, 1, &nNames);
			
			switch(pFuncDesc->invkind)
			{
			case INVOKE_FUNC:
				m_aMethodName.Add(bstrName);
				m_mapFunc.Add(bstrName, *pFuncDesc);
				break;
			case INVOKE_PROPERTYGET:
				if(pFuncDesc->cParams == 0)
				{
					m_aPropertyName.Add(bstrName);
					m_mapPropertyGet.Add(bstrName, *pFuncDesc);
				}
				else //for STDMETHODIMP CAcnts::get_Item(long lIndex, VARIANT *pvtValue)
				{
					m_aMethodName.Add(bstrName);
					m_mapFunc.Add(bstrName, *pFuncDesc);
				}
				break;
			case INVOKE_PROPERTYPUT:
				if(pFuncDesc->cParams == 1)
				{
					m_aPropertyNamePut.Add(bstrName);
					m_mapPropertyPut.Add(bstrName, *pFuncDesc);
					if(m_mapPropertyGet.FindKey(bstrName) == -1)
					{
						m_aPropertyName.Add(bstrName);
						m_mapPropertyGet.Add(bstrName, *pFuncDesc);
					}
				}
				else if(pFuncDesc->cParams == 2)//for STDMETHODIMP CAcnts::put_Item(long lIndex, VARIANT vtValue)
				{
					m_aMethodName.Add(bstrName);
					m_mapFunc.Add(bstrName, *pFuncDesc);
				}
				else
				{
				}
				break;
			case INVOKE_PROPERTYPUTREF:
				//not supported with NPObject
				ATLASSERT(FALSE);
				break;
			default:
				break;
			}
			if(pFuncDesc != NULL)
			{
				pITypeInfo->ReleaseFuncDesc(pFuncDesc);
			}
		}
		pITypeInfo->ReleaseTypeAttr(pTypeAttr);
		pITypeInfo.Release();
	}

	CComQIPtr<IUMozilla> pIMozilla(pIDispatch);
	if(pIMozilla.p != NULL)
	{
		HRESULT hr = CComObject<CCOMWebItem>::CreateInstance(&m_pIMozillaWebItem);
		if(m_pIMozillaWebItem != NULL)
		{
			m_pIMozillaWebItem->m_pInstance = pInstance->m_pInstance;
			CWebItem::GetBrowserWindow(*m_pIMozillaWebItem);
			m_pIMozillaWebItem->AddRef(); //IUnknown::AddRef
			m_pIMozillaWebItem->m_bWnd = true;
			pIMozilla->OnStart(m_pIMozillaWebItem);
		}
	}
}

CMDispatch::CMDispatch(const CLSID &clsid, nsPluginInstanceBase *pInstance)
{
	ATLASSERT(pInstance != NULL);
	m_pIMozillaWebItem = NULL;
	m_pIMozilla = NULL;
	m_pIDispatch.CoCreateInstance(clsid);
	if(m_pIDispatch.p != NULL)
	{
		m_pIDispatch->QueryInterface(&m_pIMozilla);
	}
	if(m_pIMozilla.p != NULL)
	{
		QueryAndSet(m_pIDispatch.p, pInstance);
	}
	else
	{
		if(NPNFuncs.setexception != NULL)
		{
			USES_CONVERSION;
			LPOLESTR strClassID = NULL;
			::StringFromCLSID(clsid, &strClassID);
			CComBSTR bstrMessage(_T("Object can't be created with class id = "));
			bstrMessage += strClassID;
			::CoTaskMemFree(strClassID);
			NPNFuncs.setexception(this, OLE2A(bstrMessage));
		}
	}
}

CMDispatch::~CMDispatch()
{
	if(m_pIMozillaWebItem != NULL)
	{
		m_pIMozillaWebItem->Release();
		m_pIMozillaWebItem = NULL;
	}	
}

bool CMDispatch::GetProperty(const CComBSTR &bstrPropertyName, CComVariant &vtData)
{
	LPWSTR str = bstrPropertyName.m_str;
	DISPID dispid;
	HRESULT hr = m_pIDispatch->GetIDsOfNames(IID_NULL, &str, 1, LOCALE_USER_DEFAULT, &dispid);
	if(FAILED(hr))
		return false;
	return (InvokeVariantMethod(dispid, INVOKE_PROPERTYGET, NULL, 0, &vtData) == S_OK);
}

bool CMDispatch::SetProperty(const CComBSTR &strPropertyName, const CComVariant &vtData)
{
	CComVariant vtOutput;
	LPWSTR str = strPropertyName.m_str;
	DISPID dispid;
	HRESULT hr = m_pIDispatch->GetIDsOfNames(IID_NULL, &str, 1, LOCALE_USER_DEFAULT, &dispid);
	if(FAILED(hr))
		return false;
	return (InvokeVariantMethod(dispid, INVOKE_PROPERTYPUT, &vtData, 1, &vtOutput) == S_OK);
}

bool CMDispatch::Invoke(const CComBSTR &bstrMethodName, const VARIANT *pvtArgs, uint32_t argCount, CComVariant &vtResult)
{
	LPWSTR str = bstrMethodName.m_str;
	DISPID dispid;
	HRESULT hr = m_pIDispatch->GetIDsOfNames(IID_NULL, &str, 1, LOCALE_USER_DEFAULT, &dispid);
	if(FAILED(hr))
		return false;
	return (InvokeVariantMethod(dispid, INVOKE_FUNC, pvtArgs, argCount, &vtResult) == S_OK);
}

HRESULT CMDispatch::InvokeVariantMethod(const DISPID dispidMethod, WORD wInvokeFlag, const VARIANT *pvtArgs, uint32_t argCount, VARIANT* pVarRet)
{
/*	if(m_pIMozillaSpecific.p == NULL)
		return E_FAIL;*/
	ATLASSERT(pVarRet != NULL);
//	CComVariant *pOrder = NULL;
	VARIANT *pOrder = NULL;
	DISPID dispidNamed = DISPID_PROPERTYPUT;
	DISPPARAMS disp;
	disp.cArgs = argCount;
	disp.rgvarg = (VARIANT *)pvtArgs;
	if(wInvokeFlag == INVOKE_PROPERTYPUT)
	{
		disp.rgdispidNamedArgs = &dispidNamed;
		disp.cNamedArgs = 1;
	}
	else
	{
		disp.rgdispidNamedArgs = NULL;
		disp.cNamedArgs = 0;
	}
	if(/*wInvokeFlag == INVOKE_FUNC &&*/argCount > 1)
	{
//		pOrder = new CComVariant[argCount];
		pOrder = new VARIANT[argCount];
		uint32_t n;
		for(n=0; n<argCount; n++)
		{
			pOrder[argCount-n-1] = pvtArgs[n];
		}
		disp.rgvarg = pOrder;
	}
	unsigned int nError = 0;
	HRESULT hr = m_pIDispatch->Invoke(dispidMethod, IID_NULL, LOCALE_USER_DEFAULT, wInvokeFlag, &disp, pVarRet, NULL, &nError);
	if(pOrder != NULL)
	{
		delete []pOrder;
	}
	return hr;
}

void CMDispatch::OnInvalidate()
{
	ULONG ulRef;
	if(m_pIMozillaWebItem != NULL)
	{
/*		if(m_pIMozillaWebItem->m_bJSObject)
			m_pIMozillaWebItem->Detach();*/
		m_pIMozillaWebItem->Release();
		m_pIMozillaWebItem = NULL;
	}
	CComQIPtr<IUMozilla> pIMozilla(m_pIMozilla);
	if(pIMozilla.p != NULL)
	{
		pIMozilla->OnShutdown();
	}
	m_pIMozilla.Release();
	if(m_pIDispatch != NULL)
	{
		ulRef = m_pIDispatch.p->Release();
		m_pIDispatch.p = NULL;
	}
	ulRef = 0;
}

#endif //_WIN64