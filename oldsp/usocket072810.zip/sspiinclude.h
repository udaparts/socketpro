#ifndef __SECURE_SOCKET_CHANNEL_INCLUDE_H__
#define __SECURE_SOCKET_CHANNEL_INCLUDE_H__

#include "uqueue.h"
using namespace SocketProAdapter;

#include <schannel.h>
#define SECURITY_WIN32
#include <security.h>
#include <sspi.h>

#define IO_BUFFER_SIZE		(0x800)
#define DLL_NAME		_T("Secur32.dll")
#define NT4_DLL_NAME	_T("Security.dll")

enum tagSSLState
{
	ssUnknown = 0,
	ssClientHello,
	ssHandshaking,
	ssFinished,
};

#endif