// WSAStartup.h: interface for the CWSAStartup class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WSASTARTUP_H__C72B5F4C_14E1_4BF7_A862_0DA07F9ACC6C__INCLUDED_)
#define AFX_WSASTARTUP_H__C72B5F4C_14E1_4BF7_A862_0DA07F9ACC6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "USocket.h"
#include "USocketImp.h"

extern CUSocketMap	g_mapUSocket;

#include "openssl\ssl.h"
#include "openssl\err.h"

typedef	int (*PSSL_library_init) (void);
typedef SSL_METHOD* (*PSSLv23_method) (void);
typedef SSL_METHOD* (*PTLSv1_method) (void);	
typedef void(*PSSL_load_error_strings) (void);

typedef SSL_CTX*(*PSSL_CTX_new) (SSL_METHOD* pMethod);
typedef void(*PSSL_CTX_free) (SSL_CTX *pCTX);
typedef long (*PSSL_CTX_ctrl) (SSL_CTX *ctx,int cmd, long larg, void *parg);

typedef void(*PSSL_set_connect_state) (SSL *pSSL);
typedef void(*PSSL_set_accept_state) (SSL *pSSL);
typedef int	(*PSSL_CTX_use_certificate_file) (SSL_CTX *pCTX, const char *strFile, int nType);
typedef int	(*PSSL_CTX_use_PrivateKey_file) (SSL_CTX *pCTX, const char *strFile, int nType);
typedef int (*PSSL_CTX_check_private_key) (SSL_CTX *pCTX);
typedef int (*PSSL_do_handshake) (SSL *pSSL);

typedef int	(*PSSL_set_fd) (SSL *pSSL, int hSocket);
typedef int (*PSSL_accept) (SSL *pSSL);
typedef int	(*PSSL_get_error) (SSL *pSSL, int nRet);
typedef int (*PSSL_write) (SSL *pSSL, const void *pBuf, int nLen);
typedef int (*PSSL_read) (SSL *pSSL, void *pBuf, int nLen);
typedef int (*PSSL_peek) (SSL *pSSL,void *pBuf,int nLen);

typedef SSL*(*PSSL_new) (SSL_CTX *pCTX);
typedef void(*PSSL_free)  (SSL* pSSL);
typedef int (*PSSL_shutdown) (SSL *pSSL);

typedef int (*PSSL_state) (SSL *pSSL);

typedef const char* (*PSSL_get_version) (SSL *pSSL);

typedef int (*PBIO_socket_ioctl) (int hSocket, long nType, void *nArg);
typedef int (*PSSL_want) (SSL *pSSL);

typedef const char*(*PSSL_state_string_long) (const SSL *pSSL);
typedef int	(*PSSL_pending) (SSL *pSSL);
typedef int (*PSSL_connect) (SSL *pSSL);

typedef void (*PSSL_set_bio) (SSL *pSSL, BIO *bioRead, BIO *bioWrite);
typedef BIO* (*PSSL_get_rbio) (SSL *pSSL);
typedef BIO* (*PSSL_get_wbio) (SSL *pSSL);
typedef int	(*PBIO_read) (BIO *pBIO, void *pData, int nLen);
typedef int	(*PBIO_write) (BIO *pBIO, const void *pData, int nLen);

typedef void (*PERR_clear_error) (void);
typedef int	(*PSSL_clear) (SSL *pSSL);
typedef void* (*PCRYPTO_malloc) (int nNum, const char *strFile, int nLine);
typedef void (*PCRYPTO_free) (void *);

typedef void (*PCRYPTO_set_locking_callback) (void (*func)(int mode,int type, const char *file,int line));
typedef int (*PCRYPTO_num_locks) (void);
typedef void (*PSSL_set_read_ahead) (SSL *pSSL, int nYes);
typedef void (*PSSL_set_info_callback) (SSL *pSSL, void (*cb) (const SSL *pSSL, int nWhere,int nRtn));
typedef int	(*PSSL_get_fd) (SSL *pSSL);
typedef unsigned long (*PERR_get_error) (void);
typedef char*(*PERR_error_string) (unsigned long e, char *buf);

typedef SSL_CIPHER* (*PSSL_get_current_cipher) (SSL *s);
typedef X509* (*PSSL_get_peer_certificate) (SSL *pSSL);

//CERTIFICATE
typedef int (*PASN1_TIME_print) (BIO *fp,ASN1_TIME *a);
typedef int	(*PBIO_free) (BIO *a);
typedef long (*PBIO_ctrl) (BIO *bp,int cmd,long larg,void *parg);
typedef BIO* (*PBIO_new) (BIO_METHOD *type);
typedef BIO_METHOD* (*PBIO_s_mem) (void);
typedef const char* (*PSSL_get_version) (SSL *s);
typedef char* (*PSSL_CIPHER_get_version) (SSL_CIPHER *c);
typedef const char*	(*PSSL_CIPHER_get_name) (SSL_CIPHER *c);
typedef void (*PX509_free) (X509 *pX509);
typedef void (*PEVP_PKEY_free) (EVP_PKEY *pkey);
typedef int	(*PBN_num_bits) (const BIGNUM *a);
typedef EVP_PKEY* (*PX509_get_pubkey) (X509 *x);
typedef X509_NAME* (*PX509_get_issuer_name) (X509 *a);
typedef char* (*PX509_NAME_oneline) (X509_NAME *a,char *buf,int size);
typedef X509_NAME* (*PX509_get_subject_name) (X509 *a);
typedef const char*	(*POBJ_nid2sn) (int n);
typedef int	(*POBJ_obj2nid) (const ASN1_OBJECT *o);
typedef int	(*PX509_cmp_current_time) (ASN1_TIME *s);
typedef void (*PBIO_free_all) (BIO *a);
typedef int (*PPEM_write_bio_X509) (BIO *p, X509 *cert);
typedef int (*PSSL_CTX_load_verify_locations) (SSL_CTX *ctx, const char *CAfile, const char *CApath);
typedef long (*PSSL_get_verify_result) (SSL *ssl);
typedef const char*(*PX509_verify_cert_error_string) (long n);
typedef void (*PSSL_set_bio) (SSL *s, BIO *rbio,BIO *wbio);
typedef int	(*PBIO_read) (BIO *b, void *data, int len);
typedef int	(*PBIO_write) (BIO *b, const void *data, int len);
typedef size_t (*PBIO_ctrl_pending) (BIO *b);
typedef BIO* (*PSSL_get_rbio)(SSL *s);
typedef BIO* (*PSSL_get_wbio)(SSL *s);


class CWSAStartup  
{
public:
	CWSAStartup();
	virtual ~CWSAStartup();

public:
	void Cleanup();
	bool Startup();

	static void LockingCallback(int nMode, int nType, const char *strFile, int nLine);
	void StopOpenSSL();
	bool StartOpenSSL();
	void UnloadOpenSSL();
	bool LoadOpenSSL(bool bUseSSL);
	bool StartSSPI();
	void StopSSPI();

public:
	void KillTimer();
	void SetTimer();
	PSSL_library_init				SSL_library_init;
	PSSLv23_method					SSLv23_method;
	PTLSv1_method					TLSv1_method;
	PSSL_load_error_strings			SSL_load_error_strings;
	PSSL_CTX_new					SSL_CTX_new;
	PSSL_CTX_free					SSL_CTX_free;
	PSSL_new						SSL_new;
	PSSL_free						SSL_free;
	PSSL_set_fd						SSL_set_fd;
	PSSL_do_handshake				SSL_do_handshake;
	PSSL_accept						SSL_accept;
	PSSL_get_error					SSL_get_error;
	PSSL_write						SSL_write;
	PSSL_read						SSL_read;
	PSSL_shutdown					SSL_shutdown;
	PSSL_state						SSL_state;
	PSSL_want						SSL_want;
	PSSL_pending					SSL_pending;
	PSSL_set_connect_state			SSL_set_connect_state;
	PSSL_set_accept_state			SSL_set_accept_state;
	PSSL_CTX_use_certificate_file	SSL_CTX_use_certificate_file;
	PSSL_CTX_use_PrivateKey_file	SSL_CTX_use_PrivateKey_file;
	PSSL_CTX_check_private_key		SSL_CTX_check_private_key;
	PSSL_get_peer_certificate		SSL_get_peer_certificate;
	PSSL_get_current_cipher			SSL_get_current_cipher;
	PSSL_set_read_ahead				SSL_set_read_ahead;
	PSSL_state_string_long			SSL_state_string_long;
	PSSL_connect					SSL_connect;
	PSSL_peek						SSL_peek;
	PERR_clear_error				ERR_clear_error;
	PSSL_clear						SSL_clear;
	PSSL_set_info_callback			SSL_set_info_callback;
	PSSL_get_fd						SSL_get_fd;
	PCRYPTO_free					CRYPTO_free;
	PCRYPTO_malloc					CRYPTO_malloc;
	PCRYPTO_set_locking_callback	CRYPTO_set_locking_callback;
	PCRYPTO_num_locks				CRYPTO_num_locks;
	PERR_get_error					ERR_get_error;
	PERR_error_string				ERR_error_string;
	PSSL_CTX_ctrl					SSL_CTX_ctrl;
	PSSL_set_bio					SSL_set_bio;
	PBIO_read						BIO_read;
	PBIO_write						BIO_write;
	PBIO_ctrl_pending				BIO_ctrl_pending;
	PSSL_get_rbio					SSL_get_rbio;
	PSSL_get_wbio					SSL_get_wbio;

	SSL_CTX		*m_pCtx;
	HINSTANCE	m_hSSLEay;
	HINSTANCE	m_hLibeay;

	ULONG		m_ulOS;


	PBIO_free						BIO_free;
	PBIO_ctrl						BIO_ctrl;
	PBIO_new						BIO_new;
	PBIO_s_mem						BIO_s_mem;
	PBIO_free_all					BIO_free_all;

	PSSL_get_version				SSL_get_version;
	PSSL_CIPHER_get_version			SSL_CIPHER_get_version;
	PSSL_CIPHER_get_name			SSL_CIPHER_get_name;
	PSSL_CTX_load_verify_locations	SSL_CTX_load_verify_locations;
	PSSL_get_verify_result			SSL_get_verify_result;
	
	PX509_get_pubkey				X509_get_pubkey;
	PX509_get_issuer_name			X509_get_issuer_name;
	PX509_NAME_oneline				X509_NAME_oneline;	
	PX509_get_subject_name			X509_get_subject_name;
	PX509_free						X509_free;
	PX509_cmp_current_time			X509_cmp_current_time;
	PX509_verify_cert_error_string	X509_verify_cert_error_string;

	POBJ_nid2sn						OBJ_nid2sn;
	POBJ_obj2nid					OBJ_obj2nid;
	PASN1_TIME_print				ASN1_TIME_print;
	PEVP_PKEY_free					EVP_PKEY_free;
	PBN_num_bits					BN_num_bits;
	PPEM_write_bio_X509				PEM_write_bio_X509;

private:
	WORD	m_nVersionRequested;
	WSADATA	m_wsaData;
	UINT	m_nTimer;
	SSL_METHOD	*m_pMeth;
	HANDLE		*m_pSSLLockHandle;
};

#endif // !defined(AFX_WSASTARTUP_H__C72B5F4C_14E1_4BF7_A862_0DA07F9ACC6C__INCLUDED_)
