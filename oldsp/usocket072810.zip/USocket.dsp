# Microsoft Developer Studio Project File - Name="USocket" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=USocket - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "USocket.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "USocket.mak" CFG="USocket - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "USocket - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "USocket - Win32 Release MinDependency" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "USocket - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /Gm /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MTd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_USRDLL" /D "_MBCS" /D "MOZILLA_STRICT_API" /D "XP_WIN32" /D "XPCOM_GLUE" /D "XP_WIN" /D "_X86_" /FR /Yu"stdafx.h" /FD /GZ /c
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386 /pdbtype:sept
# ADD LINK32 ws2_32.lib iphlpapi.lib crypt32.lib /nologo /base:"0x41000000" /subsystem:windows /dll /debug /machine:I386 /out:"C:\Program Files\Mozilla Firefox\plugins/npUSocket.dll" /pdbtype:sept
# Begin Custom Build - Performing registration
OutDir=.\Debug
TargetPath=C:\Program Files\Mozilla Firefox\plugins\npUSocket.dll
InputPath=C:\Program Files\Mozilla Firefox\plugins\npUSocket.dll
SOURCE="$(InputPath)"

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "ReleaseMinDependency"
# PROP BASE Intermediate_Dir "ReleaseMinDependency"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "ReleaseMinDependency"
# PROP Intermediate_Dir "ReleaseMinDependency"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MT /W3 /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /D "_ATL_STATIC_REGISTRY" /D "_ATL_MIN_CRT" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MT /W3 /GX /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /D "_ATL_STATIC_REGISTRY" /D "MOZILLA_STRICT_API" /D "XP_WIN32" /D "XPCOM_GLUE" /D "XP_WIN" /D "_X86_" /Yu"stdafx.h" /FD /c
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 ws2_32.lib iphlpapi.lib crypt32.lib /nologo /base:"0x41000000" /subsystem:windows /dll /machine:I386 /out:"ReleaseMinDependency/npUSocket.dll"
# SUBTRACT LINK32 /incremental:yes /debug
# Begin Custom Build - Performing registration
OutDir=.\ReleaseMinDependency
TargetPath=.\ReleaseMinDependency\npUSocket.dll
InputPath=.\ReleaseMinDependency\npUSocket.dll
SOURCE="$(InputPath)"

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	
# End Custom Build

!ENDIF 

# Begin Target

# Name "USocket - Win32 Debug"
# Name "USocket - Win32 Release MinDependency"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\adler32.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\BF.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\compress.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\COMWebItem.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\crc32.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\deflate.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\dlldatax.c
# PROP Exclude_From_Scan -1
# PROP BASE Exclude_From_Build 1
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\infback.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\inffast.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\inflate.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\inftrees.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\JSSerialization.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\MDispatch.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\MyOpenSSL.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\np_entry.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\npn_gate.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\NPObjectImpBase.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\npp_gate.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\plugin.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\quick.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\SHA1.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE="..\..\Program Files\UDAParts\SocketPro\include\sprowrap.cpp"

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

# ADD CPP /Yc"stdafx.h"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1 /Yc"stdafx.h"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\trees.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\UCert.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\uncompr.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\USocket.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\USocket.def
# End Source File
# Begin Source File

SOURCE=.\USocket.idl
# ADD MTL /tlb ".\USocket.tlb" /h "USocket.h" /iid "USocket_i.c" /Oicf
# End Source File
# Begin Source File

SOURCE=.\USocket.rc
# End Source File
# Begin Source File

SOURCE=.\USocketImp.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\USocketModule.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\USocketPool.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\usspiimpl.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\UZip.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\WSAStartup.cpp

!IF  "$(CFG)" == "USocket - Win32 Debug"

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\zutil.c

!IF  "$(CFG)" == "USocket - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "USocket - Win32 Release MinDependency"

# ADD CPP /O1
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\BF.h
# End Source File
# Begin Source File

SOURCE=.\COMWebItem.h
# End Source File
# Begin Source File

SOURCE=.\dlldatax.h
# PROP Exclude_From_Scan -1
# PROP BASE Exclude_From_Build 1
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\inffast.h
# End Source File
# Begin Source File

SOURCE=.\inffixed.h
# End Source File
# Begin Source File

SOURCE=.\inflate.h
# End Source File
# Begin Source File

SOURCE=.\inftrees.h
# End Source File
# Begin Source File

SOURCE=.\JSSerialization.h
# End Source File
# Begin Source File

SOURCE=.\MDispatch.h
# End Source File
# Begin Source File

SOURCE=.\MyOpenSSL.h
# End Source File
# Begin Source File

SOURCE=.\NPObjectImpBase.h
# End Source File
# Begin Source File

SOURCE=..\mozilla\gecko_sdk\include\npruntime.h
# End Source File
# Begin Source File

SOURCE=..\mozilla\gecko_sdk\include\npupp.h
# End Source File
# Begin Source File

SOURCE=.\plugin.h
# End Source File
# Begin Source File

SOURCE=.\pluginbase.h
# End Source File
# Begin Source File

SOURCE=.\quick.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\SHA1.h
# End Source File
# Begin Source File

SOURCE=.\socketpoolevent.h
# End Source File
# Begin Source File

SOURCE=..\install\SocketProAdapter\cplusplus\sprowrap.h
# End Source File
# Begin Source File

SOURCE=.\SspiServer.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\streamhead.h
# End Source File
# Begin Source File

SOURCE=.\UCert.h
# End Source File
# Begin Source File

SOURCE="..\..\Program Files\UDAParts\SocketPro\include\uqueue.h"
# End Source File
# Begin Source File

SOURCE=.\USocket.h
# End Source File
# Begin Source File

SOURCE=.\USocketCP.h
# End Source File
# Begin Source File

SOURCE=.\USocketImp.h
# End Source File
# Begin Source File

SOURCE=.\USocketModule.h
# End Source File
# Begin Source File

SOURCE=.\USocketPool.h
# End Source File
# Begin Source File

SOURCE=.\usocketsink.h
# End Source File
# Begin Source File

SOURCE=.\usspiimpl.h
# End Source File
# Begin Source File

SOURCE=.\UZip.h
# End Source File
# Begin Source File

SOURCE=.\WSAStartup.h
# End Source File
# Begin Source File

SOURCE="..\..\Program Files\UDAParts\SocketPro\include\wuqueue.h"
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\USocket.rgs
# End Source File
# Begin Source File

SOURCE=.\USocketPool.rgs
# End Source File
# End Group
# End Target
# End Project
