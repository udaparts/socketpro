// stdafx.cpp : source file that includes just the standard includes
//  stdafx.pch will be the pre-compiled header
//  stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#ifdef _ATL_STATIC_REGISTRY
#include <statreg.h>
#include <statreg.cpp>
#endif

#include <atlimpl.cpp>

//DWORD	g_dwCountSockets;

#include "USocket.h"
#include "USocketImp.h"

extern bool g_bRegistered;
extern TCHAR *g_strInfoMsg;
extern TCHAR *g_strTitle;

DWORD g_lastTime = 0;

CComAutoCriticalSection	g_ucs;
extern CUSocketMap	g_mapUSocket;

//CUQueue		g_tempQueue;

char *strGetDate = "new Date()";
char *strGetArray = "new Array()";

ULONG GetOS()
{
	ULONG ulOs;
	BYTE bMajor, bMinor, bBuildNumber, bPlatform;
	OSVERSIONINFO	OsInfo;
	memset(&OsInfo, 0, sizeof(OSVERSIONINFO));
	OsInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	::GetVersionEx(&OsInfo);
	bMajor = (BYTE)OsInfo.dwMajorVersion;
	bMinor = (BYTE)OsInfo.dwMinorVersion;
	bBuildNumber = (BYTE)OsInfo.dwBuildNumber;
	bPlatform = (BYTE)OsInfo.dwPlatformId;
	ulOs = bPlatform*(0x1000000L) + bMajor*(0x10000L) + bMinor*(0x100L) + bBuildNumber;
	return ulOs;
}

void CALLBACK UTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	UINT n;
	unsigned long ulNow;
	CUSocket	*pUSocket;

	if(!g_bRegistered && dwTime > g_lastTime && (dwTime - g_lastTime) > 300000)
	{
		g_lastTime = dwTime;
		srand(300000);
		g_lastTime += rand();
		::MessageBox(NULL, g_strInfoMsg, g_strTitle, MB_ICONINFORMATION);
	}

	ulNow = dwTime;
	CAutoLock AutoLock(&g_ucs.m_sec);
	UINT nCount = g_mapUSocket.GetSize();
	for(n=0; n<nCount; n++)
	{
		pUSocket = g_mapUSocket.GetValueAt(n);
		if(dwTime > pUSocket->m_ulTimeTrack && (dwTime - pUSocket->m_ulTimeTrack) > 250 && !pUSocket->m_bChecked && pUSocket->m_SBAttr.m_hSocket!=INVALID_SOCKET)
		{
			long lByte = 0;
			pUSocket->IOCtl(iocRead, &lByte);
			if(lByte + pUSocket->m_Sspi.m_UQueueRecv.GetSize())
			{
				::PostMessage(pUSocket->m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, FD_READ);
//				::PostMessage(pUSocket->m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, FD_WRITE);
			}
			if(pUSocket->m_sndQueue.GetSize() || pUSocket->m_Sspi.GetDataInBuffer())
			{
				::PostMessage(pUSocket->m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, FD_WRITE);
			}
//			pUSocket->m_bChecked = true;
		}
		if(ulNow - pUSocket->m_ulTimeTrack > 30000)
		{
			unsigned long ulSize = pUSocket->m_USAttr.m_ulMemBlockSize;
			if((pUSocket->m_rcvQueue.GetSize())<ulSize && pUSocket->m_rcvQueue.GetMaxSize()>ulSize )
			{
				pUSocket->m_rcvQueue.ReallocBuffer(ulSize);
			}
		}
		if((ulNow-pUSocket->m_ulLSend) > 30000)
		{
			unsigned long ulSize = pUSocket->m_USAttr.m_ulMemBlockSize;
			if(pUSocket->m_sndQueue.GetSize()<ulSize && pUSocket->m_sndQueue.GetMaxSize()>ulSize )
			{
				pUSocket->m_sndQueue.ReallocBuffer(ulSize);
			}
		}
		if((ulNow-pUSocket->m_ulLSend) > 30000 && ulNow - pUSocket->m_ulTimeTrack > 30000)
		{
			unsigned long ulSize = pUSocket->m_USAttr.m_ulMemBlockSize;
			if(pUSocket->m_BatchQueue.GetSize()<ulSize && pUSocket->m_BatchQueue.GetMaxSize()>ulSize )
			{
				pUSocket->m_BatchQueue.ReallocBuffer(ulSize);
			}
		}
		if(pUSocket->m_sndQueue.GetSize() && ulNow>pUSocket->m_ulLSend && (ulNow-pUSocket->m_ulLSend) > pUSocket->m_SBAttr.m_ulSendTimeout)
		{
//			pUSocket->OnClosed(seTimedOut);
			::PostMessage(pUSocket->m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, MAKELONG(FD_CLOSE, (WORD)seTimedOut));
			break;
		}
		if((pUSocket->m_USAttr.m_curRcvStreamHeader.m_nRequestID || pUSocket->m_requestQueue.GetSize()) && ulNow>pUSocket->m_ulTimeTrack && (ulNow - pUSocket->m_ulTimeTrack)>pUSocket->m_SBAttr.m_ulRecvTimeout)
		{
			if(hwnd == NULL && uMsg == 0 && idEvent == 0)
				pUSocket->OnClosed(seTimedOut);
			else
				::PostMessage(pUSocket->m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, MAKELONG(FD_CLOSE, (WORD)seTimedOut));
			break;
		}
	}
}


/*
#include <iostream>
#include <fstream>
#include "Blowfish.h"
using namespace std;*/

/*
//Function to convert unsigned char to string of length 2
void Char2Hex(const unsigned char ch, char* szHex)
{
	unsigned char byte[2];
	byte[0] = ch/16;
	byte[1] = ch%16;
	for(int i=0; i<2; i++)
	{
		if(byte[i] >= 0 && byte[i] <= 9)
			szHex[i] = '0' + byte[i];
		else
			szHex[i] = 'A' + byte[i] - 10;
	}
	szHex[2] = 0;
}

//Function to convert string of length 2 to unsigned char
void Hex2Char(const char* szHex, unsigned char& rch)
{
	rch = 0;
	for(int i=0; i<2; i++)
	{
		if(*(szHex + i) >='0' && *(szHex + i) <= '9')
			rch = (rch << 4) + (*(szHex + i) - '0');
		else if(*(szHex + i) >='A' && *(szHex + i) <= 'F')
			rch = (rch << 4) + (*(szHex + i) - 'A' + 10);
		else
			break;
	}
}    

//Function to convert string of unsigned chars to string of chars
void CharStr2HexStr(const unsigned char* pucCharStr, char* pszHexStr, int iSize)
{
	int i;
	char szHex[3];
	pszHexStr[0] = 0;
	for(i=0; i<iSize; i++)
	{
		Char2Hex(pucCharStr[i], szHex);
		strcat(pszHexStr, szHex);
	}
}

//Function to convert string of chars to string of unsigned chars
void HexStr2CharStr(const char* pszHexStr, unsigned char* pucCharStr, int iSize)
{
	int i;
	unsigned char ch;
	for(i=0; i<iSize; i++)
	{
		Hex2Char(pszHexStr+2*i, ch);
		pucCharStr[i] = ch;
	}
}*/
