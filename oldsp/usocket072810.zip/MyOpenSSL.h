// MyOpenSSL.h: interface for the CMyOpenSSL class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __UDAPARTS_MY_OPENSSL_H___
#define __UDAPARTS_MY_OPENSSL_H___


#include "uqueue.h"
using namespace SocketProAdapter;

#include <openssl/ssl.h> 

#define STATIC_BUFFER_SIZE (1460 * 12)

class CMyOpenSSL  
{
public:
	CMyOpenSSL(SSL_CTX *pContext, bool bClient);
	virtual ~CMyOpenSSL();

public:
	int DoHandshake(const void *pBuffer, unsigned int nLen, CUQueue &qOut);
	int Encrypt(const void *pBuffer, unsigned int nLen);
	int Decrypt(const void *pBuffer, unsigned int nLen, CUQueue &qOut);
	int Shutdown(CUQueue &qOut);
	int GetSSLState();
	bool IsSSLConnected();
	SSL* GetSSL(){return m_pSSL;}
	BIO* GetBioIn();
	CUQueue& GetOut();

private:
	SSL *m_pSSL;
	BIO *m_pBioIn;
	BIO *m_pBioOut;
	CUQueue m_qOut;
	bool m_bClient;
};

#endif // __UDAPARTS_MY_OPENSSL_H___
