// USocketPool.h : Declaration of the CUSocketPool

#ifndef __USOCKETPOOL_H_
#define __USOCKETPOOL_H_

#include "resource.h"       // main symbols
#include "USocketCP.h"

class CSContext
{
public:
	CSContext()
	{
		m_hEvent = NULL;
		m_dwThreadID = 0;
		m_bLocked = FALSE;
	}

public:
	HANDLE				m_hEvent;
	DWORD				m_dwThreadID;
	BOOL				m_bLocked;
};

struct CHostInfo
{
	BSTR	m_bstrHost;
	int		m_nPort;
	long	m_lSvsID;
	bool	m_bZip;
	BSTR	m_bstrPassword;
};

#define	WM_CONNECT_SERVER	(WM_USER + 0x0222)
/////////////////////////////////////////////////////////////////////////////
// CUSocketPool
class ATL_NO_VTABLE CUSocketPool : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CUSocketPool, &CLSID_USocketPool>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CUSocketPool>,
	public IDispatchImpl<IUSocketPool, &IID_IUSocketPool, &LIBID_USOCKETLib>,
	public CProxy_IUSocketPoolEvents< CUSocketPool >
{
public:
	CUSocketPool()
	{
		m_ulCount = 0;
		m_bSocketsPerThread = 0;
		m_ulIndex = 0;
		m_hEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);
		m_hLock = ::CreateEvent(NULL, FALSE, TRUE, NULL);
	}

	virtual ~CUSocketPool()
	{
		CleanAll();
		::CloseHandle(m_hLock);
		::CloseHandle(m_hEvent);
	}

	HRESULT FinalConstruct();
	void FinalRelease();

DECLARE_REGISTRY_RESOURCEID(IDR_USOCKETPOOL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CUSocketPool)
	COM_INTERFACE_ENTRY(IUSocketPool)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CUSocketPool)
CONNECTION_POINT_ENTRY(DIID__IUSocketPoolEvents)
END_CONNECTION_POINT_MAP()


// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IUSocketPool
public:
	STDMETHOD(get_USockets)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(AddOneThreadIntoPool)();
	STDMETHOD(get_LockedSocketsEx)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_IdleSocketsEx)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_DisconnectedSocketsEx)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_ConnectedSocketsEx)(/*[out, retval]*/ long *pVal);
	STDMETHOD(Connect)(/*[in]*/IUSocket *pIUSocket, /*[in]*/BSTR bstrHost, /*[in]*/long lPort, /*[in]*/long lInitialSvsID, /*[in]*/BSTR bstrUID, /*[in]*/BSTR bstrPWD, /*[in]*/short EncryptionMethod, /*[in, defaultvalue(-1)]*/VARIANT_BOOL bEnableZip);
	STDMETHOD(FindAClosedSocket)(/*[out, retval]*/IUSocket **ppIUSocket);
	STDMETHOD(get_ThreadCounts)(/*[out, retval]*/ BYTE *pVal);
	STDMETHOD(get_LockedSockets)(/*[out, retval]*/ BYTE *pVal);
	STDMETHOD(ShutdownPool)();
	STDMETHOD(get_ConnectedSockets)(/*[out, retval]*/ BYTE *pVal);
	STDMETHOD(get_DisconnectedSockets)(/*[out, retval]*/ BYTE *pVal);
	STDMETHOD(get_IdleSockets)(/*[out, retval]*/ BYTE *pVal);
	STDMETHOD(DisconnectAll)();
	STDMETHOD(ConnectAll)(/*[in]*/BSTR bstrHost, /*[in]*/long lPort, /*[in]*/long lSvsID, /*[in]*/BSTR bstrUID, /*[in]*/BSTR bstrPWD, /*[in]*/short EncryptionMethod, /*[in, defaultvalue(-1)]*/VARIANT_BOOL bEnableZip);
	STDMETHOD(UnlockASocket)(/*[in]*/IUSocket *pIUSocket);
	STDMETHOD(LockASocket)(/*[in]*/long lTimeout, /*[in]*/IUSocket *pIUSocketSameThreadWith, /*[out, retval]*/IUSocket **ppIUSocket);
	STDMETHOD(StartPool)(/*[in]*/BYTE bThreadCount, /*[in]*/BYTE bSocketsPerThread);

	CSimpleMap<IUSocket*, CSContext>	m_mapSocket;
	CSimpleMap<DWORD, DWORD>			m_mapThreadLocks;
	CSimpleMap<HANDLE, DWORD>			m_mapThread;

	bool	m_bMTA;
	unsigned long	m_ulIndex;
	static DWORD WINAPI ThreadFunction(LPVOID lpParameter);


private:
	ULONG GetAvailable(int nIndex);
	ULONG GetAnIdleSocketHandle(IUSocket *pIUSocketSameThreadWith);
	IUSocket *GetSocket(HANDLE hEvent);
	void CleanAll();
	HANDLE		m_hEvent;
	BYTE		m_bSocketsPerThread;
	unsigned long		m_ulCount;
	HANDLE		m_hLock;
	CComAutoCriticalSection	m_cs;
};

#endif //__USOCKETPOOL_H_
