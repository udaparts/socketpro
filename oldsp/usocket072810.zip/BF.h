// BF.h: interface for the CBF class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BF_H__ED05768F_5B87_4BB4_BD28_78C37828FAC2__INCLUDED_)
#define AFX_BF_H__ED05768F_5B87_4BB4_BD28_78C37828FAC2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct BLOWFISH_CTX
{
  unsigned int P[16 + 2];
  unsigned int S[4][256];
};

class CBF  
{
public:
	CBF(unsigned char *strKey, unsigned char nSize);

public:
	// Encrypt/Decrypt Buffer in Place
	void Encrypt(unsigned char* buf, unsigned int nSize);
	void Decrypt(unsigned char* buf, unsigned int nSize);

private:
	void Blowfish_Init(unsigned char *key, int keyLen);
	void Blowfish_Encrypt(unsigned int *xl, unsigned int *xr);
	void Blowfish_Decrypt(unsigned int *xl, unsigned int *xr);
	inline unsigned int F(unsigned int x);

private:
	BLOWFISH_CTX	m_ctx;
	static unsigned long ORIG_P[16 + 2];
	static unsigned long ORIG_S[4][256];
};

#endif // !defined(AFX_BF_H__ED05768F_5B87_4BB4_BD28_78C37828FAC2__INCLUDED_)
