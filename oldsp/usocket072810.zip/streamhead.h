#ifndef	__USOCKET__H__STREAM_HEADER__
#define __USOCKET__H__STREAM_HEADER__

#pragma pack(push,1)

struct CStreamHeader
{
	unsigned short  m_nRequestID;
	unsigned char	m_bTreat;   	
	unsigned char	m_bRatio;
	unsigned long	m_ulLen;
};

#pragma pack(pop)

#endif