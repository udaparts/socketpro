// UMsgQueue.cpp: implementation of the CUMsgQueue class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UMsgQueue.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUMsgQueue::CUMsgQueue()
{

}

CUMsgQueue::~CUMsgQueue()
{

}

ULONG CUMsgQueue::GetCount()
{
	return GetSize()/sizeof(MSG);
}

void CUMsgQueue::PushMsg(const MSG &msg)
{
	Push((const BYTE*)&msg, sizeof(MSG));
}

ULONG CUMsgQueue::PopMsg(MSG &msg)
{
	ATLASSERT(GetSize() >= sizeof(msg));
	return Pop((BYTE*)&msg, sizeof(msg));
}
