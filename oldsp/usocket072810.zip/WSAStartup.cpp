// WSAStartup.cpp: implementation of the CWSAStartup class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WSAStartup.h"
#include "usspiimpl.h"

CWSAStartup	g_WSAStartup;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
ULONG GetOS();

CWSAStartup::CWSAStartup()
{
	memset(this, 0, sizeof(CWSAStartup));
//	g_dwCountSockets = 0;
	m_ulOS = GetOS();
}

CWSAStartup::~CWSAStartup()
{
	KillTimer();
	StopOpenSSL();
	UnloadOpenSSL();
	StopSSPI();
}

bool CWSAStartup::Startup()
{
//	InitZLib();
	g_mapUSocket.RemoveAll();
	m_nVersionRequested = MAKEWORD(2, 2);
	int err = WSAStartup(m_nVersionRequested, &m_wsaData);
	if(err != 0)
		return false;
	if(HIBYTE(m_wsaData.wVersion) !=2 )
		return false;
	return true;
}

void CWSAStartup::Cleanup()
{
//	FreeDeflateGlobals();
//	FreeInflateGlobals();
//	UninitZLib();
	KillTimer();
	g_mapUSocket.RemoveAll();
	int err = WSACleanup();
}

void CWSAStartup::UnloadOpenSSL()
{
	if(m_hSSLEay)
	{
		::FreeLibrary(m_hSSLEay);
		m_hSSLEay=NULL;
	}
	if(m_hLibeay)
	{
		::FreeLibrary(m_hLibeay);
		m_hLibeay=NULL;
	}
	SSL_library_init = NULL;
	SSLv23_method = NULL;
	SSL_load_error_strings = NULL;
	SSL_CTX_new = NULL;
	SSL_CTX_free = NULL;
	SSL_new = NULL;
	SSL_free = NULL;
	SSL_set_fd = NULL;
	SSL_accept = NULL;
	SSL_get_error = NULL;
	SSL_write = NULL;
	SSL_read = NULL;
	SSL_shutdown = NULL;
	SSL_state = NULL;
	SSL_set_connect_state = NULL;
	SSL_set_accept_state = NULL;
	SSL_CTX_use_certificate_file = NULL;
	SSL_CTX_use_PrivateKey_file = NULL;
	SSL_CTX_check_private_key = NULL;
	SSL_get_peer_certificate = NULL;
	SSL_get_current_cipher = NULL;
	SSL_state_string_long = NULL;
	SSL_do_handshake = NULL;
	SSL_want = NULL;
	SSL_pending = NULL;
	SSL_connect = NULL;
	SSL_peek = NULL;
	TLSv1_method = NULL;
	ERR_clear_error = NULL;
	SSL_clear = NULL;
	CRYPTO_free = NULL;
	CRYPTO_malloc = NULL;
	CRYPTO_set_locking_callback = NULL;
	CRYPTO_num_locks = NULL;
	SSL_set_read_ahead = NULL;
	SSL_set_info_callback = NULL;
	SSL_get_fd = NULL;
	ERR_get_error = NULL;
	ERR_error_string = NULL;
	SSL_CTX_ctrl = NULL;

	SSL_set_bio = NULL;
	BIO_read = NULL;
	BIO_write = NULL;
	BIO_ctrl_pending = NULL;
	SSL_get_rbio = NULL;
	SSL_get_wbio = NULL;


//CERT
	BIO_free = NULL;
	BIO_ctrl = NULL;
	BIO_new = NULL;
	BIO_s_mem = NULL;
	BIO_free_all = NULL;

	SSL_get_version = NULL;
	SSL_CIPHER_get_version = NULL;
	SSL_CIPHER_get_name = NULL;
	SSL_CTX_load_verify_locations = NULL;
	SSL_get_verify_result = NULL;
	
	X509_get_pubkey = NULL;
	X509_get_issuer_name = NULL;
	X509_NAME_oneline = NULL;	
	X509_get_subject_name = NULL;
	X509_free = NULL;
	X509_cmp_current_time = NULL;
	X509_verify_cert_error_string = NULL;

	OBJ_nid2sn = NULL;
	OBJ_obj2nid = NULL;
	ASN1_TIME_print = NULL;
	EVP_PKEY_free = NULL;
	BN_num_bits = NULL;
	PEM_write_bio_X509 = NULL;
}

void CWSAStartup::StopSSPI()
{
	CSspiClient::CloseStoreAndUnloadSecurityLibrary();
}

bool CWSAStartup::StartSSPI()
{
	return CSspiClient::LoadSecurityLibraryAndOpenStore();
}

bool CWSAStartup::LoadOpenSSL(bool bUseSSL)
{
	m_hSSLEay=::LoadLibrary(_T("ssleay32.dll"));
	m_hLibeay=::LoadLibrary(_T("libeay32.dll"));
	if(!m_hSSLEay || !m_hLibeay)
	{
		UnloadOpenSSL();
		return false;
	}

	SSL_get_rbio = (PSSL_get_rbio)::GetProcAddress(m_hSSLEay, "SSL_get_rbio");
	SSL_get_wbio = (PSSL_get_wbio)::GetProcAddress(m_hSSLEay, "SSL_get_wbio");
	SSL_set_bio =(PSSL_set_bio)::GetProcAddress(m_hSSLEay, "SSL_set_bio");
	SSL_get_version =(PSSL_get_version)::GetProcAddress(m_hSSLEay, "SSL_get_version");
	SSL_CIPHER_get_version =(PSSL_CIPHER_get_version)::GetProcAddress(m_hSSLEay, "SSL_CIPHER_get_version");
	SSL_CIPHER_get_name =(PSSL_CIPHER_get_name)::GetProcAddress(m_hSSLEay, "SSL_CIPHER_get_name");
	SSL_CTX_load_verify_locations = (PSSL_CTX_load_verify_locations)::GetProcAddress(m_hSSLEay, "SSL_CTX_load_verify_locations");
	SSL_get_verify_result = (PSSL_get_verify_result)::GetProcAddress(m_hSSLEay, "SSL_get_verify_result");

	BIO_free = (PBIO_free)::GetProcAddress(m_hLibeay, "BIO_free");
	BIO_ctrl = (PBIO_ctrl)::GetProcAddress(m_hLibeay, "BIO_ctrl");

	BIO_new = (PBIO_new)::GetProcAddress(m_hLibeay, "BIO_new");
	BIO_s_mem = (PBIO_s_mem)::GetProcAddress(m_hLibeay, "BIO_s_mem");
	BIO_free_all = (PBIO_free_all)::GetProcAddress(m_hLibeay, "BIO_free_all");
	BIO_read = (PBIO_read)::GetProcAddress(m_hLibeay, "BIO_read");
	BIO_write = (PBIO_write)::GetProcAddress(m_hLibeay, "BIO_write");
	BIO_ctrl_pending = (PBIO_ctrl_pending)::GetProcAddress(m_hLibeay, "BIO_ctrl_pending");
	
	X509_get_pubkey = (PX509_get_pubkey)::GetProcAddress(m_hLibeay, "X509_get_pubkey");
	X509_get_issuer_name = (PX509_get_issuer_name)::GetProcAddress(m_hLibeay, "X509_get_issuer_name");
	X509_NAME_oneline = (PX509_NAME_oneline)::GetProcAddress(m_hLibeay, "X509_NAME_oneline");
	X509_get_subject_name = (PX509_get_subject_name)::GetProcAddress(m_hLibeay, "X509_get_subject_name");
	X509_free = (PX509_free)::GetProcAddress(m_hLibeay, "X509_free");
	X509_cmp_current_time = (PX509_cmp_current_time)::GetProcAddress(m_hLibeay, "X509_cmp_current_time");
	X509_verify_cert_error_string =(PX509_verify_cert_error_string)::GetProcAddress(m_hLibeay, "X509_verify_cert_error_string");

	OBJ_nid2sn = (POBJ_nid2sn)::GetProcAddress(m_hLibeay, "OBJ_nid2sn");
	OBJ_obj2nid = (POBJ_obj2nid)::GetProcAddress(m_hLibeay, "OBJ_obj2nid");
	ASN1_TIME_print = (PASN1_TIME_print)::GetProcAddress(m_hLibeay, "ASN1_TIME_print");
	EVP_PKEY_free = (PEVP_PKEY_free)::GetProcAddress(m_hLibeay, "EVP_PKEY_free");
	BN_num_bits = (PBN_num_bits)::GetProcAddress(m_hLibeay, "BN_num_bits");
	PEM_write_bio_X509 = (PPEM_write_bio_X509)::GetProcAddress(m_hLibeay, "PEM_write_bio_X509");

	if(SSL_get_version == NULL || SSL_CIPHER_get_version == NULL || SSL_CIPHER_get_name == NULL || SSL_CTX_load_verify_locations == NULL ||
		BIO_free == NULL || BIO_ctrl == NULL || BIO_new == NULL || BIO_s_mem == NULL || BIO_free_all == NULL ||
		X509_get_pubkey == NULL || X509_get_issuer_name == NULL || X509_NAME_oneline == NULL || X509_get_subject_name == NULL ||
		X509_free == NULL || X509_cmp_current_time == NULL || OBJ_nid2sn == NULL || OBJ_obj2nid == NULL || X509_verify_cert_error_string == NULL ||
		ASN1_TIME_print == NULL || EVP_PKEY_free == NULL || BN_num_bits == NULL || PEM_write_bio_X509 == NULL || SSL_get_verify_result == NULL ||
		BIO_read == NULL || BIO_write == NULL || BIO_ctrl_pending == NULL || SSL_set_bio == NULL || SSL_get_rbio == NULL || SSL_get_wbio == NULL
	)
	{
		UnloadOpenSSL();
		return false;
	}

	ERR_error_string = (PERR_error_string)::GetProcAddress(m_hLibeay, "ERR_error_string");
	ERR_get_error = (PERR_get_error)::GetProcAddress(m_hLibeay, "ERR_get_error");
	ERR_clear_error = (PERR_clear_error)::GetProcAddress(m_hLibeay, "ERR_clear_error");
	TLSv1_method = (PTLSv1_method)::GetProcAddress(m_hSSLEay, "TLSv1_method");
	SSL_set_info_callback = (PSSL_set_info_callback)::GetProcAddress(m_hSSLEay, "SSL_set_info_callback");
	SSL_get_fd =(PSSL_get_fd)::GetProcAddress(m_hSSLEay, "SSL_get_fd");
	SSL_clear =(PSSL_clear)::GetProcAddress(m_hSSLEay, "SSL_clear");
	SSL_peek = (PSSL_peek)::GetProcAddress(m_hSSLEay, "SSL_peek");
	SSL_connect = (PSSL_connect)::GetProcAddress(m_hSSLEay, "SSL_connect");
	SSL_pending	= (PSSL_pending)::GetProcAddress(m_hSSLEay, "SSL_pending");
	SSL_accept = (PSSL_accept)::GetProcAddress(m_hSSLEay, "SSL_accept");
	SSL_want = (PSSL_want)::GetProcAddress(m_hSSLEay, "SSL_want");
	SSL_CTX_check_private_key = (PSSL_CTX_check_private_key)::GetProcAddress(m_hSSLEay, "SSL_CTX_check_private_key");
	SSL_CTX_free = (PSSL_CTX_free)::GetProcAddress(m_hSSLEay, "SSL_CTX_free");
	SSL_CTX_new = (PSSL_CTX_new)::GetProcAddress(m_hSSLEay, "SSL_CTX_new");
	SSL_CTX_use_certificate_file = (PSSL_CTX_use_certificate_file)::GetProcAddress(m_hSSLEay, "SSL_CTX_use_certificate_file");
	SSL_CTX_use_PrivateKey_file = (PSSL_CTX_use_PrivateKey_file)::GetProcAddress(m_hSSLEay, "SSL_CTX_use_PrivateKey_file");
	SSL_CTX_ctrl = (PSSL_CTX_ctrl)::GetProcAddress(m_hSSLEay, "SSL_CTX_ctrl");
	SSL_free = (PSSL_free)::GetProcAddress(m_hSSLEay, "SSL_free");
	SSL_do_handshake = (PSSL_do_handshake)::GetProcAddress(m_hSSLEay, "SSL_do_handshake");
	SSL_get_current_cipher = (PSSL_get_current_cipher)::GetProcAddress(m_hSSLEay, "SSL_get_current_cipher");
	SSL_get_error = (PSSL_get_error)::GetProcAddress(m_hSSLEay, "SSL_get_error");
	SSL_get_peer_certificate = (PSSL_get_peer_certificate)::GetProcAddress(m_hSSLEay, "SSL_get_peer_certificate");
	SSL_library_init = (PSSL_library_init)::GetProcAddress(m_hSSLEay, "SSL_library_init");
	SSL_load_error_strings = (PSSL_load_error_strings)::GetProcAddress(m_hSSLEay, "SSL_load_error_strings");
	SSL_new = (PSSL_new)::GetProcAddress(m_hSSLEay, "SSL_new");
	SSL_read = (PSSL_read)::GetProcAddress(m_hSSLEay, "SSL_read");
	SSL_set_accept_state = (PSSL_set_accept_state)::GetProcAddress(m_hSSLEay, "SSL_set_accept_state");
	SSL_set_connect_state = (PSSL_set_connect_state)::GetProcAddress(m_hSSLEay, "SSL_set_connect_state");
	SSL_set_fd	 = (PSSL_set_fd	)::GetProcAddress(m_hSSLEay, "SSL_set_fd");
	SSL_shutdown = (PSSL_shutdown)::GetProcAddress(m_hSSLEay, "SSL_shutdown");
	SSL_state = (PSSL_state)::GetProcAddress(m_hSSLEay, "SSL_state");
	SSL_state_string_long = (PSSL_state_string_long)::GetProcAddress(m_hSSLEay, "SSL_state_string_long");
	SSL_write = (PSSL_write)::GetProcAddress(m_hSSLEay, "SSL_write");
	SSLv23_method = (PSSLv23_method)::GetProcAddress(m_hSSLEay, "SSLv23_method");
	SSL_set_read_ahead = (PSSL_set_read_ahead)::GetProcAddress(m_hSSLEay, "SSL_set_read_ahead");
	CRYPTO_free = (PCRYPTO_free)::GetProcAddress(m_hLibeay, "CRYPTO_free");
	CRYPTO_malloc = (PCRYPTO_malloc)::GetProcAddress(m_hLibeay, "CRYPTO_malloc");
	CRYPTO_set_locking_callback = (PCRYPTO_set_locking_callback)::GetProcAddress(m_hLibeay, "CRYPTO_set_locking_callback");
	CRYPTO_num_locks = (PCRYPTO_num_locks)::GetProcAddress(m_hLibeay, "CRYPTO_num_locks");

	if( SSL_library_init && SSL_load_error_strings && SSL_CTX_new && ERR_clear_error && CRYPTO_num_locks && ERR_error_string
		&& SSL_CTX_free && SSL_new && SSL_free && SSL_set_fd && SSL_accept && SSL_get_error && CRYPTO_set_locking_callback
		&& SSL_write && SSL_read && SSL_shutdown && SSL_state && SSL_set_connect_state && CRYPTO_malloc && SSL_CTX_ctrl
		&& SSL_set_accept_state && SSL_CTX_use_certificate_file && SSL_CTX_use_PrivateKey_file && ERR_get_error
		&& SSL_CTX_check_private_key && SSL_get_peer_certificate && SSL_get_current_cipher && SSL_set_info_callback
		&& SSL_set_read_ahead
		&& CRYPTO_free && SSL_get_fd
		&& SSL_state_string_long && SSL_do_handshake && SSL_want 
		&& SSL_pending && SSL_connect && SSL_peek)
	{
		if(bUseSSL && SSLv23_method)
			return true;
		if(!bUseSSL && TLSv1_method)
			return true;
	}
	UnloadOpenSSL();
	return false;
}

bool CWSAStartup::StartOpenSSL()
{
	int i;
	if(!SSL_library_init())
		return false;
	if(SSLv23_method)
		m_pMeth = SSLv23_method();
	else
		m_pMeth = TLSv1_method();
	if(!m_pMeth)
	{
		StopOpenSSL();
		return false;
	}
	SSL_load_error_strings();
	m_pCtx = SSL_CTX_new(m_pMeth);
	if(!m_pCtx)
	{
		StopOpenSSL();
		return false;
	}
	SSL_CTX_ctrl(m_pCtx, SSL_CTRL_MODE, SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER, NULL);
	m_pSSLLockHandle = (HANDLE*)CRYPTO_malloc(CRYPTO_num_locks()*sizeof(HANDLE), __FILE__,__LINE__);
	ATLASSERT(m_pSSLLockHandle);
	for(i=0; i<CRYPTO_num_locks(); i++)
	{
		m_pSSLLockHandle[i] = ::CreateMutex(NULL, FALSE, NULL);
		ATLASSERT(m_pSSLLockHandle[i]);
	}

	CRYPTO_set_locking_callback(LockingCallback);
	return true;
}

void CWSAStartup::StopOpenSSL()
{
	if(CRYPTO_set_locking_callback)
		CRYPTO_set_locking_callback(NULL);
	if(m_pSSLLockHandle)
	{
		int i;
		for(i=0; i<CRYPTO_num_locks(); i++)
		{
			::CloseHandle(m_pSSLLockHandle[i]);
		}
		CRYPTO_free(m_pSSLLockHandle); //OPENSSL_free
		m_pSSLLockHandle = NULL;
	}
	if(m_pCtx)
	{
		SSL_CTX_free(m_pCtx);
		m_pCtx=NULL;
	}
	if(m_pMeth)
		m_pMeth=NULL;
}

void CWSAStartup::LockingCallback(int nMode, int nType, const char *strFile, int nLine)
{
	ATLASSERT(nType<g_WSAStartup.CRYPTO_num_locks());
	if(nMode & CRYPTO_LOCK)
	{
		::WaitForSingleObject(g_WSAStartup.m_pSSLLockHandle[nType], INFINITE);
	}
	else
	{
		::ReleaseMutex(g_WSAStartup.m_pSSLLockHandle[nType]);
	}
}

void CWSAStartup::SetTimer()
{
	CAutoLock AutoLock(&g_ucs.m_sec);
	if(m_nTimer && g_mapUSocket.GetSize()/25 == (g_mapUSocket.GetSize()-1)/25)
	{

	}
	else
	{
		KillTimer();
		m_nTimer = ::SetTimer(NULL, 0x10101010, 350*(1 + g_mapUSocket.GetSize()/25), UTimerProc);
	}
}

void CWSAStartup::KillTimer()
{
	CAutoLock AutoLock(&g_ucs.m_sec);
	if(m_nTimer)
	{
		::KillTimer(NULL, m_nTimer);
		m_nTimer = 0;
	}
}
