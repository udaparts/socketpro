// COMWebItem.h: interface for the CCOMWebItem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMWEBITEM_H__199A086C_C49E_4CEC_B14C_94D27BE337F2__INCLUDED_)
#define AFX_COMWEBITEM_H__199A086C_C49E_4CEC_B14C_94D27BE337F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "pluginbase.h"
#include "NPObjectImpBase.h"

#include <atlbase.h>
#include "USocketModule.h"
extern CUSocketModule _Module;
#include <atlcom.h>
#include "umozilla.h"

class CCOMWebItem : 
	public CWebItem,
	public CComObjectRootEx<CComSingleThreadModel>,
	public IMozillaWebItem

{
public:
	CCOMWebItem();
	virtual ~CCOMWebItem();

public:
	BEGIN_COM_MAP(CCOMWebItem)
		COM_INTERFACE_ENTRY(IMozillaWebItem)
	END_COM_MAP()

public:
	HRESULT STDMETHODCALLTYPE HasProperty( 
        /* [in] */ BSTR bstrPropertyName,
        /* [retval][out] */ VARIANT_BOOL *pVal);
    
    HRESULT STDMETHODCALLTYPE HasMethod( 
        /* [in] */ BSTR bstrMethodName,
        /* [retval][out] */ VARIANT_BOOL *pVal);
    
    HRESULT STDMETHODCALLTYPE Invoke( 
        /* [in] */ BSTR bstrMethodName,
        /* [in] */ VARIANT vtParameters,
        /* [retval][out] */ VARIANT *pvtResult);
    
    HRESULT STDMETHODCALLTYPE InvokeWebItem( 
        /* [in] */ BSTR bstrMethodName,
        /* [in] */ VARIANT vtParameters,
        /* [retval][out] */ IMozillaWebItem **ppIMozillaWebItem);
    
    HRESULT STDMETHODCALLTYPE SetException( 
        /* [in] */ BSTR bstrExceptionMessage);
    
    HRESULT STDMETHODCALLTYPE SetProperty(BSTR bstrPropertyName, 
        /* [in] */ VARIANT vtNewValue);
    
    HRESULT STDMETHODCALLTYPE GetProperty( 
        /* [in] */ BSTR bstrPropertyName,
        /* [retval][out] */ VARIANT *pvtValue);

	HRESULT STDMETHODCALLTYPE GetPropertyByIndex( 
        /* [in] */ long lIndex,
        /* [retval][out] */ VARIANT *pvtValue);
    
    HRESULT STDMETHODCALLTYPE GetPropertyWebItem( 
        /* [in] */ BSTR bstrPropertyName,
        /* [retval][out] */ IMozillaWebItem **ppIMozillaWebItem);

    HRESULT STDMETHODCALLTYPE Detach();
    HRESULT STDMETHODCALLTYPE get_Attached( 
        /* [retval][out] */ VARIANT_BOOL *pVal);

	STDMETHOD(get_CreateDataStructure)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_WindowHandle)(/*[out, retval]*/ long *pVal);

public:
	bool m_bWnd;

};

#endif // !defined(AFX_COMWEBITEM_H__199A086C_C49E_4CEC_B14C_94D27BE337F2__INCLUDED_)
