unsigned int qlz_size_decompressed(const char *source);
unsigned int qlz_compress(const void *source, char *destination, unsigned int size);
unsigned int qlz_decompress(const char *source, void *destination);

