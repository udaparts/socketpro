#include "AsyncHandler.h"

CAsyncHandler::CAsyncHandler(CClientSocket *pClientSocket, IAsyncResultsHandler *pIAsyncResultsHandler)
: CAsyncServiceHandler(0, pClientSocket, pIAsyncResultsHandler)
{
	m_PeerJob.m_hSocketPeer = 0;
}

CAsyncHandler::~CAsyncHandler(void)
{

}

unsigned int CAsyncHandler::GetPeer()
{
	CAutoLock al(&g_cs.m_sec);
	return m_PeerJob.m_hSocketPeer;
}

void CAsyncHandler::SetPeer(unsigned int hSocketPeer)
{
	CAutoLock al(&g_cs.m_sec);
	m_PeerJob.m_hSocketPeer = hSocketPeer;
}
