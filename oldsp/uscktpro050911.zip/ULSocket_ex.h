// ULSocket.h: interface for the CULSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ULSOCKET_H__CBA83B27_110A_4DF0_8309_EA8905414B4B__INCLUDED_)
#define AFX_ULSOCKET_H__CBA83B27_110A_4DF0_8309_EA8905414B4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <winsock2.h>
#include "mswsock.h"
#include "usocket.h"
#include "openssl\ssl.h"
#include "uqueue.h"
#include "uscktpro.h"
#include "UThread.h"
#include "BlowfishGA.h"
#include "BF.h"
#include "sspilogon.h"

#include "sspiserver.h"

#include "UMsgQueue.h"
#include "SHA1.h"

#include "UZip.h"

#include "chatroom.h"

#include "MyOpenSSL.h"
//bool IsCanceled();

bool IsRegistered();

/*
unsigned long RetrieveBuffer(SOCKET hSocket, unsigned long ulLen, unsigned char* pBuffer);
unsigned long SendReturnData(SOCKET hSocket, unsigned short usRequestId, unsigned long ulLen, const unsigned char* pBuffer);
bool StartBatching(SOCKET hSocket);
bool CommitBatching(SOCKET hSocket);
bool AbortBatching(SOCKET hSocket);
bool ContinueProcessing(SOCKET hSocket, unsigned short usRequestID);*/

#include <atlbase.h>

#include "MsgHolder.h"


class CRequestArray : public CSimpleArray<unsigned short>
{
public:
	CRequestArray()
	{
	}
	CRequestArray(const CRequestArray& aRequest)
	{
		int n;
		int nCount = aRequest.GetSize();
		for(n=0; n<nCount; n++)
		{
			Add(aRequest[n]);
		}
	}

public:
	CRequestArray& operator=(const CRequestArray& aRequest)
	{
		int n;
		RemoveAll();
		int nCount = aRequest.GetSize();
		for(n=0; n<nCount; n++)
		{
			Add(aRequest[n]);
		}
		return *this;
	}
};

class CSktBase  
{
public:
	CSktBase();
	virtual ~CSktBase();

public:
	bool IsOpen();
	static FARPROC	GetProcAddress(LPCTSTR strOpenSSLFuncName);
	static int GetLastError( );

protected:
	virtual void CloseSocket();

public:
	SOCKET					m_hSocket;
	int						m_nRtn;
	tagEncryptionMethod		m_EncryptionMethod;

	//default to 20*1460
	unsigned long			m_ulStartBlocking;

	bool					m_bZip;
};

class CUClientThreaded;
class CUListener;
class CUThread;

#define UIO_RCV_BUFFER_SIZE		(10*1460)
#define UIO_SND_BUFFER_SIZE		(10*1460)
#define NO_DATA_TRANSFERED		((ULONG)-1)

class CIOPortContext : public OVERLAPPED
{
public:
	CIOPortContext()
	{
		m_RcvWSABuf.len = 0;
		m_RcvWSABuf.buf = NULL;
		m_dwTransfered = 0;
	}

public:
	WSABUF	m_RcvWSABuf;
	DWORD	m_dwTransfered;
};

#define DEFAULT_MAX_HTTP_MSG_SIZE	(128*1024)

struct CHttpReqAttribute
{
	enumHTTPRequest	m_HttpRequest;
	double			m_dHttpVersion;
	bool			m_bKeepAlive;
	unsigned int	m_nKeepAlive;
	unsigned int	m_nResponseCode;
	bool			m_bResponseChunked;
	bool			m_bHeaderSent;
	bool			m_bRequestChunked;
	unsigned int	m_nMaxMessageSize;
	bool			m_bServerMessage;
	CUQueue			m_qRMult;
	bool			m_bAutoPartition;
	unsigned int	m_nSeeked;
	unsigned int	m_nResponseLength;
	unsigned int	m_nRequestLen;
	unsigned long	m_ulChatGroups;
};

class CUClient : public CSktBase  
{
public:
	CUClient();
	virtual ~CUClient();

public:
	const unsigned char* GetMySpecificBytes(unsigned long& ulLen);
	unsigned long	PeekRcvMemory(unsigned char *pBuffer, unsigned long ulBufferSize);
	bool			abortBatching();
	bool			commitBatching();
	bool			startBatching();
	void			ResetBytesIn(unsigned long ulStart = 0, unsigned long *pulHigh = 0);
	void			ResetBytesOut(unsigned long ulStart = 0, unsigned long *pulHigh = 0);
	unsigned long	GetBytesIn(unsigned long *pulHigh = 0);
	unsigned long	GetBytesOut(unsigned long *pulHigh = 0);
	unsigned long	GetCurrentRequestLen();
	unsigned short	GetCurrentRequestId();
	unsigned long	GetLastSndTime();
	unsigned long	GetLastRcvTime();
	unsigned long	GetSndBufferSize();
	unsigned long	GetRcvBufferSize();
	unsigned long	GetSndBytesInQueue();
	unsigned long	GetRcvBytesInQueue();
	unsigned long	GetSvsID();
	unsigned long	GetTotalMemory();
	inline unsigned long	QueryRequestsInQueue();
	unsigned long	GetReqIDsInQueue(unsigned short *pusRequestID, unsigned long ulBufferSize);
	bool			GetSockAddr(unsigned int &nSocketPort, LPSTR& strIPAddress);
	bool			GetPeerName(unsigned int &nPeerPort, LPSTR& strPeerName);
	bool			GetSockOpt(int nOptName, int *pnOptVal, int nLevel=slSocket);
	bool			SetSockOpt(int nOptName, int nOptVal, int nLevel=slSocket);
	bool			IsBatching();
	bool			GetInterfaceAttributes(unsigned long& ulMTU, unsigned long& ulMaxSpeed, unsigned long& ulType, unsigned long &ulMask);
	bool			IOCtl(long *plArgment, long lCommand = iocRead);

	void			ShrinkMemory();
	unsigned long	GetRecvBuffer(unsigned char *pBuffer, unsigned long ulBufferSize);
	unsigned long	sendReturnData(unsigned short usRequestId, unsigned long ulLen, const unsigned char* pBuffer);
	void			Send();
	bool			IsRegistered();
	void			Register(BYTE *pbLock, BYTE *pbKey);
	void			CleanPassword();
	inline void		ZeroTrack();
	virtual void	OnBaseRequestCame(unsigned short usRequestID);
	bool			SetHTTPResponseHeader(const char *strUTF8Header, const char *strUTF8Value);
	void			SetHTTPResponseCode(unsigned int nHTTPResponseCode);

protected:
	virtual void	CloseSocket();
	virtual void	OnRequestArrive(unsigned short usRequestID, unsigned long ulLen) = 0;
	virtual void	OnContinueProcessing(unsigned short usRequestID);

	//native SOCKET messages
	virtual void	OnClose(int nError);
	virtual void	OnReceive(int nError);
	virtual void	OnSend(int nError);
	
	virtual void	OnRequestProcessed(unsigned short usRequestID);

	//SSL Event
	virtual void	OnSSLEvent(int nWhere, int nRtn);

	void			PostProcessOnReceive(int nError);
	void			FakeSwitchToHttp(unsigned long ulSvsID = sidHTTP);

private:
	void			IOPortSend();
	void			IOPortOpenSSLSend();
	void			IOPortRecv();
	void			IOPortSendSSL();
	void			IOPortRecvSSL();
	void			Recv();
	bool			SetSSL();
	inline void		CheckCancel();
	inline void		DebugCheck();
	void			PrepareResponseHeader();
	void			RemoveHTTPResponseHeader(const char *strUTF8Header);
	void			HTTPAutoClose();
	
public:
	bool			m_bRegistered;
//	SSL				*m_pSSL;
	CMyOpenSSL		*m_pSSL;
	unsigned long	m_ulSvsID;
//	BYTE			m_strKey[57];  //used by BlowFish, the max key size is 56 bytes
	BYTE			m_bKeyLen;

	POnReceive		m_OnReceive;
	POnSend			m_OnSend;
	
	//multisvs
	WCHAR			*m_strUID;
	WCHAR			*m_strPassword;
	CSwitchInfo		m_ClientInfo;
	CSwitchInfo		m_ServerInfo;
	unsigned long	m_ulTimeOut;
	unsigned long	m_ulSpeed;
	unsigned long	m_ulAddr;
	
	POnBaseRequestCame		m_OnBaseRequestCame;
	POnIsPermitted			m_OnIsPermitted;
	POnSendReturnData		m_OnSendReturnData;
	POnThreadCreated		m_OnThreadCreated;

	CStreamHeader		m_StreamHeader;
	CUQueue				m_sndQueue;
	CUQueue				m_rcvQueue;
	CUQueue				m_batchQueue;
	CUQueue				m_MySpecificBytes;
	CUQueue				m_tempQueue;
	DWORD				m_dwTimeTrackSnd;
	DWORD				m_dwTimeTrackRcv;
	DWORD				m_dwMaxBuffer;
	CBF					*m_pBlowFish;
	CUThread			*m_pUThread;
	bool				m_bSameEndian;
	bool				m_bProcessingSlowRequest;
	bool				m_bClosing;
	bool				m_bCleanFromSvr;
	CSspiServer			*m_pSspiServer;

	CIOPortContext		m_RcvIOContext;

	CIOPortContext		m_SndIOContext;
	CUQueue				*m_pIOUQueueSnd;
	bool				m_bDropSlow;
	bool				m_bZipping;
	bool				m_bVerify;
	CSHA1				m_Sha1;
	GUID				m_guid;
	tagZipLevel			m_ZipLevel;
	bool				m_bLocal;
	CHttpReqAttribute	m_HttpReqAttribute;
	CWebChatContext		*m_pHttpChatContext;
	LPFN_GETACCEPTEXSOCKADDRS m_lp;

private:
	void Partition(unsigned long len);
	void HandleTooFast();
	void HandleRequest();
	bool HandleUnzip();
	bool HandleEncryption();
	bool HandleHeader();
	void ProcessHTTPRequest();
	char* GetBoundary(unsigned long &ulLen);
	char* GetHTTPPartHead(const char *strBoundary, unsigned long nBlen, unsigned char *strBuffer, unsigned long nLen);

	bool			m_bSendingTooFast;
	__int64			m_llBytesIn;
	__int64			m_llBytesOut;
	bool			m_bBatching;
	friend	CUClientThreaded;
	friend	CUListener;
	friend  LRESULT CALLBACK UWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	friend  void SSLCallback(const SSL *pSSL, int nWhere, int nRtn);
};

class CRegInfo
{
public:
	CRegInfo()
	{
		m_bSmartDevice = false;
		m_bWeb = false;
		m_bJava = false;
		m_bUnix = false;
		m_bOther = false;
		m_bPLG = false;
	}
public:
	CComBSTR m_bstrFileName;
	bool m_bSmartDevice;
	bool m_bWeb;
	bool m_bJava;
	bool m_bUnix;
	bool m_bPLG;
	CComBSTR m_bstrMachineID;
	CComBSTR m_bstrKey;
	bool m_bOther;
};

class CUListener : public CSktBase  
{
public:
	CUListener();
	virtual ~CUListener();

public:
	HWND	GetWin();
	unsigned long GetClientCount();
	CUClient* FindClient(BIO *pBio);
	CUClient* GetClient(UINT nIndex);
	CUClient* FindClient(SOCKET hSocket);
	inline CRITICAL_SECTION* GetCriticalSection()
	{
		return &m_csLock;
	}
	DWORD GetMainThreadID();
	bool CreateAChatGroup(unsigned long ulGroupID, LPCWSTR strDescription);
	unsigned long GetJoinedGroup(const VARIANT &vtGroups);
	unsigned long GetJoinedGroup(SOCKET hSocket);
	unsigned long GetJoinedGroup(unsigned long *pGroup, unsigned long ulSize);

	void GetJoinedGroup(SOCKET hSocket, CSimpleArray<CChatGroup*> &groups);

	//unsigned long GetJoinedGroup(LPCSTR strChatSession, LPCSTR strIpAddr);

	virtual void CloseSocket();
	bool Create(UINT nPort, LPCTSTR lpszSocketAddress=NULL);
	bool Listen(int nMaxBacklog=64);

	bool AddSvsContext(unsigned long ulSvsID, CSvsContext &SvsContext);
	bool AddSlowRequest(unsigned long ulSvsID, unsigned short usRequestID);

//	virtual bool ResetSocketClient(CUClient* pOldUClient, CUClient* pNewUClient);
	CUClientThreaded* CreateClientSocket();
	
	virtual void OnChatRequestArrive(SOCKET hSocket, unsigned short usRequestID, unsigned long ulLen);
	
	bool RemoveADll(HINSTANCE hInstance);
	bool RemoveADll(const wchar_t *strDllFile);
	HINSTANCE AddADll(const wchar_t *strLibFile, int nParam);

	CUClient* PostProcess(unsigned int hSocket);
	bool StartIOPump();
	bool ExistAChatGroup(unsigned long ulGroupID);
	bool NotFindAChatGroup(unsigned long ulGroupID);
	void ShutdownThreadPools();
	void HTTPEnter(CWebChatContext *pWebChatContext);
	void HTTPExit(LPCWSTR strPushSessionId, LPSTR strPeerName, CComBSTR &bstrUserId, CComVariant &vtGroups);
	bool HTTPSendUserMessage(LPCWSTR strPushSessionId, LPSTR strPeerName, LPCWSTR strUserID, const VARIANT& vtMsg);
	bool HTTPSpeak(LPCWSTR strPushSessionId, LPSTR strPeerName, const VARIANT& vtMsg, const VARIANT &vtGroups);
	void CleanWebChat();
	unsigned long GetChatGroups();
	CWebChatContext* HTTPSubscribe(LPCWSTR strPushSessionId, LPSTR strPeerName);
	CWebChatContext* Seek(LPCWSTR strPushSessionId, LPSTR strPeerName);
	void ShutdownHTTP(unsigned int hSocket);
	void Merge(const VARIANT &vtOne, const VARIANT &vtTwo, CUQueue &qMerge);
	void Merge(unsigned long *pGroups, unsigned long ulCount, const VARIANT &vtTwo, CUQueue &qMerge);
	void Merge(const VARIANT &vtOne, CUQueue &qMerge);
	void Merge(unsigned long *pGroups, unsigned long ulCount, CUQueue &qMerge);
	LPFN_GETACCEPTEXSOCKADDRS LoadGetAcceptExSockaddrs(SOCKET hSocket);

protected:
	void SetRegInfo();
	virtual bool Accept();
	virtual void OnAccept(int nError);
	virtual void OnMessage(HWND hWnd, UINT uMsg, WPARAM wParam,  LPARAM lParam);
	virtual void OnTimer(DWORD dwTime);
	static int CALLBACK ConditionFunc(LPWSABUF lpCallerId, LPWSABUF lpCallerData, LPQOS lpSQOS, LPQOS lpGQOS, LPWSABUF lpCalleeId, LPWSABUF lpCalleeData, GROUP *g, DWORD_PTR dwCallbackData);

private:
	bool	CreateWnd();
	bool	StartThreadPools();
	bool	LoadOpenSSLKeyCert();
	static	DWORD WINAPI LThreadProc(LPVOID lpParameter);
	static	DWORD WINAPI MThreadProc(LPVOID lpParameter);
	void	CheckCount();
	void	CleanMutex();
	bool	CheckOther0(bool &bSecond);
	void	CreateMutex(bool bZero);
	void	Enter(CUClientThreaded *pUClient, ULONG ulLen);
	void	XEnter(CUClientThreaded *pUClient, ULONG ulLen, unsigned short usId = idXEnter);
	void	Exit(CUClientThreaded *pUClient, ULONG ulLen, bool bOwn = true);
	void	Exit(LPCWSTR strUserId, LPCWSTR strIpAddr, const VARIANT &vtGroups);
	void	GetAllGroups(CUClientThreaded *pUClient, ULONG ulLen);
	void	GetAllClients(CUClientThreaded *pUClient, ULONG ulLen);
	void	GetAllListeners(CUClientThreaded *pUClient, ULONG ulLen);
	void	SpeakEx(CUClientThreaded *pUClient, ULONG ulLen);
	void	XSpeakEx(CUClientThreaded *pUClient, ULONG ulLen, unsigned short usId = idXSpeakEx);
	void	Speak(CUClientThreaded *pUClient, ULONG ulLen);
	void	XSpeak(CUClientThreaded *pUClient, ULONG ulLen, unsigned short usId = idXSpeak);
	void	SpeakToEx(CUClientThreaded *pUClient, ULONG ulLen);
	void	SpeakTo(CUClientThreaded *pUClient, ULONG ulLen);
	void	SendUserMessage(CUClientThreaded *pUClient, ULONG ulLen);
	void	SendUserMessageEx(CUClientThreaded *pUClient, ULONG ulLen);
	void	GetJoinedClients(ULONG ulGroups, CSimpleArray<SOCKET> &aJoinedClients);
	void	RemoveIdleWebContext();
	void	GetJoinedClients(ULONG *pGroups, ULONG nSize, CSimpleArray<CWebChatContext*> &aJoinedClients);
	void	GetJoinedClients(LPCWSTR strUserId, CSimpleArray<CWebChatContext*> &aJoinedClients);
	CSimpleArray<SOCKET>* XGetJoinedClients(ULONG ulGroups);

public:
	void RemoveAllDlls();

	//default to 0
	unsigned long		m_ulGroupsNotifiedWhenEntering;
	unsigned long		m_ulGroupsNotifiedWhenExiting;
	
	//max idle time (in ms) before a thread suicides, default to 60000 (60 seconds) and shouldn't be less than 1000 (1 second)
	unsigned long		m_ulMaxThreadIdleTimeBeforeSuicide;
	
	//The max connections per client machine before rejecting socket connecting from a client machine, default to 32
	unsigned long		m_ulMaxConnectionsPerClient;

	//Timer interval in ms, default to 1000 (1 second)
	unsigned long		m_ulTimerElapse; 

	//for shrink memory in ms, default to 60000 (60 seconds)
	unsigned long		m_ulSMInterval; 
	
	//check if a client is available after the client has no data transferred, default to 60000 (60 seconds)
	unsigned long		m_ulPingInterval; 
	
	//Recycle global memory, default to 1200000 (1200 seconds)
	unsigned long		m_ulRecycleGlobalMemoryInterval;
	
	//used by SSL23/TLSv1
	char				m_strCertFile[_MAX_PATH+1];
	char				m_strPrivateKeyFile[_MAX_PATH+1];

	unsigned long		m_ulMinSwitchTime;

	POnChatRequestComing	m_OnChatRequestComing;
	POnChatRequestCame		m_OnChatRequestCame;
	POnWinMessage			m_OnWinMessage;
	POnAccept				m_OnAccept;
	POnSSLEvent				m_OnSSLEvent;
	CComBSTR				m_bstrSubject;
	CSimpleMap<unsigned long, CSvsContextEx>	m_mapSvs;
	CSimpleMap<unsigned long, CRequestArray >	m_mapSvsSlowRequest;
	CSimpleArray<HINSTANCE>						m_aLibrary;

	CSimpleArray<CChatGroup>	*m_pChat;
	POnSwitchTo				m_OnSwitchTo;
	POnIsPermitted			m_OnIsPermitted;
	POnClose				m_OnClose;
	POnSend					m_OnSend;
	ULONG					m_ulCleanPoolInterval;
	CSimpleValArray<CUClientThreaded *>	m_aPool;
	bool					m_bRejected;
	CSSPILogon				m_SSPILogon;
	tagAuthenticationMethod	m_am;
	bool					m_bSharedAM;
	bool					m_bMachine;
	bool					m_bRoot;
	CComBSTR				m_strPfxFile;
	EVP_PKEY				*m_pkey;
	X509					*m_pCert;
	CComBSTR				m_strPassword;
	
	//completion port
	bool					m_bUseMessagePump;
	CUMsgQueue				m_UMsgQueue;
	HANDLE					m_hListenThread;
	DWORD					m_dwListenThread;
	HANDLE					m_hCompletionPort;
	CIOPortContext			m_IOPortContext;
	CUQueue					m_IORecvQueue;
	CUQueue					m_queueBlowfish;
	CRegInfo				m_RegInfo;
	
	bool					m_bHTTPServerPush;
	CSimpleArray<CWebChatContext*> m_aChatContext;
	HANDLE					m_hMEvent;
	static CSimpleMap<unsigned long, unsigned long> m_mapAddrCount;
	LPFN_GETACCEPTEXSOCKADDRS m_lp;

private:
	HWND				m_hWnd;
	CRITICAL_SECTION	m_csLock; 
	DWORD				m_dwMainThreadID;
	void				*m_pThreadPool;
	DWORD				m_dwTick;
	DWORD				m_dwLastTimeCount;
	HANDLE				m_h0;
	HANDLE				m_h1;
	HANDLE				m_UniqueName;

	DWORD				m_dwTickStart;
	DWORD				m_dwMThreadId;
	HANDLE				m_hMThread;
	
	friend void CALLBACK UTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime);
	friend LRESULT CALLBACK UWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	friend CUClient;
};

extern CUListener	*g_pSocketSvr;

struct CSockThreadContext
{
public:
	PSLOW_PROCESS			m_SlowProcess;			//Required
	enumThreadApartment		m_enumTA;				//Required
	
	PPRETRANSLATEMESSAGE	m_PreTranslateMessage;	//Optional
	PTHREAD_STARTED			m_ThreadStarted;		//Optional
	PTHREAD_DYING			m_ThreadDying;			//Optional
};

class CUClientThreaded : public CUClient  
{
public:
	CUClientThreaded();
	virtual ~CUClientThreaded();

public:
	bool Enter(unsigned long ulGroup);
	bool Exit();
	bool XEnter(const VARIANT *pvtGroups);
	bool SpeakTo(const VARIANT& vtMsg, CUClientThreaded *pUClientThreaded);
	bool Speak(const VARIANT& vtMsg, unsigned long ulGroups = odAllGroups);
	bool XSpeak(const VARIANT &vtMsg, const VARIANT &vtGroups);
	bool SpeakToEx(const BYTE *pMessage, unsigned long ulLen, CUClientThreaded *pUClientThreaded);
	bool SpeakEx(const BYTE *pMessage, unsigned long ulLen, unsigned long ulGroups = odAllGroups);
	bool XSpeakEx(const BYTE *pMessage, unsigned long ulLen, unsigned long ulGroupCount, const unsigned long *pGroups);
	
	bool SendUserMessage(LPCWSTR strUserID, const VARIANT& vtMsg);
	bool SendUserMessageEx(LPCWSTR strUserID, const BYTE *pMessage, unsigned long ulLen);
	
	bool IsPermitted(unsigned long ulSvsID);

	LPCWSTR	HTTPEnter(VARIANT vtGroups, DWORD dwLeaseTime, const wchar_t *strIpAddr);
	bool	HTTPExit(LPCWSTR strPushSessionId);
	bool	HTTPSendUserMessage(LPCWSTR strPushSessionId, LPCWSTR strUserID, const VARIANT& vtMsg);
	bool	HTTPSpeak(LPCWSTR strPushSessionId, const VARIANT& vtMsg, const VARIANT &vtGroups);
	bool	HTTPSubscribe(const wchar_t* strPushSessionId, unsigned long ulTimeout, const wchar_t *strCrossSiteJSCallback);

protected:
	virtual void OnContinueProcessing(unsigned short usRequestID);
	virtual void OnFastRequestArrive(unsigned short usRequestID, unsigned long ulLen);
	virtual void OnRequestArrive(unsigned short usRequestID, unsigned long ulLen);
	virtual void OnRequestProcessed(unsigned short usRequestID);
	
	//native SOCKET messages
	virtual void	OnClose(int nError);

private:
	bool DoSSPI();
	bool IsSlowRequest(unsigned short usRequestID);
	void SvsSwitch(unsigned long ulLen);
	void RetrieveClientSwitchInfo(unsigned long ulLen);
	
public:
	CSockThreadContext		m_SockThreadContext;
	POnFastRequestArrive	m_OnFastRequestArrive;
	POnRequestProcessed		m_OnRequestProcessed;
	POnClose				m_OnClose;
	POnSwitchTo				m_OnSwitchTo;

	friend				CUListener;
};

#endif // !defined(AFX_ULSOCKET_H__CBA83B27_110A_4DF0_8309_EA8905414B4B__INCLUDED_)
