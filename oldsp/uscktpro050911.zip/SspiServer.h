#ifndef ___SOCKET_SSPI_H_SERVER_HH_
#define ___SOCKET_SSPI_H_SERVER_HH_

#include "sspiinclude.h"

#define	SSL_RCV_BUFFER_SIZE  (8*1024)

class CSspiServer
{
public:
	CSspiServer(void);
	virtual ~CSspiServer(void);

public:
	static bool LoadSecurityLibrary();
	static bool OpenStore(bool bMachine = false, bool bRoot = true);
	static bool OpenStore(LPCWSTR strPfxFile, LPCWSTR strPassword);
	static void CloseStoreAndUnloadSecurityLibrary();
	static bool IsLoaded();
	static SECURITY_STATUS Open(DWORD dwProtocol, LPCSTR strUserName);
	static void FreeCredentials();

public:
	void Close(SOCKET hSocket);
	tagSSLState	GetSSLState();
	int SendData(SOCKET hSocket, const BYTE *pData, ULONG ulLen);
	int SendDataIOPort(SOCKET hSocket, const BYTE *pData, ULONG ulLen);
	SECURITY_STATUS GetDataIOPort(SOCKET hSocket, CUQueue &UQueue);
	SECURITY_STATUS GetData(SOCKET hSocket, CUQueue &UQueue, ULONG ulMaxAllowed);
	SECURITY_STATUS ClientHandshakeLoop(SOCKET hSocket, bool bImpersonateLoggedOnUser = true);
	ULONG GetMaxSize();
	ULONG GetDataInBuffer();

public:
	CtxtHandle						m_hContext;
	static CredHandle				m_hCreds;
	CUQueue							m_UQueueRecv;
	CUQueue							m_UQueueSend;

private:
	tagSSLState						m_SSLState;
	
	
	SecPkgContext_StreamSizes		m_Sizes;
	bool							m_bImpersonateLoggedOnUser;
	static HMODULE					m_hSecurity;
	static PSecurityFunctionTableA	m_pSSPI;
	static HCERTSTORE				m_hMyCertStore;
	static OSVERSIONINFOA			m_VersionInfo;
	void FreeResource();
};

#endif