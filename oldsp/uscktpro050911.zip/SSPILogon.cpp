#include "StdAfx.h"
#include "sspilogon.h"

CSSPILogon::CSSPILogon(void)
{
	AcceptSecurityContext = NULL;
	CompleteAuthToken = NULL;
	DeleteSecurityContext = NULL;
	FreeContextBuffer = NULL;
	FreeCredentialsHandle = NULL;
	
	QuerySecurityPackageInfoW = NULL;
	QuerySecurityPackageInfoA = NULL;
	AcquireCredentialsHandleW = NULL;
	AcquireCredentialsHandleA = NULL;
	InitializeSecurityContextW = NULL;
	InitializeSecurityContextA = NULL;

	m_hModule = NULL;
	m_cbMaxToken = 0;
	memset(&m_VerInfo, 0, sizeof(m_VerInfo));
	m_pClientBuf = NULL;
	m_pServerBuf = NULL;

	m_VerInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
	::GetVersionEx (&m_VerInfo);   // If this fails, something has gone wrong
	m_bNT = (m_VerInfo.dwPlatformId >= VER_PLATFORM_WIN32_NT); //Win2k3, Win2k, WinXP and WinNT
	m_bNTLM = (m_VerInfo.dwMajorVersion <= 4);
}

CSSPILogon::~CSSPILogon(void)
{
	UnloadSecurityDll();
}

void CSSPILogon::UnloadSecurityDll()
{
	m_cbMaxToken = 0;
	if(m_hModule != NULL)
	{
		if(m_pClientBuf != NULL)
		{
			::HeapFree(::GetProcessHeap(), 0, m_pClientBuf);
			m_pClientBuf = NULL;
		}

		if(m_pServerBuf != NULL)
		{
			::HeapFree(::GetProcessHeap(), 0, m_pServerBuf);
			m_pServerBuf = NULL;
		}

		::FreeLibrary(m_hModule);
		AcceptSecurityContext = NULL;
		CompleteAuthToken = NULL;
		DeleteSecurityContext = NULL;
		FreeContextBuffer = NULL;
		FreeCredentialsHandle = NULL;
		
		QuerySecurityPackageInfoW = NULL;
		QuerySecurityPackageInfoA = NULL;
		AcquireCredentialsHandleW = NULL;
		AcquireCredentialsHandleA = NULL;
		InitializeSecurityContextW = NULL;
		InitializeSecurityContextA = NULL;
	}
}

bool CSSPILogon::GenClientContextW(PAUTH_SEQ pAS, PSEC_WINNT_AUTH_IDENTITY_W pAuthIdentity, PVOID pIn, DWORD cbIn, PVOID pOut, PDWORD pcbOut, PBOOL pfDone)
{
	/*++

	Routine Description:

	Optionally takes an input buffer coming from the server and returns
	a buffer of information to send back to the server.  Also returns
	an indication of whether or not the context is complete.

	Return Value:

	Returns true if successful; otherwise false.

	--*/

	SECURITY_STATUS ss;
	TimeStamp       tsExpiry;
	SecBufferDesc   sbdOut;
	SecBuffer       sbOut;
	SecBufferDesc   sbdIn;
	SecBuffer       sbIn;
	ULONG           fContextAttr;
	
	WCHAR			*strPackage;
	if(m_bNTLM)
		strPackage = L"NTLM";
	else
		strPackage = L"Negotiate";

	if (!pAS->fInitialized) {

		ss = AcquireCredentialsHandleW(NULL, 
				strPackage,
				SECPKG_CRED_OUTBOUND, 
				NULL, 
				pAuthIdentity, 
				NULL, 
				NULL,
				&pAS->hcred, 
				&tsExpiry);
		if (ss < 0) {
			//AcquireCredentialsHandle failed
			return false;
		}

		pAS->fHaveCredHandle = TRUE;
	}

	// Prepare output buffer
	sbdOut.ulVersion = 0;
	sbdOut.cBuffers = 1;
	sbdOut.pBuffers = &sbOut;

	sbOut.cbBuffer = *pcbOut;
	sbOut.BufferType = SECBUFFER_TOKEN;
	sbOut.pvBuffer = pOut;

	// Prepare input buffer
	if (pAS->fInitialized)  {
		sbdIn.ulVersion = 0;
		sbdIn.cBuffers = 1;
		sbdIn.pBuffers = &sbIn;

		sbIn.cbBuffer = cbIn;
		sbIn.BufferType = SECBUFFER_TOKEN;
		sbIn.pvBuffer = pIn;
	}

	ss = InitializeSecurityContextW(&pAS->hcred,
			pAS->fInitialized ? &pAS->hctxt : NULL, NULL, 0, 0,
			SECURITY_NATIVE_DREP, pAS->fInitialized ? &sbdIn : NULL,
			0, &pAS->hctxt, &sbdOut, &fContextAttr, &tsExpiry);
	if (ss < 0)  {
		// <winerror.h>
		//InitializeSecurityContext failed
		return false;
	}

	pAS->fHaveCtxtHandle = TRUE;

	// If necessary, complete token
	if (ss == SEC_I_COMPLETE_NEEDED || ss == SEC_I_COMPLETE_AND_CONTINUE) {

		if (CompleteAuthToken) {
			ss = CompleteAuthToken(&pAS->hctxt, &sbdOut);
			if (ss < 0)  {
				//CompleteAuthToken failed;
				return false;
			}
		}
		else {
			//CompleteAuthToken not supported;
			return false;
		}
	}

	*pcbOut = sbOut.cbBuffer;

	if (!pAS->fInitialized)
		pAS->fInitialized = TRUE;

	*pfDone = !(ss == SEC_I_CONTINUE_NEEDED
			|| ss == SEC_I_COMPLETE_AND_CONTINUE );

	return true;
}

bool CSSPILogon::GenClientContextA(PAUTH_SEQ pAS, PSEC_WINNT_AUTH_IDENTITY_A pAuthIdentity, PVOID pIn, DWORD cbIn, PVOID pOut, PDWORD pcbOut, PBOOL pfDone)
{
	/*++

	Routine Description:

	Optionally takes an input buffer coming from the server and returns
	a buffer of information to send back to the server.  Also returns
	an indication of whether or not the context is complete.

	Return Value:

	Returns true if successful; otherwise false.

	--*/

	SECURITY_STATUS ss;
	TimeStamp       tsExpiry;
	SecBufferDesc   sbdOut;
	SecBuffer       sbOut;
	SecBufferDesc   sbdIn;
	SecBuffer       sbIn;
	ULONG           fContextAttr;

	CHAR			*strPackage;
	if(m_bNTLM)
		strPackage = "NTLM";
	else
		strPackage = "Negotiate";

	if (!pAS->fInitialized) {

		ss = AcquireCredentialsHandleA(NULL, 
				strPackage,
				SECPKG_CRED_OUTBOUND, 
				NULL, 
				pAuthIdentity, 
				NULL, 
				NULL,
				&pAS->hcred, 
				&tsExpiry);
		if (ss < 0) {
			//AcquireCredentialsHandle failed
			return false;
		}

		pAS->fHaveCredHandle = TRUE;
	}

	// Prepare output buffer
	sbdOut.ulVersion = 0;
	sbdOut.cBuffers = 1;
	sbdOut.pBuffers = &sbOut;

	sbOut.cbBuffer = *pcbOut;
	sbOut.BufferType = SECBUFFER_TOKEN;
	sbOut.pvBuffer = pOut;

	// Prepare input buffer
	if (pAS->fInitialized)  {
		sbdIn.ulVersion = 0;
		sbdIn.cBuffers = 1;
		sbdIn.pBuffers = &sbIn;

		sbIn.cbBuffer = cbIn;
		sbIn.BufferType = SECBUFFER_TOKEN;
		sbIn.pvBuffer = pIn;
	}

	ss = InitializeSecurityContextA(&pAS->hcred,
			pAS->fInitialized ? &pAS->hctxt : NULL, NULL, 0, 0,
			SECURITY_NATIVE_DREP, pAS->fInitialized ? &sbdIn : NULL,
			0, &pAS->hctxt, &sbdOut, &fContextAttr, &tsExpiry);
	if (ss < 0)  {
		// <winerror.h>
		//InitializeSecurityContext failed
		return false;
	}

	pAS->fHaveCtxtHandle = TRUE;

	// If necessary, complete token
	if (ss == SEC_I_COMPLETE_NEEDED || ss == SEC_I_COMPLETE_AND_CONTINUE) {

		if (CompleteAuthToken) {
			ss = CompleteAuthToken(&pAS->hctxt, &sbdOut);
			if (ss < 0)  {
				//CompleteAuthToken failed;
				return false;
			}
		}
		else {
			//CompleteAuthToken not supported;
			return false;
		}
	}

	*pcbOut = sbOut.cbBuffer;

	if (!pAS->fInitialized)
		pAS->fInitialized = TRUE;

	*pfDone = !(ss == SEC_I_CONTINUE_NEEDED
			|| ss == SEC_I_COMPLETE_AND_CONTINUE );

	return true;
}

bool CSSPILogon::GenServerContext(PAUTH_SEQ pAS, PVOID pIn, DWORD cbIn, PVOID pOut, PDWORD pcbOut, PBOOL pfDone)
{
	/*++
	Routine Description:
	Takes an input buffer coming from the client and returns a buffer
	to be sent to the client.  Also returns an indication of whether or
	not the context is complete.
	Return Value:
	Returns true if successful; otherwise false.

	--*/

   SECURITY_STATUS ss;
   TimeStamp       tsExpiry;
   SecBufferDesc   sbdOut;
   SecBuffer       sbOut;
   SecBufferDesc   sbdIn;
   SecBuffer       sbIn;
   ULONG           fContextAttr;

   if (!pAS->fInitialized) 
   {
		if(AcquireCredentialsHandleW)
		{
			WCHAR			*strPackage;
			if(m_bNTLM)
				strPackage = L"NTLM";
			else
				strPackage = L"Negotiate";

			ss = AcquireCredentialsHandleW(NULL,
				strPackage,
				SECPKG_CRED_INBOUND, NULL, NULL, NULL, NULL, &pAS->hcred,
				&tsExpiry);
		}
		else if(AcquireCredentialsHandleA)
		{
			CHAR			*strPackage;
			if(m_bNTLM)
				strPackage = "NTLM";
			else
				strPackage = "Negotiate";

			ss = AcquireCredentialsHandleA(NULL,
				strPackage,
				SECPKG_CRED_INBOUND, NULL, NULL, NULL, NULL, &pAS->hcred,
				&tsExpiry);
		}
		else
		{
			//
		}
		if (ss < 0) 
		{
			//AcquireCredentialsHandle failed
			return false;
		}

		pAS->fHaveCredHandle = TRUE;
	}

	// Prepare output buffer
	sbdOut.ulVersion = 0;
	sbdOut.cBuffers = 1;
	sbdOut.pBuffers = &sbOut;

	sbOut.cbBuffer = *pcbOut;
	sbOut.BufferType = SECBUFFER_TOKEN;
	sbOut.pvBuffer = pOut;

	// Prepare input buffer
	sbdIn.ulVersion = 0;
	sbdIn.cBuffers = 1;
	sbdIn.pBuffers = &sbIn;

	sbIn.cbBuffer = cbIn;
	sbIn.BufferType = SECBUFFER_TOKEN;
	sbIn.pvBuffer = pIn;

	ss = AcceptSecurityContext(&pAS->hcred,
			pAS->fInitialized ? &pAS->hctxt : NULL, &sbdIn, 0,
			SECURITY_NATIVE_DREP, &pAS->hctxt, &sbdOut, &fContextAttr,
			&tsExpiry);
	if (ss < 0)  
	{
		//AcceptSecurityContext failed
		return false;
	}

	pAS->fHaveCtxtHandle = TRUE;

	// If necessary, complete token
	if (ss == SEC_I_COMPLETE_NEEDED || ss == SEC_I_COMPLETE_AND_CONTINUE) {

		if (CompleteAuthToken) {
			ss = CompleteAuthToken(&pAS->hctxt, &sbdOut);
			if (ss < 0)  {
				fprintf(stderr, "CompleteAuthToken failed with %08X\n", ss);
				return false;
			}
		}
		else {
			//CompleteAuthToken not supported
			return false;
		}
	}

	*pcbOut = sbOut.cbBuffer;

	if (!pAS->fInitialized)
		pAS->fInitialized = TRUE;

	*pfDone = !(ss = SEC_I_CONTINUE_NEEDED
			|| ss == SEC_I_COMPLETE_AND_CONTINUE);

   return true;
}

bool CSSPILogon::Logon(LPCWSTR strDomain, LPCWSTR strUserID, LPCWSTR strPassword)
{
	LoadSecurityDll();
	if(m_hModule == NULL)
		return false;
	
	bool		bSuc = false;
	AUTH_SEQ    asServer   = {0};
	AUTH_SEQ    asClient   = {0};
	BOOL        fDone      = FALSE;
	BOOL        fResult    = FALSE;
	DWORD       cbOut      = 0;
	DWORD       cbIn       = 0;
	
	SEC_WINNT_AUTH_IDENTITY_W ai;
	ai.Domain = (unsigned short*)strDomain;
	if(strDomain == NULL)
	{
		ai.DomainLength = 0;
	}
	else
	{
		ai.DomainLength = (DWORD)::wcslen(strDomain);
	}
    ai.User = (unsigned short*)strUserID;
	if(strUserID == NULL)
	{
		ai.UserLength = 0;
	}
	else
	{
		ai.UserLength = (DWORD)::wcslen(strUserID);
	}
    ai.Password = (unsigned short*)strPassword;
	if(strPassword == NULL)
	{
		ai.PasswordLength = 0;
	}
	else
	{
		ai.PasswordLength = (DWORD)::wcslen(strPassword);
	}
    
	ai.Flags = SEC_WINNT_AUTH_IDENTITY_UNICODE;
	
	do
	{
		memset(m_pClientBuf, 0, m_cbMaxToken);
		memset(m_pServerBuf, 0, m_cbMaxToken);

		// Prepare client message (negotiate) .
		cbOut = m_cbMaxToken;
		if(!GenClientContextW(&asClient, &ai, NULL, 0, m_pClientBuf, &cbOut, &fDone))
			break;
		
		// Prepare server message (challenge) .
		cbIn = cbOut;
		cbOut = m_cbMaxToken;
		if(!GenServerContext(&asServer, m_pClientBuf, cbIn, m_pServerBuf, &cbOut, &fDone))
			break;
		
		// Prepare client message (authenticate) .
		cbIn = cbOut;
		cbOut = m_cbMaxToken;
		if(!GenClientContextW(&asClient, &ai, m_pServerBuf, cbIn, m_pClientBuf, &cbOut, &fDone))
	        break;

		// Prepare server message (authentication) .
		cbIn = cbOut;
		cbOut = m_cbMaxToken;
		if(!GenServerContext(&asServer, m_pClientBuf, cbIn, m_pServerBuf, &cbOut, &fDone))
			break;

		bSuc = true;

	}while (false);
	
	// Clean up resources
    if (asClient.fHaveCtxtHandle)
	{
        DeleteSecurityContext(&asClient.hctxt);
	}

    if (asClient.fHaveCredHandle)
	{
        FreeCredentialsHandle(&asClient.hcred);
	}

    if (asServer.fHaveCtxtHandle)
	{
        DeleteSecurityContext(&asServer.hctxt);
	}

    if (asServer.fHaveCredHandle)
	{
        FreeCredentialsHandle(&asServer.hcred);
	}

	return bSuc;
}

bool CSSPILogon::Logon(LPCSTR strDomain, LPCSTR strUserID, LPCSTR strPassword)
{
	LoadSecurityDll();
	if(m_hModule == NULL)
		return false;
	
	bool		bSuc = false;
	AUTH_SEQ    asServer   = {0};
	AUTH_SEQ    asClient   = {0};
	BOOL        fDone      = FALSE;
	BOOL        fResult    = FALSE;
	DWORD       cbOut      = 0;
	DWORD       cbIn       = 0;
	
	SEC_WINNT_AUTH_IDENTITY_A ai;
	ai.Domain = (unsigned char *)strDomain;
	if(strDomain == NULL)
	{
		ai.DomainLength = 0;
	}
	else
	{
		ai.DomainLength = (DWORD)::strlen(strDomain);
	}
    ai.User = (unsigned char *)strUserID;
	if(strUserID == NULL)
	{
		ai.UserLength = 0;
	}
	else
	{
		ai.UserLength = (DWORD)::strlen(strUserID);
	}
    ai.Password = (unsigned char *)strPassword;
	if(strPassword == NULL)
	{
		ai.PasswordLength = 0;
	}
	else
	{
		ai.PasswordLength = (DWORD)::strlen(strPassword);
	}
    
	ai.Flags = SEC_WINNT_AUTH_IDENTITY_ANSI;
	
	do
	{
		memset(m_pClientBuf, 0, m_cbMaxToken);
		memset(m_pServerBuf, 0, m_cbMaxToken);

		// Prepare client message (negotiate) .
		cbOut = m_cbMaxToken;
		if(!GenClientContextA(&asClient, &ai, NULL, 0, m_pClientBuf, &cbOut, &fDone))
			break;
		
		// Prepare server message (challenge) .
		cbIn = cbOut;
		cbOut = m_cbMaxToken;
		if(!GenServerContext(&asServer, m_pClientBuf, cbIn, m_pServerBuf, &cbOut, &fDone))
			break;
		
		// Prepare client message (authenticate) .
		cbIn = cbOut;
		cbOut = m_cbMaxToken;
		if(!GenClientContextA(&asClient, &ai, m_pServerBuf, cbIn, m_pClientBuf, &cbOut, &fDone))
	        break;

		// Prepare server message (authentication) .
		cbIn = cbOut;
		cbOut = m_cbMaxToken;
		if(!GenServerContext(&asServer, m_pClientBuf, cbIn, m_pServerBuf, &cbOut, &fDone))
			break;

		bSuc = true;

	}while (false);
	
	// Clean up resources
    if (asClient.fHaveCtxtHandle)
	{
        DeleteSecurityContext(&asClient.hctxt);
	}

    if (asClient.fHaveCredHandle)
	{
        FreeCredentialsHandle(&asClient.hcred);
	}

    if (asServer.fHaveCtxtHandle)
	{
        DeleteSecurityContext(&asServer.hctxt);
	}

    if (asServer.fHaveCredHandle)
	{
        FreeCredentialsHandle(&asServer.hcred);
	}
	return bSuc;
}

void CSSPILogon::LoadSecurityDll()
{
	if(m_hModule == NULL)
	{
		if (m_VerInfo.dwPlatformId == VER_PLATFORM_WIN32_NT &&
			m_VerInfo.dwMajorVersion == 4 &&
			m_VerInfo.dwMinorVersion == 0)
		{
			m_hModule = ::LoadLibrary(_T("security.dll"));
		}
		else
		{
			m_hModule = ::LoadLibrary(_T("secur32.dll"));
		}
		
		if(m_hModule == NULL)
			return;

		AcceptSecurityContext = (ACCEPT_SECURITY_CONTEXT_FN)::GetProcAddress(m_hModule, "AcceptSecurityContext");
		DeleteSecurityContext = (DELETE_SECURITY_CONTEXT_FN)::GetProcAddress(m_hModule, "DeleteSecurityContext");
		FreeContextBuffer = (FREE_CONTEXT_BUFFER_FN)::GetProcAddress(m_hModule, "FreeContextBuffer");
		FreeCredentialsHandle = (FREE_CREDENTIALS_HANDLE_FN)::GetProcAddress(m_hModule, "FreeCredentialsHandle");
		
		if(AcceptSecurityContext != NULL && DeleteSecurityContext != NULL && FreeContextBuffer != NULL && FreeCredentialsHandle != NULL)
		{

		}
		else
		{
			UnloadSecurityDll();
			return;
		}

		// CompleteAuthToken is not present on Windows 9x Secur32.dll
		// Do not check for the availablity of the function if it is NULL;
		CompleteAuthToken = (COMPLETE_AUTH_TOKEN_FN)::GetProcAddress(m_hModule, "CompleteAuthToken");

		if(m_VerInfo.dwPlatformId >= VER_PLATFORM_WIN32_NT) //Win2k3, Win2k, WinXP and WinNT
		{
			PSecPkgInfoW pSPI = NULL;
			AcquireCredentialsHandleW = (ACQUIRE_CREDENTIALS_HANDLE_FN_W)::GetProcAddress(m_hModule, "AcquireCredentialsHandleW");
			InitializeSecurityContextW = (INITIALIZE_SECURITY_CONTEXT_FN_W)::GetProcAddress(m_hModule, "InitializeSecurityContextW");
			QuerySecurityPackageInfoW = (QUERY_SECURITY_PACKAGE_INFO_FN_W)::GetProcAddress(m_hModule, "QuerySecurityPackageInfoW");
			
			if(CompleteAuthToken == NULL || QuerySecurityPackageInfoW == NULL || InitializeSecurityContextW == NULL || QuerySecurityPackageInfoW == NULL)
			{
				UnloadSecurityDll();
				return;
			}
			
			WCHAR			*strPackage;
			if(m_bNTLM)
				strPackage = L"NTLM";
			else
				strPackage = L"Negotiate";

			if(QuerySecurityPackageInfoW(strPackage, &pSPI) == SEC_E_OK)
			{
				m_cbMaxToken = pSPI->cbMaxToken;
				FreeContextBuffer(pSPI);
			}
			else
			{
				UnloadSecurityDll();
				return;
			}
		}
		else //WinMe, Win95, Win98
		{
			m_bNT = false;
		}
		{
			PSecPkgInfoA pSPI = NULL;
			AcquireCredentialsHandleA = (ACQUIRE_CREDENTIALS_HANDLE_FN_A)::GetProcAddress(m_hModule, "AcquireCredentialsHandleA");
			InitializeSecurityContextA = (INITIALIZE_SECURITY_CONTEXT_FN_A)::GetProcAddress(m_hModule, "InitializeSecurityContextA");
			QuerySecurityPackageInfoA = (QUERY_SECURITY_PACKAGE_INFO_FN_A)::GetProcAddress(m_hModule, "QuerySecurityPackageInfoA");
			if(!m_bNT)
			{
				if(QuerySecurityPackageInfoA == NULL || InitializeSecurityContextA == NULL || QuerySecurityPackageInfoA == NULL)
				{
					UnloadSecurityDll();
					return;
				}
				CHAR			*strPackage;
				if(m_bNTLM)
					strPackage = "NTLM";
				else
					strPackage = "Negotiate";

				if(QuerySecurityPackageInfoA(strPackage, &pSPI) == SEC_E_OK)
				{
					m_cbMaxToken = pSPI->cbMaxToken;
					FreeContextBuffer(pSPI);
				}
				else
				{
					UnloadSecurityDll();
					return;
				}
			}
		}

		// Allocate buffers for client and server messages
		m_pClientBuf = ::HeapAlloc(::GetProcessHeap(), HEAP_ZERO_MEMORY, m_cbMaxToken);
		m_pServerBuf = ::HeapAlloc(::GetProcessHeap(), HEAP_ZERO_MEMORY, m_cbMaxToken);

		if(m_pClientBuf == NULL || m_pServerBuf == NULL)
		{
			UnloadSecurityDll();
			return;
		}
	}
}
