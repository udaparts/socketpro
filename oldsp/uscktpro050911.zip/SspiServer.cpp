#include "StdAfx.h"
#include "sspiserver.h"
#include "ULSocket.h"
//#include <iostream.h>

HMODULE CSspiServer::m_hSecurity = NULL;
PSecurityFunctionTable CSspiServer::m_pSSPI = NULL;
HCERTSTORE CSspiServer::m_hMyCertStore = NULL;
CredHandle CSspiServer::m_hCreds;
OSVERSIONINFOA CSspiServer::m_VersionInfo;

extern CUListener	*g_pSocketSvr;
extern CSimpleMap<SOCKET, CUClient*> g_mapUClient;
extern CUMsgQueue	g_UMsgQueue;

CSspiServer::CSspiServer(void)
{
	ZeroMemory(&m_hContext, sizeof(m_hContext));
	m_SSLState = ssUnknown;
	ZeroMemory(&m_Sizes, sizeof(m_Sizes));
	m_bImpersonateLoggedOnUser = false;
}

CSspiServer::~CSspiServer(void)
{
	FreeResource();
}

bool CSspiServer::IsLoaded()
{
	return (m_hSecurity != NULL);
}

void CSspiServer::Close(SOCKET hSocket)
{
	m_UQueueSend.SetSize(0);
	m_UQueueRecv.SetSize(0);
	if(m_hContext.dwLower != 0 || m_hContext.dwUpper != 0)
	{
		ATLASSERT(IsLoaded());
		do
		{
			DWORD           dwType;
			char			*pbMessage;
			DWORD           cbMessage;
			SecBufferDesc   OutBuffer;
			SecBuffer       OutBuffers[1];
			DWORD           dwSSPIFlags;
			DWORD           dwSSPIOutFlags;
			TimeStamp       tsExpiry;
			DWORD           Status;
			dwType = SCHANNEL_SHUTDOWN;
			OutBuffers[0].pvBuffer   = &dwType;
			OutBuffers[0].BufferType = SECBUFFER_TOKEN;
			OutBuffers[0].cbBuffer   = sizeof(dwType);

			OutBuffer.cBuffers  = 1;
			OutBuffer.pBuffers  = OutBuffers;
			OutBuffer.ulVersion = SECBUFFER_VERSION;
			Status = m_pSSPI->ApplyControlToken(&m_hContext, &OutBuffer);
			if(FAILED(Status))
				break;
			dwSSPIFlags =   ASC_REQ_SEQUENCE_DETECT     |
                    ASC_REQ_REPLAY_DETECT       |
                    ASC_REQ_CONFIDENTIALITY     |
                    ASC_REQ_EXTENDED_ERROR      |
                    ASC_REQ_ALLOCATE_MEMORY     |
                    ASC_REQ_STREAM;

			OutBuffers[0].pvBuffer   = NULL;
			OutBuffers[0].BufferType = SECBUFFER_TOKEN;
			OutBuffers[0].cbBuffer   = 0;

			OutBuffer.cBuffers  = 1;
			OutBuffer.pBuffers  = OutBuffers;
			OutBuffer.ulVersion = SECBUFFER_VERSION;

			Status = m_pSSPI->AcceptSecurityContext(
							&m_hCreds,
							&m_hContext,
							NULL,
							dwSSPIFlags,
							SECURITY_NATIVE_DREP,
							NULL,
							&OutBuffer,
							&dwSSPIOutFlags,
							&tsExpiry);
			if(FAILED(Status) || hSocket <= 0)
				break;
			pbMessage = (char*)OutBuffers[0].pvBuffer;
			cbMessage = OutBuffers[0].cbBuffer;
			if(pbMessage != NULL && cbMessage != 0)
			{
				int cbData = send(hSocket, pbMessage, cbMessage, 0);
				// Free output buffer.
				m_pSSPI->FreeContextBuffer(pbMessage);
				if(cbData <= 0)
				{
					break;
				}
			}
		}while(false);
	}
	m_SSLState = ssUnknown;
	FreeResource();
	ZeroMemory(&m_Sizes, sizeof(m_Sizes));
}

SECURITY_STATUS CSspiServer::ClientHandshakeLoop(SOCKET hSocket, bool bImpersonateLoggedOnUser)
{
	SECURITY_STATUS scRet = SEC_E_OK;
	SecBufferDesc   InBuffer;
    SecBuffer       InBuffers[2];
    SecBufferDesc   OutBuffer;
    SecBuffer       OutBuffers[1];
    DWORD           dwSSPIFlags = 0;
    DWORD           dwSSPIOutFlags = 0;
    TimeStamp       tsExpiry;
    int				nData;
	CHAR			IoBuffer[IO_BUFFER_SIZE] = {0};
	int				err = 0;
	DWORD			dwFlags = 0;
	bool			bBreak = false;

    dwSSPIFlags =   ASC_REQ_SEQUENCE_DETECT |
                    ASC_REQ_REPLAY_DETECT |
                    ASC_REQ_CONFIDENTIALITY |
                    ASC_REQ_EXTENDED_ERROR |
                    ASC_REQ_ALLOCATE_MEMORY |
                    ASC_REQ_STREAM;

	scRet = SEC_I_CONTINUE_NEEDED;
	while(scRet == SEC_I_CONTINUE_NEEDED        ||
          scRet == SEC_E_INCOMPLETE_MESSAGE     ||
          scRet == SEC_I_INCOMPLETE_CREDENTIALS) 
	{
		m_SSLState = ssHandshaking;
		
		do
		{
			//Read data from server.
			nData = ::recv(hSocket, IoBuffer, sizeof(IoBuffer), 0);
			if(nData > 0)
			{
				m_UQueueRecv.Push((BYTE*)IoBuffer, nData);
			}
		}while(nData == sizeof(IoBuffer));
		

		if(m_UQueueRecv.GetSize() == 0)
		{
			return SEC_E_OK;
		}
		
		// Set up the input buffers. Buffer 0 is used to pass in data
		// received from the server. Schannel will consume some or all
		// of this. Leftover data (if any) will be placed in buffer 1 and
		// given a buffer type of SECBUFFER_EXTRA.
		InBuffers[0].pvBuffer   = (void*)m_UQueueRecv.GetBuffer();
		InBuffers[0].cbBuffer   = m_UQueueRecv.GetSize();
		InBuffers[0].BufferType = SECBUFFER_TOKEN;

		InBuffers[1].pvBuffer   = NULL;
		InBuffers[1].cbBuffer   = 0;
		InBuffers[1].BufferType = SECBUFFER_EMPTY;

		InBuffer.cBuffers       = 2;
		InBuffer.pBuffers       = InBuffers;
		InBuffer.ulVersion      = SECBUFFER_VERSION;

		// Set up the output buffers. These are initialized to NULL
		// so as to make it less likely we'll attempt to free random
		// garbage later.
		OutBuffers[0].pvBuffer  = NULL;
		OutBuffers[0].BufferType= SECBUFFER_TOKEN;
		OutBuffers[0].cbBuffer  = 0;

		OutBuffer.cBuffers      = 1;
		OutBuffer.pBuffers      = OutBuffers;
		OutBuffer.ulVersion     = SECBUFFER_VERSION;
		
		bool bInit = (m_hContext.dwLower == 0 && m_hContext.dwUpper == 0);
		scRet = m_pSSPI->AcceptSecurityContext(
                        &m_hCreds,
                        (bInit ? NULL : &m_hContext),
                        &InBuffer,
                        dwSSPIFlags,
                        SECURITY_NATIVE_DREP,
                        (bInit ? &m_hContext : NULL),
                        &OutBuffer,
                        &dwSSPIOutFlags,
                        &tsExpiry);
		
		// If InitializeSecurityContext was successful (or if the error was 
		// one of the special extended ones), send the contends of the output
		// buffer to the server.
		if(scRet == SEC_E_OK || scRet == SEC_I_CONTINUE_NEEDED ||
			FAILED(scRet) && (dwSSPIOutFlags & ISC_RET_EXTENDED_ERROR))
		{
			if(OutBuffers[0].cbBuffer != 0 && OutBuffers[0].pvBuffer != NULL)
			{
				
				if(!g_pSocketSvr->m_bUseMessagePump)
				{
					CUClient *pClient = g_mapUClient.Lookup(hSocket);
					memset(&pClient->m_RcvIOContext, 0, sizeof(OVERLAPPED));
					err = ::WSARecv(hSocket, &pClient->m_RcvIOContext.m_RcvWSABuf, 1, &pClient->m_RcvIOContext.m_dwTransfered,
						&dwFlags, &pClient->m_RcvIOContext, NULL);
					ATLASSERT(err == -1);
					if(err == -1)
					{
						err = ::WSAGetLastError();
						ATLASSERT(err == WSA_IO_PENDING);
						pClient->m_RcvIOContext.m_dwTransfered = NO_DATA_TRANSFERED;
					}
					bBreak = true;
				}

				nData = ::send(hSocket,
								(char*)OutBuffers[0].pvBuffer,
								OutBuffers[0].cbBuffer,
								0);
				m_pSSPI->FreeContextBuffer(OutBuffers[0].pvBuffer);
				if(nData == SOCKET_ERROR || nData == 0)
				{
					scRet = SEC_E_INTERNAL_ERROR;
					break;
				}
				OutBuffers[0].pvBuffer = NULL;
			}
		}

		if(scRet == SEC_E_INCOMPLETE_MESSAGE)
        {
            continue;
        }
		// If InitializeSecurityContext returned SEC_E_OK, then the 
		// handshake completed successfully.
		if(scRet == SEC_E_OK)
		{
			m_bImpersonateLoggedOnUser = false;
			m_SSLState = ssFinished;
			if(bImpersonateLoggedOnUser)
			{
				HANDLE hUserToken = NULL;
				scRet = m_pSSPI->QuerySecurityContextToken(&m_hContext, &hUserToken);
				if(SUCCEEDED(scRet))
				{
					if(ImpersonateLoggedOnUser(hUserToken))
					{
						m_bImpersonateLoggedOnUser = true;
					}
				}
				scRet = SEC_E_OK;
			}
		}

		if(InBuffers[1].BufferType == SECBUFFER_EXTRA )
        {
			ATLASSERT(m_UQueueRecv.GetSize() > InBuffers[1].cbBuffer);
			ULONG ulSent = m_UQueueRecv.GetSize() - InBuffers[1].cbBuffer;
			m_UQueueRecv.Pop(ulSent);
        }
        else
        {
            m_UQueueRecv.SetSize(0);
        }
		if(bBreak)
		{
			break;
		}
	}
	if(FAILED(scRet))
	{
		m_pSSPI->DeleteSecurityContext(&m_hContext);
		ZeroMemory(&m_hContext, sizeof(m_hContext));
	}
	return scRet;
}

ULONG CSspiServer::GetDataInBuffer()
{
	return m_UQueueSend.GetSize();
}

int CSspiServer::SendDataIOPort(SOCKET hSocket, const BYTE *pData, ULONG ulLen)
{
	int err;
	unsigned long ulSent = 0;
	ATLASSERT(m_SSLState == ssFinished);
	SecBufferDesc   Message;
 //   SECURITY_STATUS scRet;
	SecBuffer       Buffers[4];
	GetMaxSize();

#ifdef _DEBUG
	SecBuffer		*pExtraBuffer;
#endif

	while(m_UQueueSend.GetSize() > 0)
	{
		int nRtn = ::send(hSocket,
				  (char*)m_UQueueSend.GetBuffer(),
				  m_UQueueSend.GetSize(),
				  0);
		if(nRtn > 0)
		{
			m_UQueueSend.Pop(nRtn);
			if (m_UQueueSend.GetSize() > 0)
				break;
		}
		else if(nRtn == -1)
		{
			return -1;
		}
	}
	if((ulLen == 0 || pData == NULL))
		return 0;
	CUClient *pClient = g_mapUClient.Lookup(hSocket);
	if(m_UQueueSend.GetSize() == 0)
	{
		ATLASSERT(ulLen <= m_Sizes.cbMaximumMessage);
		Buffers[0].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(0);
		Buffers[0].cbBuffer     = m_Sizes.cbHeader;
		Buffers[0].BufferType   = SECBUFFER_STREAM_HEADER;
		::memset(Buffers[0].pvBuffer, 0, m_Sizes.cbHeader);
		m_UQueueSend.SetSize(m_Sizes.cbHeader);
		m_UQueueSend.Push(pData, ulLen);
		Buffers[1].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(m_Sizes.cbHeader);
		Buffers[1].cbBuffer     = ulLen;
		Buffers[1].BufferType   = SECBUFFER_DATA;
		Buffers[2].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(m_UQueueSend.GetSize());
		Buffers[2].cbBuffer     = m_Sizes.cbTrailer;
		Buffers[2].BufferType   = SECBUFFER_STREAM_TRAILER;
		::memset(Buffers[2].pvBuffer, 0, m_Sizes.cbTrailer);
		Buffers[3].BufferType   = SECBUFFER_EMPTY;
		Buffers[3].cbBuffer = 0;
		Buffers[3].pvBuffer = NULL;
		Message.ulVersion       = SECBUFFER_VERSION;
		Message.cBuffers        = 4;
		Message.pBuffers        = Buffers;
		if(m_VersionInfo.dwMajorVersion == 4 && m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
			err = ((ENCRYPT_MESSAGE_FN)(m_pSSPI->Reserved3))(&m_hContext, 0, &Message, 0);
		else
			err = m_pSSPI->EncryptMessage(&m_hContext, 0, &Message, 0);
		if(FAILED(err))
		{
			ATLASSERT(FALSE);
			::SetLastError(err);
			return -1;
		}

#ifdef _DEBUG
		pExtraBuffer = NULL;
		int i;
		for (i = 1; i < 4; i++) 
		{
			if (pExtraBuffer == NULL && Buffers[i].BufferType == SECBUFFER_EXTRA) 
			{
				pExtraBuffer = &Buffers[i];
			}
		}
		ATLASSERT(pExtraBuffer == NULL);
#endif
		
		m_UQueueSend.SetSize(Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
		ATLASSERT(m_Sizes.cbHeader == Buffers[0].cbBuffer);
		ATLASSERT(ulLen == Buffers[1].cbBuffer);
		//	ATLASSERT(Buffers[2].cbBuffer == m_Sizes.cbTrailer);
		ulSent = ulLen;
	}
	while(m_UQueueSend.GetSize() > 0)
	{
		int nRtn = ::send(hSocket,
				  (char*)m_UQueueSend.GetBuffer(),
				  m_UQueueSend.GetSize(),
				  0);
		if(nRtn > 0)
		{
			m_UQueueSend.Pop(nRtn);
		}
		else if(nRtn == -1)
		{
			m_UQueueSend.SetHeadPosition();
			if(m_UQueueSend.GetSize() > 0)
			{
				//this is a work arroud to replace the below commented code
				MSG msg;
				msg.time = 1;
				msg.wParam = (WPARAM)pClient;
				CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
				g_UMsgQueue.PushMsg(msg);
				SetEvent(g_pSocketSvr->m_hMEvent);
			}
			break;
		}
	}
/*	while(m_UQueueSend.GetSize() > 0)
	{
		memset(&pClient->m_SndIOContext, 0, sizeof(OVERLAPPED));
		pClient->m_SndIOContext.m_dwTransfered = 0;
		pClient->m_SndIOContext.m_RcvWSABuf.buf = (char*)m_UQueueSend.GetBuffer();
		pClient->m_SndIOContext.m_RcvWSABuf.len = m_UQueueSend.GetSize();
		err = ::WSASend(pClient->m_hSocket, &pClient->m_SndIOContext.m_RcvWSABuf, 1, &pClient->m_SndIOContext.m_dwTransfered, 0, &pClient->m_SndIOContext, NULL); 
		if(err == -1)
		{
			err = ::WSAGetLastError();
			if(err == WSA_IO_PENDING)
			{
				pClient->m_SndIOContext.m_dwTransfered = NO_DATA_TRANSFERED;
				ATLTRACE("++++ Data to be sent = %d ++++\n", m_UQueueSend.GetSize());
				return ulSent;
			}
			else //if(err != 0)
			{
				ATLTRACE("xxx Data sent with error %d xxx\n", err);
				return -1;
			}
		}
		else if(pClient->m_SndIOContext.m_dwTransfered>0)
		{
			ATLASSERT(pClient->m_SndIOContext.m_dwTransfered == pClient->m_SndIOContext.InternalHigh);
			ATLTRACE("--- Data sent = %d ---\n", pClient->m_SndIOContext.m_dwTransfered);
			m_UQueueSend.Pop(pClient->m_SndIOContext.m_dwTransfered);
			m_UQueueSend.SetHeadPosition();
		}
	}*/
//	m_UQueueSend.CleanTrack();
	return ulSent;
}

int CSspiServer::SendData(SOCKET hSocket, const BYTE *pData, ULONG ulLen)
{
	int nRtn;
	ATLASSERT(m_SSLState == ssFinished);
	SecBufferDesc   Message;
    SECURITY_STATUS scRet;
	SecBuffer       Buffers[4];

#ifdef _DEBUG
	SecBuffer		*pDataBuffer;
	SecBuffer		*pExtraBuffer;
#endif
	
	while(m_UQueueSend.GetSize() > 0)
	{
		nRtn = ::send(hSocket,
				  (char*)m_UQueueSend.GetBuffer(),
				  m_UQueueSend.GetSize(),
				  0);
		if(nRtn > 0)
		{
			m_UQueueSend.Pop(nRtn);
		}
		else if(nRtn == -1)
		{
			return -1;
		}
	}

	if((ulLen == 0 || pData == NULL) && m_UQueueSend.GetSize() == 0)
		return 0;

	GetMaxSize();
	ATLASSERT(ulLen <= m_Sizes.cbMaximumMessage);
	Buffers[0].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(0);
    Buffers[0].cbBuffer     = m_Sizes.cbHeader;
    Buffers[0].BufferType   = SECBUFFER_STREAM_HEADER;
	::memset(Buffers[0].pvBuffer, 0, m_Sizes.cbHeader);
	m_UQueueSend.SetSize(m_Sizes.cbHeader);
	m_UQueueSend.Push(pData, ulLen);
	Buffers[1].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(m_Sizes.cbHeader);
    Buffers[1].cbBuffer     = ulLen;
    Buffers[1].BufferType   = SECBUFFER_DATA;
	Buffers[2].pvBuffer     = (BYTE*)m_UQueueSend.GetBuffer(m_UQueueSend.GetSize());
    Buffers[2].cbBuffer     = m_Sizes.cbTrailer;
    Buffers[2].BufferType   = SECBUFFER_STREAM_TRAILER;
	::memset(Buffers[2].pvBuffer, 0, m_Sizes.cbTrailer);
	Buffers[3].BufferType   = SECBUFFER_EMPTY;
    Message.ulVersion       = SECBUFFER_VERSION;
    Message.cBuffers        = 4;
    Message.pBuffers        = Buffers;
	if(m_VersionInfo.dwMajorVersion == 4 && m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
		scRet = ((ENCRYPT_MESSAGE_FN)(m_pSSPI->Reserved3))(&m_hContext, 0, &Message, 0);
	else
		scRet = m_pSSPI->EncryptMessage(&m_hContext, 0, &Message, 0);
	if(FAILED(scRet))
    {
		::SetLastError(scRet);
        return -1;
    }

#ifdef _DEBUG
	pDataBuffer  = NULL;
	pExtraBuffer = NULL;
	for (int i = 1; i < 4; i++) 
	{
		if (pDataBuffer == NULL && Buffers[i].BufferType == SECBUFFER_DATA) 
		{
			pDataBuffer = &Buffers[i];
		}
		if (pExtraBuffer == NULL && Buffers[i].BufferType == SECBUFFER_EXTRA) 
		{
			pExtraBuffer = &Buffers[i];
		}
	}
	ATLASSERT(pExtraBuffer == NULL);
#endif

	m_UQueueSend.SetSize(Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
	ATLASSERT(m_Sizes.cbHeader == Buffers[0].cbBuffer);
	ATLASSERT(ulLen == Buffers[1].cbBuffer);
//	ATLASSERT(Buffers[2].cbBuffer == m_Sizes.cbTrailer);

	do
	{
		nRtn = ::send(hSocket,
                  (char*)m_UQueueSend.GetBuffer(),
                  m_UQueueSend.GetSize(),
                  0);
		if(nRtn > 0)
		{
			m_UQueueSend.Pop(nRtn);
		}
		else if(nRtn == -1)
		{
			int nError = WSAGetLastError();
			if(nError != WSAEWOULDBLOCK)
			{
				return -1;
			}
			else
			{
//				::Sleep(1);
				return ulLen;
			}
		}
		else
		{
			ATLASSERT(FALSE);
			return 0;
		}
	}while(m_UQueueSend.GetSize() > 0);
//	m_UQueueSend.CleanTrack();
	return ulLen;
}

SECURITY_STATUS CSspiServer::GetDataIOPort(SOCKET hSocket, CUQueue &UQueue)
{
	int				i;
	SecBuffer		*pDataBuffer;
    SecBuffer		*pExtraBuffer;
	SecBuffer       Buffers[4];
	SecBufferDesc   Message;
	ULONG ulMax = GetMaxSize();
	ATLASSERT(m_SSLState == ssFinished);
	CUClient *pClient = g_mapUClient.Lookup(hSocket);
	SECURITY_STATUS scRet = SEC_E_OK;
	while(scRet == SEC_E_OK)
    {
		if(m_UQueueRecv.GetSize() == 0)
		{
			scRet = SEC_E_OK;
			break;
		}

		memset(Buffers, 0, sizeof(Buffers));

        // Attempt to decrypt the received data.
        Buffers[0].pvBuffer     = (BYTE*)m_UQueueRecv.GetBuffer();
        Buffers[0].cbBuffer     = m_UQueueRecv.GetSize();
        Buffers[0].BufferType   = SECBUFFER_DATA;

        Buffers[1].BufferType   = SECBUFFER_EMPTY;
        Buffers[2].BufferType   = SECBUFFER_EMPTY;
        Buffers[3].BufferType   = SECBUFFER_EMPTY;

        Message.ulVersion       = SECBUFFER_VERSION;
        Message.cBuffers        = 4;
        Message.pBuffers        = Buffers;

		if(m_VersionInfo.dwMajorVersion == 4 && m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
			scRet = ((DECRYPT_MESSAGE_FN)m_pSSPI->Reserved4)(&m_hContext, &Message, 0, NULL);
		else
			scRet = m_pSSPI->DecryptMessage(&m_hContext, &Message, 0, NULL);
		
        if(scRet == SEC_E_INCOMPLETE_MESSAGE)
        {
			scRet = SEC_E_OK;
			break;
        }
		 // Server signalled end of session
        if(scRet == SEC_I_CONTEXT_EXPIRED)
		{
			UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, pClient->m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, seSSLError));
            break;
		}

		if( scRet != SEC_E_OK && 
            scRet != SEC_I_RENEGOTIATE && 
            scRet != SEC_I_CONTEXT_EXPIRED
			)
        {
			ATLTRACE("Error code = %d inside CSspiServer::GetDataIOPort\n", scRet);
//			::SetLastError(scRet);
			UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, pClient->m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, seSSLError));
            break;
        }

		// Locate data and (optional) extra buffers.
        pDataBuffer  = NULL;
        pExtraBuffer = NULL;
		int nExtra = -1;
		int nData = -1;
        for(i = 1; i < 4; i++)
        {
            if(pDataBuffer == NULL && Buffers[i].BufferType == SECBUFFER_DATA)
            {
                pDataBuffer = &Buffers[i];
				nData = i;
            }
            if(pExtraBuffer == NULL && Buffers[i].BufferType == SECBUFFER_EXTRA)
            {
                pExtraBuffer = &Buffers[i];
				nExtra = i;
            }
        }

		// Display or otherwise process the decrypted data.
        if(pDataBuffer)
        {
			UQueue.Push((BYTE*)pDataBuffer->pvBuffer, pDataBuffer->cbBuffer);
        }
		
		m_UQueueRecv.SetSize(0);

		// Move any "extra" data to the input buffer.
        if(pExtraBuffer && pExtraBuffer->BufferType == SECBUFFER_EXTRA)
        {
			m_UQueueRecv.Push((BYTE*)pExtraBuffer->pvBuffer, pExtraBuffer->cbBuffer);			
//			ATLTRACE("Extra data length = %d inside CSspiServer::GetDataIOPort\n", pExtraBuffer->cbBuffer);
        }
	}
	if(scRet == SEC_I_CONTEXT_EXPIRED)
	{
		m_UQueueRecv.SetSize(0);
		scRet = SEC_E_OK;
	}
//	m_UQueueRecv.CleanTrack();
	
	return scRet;
}

SECURITY_STATUS CSspiServer::GetData(SOCKET hSocket, CUQueue &UQueue, ULONG ulMaxAllowed)
{
	int nRcv;
	int i;
	GetMaxSize();
	bool bContinue = true;
	ATLASSERT(m_SSLState == ssFinished);
	ULONG ulStart = UQueue.GetSize();
	SecBuffer		*pDataBuffer;
    SecBuffer		*pExtraBuffer;
	SecBuffer       Buffers[4];
	SecBufferDesc   Message;
	char strBuffer[8*1024];
	SECURITY_STATUS scRet = SEC_E_OK;
	while(true)
    {
		while(scRet == SEC_E_OK && m_UQueueRecv.GetSize() < (m_Sizes.cbMaximumMessage + 50))
		{
			nRcv = ::recv(hSocket, 
							strBuffer, 
							sizeof(strBuffer), 
							0);
			if(nRcv > 0)
			{
				bContinue = true;
				m_UQueueRecv.Push((BYTE*)strBuffer, nRcv);
			}
			else if(nRcv == -1)
			{
				int nError = WSAGetLastError();
				if(nError == WSAEWOULDBLOCK)
				{
					break;
				}
				else
				{
					scRet = SEC_E_INTERNAL_ERROR;
					return scRet;
				}
			}
			else
			{
				break;
			}
		}

		if(m_UQueueRecv.GetSize() == 0)
		{
			scRet = SEC_E_OK;
			break;
		}

        // Attempt to decrypt the received data.
        Buffers[0].pvBuffer     = (BYTE*)m_UQueueRecv.GetBuffer();
        Buffers[0].cbBuffer     = m_UQueueRecv.GetSize();
        Buffers[0].BufferType   = SECBUFFER_DATA;

        Buffers[1].BufferType   = SECBUFFER_EMPTY;
        Buffers[2].BufferType   = SECBUFFER_EMPTY;
        Buffers[3].BufferType   = SECBUFFER_EMPTY;

        Message.ulVersion       = SECBUFFER_VERSION;
        Message.cBuffers        = 4;
        Message.pBuffers        = Buffers;

		if(m_VersionInfo.dwMajorVersion == 4 && m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
			scRet = ((DECRYPT_MESSAGE_FN)m_pSSPI->Reserved4)(&m_hContext, &Message, 0, NULL);
		else
			scRet = m_pSSPI->DecryptMessage(&m_hContext, &Message, 0, NULL);

        if(scRet == SEC_E_INCOMPLETE_MESSAGE)
        {
			if(bContinue)
			{
				bContinue = false;
				continue;
			}
			else
			{
				scRet = SEC_E_OK;
				break;
			}
        }
		 // Server signalled end of session
        if(scRet == SEC_I_CONTEXT_EXPIRED)
		{
            break;
		}

		if( scRet != SEC_E_OK && 
            scRet != SEC_I_RENEGOTIATE && 
            scRet != SEC_I_CONTEXT_EXPIRED
			)
        {
			::SetLastError(scRet);
            break;
        }

		// Locate data and (optional) extra buffers.
        pDataBuffer  = NULL;
        pExtraBuffer = NULL;
        for(i = 1; i < 4; i++)
        {
            if(pDataBuffer == NULL && Buffers[i].BufferType == SECBUFFER_DATA)
            {
                pDataBuffer = &Buffers[i];
            }
            if(pExtraBuffer == NULL && Buffers[i].BufferType == SECBUFFER_EXTRA)
            {
                pExtraBuffer = &Buffers[i];
            }
        }

		// Display or otherwise process the decrypted data.
        if(pDataBuffer)
        {
			UQueue.Push((BYTE*)pDataBuffer->pvBuffer, pDataBuffer->cbBuffer);
        }
		
		m_UQueueRecv.SetSize(0);
		// Move any "extra" data to the input buffer.
        if(pExtraBuffer && pExtraBuffer->BufferType == SECBUFFER_EXTRA)
        {
			m_UQueueRecv.Push((BYTE*)pExtraBuffer->pvBuffer, pExtraBuffer->cbBuffer);
        }

		if((UQueue.GetSize() - ulStart) > ulMaxAllowed)
		{
			scRet = SEC_E_OK;
			break;
		}
	}
	if(scRet == SEC_I_CONTEXT_EXPIRED)
	{
		scRet = SEC_E_OK;
		m_UQueueRecv.SetSize(0);
	}
//	m_UQueueRecv.CleanTrack();
	return scRet;
}

SECURITY_STATUS CSspiServer::Open(DWORD dwProtocol, LPCSTR strUserName)
{
	ATLASSERT(IsLoaded());

	TimeStamp       tsExpiry;
    SECURITY_STATUS Status = SEC_E_OK;
    PCCERT_CONTEXT  pCertContext = NULL;

	if(strUserName == NULL || ::_tcslen(strUserName) == 0)
    {
        return SEC_E_NO_CREDENTIALS;
    }

	
	pCertContext = ::CertFindCertificateInStore(m_hMyCertStore, 
                                              X509_ASN_ENCODING, 
                                              0,
											  CERT_FIND_SUBJECT_STR_A,
                                              strUserName,
                                              NULL);
	if(pCertContext == NULL)
    {
		DWORD dwErrorCode = ::GetLastError();
        return dwErrorCode;
    }

	
	SCHANNEL_CRED					SchannelCred;
	ZeroMemory(&SchannelCred, sizeof(SchannelCred));

    SchannelCred.dwVersion  = SCHANNEL_CRED_VERSION;
    if(pCertContext)
    {
        SchannelCred.cCreds = 1;
        SchannelCred.paCred = &pCertContext;
    }

    SchannelCred.grbitEnabledProtocols = dwProtocol;
	
	if(m_hCreds.dwLower != 0 || m_hCreds.dwUpper != 0)
	{
		m_pSSPI->FreeCredentialsHandle(&m_hCreds);
		ZeroMemory(&m_hCreds, sizeof(m_hCreds));
	}

	Status = m_pSSPI->AcquireCredentialsHandleA(
                        NULL,                   // Name of principal    
                        UNISP_NAME_A,				// Name of package UNISP_NAME for the Schannel SSP
                        SECPKG_CRED_INBOUND,   // Flags indicating use
                        NULL,                   // Pointer to logon ID
                        &SchannelCred,        // Package specific data
                        NULL,                   // Pointer to GetKey() func
                        NULL,                   // Value to pass to GetKey()
                        &m_hCreds,              // (out) Cred Handle
                        &tsExpiry);    
	if(pCertContext)
    {
		::CertFreeCertificateContext(pCertContext);
    }
	return Status;
}

void CSspiServer::FreeResource()
{
	if(m_bImpersonateLoggedOnUser)
	{
		BOOL bSuc = RevertToSelf();
		ATLASSERT(bSuc);
	}
	if(m_hContext.dwLower != 0 || m_hContext.dwUpper != 0)
	{
		ATLASSERT(IsLoaded());
		m_pSSPI->DeleteSecurityContext(&m_hContext);
		ZeroMemory(&m_hContext, sizeof(m_hContext));
	}
}

void CSspiServer::FreeCredentials()
{
	if(m_hCreds.dwLower != 0 || m_hCreds.dwUpper != 0)
	{
		ATLASSERT(IsLoaded());
		m_pSSPI->FreeCredentialsHandle(&m_hCreds);
		ZeroMemory(&m_hCreds, sizeof(m_hCreds));
	}
}

ULONG CSspiServer::GetMaxSize()
{
	ATLASSERT(IsLoaded());

	if(m_Sizes.cbMaximumMessage == 0)
	{
		SECURITY_STATUS scRet = m_pSSPI->QueryContextAttributesA(&m_hContext,
                SECPKG_ATTR_STREAM_SIZES, &m_Sizes);
		if(scRet != SEC_E_OK)
		{
			ATLASSERT(FALSE);
			return scRet;
		}
		ULONG ulTotal = m_Sizes.cbMaximumMessage + m_Sizes.cbHeader + m_Sizes.cbTrailer;
		if(m_UQueueSend.GetMaxSize() < ulTotal +10)
		{
			m_UQueueSend.ReallocBuffer(ulTotal + 10);
		}

		if(m_UQueueRecv.GetMaxSize() < ulTotal + 10)
		{
			m_UQueueRecv.ReallocBuffer(ulTotal + 10);
		}
	}
	return m_Sizes.cbMaximumMessage;
}

tagSSLState	CSspiServer::GetSSLState()
{
	return m_SSLState;
}

bool CSspiServer::OpenStore(LPCWSTR strPfxFile, LPCWSTR strPassword)
{
	USES_CONVERSION;
	
	ULONG ulRead = 0;
	ATLASSERT(m_hMyCertStore == NULL);

	HANDLE hfile = INVALID_HANDLE_VALUE;
	
	// get the handle to the file...
	hfile = CreateFile(OLE2A(strPfxFile), FILE_READ_DATA, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0);
	if(INVALID_HANDLE_VALUE == hfile)
		return false;
	CRYPT_DATA_BLOB blob;
	blob.cbData = GetFileSize(hfile, 0);
	blob.pbData = (BYTE*)::malloc(blob.cbData);
	::ReadFile(hfile, blob.pbData, blob.cbData, &ulRead, NULL);
	bool bSuc = true;
	do
	{
		bSuc = ::PFXIsPFXBlob(&blob) ? true : false;
		if(!bSuc)
			break;
		m_hMyCertStore = PFXImportCertStore(&blob, strPassword, 0/*bMachine ? CRYPT_MACHINE_KEYSET : CRYPT_USER_KEYSET*/);
		bSuc = (m_hMyCertStore != NULL);
	}while(false);
	::free(blob.pbData);
	::CloseHandle(hfile);
	return bSuc;
}

bool CSspiServer::OpenStore(bool bMachine, bool bRoot)
{
	ATLASSERT(m_hMyCertStore == NULL);
	DWORD dwStoreOpenFlag = (CERT_STORE_OPEN_EXISTING_FLAG | CERT_STORE_READONLY_FLAG);
	if(bMachine)
	{
		if(bRoot)
			dwStoreOpenFlag |= CERT_SYSTEM_STORE_CURRENT_USER;
		else
			dwStoreOpenFlag |= CERT_SYSTEM_STORE_LOCAL_MACHINE;

		m_hMyCertStore = CertOpenStore( CERT_STORE_PROV_SYSTEM,
										0,
										X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
										dwStoreOpenFlag,
										bRoot ? L"ROOT" : L"MY");
	}
	else
	{
		m_hMyCertStore = ::CertOpenSystemStore(0, bRoot ? "ROOT" : "MY"); 
	}
	if(m_hMyCertStore == NULL)
	{
		CloseStoreAndUnloadSecurityLibrary();
        return false;
	}
	return true;
}

bool CSspiServer::LoadSecurityLibrary()
{
	if(IsLoaded())
		return true;

	INIT_SECURITY_INTERFACE         pInitSecurityInterface;
 //   OSVERSIONINFO	VerInfo;
    TCHAR			lpszDLL[MAX_PATH];
    m_VersionInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
    if (!GetVersionExA(&m_VersionInfo))   
    {
        return false;
    }

    if (m_VersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT 
        && m_VersionInfo.dwMajorVersion == 4)
    {
		::_tcscpy(lpszDLL, NT4_DLL_NAME);
    }
    else /*if (VerInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS ||
          VerInfo.dwPlatformId == VER_PLATFORM_WIN32_NT )*/
    {
		::_tcscpy(lpszDLL, DLL_NAME);
    }
  
    m_hSecurity = LoadLibrary(lpszDLL);
    if(m_hSecurity == NULL)
    {
        return false;
    }

    pInitSecurityInterface = (INIT_SECURITY_INTERFACE)GetProcAddress(
                                    m_hSecurity,
                                    "InitSecurityInterfaceA");
    if(pInitSecurityInterface == NULL)
    {
		CloseStoreAndUnloadSecurityLibrary();
        return false;
    }

    m_pSSPI = pInitSecurityInterface();
    if(m_pSSPI == NULL)
    {
		CloseStoreAndUnloadSecurityLibrary();
        return false;
    }

	return true;
}

void CSspiServer::CloseStoreAndUnloadSecurityLibrary()
{
	if(m_hCreds.dwLower != 0 || m_hCreds.dwUpper != 0)
	{
		m_pSSPI->FreeCredentialsHandle(&m_hCreds);
		ZeroMemory(&m_hCreds, sizeof(m_hCreds));
	}

	if(m_hMyCertStore != NULL)
	{
		::CertCloseStore(m_hMyCertStore, 0);
		m_hMyCertStore = NULL;
	}

	if(m_hSecurity != NULL)
	{
		::FreeLibrary(m_hSecurity);
		m_hSecurity = NULL;
	}

    m_pSSPI = NULL;
}