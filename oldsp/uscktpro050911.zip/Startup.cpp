// Startup.cpp: implementation of the CStartup class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Startup.h"
#include "ULSocket.h"
#include <tlhelp32.h>


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
extern CStartup	*g_pStartup;
extern CUQueue	g_tempQueue;
extern CUQueue	g_tempQueueSnd;

ULONG GetOS();

void CALLBACK UTimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	if(g_pSocketSvr)
	{
		g_pSocketSvr->OnTimer(dwTime);
	}
}

CStartup::CStartup()
{
	memset(this, 0, sizeof(CStartup));
	m_ulOS = GetOS();
	SYSTEM_INFO	SysInfo;
	GetSystemInfo(&SysInfo);
	m_ulQueue = SysInfo.dwNumberOfProcessors + 3;
	if(m_ulQueue > 64)
	{
		m_ulQueue = 64;
	}
	ATLASSERT(m_ulQueue >= 4);

	m_pUZip = new CUZip[m_ulQueue];

	m_hKernel32 = ::LoadLibrary(_T("kernel32.dll"));
	if(m_hKernel32 != NULL)
	{
		PostQueuedCompletionStatus = (PPostQueuedCompletionStatus)::GetProcAddress(m_hKernel32, "PostQueuedCompletionStatus");
		GetQueuedCompletionStatus = (PGetQueuedCompletionStatus)::GetProcAddress(m_hKernel32, "GetQueuedCompletionStatus");
		CreateIoCompletionPort = (PCreateIoCompletionPort)::GetProcAddress(m_hKernel32, "CreateIoCompletionPort");
		CreateToolhelp32Snapshot = (PCreateToolhelp32Snapshot)::GetProcAddress(m_hKernel32, "CreateToolhelp32Snapshot");
		Process32First = (PProcess32First)::GetProcAddress(m_hKernel32, "Process32First");
		Process32Next = (PProcess32Next)::GetProcAddress(m_hKernel32, "Process32Next");				
	}
}

CStartup::~CStartup()
{
	if(m_hKernel32 != NULL)
	{
		::FreeLibrary(m_hKernel32);
	}

	if(m_pUZip)
	{
		delete []m_pUZip;
	}
}

bool CStartup::Startup()
{
	m_nVersionRequested = MAKEWORD(2, 2);
	int err = WSAStartup(m_nVersionRequested, &m_wsaData);
	if(err != 0)
		return false;
	if(HIBYTE(m_wsaData.wVersion) !=2 )
		return false;
	return true;
}

void CStartup::Cleanup()
{
	StopSSPI();
//	KillTimer();
	int err = WSACleanup();
}

bool CStartup::StartSSPI(LPCWSTR strPfxFile, LPCWSTR strPassword)
{
	bool bSuc = CSspiServer::LoadSecurityLibrary();
	if(!bSuc)
		return false;
	return CSspiServer::OpenStore(strPfxFile, strPassword);
}

bool CStartup::StartSSPI(bool bMachine, bool bRoot)
{
	bool bSuc = CSspiServer::LoadSecurityLibrary();
	if(!bSuc)
		return false;
	return CSspiServer::OpenStore(bMachine, bRoot);
}

void CStartup::StopSSPI()
{
	CSspiServer::CloseStoreAndUnloadSecurityLibrary();
}

void CStartup::UnloadOpenSSL()
{
	if(m_hSSLEay)
	{
		::FreeLibrary(m_hSSLEay);
		m_hSSLEay=NULL;
	}
	if(m_hLibeay)
	{
		::FreeLibrary(m_hLibeay);
		m_hLibeay=NULL;
	}
	SSL_library_init = NULL;
	SSLv23_method = NULL;
	SSL_load_error_strings = NULL;
	SSL_CTX_new = NULL;
	SSL_CTX_free = NULL;
	SSL_new = NULL;
	SSL_free = NULL;
	SSL_set_fd = NULL;
	SSL_accept = NULL;
	SSL_get_error = NULL;
	SSL_write = NULL;
	SSL_read = NULL;
	SSL_shutdown = NULL;
	SSL_state = NULL;
	SSL_set_connect_state = NULL;
	SSL_set_accept_state = NULL;
	SSL_CTX_use_certificate_file = NULL;
	SSL_CTX_use_PrivateKey_file = NULL;
	SSL_CTX_check_private_key = NULL;
	SSL_state_string_long = NULL;
	SSL_do_handshake = NULL;
	SSL_want = NULL;
	SSL_pending = NULL;
	SSL_connect = NULL;
	SSL_peek = NULL;
	TLSv1_method = NULL;
	ERR_clear_error = NULL;
	SSL_clear = NULL;
	CRYPTO_free = NULL;
	CRYPTO_malloc = NULL;
	CRYPTO_set_locking_callback = NULL;
	CRYPTO_num_locks = NULL;
	SSL_set_read_ahead = NULL;
	SSL_set_info_callback = NULL;
	SSL_get_fd = NULL;
	ERR_get_error = NULL;
	ERR_error_string = NULL;
	SSL_CTX_ctrl = NULL;
//	d2i_PKCS12_fp = NULL;
	PKCS12_parse = NULL;
	PKCS12_free = NULL;
	SSL_use_certificate = NULL;
	SSL_use_PrivateKey = NULL;
	ERR_load_crypto_strings = NULL;
	OPENSSL_add_all_algorithms_noconf = NULL;
	BIO_free = NULL;
	BIO_new_file = NULL;
	d2i_PKCS12_bio = NULL;
	X509_free = NULL;
	EVP_PKEY_free = NULL;

	BIO_new = NULL;
	BIO_s_mem = NULL;
	SSL_set_bio = NULL;
	BIO_read = NULL;
	BIO_write = NULL;
	BIO_ctrl_pending = NULL;
	SSL_get_rbio = NULL;
	SSL_get_wbio = NULL;
}

bool CStartup::LoadOpenSSL(bool bUseSSL)
{
	m_hSSLEay=::LoadLibrary(_T("ssleay32.dll"));
	m_hLibeay=::LoadLibrary(_T("libeay32.dll"));
	if(!m_hSSLEay || !m_hLibeay)
	{
		UnloadOpenSSL();
		return false;
	}
	
	SSL_get_rbio = (PSSL_get_rbio)::GetProcAddress(m_hSSLEay, "SSL_get_rbio");
	SSL_get_wbio = (PSSL_get_wbio)::GetProcAddress(m_hSSLEay, "SSL_get_wbio");
	SSL_set_bio =(PSSL_set_bio)::GetProcAddress(m_hSSLEay, "SSL_set_bio");
	BIO_new = (PBIO_new)::GetProcAddress(m_hLibeay, "BIO_new");
	BIO_s_mem = (PBIO_s_mem)::GetProcAddress(m_hLibeay, "BIO_s_mem");
	BIO_read = (PBIO_read)::GetProcAddress(m_hLibeay, "BIO_read");
	BIO_write = (PBIO_write)::GetProcAddress(m_hLibeay, "BIO_write");
	BIO_ctrl_pending = (PBIO_ctrl_pending)::GetProcAddress(m_hLibeay, "BIO_ctrl_pending");

	X509_free = (PX509_free)::GetProcAddress(m_hLibeay, "X509_free");
	EVP_PKEY_free = (PEVP_PKEY_free)::GetProcAddress(m_hLibeay, "EVP_PKEY_free");

	BIO_free = (PBIO_free)::GetProcAddress(m_hLibeay, "BIO_free");
	d2i_PKCS12_bio = (Pd2i_PKCS12_bio)::GetProcAddress(m_hLibeay, "d2i_PKCS12_bio");
	BIO_new_file = (PBIO_new_file)::GetProcAddress(m_hLibeay, "BIO_new_file");

	ERR_load_crypto_strings = (PERR_load_crypto_strings)::GetProcAddress(m_hLibeay, "ERR_load_crypto_strings");
	OPENSSL_add_all_algorithms_noconf = (POPENSSL_add_all_algorithms_noconf)::GetProcAddress(m_hLibeay, "OPENSSL_add_all_algorithms_noconf");

	SSL_use_certificate = (PSSL_use_certificate)::GetProcAddress(m_hSSLEay, "SSL_use_certificate");
	SSL_use_PrivateKey = (PSSL_use_PrivateKey)::GetProcAddress(m_hSSLEay, "SSL_use_PrivateKey");
	
	PKCS12_free = (PPKCS12_free)::GetProcAddress(m_hLibeay, "PKCS12_free");
	PKCS12_parse = (PPKCS12_parse)::GetProcAddress(m_hLibeay, "PKCS12_parse");
	//debug
	ERR_error_string = (PERR_error_string)::GetProcAddress(m_hLibeay, "ERR_error_string");
	ERR_get_error = (PERR_get_error)::GetProcAddress(m_hLibeay, "ERR_get_error");
	ERR_clear_error = (PERR_clear_error)::GetProcAddress(m_hLibeay, "ERR_clear_error");
	TLSv1_method = (PTLSv1_method)::GetProcAddress(m_hSSLEay, "TLSv1_method");
	SSL_set_info_callback = (PSSL_set_info_callback)::GetProcAddress(m_hSSLEay, "SSL_set_info_callback");
	SSL_get_fd =(PSSL_get_fd)::GetProcAddress(m_hSSLEay, "SSL_get_fd");
	SSL_clear =(PSSL_clear)::GetProcAddress(m_hSSLEay, "SSL_clear");
	SSL_peek = (PSSL_peek)::GetProcAddress(m_hSSLEay, "SSL_peek");
	SSL_connect = (PSSL_connect)::GetProcAddress(m_hSSLEay, "SSL_connect");
	SSL_pending	= (PSSL_pending)::GetProcAddress(m_hSSLEay, "SSL_pending");
	SSL_accept = (PSSL_accept)::GetProcAddress(m_hSSLEay, "SSL_accept");
	SSL_want = (PSSL_want)::GetProcAddress(m_hSSLEay, "SSL_want");
	SSL_CTX_ctrl = (PSSL_CTX_ctrl)::GetProcAddress(m_hSSLEay, "SSL_CTX_ctrl");
	SSL_CTX_check_private_key = (PSSL_CTX_check_private_key)::GetProcAddress(m_hSSLEay, "SSL_CTX_check_private_key");
	SSL_CTX_free = (PSSL_CTX_free)::GetProcAddress(m_hSSLEay, "SSL_CTX_free");
	SSL_CTX_new = (PSSL_CTX_new)::GetProcAddress(m_hSSLEay, "SSL_CTX_new");
	SSL_CTX_use_certificate_file = (PSSL_CTX_use_certificate_file)::GetProcAddress(m_hSSLEay, "SSL_CTX_use_certificate_file");
	SSL_CTX_use_PrivateKey_file = (PSSL_CTX_use_PrivateKey_file)::GetProcAddress(m_hSSLEay, "SSL_CTX_use_PrivateKey_file");
	SSL_free = (PSSL_free)::GetProcAddress(m_hSSLEay, "SSL_free");
	SSL_do_handshake = (PSSL_do_handshake)::GetProcAddress(m_hSSLEay, "SSL_do_handshake");
	SSL_get_error = (PSSL_get_error)::GetProcAddress(m_hSSLEay, "SSL_get_error");
	SSL_library_init = (PSSL_library_init)::GetProcAddress(m_hSSLEay, "SSL_library_init");
	SSL_load_error_strings = (PSSL_load_error_strings)::GetProcAddress(m_hSSLEay, "SSL_load_error_strings");
	SSL_new = (PSSL_new)::GetProcAddress(m_hSSLEay, "SSL_new");
	SSL_read = (PSSL_read)::GetProcAddress(m_hSSLEay, "SSL_read");
	SSL_set_accept_state = (PSSL_set_accept_state)::GetProcAddress(m_hSSLEay, "SSL_set_accept_state");
	SSL_set_connect_state = (PSSL_set_connect_state)::GetProcAddress(m_hSSLEay, "SSL_set_connect_state");
	SSL_set_fd	 = (PSSL_set_fd	)::GetProcAddress(m_hSSLEay, "SSL_set_fd");
	SSL_shutdown = (PSSL_shutdown)::GetProcAddress(m_hSSLEay, "SSL_shutdown");
	SSL_state = (PSSL_state)::GetProcAddress(m_hSSLEay, "SSL_state");
	SSL_state_string_long = (PSSL_state_string_long)::GetProcAddress(m_hSSLEay, "SSL_state_string_long");
	SSL_write = (PSSL_write)::GetProcAddress(m_hSSLEay, "SSL_write");
	SSLv23_method = (PSSLv23_method)::GetProcAddress(m_hSSLEay, "SSLv23_method");
	SSL_set_read_ahead = (PSSL_set_read_ahead)::GetProcAddress(m_hSSLEay, "SSL_set_read_ahead");
	CRYPTO_free = (PCRYPTO_free)::GetProcAddress(m_hLibeay, "CRYPTO_free");
	CRYPTO_malloc = (PCRYPTO_malloc)::GetProcAddress(m_hLibeay, "CRYPTO_malloc");
	CRYPTO_set_locking_callback = (PCRYPTO_set_locking_callback)::GetProcAddress(m_hLibeay, "CRYPTO_set_locking_callback");
	CRYPTO_num_locks = (PCRYPTO_num_locks)::GetProcAddress(m_hLibeay, "CRYPTO_num_locks");

	if( SSL_library_init && SSL_load_error_strings && SSL_CTX_new && d2i_PKCS12_bio && ERR_load_crypto_strings
		&& SSL_CTX_free && SSL_new && SSL_free && SSL_set_fd && PKCS12_parse && BIO_free && X509_free
		&& SSL_write && SSL_read && SSL_shutdown && SSL_state && SSL_set_connect_state && CRYPTO_malloc && SSL_CTX_ctrl
		&& SSL_set_accept_state && SSL_CTX_use_certificate_file && SSL_CTX_use_PrivateKey_file && ERR_get_error
		&& SSL_CTX_check_private_key && SSL_set_info_callback && PKCS12_free && SSL_use_PrivateKey
		&& SSL_set_read_ahead && ERR_clear_error && CRYPTO_num_locks && ERR_error_string
		&& CRYPTO_free && SSL_get_fd && SSL_accept && SSL_get_error && CRYPTO_set_locking_callback
		&& SSL_state_string_long && SSL_do_handshake && SSL_want && SSL_use_certificate && EVP_PKEY_free
		&& SSL_pending && SSL_connect && SSL_peek && BIO_new_file && OPENSSL_add_all_algorithms_noconf
		&& BIO_read && BIO_write && BIO_ctrl_pending && SSL_set_bio && SSL_get_rbio && SSL_get_wbio && BIO_new && BIO_s_mem
		)
	{
		if(bUseSSL && SSLv23_method)
			return true;
		if(!bUseSSL && TLSv1_method)
			return true;
	}
	UnloadOpenSSL();
	return false;
}

bool CStartup::StartOpenSSL()
{
	int i;
	if(!SSL_library_init())
		return false;
	OPENSSL_add_all_algorithms_noconf();
	ERR_load_crypto_strings();
	if(SSLv23_method)
		m_pMeth = SSLv23_method();
	else
		m_pMeth = TLSv1_method();
	if(!m_pMeth)
	{
		StopOpenSSL();
		return false;
	}
	SSL_load_error_strings();
	m_pCtx = SSL_CTX_new(m_pMeth);
	if(!m_pCtx)
	{
		StopOpenSSL();
		return false;
	}
	
	SSL_CTX_ctrl(m_pCtx, SSL_CTRL_MODE, SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER, NULL);

	m_pSSLLockHandle = (HANDLE*)CRYPTO_malloc(CRYPTO_num_locks()*sizeof(HANDLE), __FILE__,__LINE__);
	ATLASSERT(m_pSSLLockHandle);
	for(i=0; i<CRYPTO_num_locks(); i++)
	{
		m_pSSLLockHandle[i] = ::CreateMutex(NULL, FALSE, NULL);
		ATLASSERT(m_pSSLLockHandle[i]);
	}

	CRYPTO_set_locking_callback(LockingCallback);
	return true;
}

void CStartup::StopOpenSSL()
{
	if(CRYPTO_set_locking_callback)
		CRYPTO_set_locking_callback(NULL);
	if(m_pSSLLockHandle)
	{
		int i;
		for(i=0; i<CRYPTO_num_locks(); i++)
		{
			::CloseHandle(m_pSSLLockHandle[i]);
		}
		CRYPTO_free(m_pSSLLockHandle); //OPENSSL_free
		m_pSSLLockHandle = NULL;
	}
	if(m_pCtx)
	{
		SSL_CTX_free(m_pCtx);
		m_pCtx=NULL;
	}
	if(m_pMeth)
		m_pMeth=NULL;
}

void CStartup::LockingCallback(int nMode, int nType, const char *strFile, int nLine)
{
	ATLASSERT(nType<g_pStartup->CRYPTO_num_locks());
	if(nMode & CRYPTO_LOCK)
	{
		::WaitForSingleObject(g_pStartup->m_pSSLLockHandle[nType], INFINITE);
	}
	else
	{
		::ReleaseMutex(g_pStartup->m_pSSLLockHandle[nType]);
	}
}

void CStartup::SetTimer(HWND hWnd, unsigned long ulTimerInterval)
{
	KillTimer();
	m_hWnd = hWnd;
	m_nTimer = ::SetTimer(m_hWnd, 1, ulTimerInterval, UTimerProc);
}

void CStartup::KillTimer()
{
	if(m_nTimer)
	{
		::KillTimer(m_hWnd, m_nTimer);
		m_nTimer = 0;
	}
}


CUQueue* CStartup::LockQueue(ULONG &ulIndex)
{
	ULONG ul;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	for(ul=0; ul<m_ulQueue; ul++)
	{
		if(!m_pUZip[ul].m_bUsing)
		{
			m_pUZip[ul].m_bUsing = true;
			ulIndex = ul;
			return &(m_pUZip[ul].m_UQueue);
		}
	}
	return NULL;
}

void CStartup::UnlockQueue(ULONG ulIndex)
{
	ATLASSERT(ulIndex < m_ulQueue);
	ATLASSERT(m_pUZip[ulIndex].m_bUsing);
	m_pUZip[ulIndex].m_bUsing = false;
}

void CStartup::ShrinkZipQueue()
{
	ULONG ul;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	for(ul=0; ul<m_ulQueue; ul++)
	{
		if(!m_pUZip[ul].m_bUsing && m_pUZip[ul].m_UQueue.GetMaxSize() > 102400)
		{
			m_pUZip[ul].m_UQueue.ReallocBuffer(102400);
		}	
	}
}

int EnumApp(LPCTSTR strModuleName)
{
	
	if(g_pStartup->CreateToolhelp32Snapshot == NULL)
		return 1;

	PROCESSENTRY32 pe32      = {0}; 
	int n = 0;
	HANDLE  hProcessSnap = NULL;
	pe32.dwSize = sizeof(PROCESSENTRY32); 
	CComBSTR bstrTheName(strModuleName);
	bstrTheName.ToUpper();
	do
	{
		hProcessSnap = g_pStartup->CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		if(hProcessSnap == NULL)
			break;
		if (g_pStartup->Process32First(hProcessSnap, &pe32)) 
		{
			CComBSTR bstr;
			do 
			{ 
				bstr = pe32.szExeFile;
				bstr.ToUpper();
				if(bstr == bstrTheName)
					n++;	
			} 
			while (g_pStartup->Process32Next(hProcessSnap, &pe32)); 
		}
	}while(false);
	
	if(hProcessSnap != NULL)
		CloseHandle (hProcessSnap); 
	if(n == 0)
		n = 1;
	return n;
}
