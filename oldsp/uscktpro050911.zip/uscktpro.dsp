# Microsoft Developer Studio Project File - Name="uscktpro" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=uscktpro - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "uscktpro.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "uscktpro.mak" CFG="uscktpro - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "uscktpro - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "uscktpro - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "uscktpro - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /D "USCKTPRO_EXPORTS" /YX /FD /c
# ADD CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /D "USCKTPRO_EXPORTS" /YX /FD /c
# SUBTRACT CPP /Fr
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386
# ADD LINK32 ws2_32.lib Iphlpapi.lib crypt32.lib shlwapi.lib /nologo /dll /machine:I386 /out:"../Release/usktpror.dll"
# SUBTRACT LINK32 /incremental:yes /debug

!ELSEIF  "$(CFG)" == "uscktpro - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /D "USCKTPRO_EXPORTS" /YX /FD /GZ /c
# ADD CPP /nologo /MTd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /FR /YX /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept
# ADD LINK32 ws2_32.lib Iphlpapi.lib crypt32.lib shlwapi.lib /nologo /base:"0x66630000" /dll /debug /machine:I386 /out:"../Debug/usktpror.dll" /implib:"../lib/usktpror.lib" /pdbtype:sept
# SUBTRACT LINK32 /pdb:none /incremental:no

!ENDIF 

# Begin Target

# Name "uscktpro - Win32 Release"
# Name "uscktpro - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\adler32.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\BF.cpp
# End Source File
# Begin Source File

SOURCE=.\BlowFishGA.cpp
# End Source File
# Begin Source File

SOURCE=.\ChatRoom.cpp
# End Source File
# Begin Source File

SOURCE=.\clientthread.cpp

!IF  "$(CFG)" == "uscktpro - Win32 Release"

# ADD CPP /O1
# SUBTRACT CPP /Z<none> /Fr

!ELSEIF  "$(CFG)" == "uscktpro - Win32 Debug"

# ADD CPP /ZI /Od /Fr

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\compress.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\crc32.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\deflate.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\infback.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\inffast.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\inflate.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\inftrees.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\listensocket.cpp
# End Source File
# Begin Source File

SOURCE=.\MsgHolder.cpp
# End Source File
# Begin Source File

SOURCE=.\MyOpenSSL.cpp
# End Source File
# Begin Source File

SOURCE=.\quick.cpp
# End Source File
# Begin Source File

SOURCE=.\SHA1.cpp
# End Source File
# Begin Source File

SOURCE=.\sktbase.cpp
# End Source File
# Begin Source File

SOURCE=.\SN.cpp
# End Source File
# Begin Source File

SOURCE=.\socketpro.rc
# End Source File
# Begin Source File

SOURCE=.\sprowrap.cpp
# End Source File
# Begin Source File

SOURCE=.\SSPILogon.cpp
# End Source File
# Begin Source File

SOURCE=.\SspiServer.cpp
# End Source File
# Begin Source File

SOURCE=.\Startup.cpp
# End Source File
# Begin Source File

SOURCE=.\stdafx.cpp
# End Source File
# Begin Source File

SOURCE=.\trees.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\ULSocket.cpp

!IF  "$(CFG)" == "uscktpro - Win32 Release"

# ADD CPP /O1
# SUBTRACT CPP /Z<none> /Fr

!ELSEIF  "$(CFG)" == "uscktpro - Win32 Debug"

# ADD CPP /ZI /Od /Fr

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\UMsgQueue.cpp
# End Source File
# Begin Source File

SOURCE=.\uncompr.c
# SUBTRACT CPP /YX
# End Source File
# Begin Source File

SOURCE=.\uscktpro.cpp
# End Source File
# Begin Source File

SOURCE=.\uscktpro.def
# End Source File
# Begin Source File

SOURCE=.\UThread.cpp

!IF  "$(CFG)" == "uscktpro - Win32 Release"

# ADD CPP /O2
# SUBTRACT CPP /Z<none> /Fr

!ELSEIF  "$(CFG)" == "uscktpro - Win32 Debug"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\UZip.cpp
# End Source File
# Begin Source File

SOURCE=.\zutil.c
# SUBTRACT CPP /YX
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\BF.h
# End Source File
# Begin Source File

SOURCE=.\BlowfishGA.h
# End Source File
# Begin Source File

SOURCE=.\ChatRoom.h
# End Source File
# Begin Source File

SOURCE=.\context.h
# End Source File
# Begin Source File

SOURCE=.\MsgHolder.h
# End Source File
# Begin Source File

SOURCE=.\MyOpenSSL.h
# End Source File
# Begin Source File

SOURCE=.\SHA1.h
# End Source File
# Begin Source File

SOURCE=.\sprowrap.h
# End Source File
# Begin Source File

SOURCE=.\SSPILogon.h
# End Source File
# Begin Source File

SOURCE=.\SspiServer.h
# End Source File
# Begin Source File

SOURCE=.\Startup.h
# End Source File
# Begin Source File

SOURCE=.\stdafx.h
# End Source File
# Begin Source File

SOURCE=..\src\streamhead.h
# End Source File
# Begin Source File

SOURCE=.\ULSocket.h
# End Source File
# Begin Source File

SOURCE=.\UMsgQueue.h
# End Source File
# Begin Source File

SOURCE=..\inc\uqueue.h
# End Source File
# Begin Source File

SOURCE=..\inc\USocket.h
# End Source File
# Begin Source File

SOURCE=.\UThread.h
# End Source File
# Begin Source File

SOURCE=.\UZip.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# End Group
# End Target
# End Project
