// This is a part of the SocketPro package.
// Copyright (C) 2000-2004 UDAParts 
// All rights reserved.
//
// This source code is only intended as a supplement to the
// SocketPro package and related electronic documentation provided with the package.
// See these sources for detailed information regarding this
// UDAParts product.

// Please don't disclose any source code of the software to any person or entity,
//
// Please don't decompile, disassemble, or reverse engineer any object code of 
// any portion of the software.
//  
// http://www.udaparts.com/index.htm
// support@udaparts.com

#ifndef ___U_SOCKET_PRO_H____
#define ___U_SOCKET_PRO_H____

#ifdef __cplusplus
extern "C" {
#endif

#define	SOCKET_NOT_FOUND		(0xFFFFFFFF)
#define	LEN_NOT_AVAILABLE		(0xFFFFFFFF)
#define REQUEST_CANCELED		(0xFFFFFFFE)
#define RETURN_DATA_INTERCEPTED	(0xFFFFFFFD)

//your window message can NOT be in the following range
#define WM_SOCKETPRO_RESERVED_MIN		(WM_USER + 0x0401)
#define WM_SOCKETPRO_RESERVED_MAX		(WM_USER + 0x06FF)

#define WM_SOCKET_SVR_NOTIFY			(WM_USER + 0x0480)
#define	WM_ASK_FOR_PROCESSING			(WM_USER + 0x0500)
#define	WM_REQUEST_PROCESSED			(WM_USER + 0x0501)
#define	WM_WORKER_THREAD_DYING			(WM_USER + 0x0502)
#define	WM_SET_PROCESSING_FUNC			(WM_USER + 0x0503)
#define WM_SET_PRETRANS_FUNC			(WM_USER + 0x0504)
#define	WM_CANCEL_REQUEST				(WM_USER + 0x0505)
#define	WM_CONTINUE_PROCESSING			(WM_USER + 0x0506)

//Error codes 
#define ERROR_UNO_ERROR							(0x000)
#define ERROR_UWRONG_SWICTH						(0x100)
#define ERROR_UAUTHENTICATION_FAILED			(0x101)
#define ERROR_USERVICE_NOT_FOUND				(0x102)
#define ERROR_UBLOWFISH_KEY_WRONG				(0x103)
#define ERROR_UNOT_SWITCHED_YET					(0x104)	

//SSL error codes		


//used with listening socket
typedef void (CALLBACK *POnChatRequestComing) (unsigned int hSocketSource, unsigned short usRequestID, unsigned long ulLen);
typedef void (CALLBACK *POnChatRequestCame) (unsigned int hSocketSource, unsigned short usRequestID, unsigned long ulLen);
typedef void (CALLBACK *POnWinMessage) (HWND hWnd, UINT uMsg, WPARAM wParam,  LPARAM lParam);
typedef void (CALLBACK *POnAccept) (unsigned int hSocket, int nError);

typedef void (CALLBACK *POnCleanPool) (unsigned long ulSvsID, unsigned long ulTickCount);

//used by client-peer socket
typedef void (CALLBACK *POnClose) (unsigned int hSocket, int nError);
typedef void (CALLBACK *POnReceive) (unsigned int hSocket, int nError);
typedef void (CALLBACK *POnSend) (unsigned int hSocket, int nError);
typedef void (CALLBACK *POnSSLEvent) (unsigned int hSocket, int nWhere, int nRtn);
typedef void (CALLBACK *POnBaseRequestCame) (unsigned int hSocket, unsigned short usRequestID);
typedef void (CALLBACK *POnRequestProcessed) (unsigned int hSocket, unsigned short usRequestID);
typedef void (CALLBACK *POnFastRequestArrive) (unsigned int hSocket, unsigned short usRequestID, unsigned long ulLen);
typedef bool (CALLBACK *POnIsPermitted) (unsigned int hSocket, unsigned long ulSvsID);
typedef void (CALLBACK *POnSwitchTo) (unsigned int hSocket, unsigned long ulPrevSvsID, unsigned long ulCurrSvsID);

typedef bool (CALLBACK *POnSendReturnData) (unsigned int hSocket, unsigned short usRequestId, unsigned long ulLen, const unsigned char *pBuffer);

//used within a worker thread
typedef void (CALLBACK *PTHREAD_STARTED) ();
typedef HRESULT (CALLBACK *PSLOW_PROCESS) (unsigned short usRequestID, unsigned long ulLen, unsigned int hSocket);
typedef void (CALLBACK *PTHREAD_DYING) ();
typedef BOOL (CALLBACK *PPRETRANSLATEMESSAGE) (MSG* pMsg);
typedef void (CALLBACK *POnThreadCreated) (unsigned long ulSvsID, unsigned long ulThreadID, unsigned int hSocket);

enum enumThreadApartment
{
	taNone = 0,
	taApartment,
	taFree,
};

struct CSvsContext
{
	//called within main thread
	POnIsPermitted			m_OnIsPermitted;		//for authentication
	POnSwitchTo				m_OnSwitchTo;			//called when a service is switched
	POnFastRequestArrive	m_OnFastRequestArrive;  //request processed within main thread
	POnBaseRequestCame		m_OnBaseRequestCame;	//SocketPro defines a set of base requests
	POnCleanPool			m_OnCleanPool;			//Clean objects in pool
	POnRequestProcessed		m_OnRequestProcessed;	//called when a slow request processed

	POnClose				m_OnClose;				//native socket event
	POnReceive				m_OnReceive;			//native socket event
	POnSend					m_OnSend;				//native socket event
	
	//called within worker thread
	enumThreadApartment		m_enumTA;				//required with a worker thread							
	PSLOW_PROCESS			m_SlowProcess;			//required with a worker thread	
	PPRETRANSLATEMESSAGE	m_PreTranslateMessage;	//Optional
	PTHREAD_STARTED			m_ThreadStarted;		//Optional
	PTHREAD_DYING			m_ThreadDying;			//Optional

	POnSendReturnData		m_OnSendReturnData;
	POnThreadCreated		m_OnThreadCreated;
};

bool WINAPI InitSocketProServer(int nParam);
void WINAPI UninitSocketProServer();
bool WINAPI StartSocketProServer(unsigned int uiPort, unsigned int uiMaxBacklog = 64); 
void WINAPI StopSocketProServer();
bool WINAPI IsCanceled();
void WINAPI SetOnSSLEvent(POnSSLEvent pOnSSLEvent);
void WINAPI SetOnWinMessage(POnWinMessage pOnWinMessage);
void WINAPI SetOnAccept(POnAccept pOnAccept);
void WINAPI SetOnSwitchTo(POnSwitchTo pOnSwitchTo);
void WINAPI SetOnIsPermitted(POnIsPermitted pOnIsPermitted);
void WINAPI SetOnClose(POnClose pOnClose);
void WINAPI SetOnSend(POnSend pOnSend);
unsigned int WINAPI GetListeningSocket();

unsigned int WINAPI GetCountOfClients();
unsigned int WINAPI GetClient(unsigned int uiIndex);
HWND WINAPI GetWin();
unsigned long WINAPI GetMainThreadID();
int WINAPI GetLastSocketError();

void WINAPI SetDefaultEncryptionMethod(tagEncryptionMethod EncryptionMethod);
tagEncryptionMethod WINAPI GetDefaultEncryptionMethod();
void WINAPI SetDefaultZip(bool bZip);
bool WINAPI GetDefaultZip();
void WINAPI SetMaxThreadIdleTimeBeforeSuicide(unsigned long ulMaxThreadIdleTimeBeforeSuicide);
void WINAPI SetMaxConnectionsPerClient(unsigned long ulMaxConnectionsPerClient);
unsigned long WINAPI GetMaxThreadIdleTimeBeforeSuicide();
unsigned long WINAPI GetMaxConnectionsPerClient();
void WINAPI SetTimerElapse(unsigned long ulTimerElapse); 
void WINAPI SetSMInterval(unsigned long ulSMInterval); 
void WINAPI SetPingInterval(unsigned long ulPingInterval);
unsigned long WINAPI GetTimerElapse(); 
unsigned long WINAPI GetSMInterval(); 
unsigned long WINAPI GetPingInterval();
void WINAPI SetRecycleGlobalMemoryInterval(unsigned long ulRecycleGlobalMemoryInterval);
unsigned long WINAPI GetRecycleGlobalMemoryInterval();
void WINAPI SetCleanPoolInterval(unsigned long ulCleanPoolInterval);
unsigned long WINAPI GetCleanPoolInterval();

//used by OpenSSL. 
//When using SSL23 or TLSv1 to secure SocketPro, you must call the two methods before starting SocketPro server
void WINAPI SetCertFile(const wchar_t *strCertFile);	
void WINAPI SetPrivateKeyFile(const wchar_t *strPrivateKeyFile);
FARPROC GetOpenSSLProcAddress(const wchar_t *strOpenSSLFuncName);
//void* WINAPI GetSSL(unsigned int hSocket);

//plug and unplug a dll 
HINSTANCE WINAPI AddADll(const wchar_t *strLibFile, int nParam);
bool WINAPI RemoveADll(const wchar_t *strLibFile);
unsigned long WINAPI GetCountOfLibraries();
HINSTANCE WINAPI GetADll(unsigned long ulIndex);
bool WINAPI RemoveADllByHandle(HINSTANCE hInstance);

//APIs for managing services
bool WINAPI AddSvsContext(unsigned long ulSvsID, CSvsContext SvsContext);
CSvsContext WINAPI GetSvsContext(unsigned long ulSvsID);
bool WINAPI RemoveASvsContext(unsigned long ulSvsID);
bool WINAPI ReplaceSvsContext(unsigned long ulSvsID, CSvsContext SvsContext);
unsigned long WINAPI GetCountOfServices();
unsigned long WINAPI GetServiceID(unsigned long ulIndex);
bool WINAPI AddSlowRequest(unsigned long ulSvsID, unsigned short usRequestID);
bool WINAPI RemoveSlowRequest(unsigned long ulSvsID, unsigned short usRequestID);
unsigned short WINAPI GetCountOfSlowRequests(unsigned long ulSvsID);
void WINAPI RemoveAllSlowRequests(unsigned long ulSvsID);
unsigned short WINAPI GetSlowRequest(unsigned long ulSvsID, unsigned short usIndex);

//The following fifteen methods are used for chat service
void WINAPI SetGroupsNotifiedWhenEntering(unsigned long ulGroupsNotifiedWhenEntering);
void WINAPI SetGroupsNotifiedWhenExiting(unsigned long ulGroupsNotifiedWhenExiting);
unsigned long WINAPI GetGroupsNotifiedWhenEntering();
unsigned long WINAPI GetGroupsNotifiedWhenExiting();
void WINAPI SetOnChatRequestComing(POnChatRequestComing pOnChatRequestComing);
void WINAPI SetOnChatRequestCame(POnChatRequestCame pOnChatRequestCame);
bool WINAPI AddAChatGroup(unsigned long ulGroupID, const wchar_t *strDescription);
unsigned long WINAPI GetAChatGroup(unsigned long ulGroupID, wchar_t *strDescription, unsigned long ulChars);
unsigned char WINAPI GetCountOfChatGroups();
unsigned long WINAPI GetGroupID(unsigned char bIndex);
unsigned long WINAPI GetCountOfChatters(unsigned long ulGroupID);
unsigned int WINAPI GetChatterSocket(unsigned long ulGroupID, unsigned long ulIndex);

//hSocket always cooresponds to a client socket connection, and is unique at any time
//SocketPro uses hSocket as a key index
unsigned long WINAPI GetJoinedGroup(unsigned int hSocket);
bool WINAPI SpeakTo(unsigned int hSocket, const VARIANT *pvtMsg, unsigned int hSocketTarget);
bool WINAPI Speak(unsigned int hSocket, const VARIANT *pvtMsg, unsigned long ulGroups = odAllGroups);
bool WINAPI Enter(unsigned int hSocket, unsigned long ulGroup);
bool WINAPI Exit(unsigned int hSocket);
bool WINAPI SpeakToEx(unsigned int hSocket, const unsigned char *pMessage, unsigned long ulLen, unsigned int hSocketTarget);
bool WINAPI SpeakEx(unsigned int hSocket, const unsigned char *pMessage, unsigned long ulLen, unsigned long ulGroups = odAllGroups);

void* WINAPI GetSSL(unsigned int hSocket);
unsigned int WINAPI FindClient(unsigned int hSocket);
bool WINAPI PostClose(unsigned int hSocket, unsigned short usError);
unsigned long WINAPI RetrieveBuffer(unsigned int hSocket, unsigned long ulLen, unsigned char* pBuffer, bool bPeek = false);
unsigned long WINAPI SendReturnData(unsigned int hSocket, unsigned short usRequestId, unsigned long ulLen, const unsigned char* pBuffer);
bool WINAPI StartBatching(unsigned int hSocket);
bool WINAPI CommitBatching(unsigned int hSocket);
bool WINAPI AbortBatching(unsigned int hSocket);
bool WINAPI ContinueProcessing(unsigned int hSocket, unsigned short usRequestID);
void WINAPI ResetBytesIn(unsigned int hSocket, unsigned long ulStart = 0, unsigned long *pulHigh = 0);
void WINAPI ResetBytesOut(unsigned int hSocket, unsigned long ulStart = 0, unsigned long *pulHigh = 0);
unsigned long WINAPI GetBytesIn(unsigned int hSocket, unsigned long *pulHigh = 0);
unsigned long WINAPI GetBytesOut(unsigned int hSocket, unsigned long *pulHigh = 0);
unsigned long WINAPI GetCurrentRequestLen(unsigned int hSocket);
unsigned short WINAPI GetCurrentRequestID(unsigned int hSocket);
unsigned long WINAPI GetLastSndTime(unsigned int hSocket);
unsigned long WINAPI GetLastRcvTime(unsigned int hSocket);
unsigned long WINAPI GetSndBufferSize(unsigned int hSocket);
unsigned long WINAPI GetRcvBufferSize(unsigned int hSocket);
unsigned long WINAPI GetSndBytesInQueue(unsigned int hSocket);
unsigned long WINAPI GetRcvBytesInQueue(unsigned int hSocket);
unsigned long WINAPI GetSvsID(unsigned int hSocket);
unsigned long WINAPI GetTotalMemory(unsigned int hSocket);
unsigned long WINAPI QueryRequestsInQueue(unsigned int hSocket);
bool WINAPI IsBatching(unsigned int hSocket);
bool WINAPI GetInterfaceAttributes(unsigned int hSocket, unsigned long *pulMTU, unsigned long *pulMaxSpeed, unsigned long *pulType, unsigned long *pulMask);
void WINAPI ShrinkMemory(unsigned int hSocket);
unsigned long WINAPI GetCountOfMySpecificBytes(unsigned int hSocket);
unsigned long WINAPI GetMySpecificBytes(unsigned int hSocket, unsigned char* pBuffer, unsigned long ulLen);
bool WINAPI SetBlowFish(unsigned int hSocket, unsigned char bKeyLen, unsigned char *strKey);
bool WINAPI SetEncryptionMethod(unsigned int hSocket, tagEncryptionMethod EncryptionMethod);
bool WINAPI SetZip(unsigned int hSocket, bool bZip);
tagEncryptionMethod WINAPI GetEncryptionMethod(unsigned int hSocket);
bool WINAPI GetZip(unsigned int hSocket);
unsigned long WINAPI GetUID(unsigned int hSocket, wchar_t *strUID, unsigned long ulCharLen);
unsigned long WINAPI GetPassword(unsigned int hSocket, wchar_t *strPassword, unsigned long ulCharLen);
unsigned long WINAPI GetTimeOut(unsigned int hSocket);
bool WINAPI SetTimeOut(unsigned int hSocket, unsigned long ulTimeOut);
bool WINAPI GetClientInfo(unsigned int hSocket, CSwitchInfo *pClientInfo);
bool WINAPI GetServerInfo(unsigned int hSocket, CSwitchInfo *pServerInfo);
bool WINAPI SetServerInfo(unsigned int hSocket, CSwitchInfo *pServerInfo);
bool WINAPI IsSameEndian(unsigned int hSocket);
unsigned long WINAPI GetAssociatedThreadID(unsigned int hSocket);
unsigned int WINAPI GetAssociatedSocket();
unsigned long WINAPI GetBytesBatched(unsigned int hSocket);
bool WINAPI GetSockAddr(unsigned int hSocket, unsigned int *pnSockPort, wchar_t *strIPAddrBuffer, unsigned short usChars);
bool WINAPI GetPeerName(unsigned int hSocket, unsigned int *pnPeerPort, wchar_t *strPeerAddr, unsigned short usChars);
unsigned long WINAPI GetRequestIDsInQueue(unsigned int hSocket, unsigned short *pusRequestID, unsigned long ulSize);
bool WINAPI GetLocalName(wchar_t *strLocalName, unsigned short usChars);
void WINAPI Register(unsigned int hSocket, unsigned char *pbLock, unsigned char *pbKey);

#ifdef __cplusplus
}
#endif

#endif

// This is a part of the SocketPro package.
// Copyright (C) 2000-2004 UDAParts 
// All rights reserved.
//
// This source code is only intended as a supplement to the
// SocketPro package and related electronic documentation provided with the package.
// See these sources for detailed information regarding this
// UDAParts product.

// Please don't disclose any source code of the software to any person or entity,
//
// Please don't decompile, disassemble, or reverse engineer any object code of 
// any portion of the software.
//  
// http://www.udaparts.com/index.htm
// support@udaparts.com