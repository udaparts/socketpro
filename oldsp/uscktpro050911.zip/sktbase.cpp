#include "stdafx.h"
#include "ULSocket.h"
#include "Startup.h"

extern CStartup	*g_pStartup;

CSktBase::CSktBase()
{
	m_hSocket = INVALID_SOCKET;
	m_nRtn = 0;
	m_EncryptionMethod = NoEncryption;
	m_bZip = false;
	m_ulStartBlocking = 10*1460;
}

CSktBase::~CSktBase()
{
	if(m_hSocket!=INVALID_SOCKET)
		::closesocket(m_hSocket);
}

void CSktBase::CloseSocket()
{
	if(m_hSocket!=INVALID_SOCKET)
	{
		::shutdown(m_hSocket, SD_BOTH);
		::closesocket(m_hSocket);
		m_hSocket = INVALID_SOCKET;
	}
}

int CSktBase::GetLastError( )
{
	return ::WSAGetLastError();
}

bool CSktBase::IsOpen()
{
	return (m_hSocket != INVALID_SOCKET);
}

FARPROC	CSktBase::GetProcAddress(LPCTSTR strOpenSSLFuncName)
{
	FARPROC	farProc=NULL;
	if(!strOpenSSLFuncName)
		return NULL;
	if(!g_pStartup->SSL_accept)
		return NULL;
	if(g_pStartup->m_hSSLEay)
	{
		farProc = ::GetProcAddress(g_pStartup->m_hSSLEay, strOpenSSLFuncName);
	}
	if(!farProc && g_pStartup->m_hLibeay)
		farProc = ::GetProcAddress(g_pStartup->m_hLibeay, strOpenSSLFuncName);
	return farProc;
}