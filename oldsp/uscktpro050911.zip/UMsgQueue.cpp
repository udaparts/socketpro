// UMsgQueue.cpp: implementation of the CUMsgQueue class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UMsgQueue.h"
#include "uscktpro.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUMsgQueue::CUMsgQueue()
{

}

CUMsgQueue::~CUMsgQueue()
{

}

ULONG CUMsgQueue::GetCount()
{
	return GetSize()/sizeof(MSG);
}

void CUMsgQueue::PushMsg(const MSG &msg)
{
	Push((const BYTE*)&msg, sizeof(MSG));
}

ULONG CUMsgQueue::PopMsg(MSG &msg)
{
	ATLASSERT(GetSize() >= sizeof(msg));
	return Pop((BYTE*)&msg, sizeof(msg));
}

bool CUMsgQueue::CheckCancel()
{
	int n;
	int nCount = GetSize()/sizeof(MSG);
	MSG *pMsg = (MSG*)GetBuffer();
	for(n=0; n<nCount; n++)
	{
//		ATLASSERT(nCount == 1);
		if(pMsg[n].message == WM_CANCEL_REQUEST)
		{
			Pop(sizeof(MSG), sizeof(MSG)*n);
			return true;
		}
	}
	return false;
}