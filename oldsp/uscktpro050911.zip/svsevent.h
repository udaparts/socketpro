#ifndef __U_SOCKET_EVENT_SERVICE_1_H__
#define __U_SOCKET_EVENT_SERVICE_1_H__

#define	IDC_SRCSERVICEEVENT		1

static _ATL_FUNC_INFO OnSvsRequestProcessedInfo = {CC_STDCALL, VT_I4, 4, {VT_I2, VT_I4, VT_I4, VT_I2}};

template <class CContainer>
class CClientServiceEvent : public IDispEventSimpleImpl<IDC_SRCSERVICEEVENT, CClientServiceEvent, &__uuidof(_IURequestEvent)>							
{
public:
BEGIN_SINK_MAP(CClientServiceEvent)
	SINK_ENTRY_INFO(IDC_SRCSERVICEEVENT, __uuidof(_IURequestEvent), 1, OnSvsRequestProcessed, &OnSvsRequestProcessedInfo)
END_SINK_MAP()
	virtual HRESULT __stdcall OnSvsRequestProcessed(short nRequestID, long lLen, long lLenInBuffer, short sFlag)
	{
		return m_pContainer->OnSvsRequestProcessed(nRequestID, lLen, lLenInBuffer, sFlag);
	}
public:
	CContainer	*m_pContainer;
};

#endif