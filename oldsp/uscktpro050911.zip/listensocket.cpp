#include "stdafx.h"
#include "ULSocket.h"
#include "Startup.h"
#include "UThread.h"
#include "ChatRoom.h"
#include "context.h"
#include "mswsock.h"

CUListener	*g_pSocketSvr = NULL;
CSimpleMap<SOCKET, CUClient*> g_mapUClient;
CUMsgQueue	g_UMsgQueue;

extern CStartup	*g_pStartup;

CUQueue	g_chatQueue;
extern CUQueue	g_tempQueue;
extern CUQueue	g_cancelQueue;
extern CUQueue	g_tempQueue;
extern CUQueue	g_tempQueueSnd;

extern CThreadPool		*g_pThreadPool;


bool WINAPI StartBatching(unsigned int hSocket)
{
	CUClient *pUClient;
	if(g_pSocketSvr == NULL)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient)
	{
		return pUClient->startBatching();
	}
	return false;
}

bool WINAPI CommitBatching(unsigned int hSocket)
{
	CUClient *pUClient;
	DWORD	ulMaxSpeed = 0;
	DWORD dwThreadID = ::GetCurrentThreadId();
	DWORD dwMainThreadID = GetMainThreadID();
	if(dwThreadID != dwMainThreadID)
	{
		do
		{
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				pUClient = g_mapUClient.Lookup(hSocket);
				if(!pUClient || pUClient->m_bClosing)
					return false;
				if(ulMaxSpeed == 0)
				{
					if(pUClient->m_ulSpeed == 0)
					{
						unsigned long ulMTU;
						unsigned long ulType;
						unsigned long ulMask;
						pUClient->GetInterfaceAttributes(ulMTU, pUClient->m_ulSpeed, ulType, ulMask);
						if(pUClient->m_ulSpeed > 100000000)
							pUClient->m_ulSpeed = 100000000;
					}
					ulMaxSpeed = pUClient->m_ulSpeed;
				}
				if(pUClient->GetSndBytesInQueue()<(100000 + ulMaxSpeed/1000))
				{
					break;
				}
				else
				{
					pUClient->Send();
					if(pUClient->m_nRtn < 0)
					{
						return false;
					}
					if(pUClient->GetSndBytesInQueue()<(100000 + ulMaxSpeed/1000))
						break;
				}
			}
			::Sleep(5);
		}while(true);
	}

	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	pUClient = g_mapUClient.Lookup(hSocket);
	if(!pUClient || pUClient->m_bClosing)
		return false;
	return pUClient->commitBatching();
}


DWORD CUListener::GetMainThreadID()
{
//	CAutoLock AutoLock(&m_csLock);
	return m_dwMainThreadID;
}

/*
CRITICAL_SECTION* CUListener::GetCriticalSection()
{
	return &m_csLock;
}*/


ULONG RemoveLock()
{
	ULONG ul = 0;
	CRITICAL_SECTION *pCS = g_pSocketSvr->GetCriticalSection();
	ULONG	dwThreadID = ::GetCurrentThreadId();
	while((DWORD)pCS->OwningThread == dwThreadID)
	{
		ul++;
		::LeaveCriticalSection(pCS);
	}
	
	return ul;
}

void Relock(ULONG ulCount)
{
	CRITICAL_SECTION *pCS = g_pSocketSvr->GetCriticalSection();
	while(ulCount > 0)
	{
		::EnterCriticalSection(pCS);
		ulCount--;
	}
}

CUClient* CUListener::PostProcess(CUClient *pClientFromAceeptex)
{
	if(pClientFromAceeptex == NULL)
	{
		m_nRtn = -1;
		if(m_OnAccept)
		{
			ULONG ulCount = RemoveLock();
			m_OnAccept(INVALID_SOCKET, ::WSAGetLastError());
			Relock(ulCount);
		}
		return NULL;
	}

	else if(pClientFromAceeptex->m_bRejected)
	{
		UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, pClientFromAceeptex->m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, WSAECONNREFUSED));
//		return false;
	}

	UINT nPeerPort = NULL;
	LPSTR strPeerName = NULL;
	pClientFromAceeptex->GetPeerName(nPeerPort, strPeerName);
	if(strPeerName != NULL && strcmp(strPeerName, "127.0.0.1") == 0)
	{
		//pClient->m_bRegistered = true;
		pClientFromAceeptex->m_bLocal = true;
	}
	else
	{
		pClientFromAceeptex->m_bLocal = false;
	}

	if(pClientFromAceeptex->m_EncryptionMethod==TLSv1 || pClientFromAceeptex->m_EncryptionMethod == SSL23)
	{
		if(!pClientFromAceeptex->SetSSL())
		{
			if(m_OnAccept)
			{
				ULONG ulCount = RemoveLock();
				m_OnAccept(pClientFromAceeptex->m_hSocket, ::WSAGetLastError());
				Relock(ulCount);
			}
			delete pClientFromAceeptex;
			return NULL;	
		}
		else 
		{
			int err = g_pStartup->SSL_accept(pClientFromAceeptex->m_pSSL->GetSSL()); 
			if(err==-1)
			{
				err = g_pStartup->SSL_get_error(pClientFromAceeptex->m_pSSL->GetSSL(), err);
				switch (err)
				{
				case SSL_ERROR_NONE:
				case seSSLWantWrite:
				case seSSLWantRead :
					break;
				default :
					{
						if(m_OnAccept)
						{
							ULONG ulCount = RemoveLock();
							m_OnAccept(pClientFromAceeptex->m_hSocket, err);
							Relock(ulCount);
						}
						delete pClientFromAceeptex;
						return NULL;	
					}
					break;
				}
			}
		}
	}
	{
		CAutoLock AutoLock(&m_csLock);
		g_mapUClient.Add(pClientFromAceeptex->m_hSocket, pClientFromAceeptex);
		if(pClientFromAceeptex->m_bRejected)
			pClientFromAceeptex->m_bProcessingSlowRequest = true;

	}
	if(m_OnAccept)
	{
		ULONG ulCount = RemoveLock();
		m_OnAccept(pClientFromAceeptex->m_hSocket, 0);
		Relock(ulCount);
	}

	return pClientFromAceeptex;
}

CSimpleMap<unsigned long, unsigned long> CUListener::m_mapAddrCount;

CUClient* CUListener::PostProcess(unsigned int hClientSocket)
{
	if(hClientSocket == INVALID_SOCKET)
	{
		m_nRtn = -1;
		if(m_OnAccept)
		{
			ULONG ulCount = RemoveLock();
			m_OnAccept(INVALID_SOCKET, ::WSAGetLastError());
			Relock(ulCount);
		}
		return NULL;
	}
	else if(m_bRejected)
	{
		UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, hClientSocket, WSAMAKESELECTREPLY(FD_CLOSE, WSAECONNREFUSED));
//		return false;
	}
	CUClient* pClient = CreateClientSocket();
	if(!pClient)
	{
		::closesocket(hClientSocket);
		if(m_OnAccept)
		{
			ULONG ulCount = RemoveLock();
			m_OnAccept(INVALID_SOCKET, ::WSAGetLastError());
			Relock(ulCount);
		}
		return NULL;
	}
	pClient->m_hSocket = hClientSocket;
	UINT nPeerPort = NULL;
	LPSTR strPeerName = NULL;
	pClient->GetPeerName(nPeerPort, strPeerName);
	if(strPeerName != NULL && strcmp(strPeerName, "127.0.0.1") == 0)
	{
		//pClient->m_bRegistered = true;
		pClient->m_bLocal = true;
	}
	else
	{
		pClient->m_bLocal = false;
	}

	//pClient->GetInterfaceAttributes(pClient->m_ulMTU, pClient->m_ulSpeed, pClient->m_ulType, pClient->m_ulMask);
	if(m_bUseMessagePump)
	{
		long lData = 8*1460;
		int err = ::setsockopt(hClientSocket, SOL_SOCKET, soSndBuf, (char*)&lData, sizeof(lData)); 
		err = ::setsockopt(hClientSocket, SOL_SOCKET, soRcvBuf, (char*)&lData, sizeof(lData)); 
	}
	
	if(pClient->m_EncryptionMethod==TLSv1 || pClient->m_EncryptionMethod == SSL23)
	{
		if(!pClient->SetSSL())
		{
			delete pClient;
			if(m_OnAccept)
			{
				ULONG ulCount = RemoveLock();
				m_OnAccept(INVALID_SOCKET, ::WSAGetLastError());
				Relock(ulCount);
			}
			return NULL;	
		}
		else 
		{
			int err = g_pStartup->SSL_accept(pClient->m_pSSL->GetSSL()); 
			if(err==-1)
			{
				err = g_pStartup->SSL_get_error(pClient->m_pSSL->GetSSL(), err);
				switch (err)
				{
				case SSL_ERROR_NONE:
				case seSSLWantWrite:
				case seSSLWantRead :
					break;
				default :
					{
						delete pClient;
						if(m_OnAccept)
						{
							ULONG ulCount = RemoveLock();
							m_OnAccept(INVALID_SOCKET, err);
							Relock(ulCount);
						}
						return NULL;	
					}
					break;
				}
			}
		}
	}
	{
		CAutoLock AutoLock(&m_csLock);
		g_mapUClient.Add(hClientSocket, pClient);
		if(m_bRejected)
			pClient->m_bProcessingSlowRequest = true;

	}
	if(m_OnAccept)
	{
		ULONG ulCount = RemoveLock();
		m_OnAccept(pClient->m_hSocket, 0);
		Relock(ulCount);
	}
	return pClient;
}

DWORD WINAPI CUListener::MThreadProc(LPVOID lpParameter)
{
	HANDLE hEvent = g_pSocketSvr->m_hMEvent;
	while(::WaitForSingleObject(hEvent, 10000))
	{
		{
			MSG msg;
			msg.message = 0;
			bool bSleep = false;
			::EnterCriticalSection(g_pSocketSvr->GetCriticalSection());
			while(g_UMsgQueue.GetSize() > 0)
			{
				g_UMsgQueue.PopMsg(msg);
				::LeaveCriticalSection(g_pSocketSvr->GetCriticalSection());
				if(msg.message == WM_QUIT)
					break;
				msg.message = WM_SOCKET_SVR_NOTIFY;
				msg.lParam = MLPARAM;
				if(!bSleep)
				{
					::Sleep(msg.time);
					bSleep = true;
				}
				::EnterCriticalSection(g_pSocketSvr->GetCriticalSection());
				g_pSocketSvr->m_UMsgQueue.PushMsg(msg);
				BOOL bSuc = g_pStartup->PostQueuedCompletionStatus(g_pSocketSvr->m_hCompletionPort, 0, (DWORD)g_pSocketSvr, &g_pSocketSvr->m_IOPortContext);
			}
			if(msg.message == WM_QUIT)
				break;
			else
				::LeaveCriticalSection(g_pSocketSvr->GetCriticalSection());
		}
	}
	return 0;
}

int CUListener::GetPeerName(SOCKET hSocket, struct sockaddr *name, int *namelen)
{
	if(name == NULL || namelen == NULL || *namelen < sizeof(sockaddr))
	{
		::WSASetLastError(WSAEINVAL);
		return -1;
	}
	ULONG ul, ulPos = 0;
	ULONG ulUnit = sizeof(SOCKET) + 2*sizeof(sockaddr);
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	ULONG ulSize = m_suAddr.GetSize()/ulUnit;
	for(ul = 0; ul < ulSize; ++ul)
	{
		SOCKET *pSocket = (SOCKET*)m_suAddr.GetBuffer(ulPos);
		sockaddr *addr = (sockaddr*)m_suAddr.GetBuffer(ulPos + sizeof(SOCKET) + sizeof(sockaddr));
		if(*pSocket == hSocket)
		{
			*namelen = sizeof(sockaddr);
			::memcpy(name, addr, sizeof(sockaddr));
			return 0;
		}
		ulPos += ulUnit;
	}
	::WSASetLastError(WSAENOTSOCK);
	return -1;
}

void CUListener::RemoveSockAddr(SOCKET hSocket)
{
	ULONG ul, ulPos = 0;
	ULONG ulUnit = sizeof(SOCKET) + 2*sizeof(sockaddr);
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	ULONG ulSize = m_suAddr.GetSize()/ulUnit;
	for(ul = 0; ul < ulSize; ++ul)
	{
		SOCKET *pSocket = (SOCKET*)m_suAddr.GetBuffer(ulPos);
		if(*pSocket == hSocket)
		{
			m_suAddr.Pop(ulUnit, ulPos);
			return;
		}
		ulPos += ulUnit;
	}
}

int CUListener::GetSockName(SOCKET hSocket, struct sockaddr *name, int *namelen)
{
	if(name == NULL || namelen == NULL || *namelen < sizeof(sockaddr))
	{
		::WSASetLastError(WSAEINVAL);
		return -1;
	}
	ULONG ul, ulPos = 0;
	ULONG ulUnit = sizeof(SOCKET) + 2*sizeof(sockaddr);
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	ULONG ulSize = m_suAddr.GetSize()/ulUnit;
	for(ul = 0; ul < ulSize; ++ul)
	{
		SOCKET *pSocket = (SOCKET*)m_suAddr.GetBuffer(ulPos);
		sockaddr *addr = (sockaddr*)m_suAddr.GetBuffer(ulPos + sizeof(SOCKET));
		if(*pSocket == hSocket)
		{
			*namelen = sizeof(sockaddr);
			::memcpy(name, addr, sizeof(sockaddr));
			return 0;
		}
		ulPos += ulUnit;
	}
	::WSASetLastError(WSAENOTSOCK);
	return -1;
}

DWORD WINAPI CUListener::LThreadProc(LPVOID lpParameter)
{
	bool ok;
	bool bRoot;
	int count, n;
	SOCKET hSocket;
	DWORD dwBytes;
	ULONG_PTR dwKey;
	DWORD dwNumberOfBytesTransferred;
	LPOVERLAPPED pOverLapped;
	MSG msg;
	WSAOVERLAPPED olOverlap;
	SOCKET AcceptSocket;
	SYSTEM_INFO si;
	::GetSystemInfo(&si);
	DWORD AcceptThreadCount = 1 + si.dwNumberOfProcessors/2;
	char lpOutputBuf[(sizeof(sockaddr_in) + 16)*2] = {0};
	int outBufLen = sizeof(lpOutputBuf);
	DWORD dwTime = 1000;
	LPFN_ACCEPTEX AcceptEx = NULL;
	GUID GuidAcceptEx = WSAID_ACCEPTEX;
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		hSocket = g_pSocketSvr->m_hSocket;
		bRoot = (g_pSocketSvr->m_hAcceptExPort == INVALID_HANDLE_VALUE);
		if(bRoot)
		{
			g_pSocketSvr->m_hAcceptExPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, (u_long)0, AcceptThreadCount);
			HANDLE hPort = CreateIoCompletionPort((HANDLE)hSocket, g_pSocketSvr->m_hAcceptExPort, (u_long)0, AcceptThreadCount);
			g_pSocketSvr->m_dwAcceptThreadCount = 1;
		}
	}
	
	LPFN_GETACCEPTEXSOCKADDRS lp = NULL;
	int err = WSAIoctl(	hSocket, 
						SIO_GET_EXTENSION_FUNCTION_POINTER, 
						&GuidAcceptEx, 
						sizeof(GuidAcceptEx),
						&AcceptEx, 
						sizeof(AcceptEx), 
						&dwBytes, 
						NULL, 
						NULL);
	static GUID guid = WSAID_GETACCEPTEXSOCKADDRS;
	err = WSAIoctl(	hSocket, 
						SIO_GET_EXTENSION_FUNCTION_POINTER,
						(LPVOID)&guid, 
						sizeof(GUID), 
						(LPVOID)&lp, 
						sizeof(LPFN_GETACCEPTEXSOCKADDRS), 
						&dwBytes, 
						NULL, 
						NULL);
	CSimpleArray<SOCKET> SocketPool;
	AcceptSocket = ::WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
	//AcceptSocket = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	do
	{
		::memset(&olOverlap, 0, sizeof(olOverlap));
		err = AcceptEx(	hSocket, 
						AcceptSocket,
						lpOutputBuf, 
						0,
						sizeof(sockaddr_in) + 16, 
						sizeof(sockaddr_in) + 16, 
						&dwBytes, 
						&olOverlap);
		ok = true;
		count = SocketPool.GetSize();
		switch(count)
		{
		case 0:
		case 1:
		case 2:
		case 3:
			dwTime = 0;
			break;
		case 4:
		case 5:
		case 6:
			dwTime = 1;
			break;
		case 7:
		case 8:
		case 9:
			dwTime = 2;
			break;
		case 10:
		case 11:
		case 12:
			dwTime = 4;
			break;
		case 13:
		case 14:
		case 15:
			dwTime = 8;
			break;
		case 16:
		case 17:
		case 18:
			dwTime = 16;
			break;
		case 19:
		case 20:
		case 21:
			dwTime = 32;
			break;
		default:
			dwTime = 1000;
			break;
		}
		if(GetQueuedCompletionStatus(g_pSocketSvr->m_hAcceptExPort, &dwNumberOfBytesTransferred, &dwKey, &pOverLapped, dwTime))
		{
			int len0, len1;
			sockaddr_in *pAddr;
			sockaddr *pLocal, *pRemote;
			bool bRejected = false;
			lp(lpOutputBuf, 0, sizeof(sockaddr_in) + 16, sizeof(sockaddr_in) + 16, &pLocal, &len0, &pRemote, &len1);
			pAddr = (sockaddr_in*)pRemote;
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				if(bRoot && dwTime <= 1 && g_pSocketSvr->m_dwAcceptThreadCount < AcceptThreadCount)
				{
					DWORD dwThreadId;
					HANDLE hThread = ::CreateThread(NULL, 0, LThreadProc, g_pSocketSvr, 0, &dwThreadId);
					g_pSocketSvr->m_aChildAcceptThread.Add(hThread);
					g_pSocketSvr->m_dwAcceptThreadCount++;
				}
				m_suAddr << AcceptSocket;
				m_suAddr.Push((unsigned char*)pLocal, sizeof(sockaddr_in));
				m_suAddr.Push((unsigned char*)pRemote, sizeof(sockaddr_in));
			}
			u_long addr = pAddr->sin_addr.S_un.S_addr;
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				int index = m_mapAddrCount.FindKey(addr);
				if(index == -1)
				{
					unsigned long count = 1;
					m_mapAddrCount.Add(addr, count);
				}
				else
				{
					unsigned long &count = m_mapAddrCount.GetValueAt(index);
					if(count >= g_pSocketSvr->m_ulMaxConnectionsPerClient)
						bRejected = true;
					count++;
				}
			}
			msg.hwnd = NULL;
			msg.pt.x = 0;
			msg.pt.y = 0;
			CUClientThreaded *pClientThread = g_pSocketSvr->CreateClientSocket();
			pClientThread->m_bRejected = bRejected;
			pClientThread->m_hSocket = AcceptSocket;
			msg.time = ::GetTickCount();
			msg.wParam = (WPARAM)pClientThread;
			msg.message = WM_SOCKET_SVR_NOTIFY;
			msg.lParam = WSAMAKESELECTREPLY(FD_ACCEPT, 0);
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				g_pSocketSvr->m_UMsgQueue.PushMsg(msg);
			}
			if(g_pStartup->PostQueuedCompletionStatus(g_pSocketSvr->m_hCompletionPort, 0, (DWORD)g_pSocketSvr, &g_pSocketSvr->m_IOPortContext))
			{
				
			}
			else
			{
				ATLASSERT(FALSE);
			}
			count = SocketPool.GetSize();
			if(count)
			{
				count--;
				AcceptSocket = SocketPool[count];
				SocketPool.RemoveAt(count);
			}
			else
				AcceptSocket = ::WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
				//AcceptSocket = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		}
		else
		{
			DWORD dwError = ::GetLastError();
			switch(dwError)
			{
			case ERROR_OPERATION_ABORTED:
				ok = (g_pSocketSvr != NULL);
				break;
			case WAIT_TIMEOUT:
				do
				{
					if(SocketPool.GetSize() < 25)
					{
						//SOCKET h = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
						SOCKET h = ::WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
						SocketPool.Add(h);
					}
					else
						break;
					if(dwTime == 0)
						break;
					--dwTime;
				}while(true);
				break;
			default:
				ok = false;
				break;
			}
		}
	}while(ok);
	count = SocketPool.GetSize();
	for(n=0; n<count; ++n)
	{
		::closesocket(SocketPool[n]);
	}
	SocketPool.RemoveAll();
	::closesocket(AcceptSocket);
	return 0;
}



//DWORD WINAPI CUListener::LThreadProc(LPVOID lpParameter)
//{
//	SOCKET hSocket = g_pSocketSvr->m_hSocket; 
//	do
//	{
//		SOCKET hClientSocket=::WSAAccept(hSocket, NULL, NULL, ConditionFunc, 0);
//		if(INVALID_SOCKET == hClientSocket)
//		{
//			int nError = ::WSAGetLastError();
//			if(nError != WSAECONNREFUSED)
//			{
//				break;
//			}
//		}
//		else
//		{
//			MSG msg;
//			msg.hwnd = NULL;
//			msg.time = ::GetTickCount();
//			msg.pt.x = 0;
//			msg.pt.y = 0;
//			msg.wParam = hClientSocket;
//			msg.message = WM_SOCKET_SVR_NOTIFY;
//			msg.lParam = WSAMAKESELECTREPLY(FD_ACCEPT, 0);
//			{
//				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
//				g_pSocketSvr->m_UMsgQueue.PushMsg(msg);
//			}
//			if(g_pStartup->PostQueuedCompletionStatus(g_pSocketSvr->m_hCompletionPort, 0, (DWORD)g_pSocketSvr, &g_pSocketSvr->m_IOPortContext))
//			{
//				
//			}
//			else
//			{
//				ATLASSERT(FALSE);
//			}	
//		}
//	}while(true);
//	return 0;
//}

bool CUListener::Accept()
{
	SOCKET hClientSocket=::WSAAccept(m_hSocket, NULL, NULL, ConditionFunc, 0);
	CAutoLock AutoLock(&m_csLock);
	return (PostProcess(hClientSocket) != NULL);
}

bool CUListener::StartThreadPools()
{
	g_pThreadPool = new CThreadPool;
	m_pThreadPool = g_pThreadPool;
	return true;
}

void CUListener::ShutdownThreadPools()
{
	CAutoLock AutoLock(&m_csLock);
	if(m_pThreadPool)
	{
		ULONG ulCount = RemoveLock();
		((CThreadPool*)m_pThreadPool)->DestroyAllThread();
		Relock(ulCount);
		delete (CThreadPool*)m_pThreadPool;
		m_pThreadPool = NULL;
		g_pThreadPool = NULL;
	}
}

bool CUListener::AddSvsContext(unsigned long ulSvsID, CSvsContext &SvsContext)
{
	CAutoLock AutoLock(&m_csLock);
	if(m_hSocket != 0 && m_hSocket != INVALID_SOCKET)
	{
		return false;
	}
	if(m_mapSvs.FindKey(ulSvsID) != -1)
		return false;
	CSvsContextEx ex;
	memcpy(&ex, &SvsContext, sizeof(SvsContext));
	ex.m_bRandom = false;
	m_mapSvs.Add(ulSvsID, ex);
	return true;
}

bool CUListener::ExistAChatGroup(unsigned long ulGroupID)
{
	ULONG n;
	CAutoLock AutoLock(GetCriticalSection());
	ULONG nCount=m_pChat->GetSize();
	for(n=0; n<nCount; n++){
		ULONG ulTemp = (*m_pChat)[n].m_nID;
		if(ulTemp == ulGroupID)
			return true;
	}
	return false;
}


bool CUListener::NotFindAChatGroup(unsigned long ulGroupID)
{
	ULONG n;
	CAutoLock AutoLock(GetCriticalSection());
	ULONG nCount=m_pChat->GetSize();
	for(n=0; n<nCount; n++){
		ULONG ulBitCount = 0;
		ULONG ulTemp = (*m_pChat)[n].m_nID;
		while(ulTemp){
			if((ulTemp & 0x1) == 1){
				ulBitCount++;
			}
			if(ulBitCount > 1)
				break;
			ulTemp >>= 1;
		}
		if(ulBitCount > 1)
			continue;
		if(((*m_pChat)[n].m_nID & ulGroupID))
			return false;
	}
	return true;
}

bool CUListener::CreateAChatGroup(unsigned long ulGroupID, LPCWSTR strDescription)
{
	ULONG n;
	if(ulGroupID == 0)
		return false;
	CAutoLock AutoLock(GetCriticalSection());
	ULONG nCount=m_pChat->GetSize();
	for(n=0; n<nCount; n++)
	{
		if((*m_pChat)[n].m_nID == ulGroupID)
			return false;
	}
	CChatGroup	ChatGroup;
	ChatGroup.m_nID = ulGroupID;
	if(strDescription)
		ChatGroup.m_bstrDescription = strDescription;
	m_pChat->Add(ChatGroup);
	return true;
}

CUClientThreaded* CUListener::CreateClientSocket()
{
	int n;
	CUClientThreaded *pClient = NULL;
	{
		CAutoLock AutoLock(GetCriticalSection());
		int nTotal = m_aPool.GetSize();
		for(n=(nTotal - 1); n>=0; n--)
		{
			pClient = m_aPool[n];
			ATLASSERT(pClient != NULL);
			if(pClient->m_bZipping)
			{
				pClient = NULL;
				continue;
			}
			m_aPool.RemoveAt(n);
			pClient->m_bClosing = false;
			pClient->m_pUThread = NULL;
			pClient->m_pSSL = NULL;
			pClient->m_EncryptionMethod = g_pSocketSvr->m_EncryptionMethod;
			pClient->m_ulStartBlocking = g_pSocketSvr->m_ulStartBlocking;
			pClient->m_bZip = g_pSocketSvr->m_bZip;
			pClient->m_bKeyLen = 0;
			pClient->m_bBatching = false;
			pClient->m_llBytesIn = 0;
			pClient->m_llBytesOut = 0;
			pClient->m_dwTimeTrackSnd = pClient->m_dwTimeTrackRcv = ::GetTickCount();
			pClient->m_bProcessingSlowRequest = false;
			pClient->m_bSendingTooFast = false;
			memset(&pClient->m_ClientInfo, 0, sizeof(pClient->m_ClientInfo));
			memset(&pClient->m_ServerInfo, 0, sizeof(pClient->m_ServerInfo));
			pClient->m_ServerInfo.m_usUSockMinor = 7;
			pClient->m_OnReceive = NULL;
			pClient->m_OnSend = NULL;
			pClient->m_ulSvsID = sidStartup;
			pClient->m_ulTimeOut = 60000;
			pClient->m_OnIsPermitted = NULL;
			pClient->m_OnBaseRequestCame = NULL;
			pClient->m_OnSendReturnData = NULL;
			pClient->m_OnThreadCreated = NULL;
			pClient->m_dwMaxBuffer = g_pSocketSvr->m_ulStartBlocking;
			memset(&pClient->m_StreamHeader,  0, sizeof(pClient->m_StreamHeader));
			memset(&pClient->m_SockThreadContext, 0, sizeof(pClient->m_SockThreadContext));
			pClient->m_OnFastRequestArrive = NULL;
			pClient->m_OnRequestProcessed = NULL;
			pClient->m_OnClose = NULL;
			pClient->m_OnSwitchTo = NULL;
			pClient->m_pBlowFish = NULL;
			pClient->m_pUThread = NULL;
			pClient->m_bSameEndian = true;
			pClient->m_ulSpeed = 0;
			pClient->m_batchQueue.SetSize(0);
			pClient->m_rcvQueue.SetSize(0);
			pClient->m_MySpecificBytes.SetSize(0);
			pClient->m_sndQueue.SetSize(0);
			memset(&pClient->m_RcvIOContext, 0, sizeof(CIOPortContext));
			memset(&pClient->m_SndIOContext, 0, sizeof(CIOPortContext));
			pClient->m_bVerify = false;
			pClient->m_guid = IID_NULL;
			pClient->m_ZipLevel = zlDefault;
			pClient->m_bRegistered = g_bRegistered;
			pClient->m_HttpReqAttribute.m_HttpRequest = hrUnknown;
			pClient->m_HttpReqAttribute.m_dHttpVersion = 0.0;
			pClient->m_HttpReqAttribute.m_bRequestChunked = false;
			pClient->m_HttpReqAttribute.m_bResponseChunked = false;
			pClient->m_HttpReqAttribute.m_bKeepAlive = false;
			pClient->m_HttpReqAttribute.m_nKeepAlive = 0;
			pClient->m_HttpReqAttribute.m_nResponseCode = 200;
			pClient->m_HttpReqAttribute.m_bHeaderSent = false;
			pClient->m_HttpReqAttribute.m_nMaxMessageSize = DEFAULT_MAX_HTTP_MSG_SIZE;
			pClient->m_HttpReqAttribute.m_bServerMessage = false;
			pClient->m_HttpReqAttribute.m_qRMult.SetSize(0);
			pClient->m_HttpReqAttribute.m_bAutoPartition = true;
			pClient->m_HttpReqAttribute.m_nResponseLength = 0;
			pClient->m_HttpReqAttribute.m_nRequestLen = 0;
			pClient->m_tempQueue.SetSize(0);
			pClient->m_pHttpChatContext = NULL;
			pClient->m_bRejected = false;
			break;
		}
	}
	if(pClient == NULL)
	{
		pClient = new CUClientThreaded;
	}
	return pClient;
}

HINSTANCE CUListener::AddADll(const wchar_t *strLibFile, int nParam)
{
	USES_CONVERSION;
	if(!strLibFile)
		return NULL;
	if(m_hSocket != 0 && m_hSocket != INVALID_SOCKET)
	{
		return NULL;
	}
	HINSTANCE hInstance = ::LoadLibrary(OLE2T(strLibFile));
	if(hInstance)
	{
		CAutoLock AutoLock(GetCriticalSection());
		PInitServerLibrary InitServerLibrary = (PInitServerLibrary)::GetProcAddress(hInstance, _T("InitServerLibrary"));
		PGetNumOfServices GetNumOfServices = (PGetNumOfServices)::GetProcAddress(hInstance, _T("GetNumOfServices"));
		PGetAServiceID GetAServiceID = (PGetAServiceID)::GetProcAddress(hInstance, _T("GetAServiceID"));
		PGetOneSvsContext GetOneSvsContext = (PGetOneSvsContext)::GetProcAddress(hInstance, _T("GetOneSvsContext"));
		PGetNumOfSlowRequests GetNumOfSlowRequests = (PGetNumOfSlowRequests)::GetProcAddress(hInstance, _T("GetNumOfSlowRequests"));
		PGetOneSlowRequestID GetOneSlowRequestID = (PGetOneSlowRequestID)::GetProcAddress(hInstance, _T("GetOneSlowRequestID"));
		if(InitServerLibrary && GetNumOfServices && GetAServiceID && GetOneSvsContext && GetNumOfSlowRequests && GetOneSlowRequestID)
		{
			if(!InitServerLibrary(nParam))
			{
				::FreeLibrary(hInstance);
				return NULL;
			}
			CSvsContext SvsContext;
			unsigned short i;
			unsigned short usCount = GetNumOfServices();
			for(i=0; i<usCount; i++)
			{
				unsigned j;
				unsigned long ulSvsID = GetAServiceID(i);
				SvsContext = GetOneSvsContext(ulSvsID);
				AddSvsContext(ulSvsID, SvsContext);
				unsigned short usSlowCount = GetNumOfSlowRequests(ulSvsID);
				for(j = 0; j<usSlowCount; j++)
				{
					AddSlowRequest(ulSvsID, GetOneSlowRequestID(ulSvsID, j));
				}
			}
		}
		else
		{
			::FreeLibrary(hInstance);
			return NULL;
		}
		m_aLibrary.Add(hInstance);
	}
	return hInstance;
}

bool CUListener::RemoveADll(HINSTANCE hInstance)
{
	unsigned long ulSvsID;
	unsigned short us;
	CAutoLock AutoLock(GetCriticalSection());
	int nIndex = m_aLibrary.Find(hInstance);
	if(nIndex == -1)
		return false;
	PGetNumOfServices GetNumOfServices = (PGetNumOfServices)::GetProcAddress(hInstance, _T("GetNumOfServices"));
	PGetAServiceID GetAServiceID = (PGetAServiceID)::GetProcAddress(hInstance, _T("GetAServiceID"));
	unsigned short usCountOfService = GetNumOfServices();
	for(us=0; us<usCountOfService; us++)
	{
		ulSvsID = GetAServiceID(us);
		::RemoveASvsContext(ulSvsID);
	}
	PUninitServerLibrary UninitServerLibrary = (PUninitServerLibrary)::GetProcAddress(hInstance, _T("UninitServerLibrary"));
	UninitServerLibrary();
	::FreeLibrary(hInstance);
	m_aLibrary.RemoveAt(nIndex);
	return true;
}

bool CUListener::RemoveADll(const wchar_t *strDllFile)
{
	USES_CONVERSION;
	if(!strDllFile)
		return false;
	HMODULE hModule = ::GetModuleHandle(OLE2T(strDllFile));
	return RemoveADll(hModule);
}

bool CUListener::Create(UINT nPort, LPCTSTR lpszSocketAddress)
{
	USES_CONVERSION;
	SOCKADDR_IN sockAddr;
	m_dwMainThreadID = ::GetCurrentThreadId();
	if(g_pStartup->CreateIoCompletionPort == NULL)
	{
		m_bUseMessagePump = true;
	}
	if(m_bUseMessagePump)
	{
		if(!CreateWnd())
			return false;
		m_hSocket = ::socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
		if (m_hSocket == INVALID_SOCKET)
		{
			m_nRtn = -1;
			return false;
		}
		m_nRtn=::WSAAsyncSelect(m_hSocket, m_hWnd, WM_SOCKET_SVR_NOTIFY, FD_READ|FD_WRITE|FD_ACCEPT|FD_CLOSE);
		if(m_nRtn == -1)
		{
			::closesocket(m_hSocket);
			m_hSocket = INVALID_SOCKET;
			return false;
		}
	}
	else
	{
		m_hSocket = ::WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
		if(m_hSocket == INVALID_SOCKET)
		{
			return false;
		}
	}
	
	BOOL val = TRUE;
	::setsockopt(m_hSocket, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, (char*)&val, sizeof(val));

	memset(&sockAddr,0,sizeof(sockAddr));
	LPSTR lpszAscii = T2A((LPTSTR)lpszSocketAddress);
	sockAddr.sin_family = AF_INET;
	if (lpszAscii == NULL)
		sockAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	else
	{
		DWORD lResult = inet_addr(lpszAscii);
		if (lResult == INADDR_NONE)
		{
			WSASetLastError(WSAEINVAL);
			return false;
		}
		sockAddr.sin_addr.s_addr = lResult;
	}
	sockAddr.sin_port = htons((u_short)nPort);

	m_nRtn=bind(m_hSocket, (SOCKADDR*)&sockAddr, sizeof(sockAddr));
	if(m_nRtn == -1)
	{
		::closesocket(m_hSocket);
		m_hSocket = INVALID_SOCKET;
		return false;
	}
	return true;
}

void CUListener::Merge(const VARIANT &vt, CUQueue &qMerge)
{
	unsigned long *pGroups;
	if((vt.vt & VT_ARRAY) != VT_ARRAY)
		return;
	unsigned long j, jSize = m_pChat->GetSize();
	unsigned long n, nSize = vt.parray->rgsabound->cElements;
	SafeArrayAccessData(vt.parray, (void**)&pGroups);
	for(j=0; j<jSize; j++)
	{
		CChatGroup &cg = (*m_pChat)[j];
		for(n=0; n<nSize; n++)
		{
			if(pGroups[n] == cg.m_nID)
			{
				qMerge << pGroups[n];
				break;
			}
		}
	}
	SafeArrayUnaccessData(vt.parray);
}

void CUListener::Merge(unsigned long *pGroups, unsigned long ulCount, CUQueue &qMerge)
{
	qMerge.SetSize(0);
	if(ulCount == 0 || pGroups == NULL)
		return;
	unsigned long j, jSize = m_pChat->GetSize();
	unsigned long n, nSize = ulCount;
	for(j=0; j<jSize; j++)
	{
		CChatGroup &cg = (*m_pChat)[j];
		for(n=0; n<nSize; n++)
		{
			if(pGroups[n] == cg.m_nID)
			{
				qMerge << pGroups[n];
				break;
			}
		}
	}
}

void CUListener::Merge(unsigned long *pOne, unsigned long ulCount, const VARIANT &vtTwo, CUQueue &qMerge)
{
	unsigned long *pTwo;
	unsigned long n, nSize;
	unsigned long j, jSize = ulCount;
	qMerge.SetSize(0);
	if(ulCount == 0 || pOne == NULL)
		return;
	if((vtTwo.vt & VT_ARRAY) != VT_ARRAY)
		return;
	nSize = vtTwo.parray->rgsabound->cElements;
	SafeArrayAccessData(vtTwo.parray, (void**)&pTwo);
	for(n=0; n<nSize; n++)
	{
		for(j=0; j<jSize; j++)
		{
			if(pOne[j] == pTwo[n])
				qMerge << pOne[j];
		}
	}
	SafeArrayUnaccessData(vtTwo.parray);
}

void  CUListener::Merge(const VARIANT &vtOne, const VARIANT &vtTwo, CUQueue &qMerge)
{
	int n, nSize;
	int j, jSize;
	unsigned long	*pOne;
	unsigned long	*pTwo;
	
	qMerge.SetSize(0);
	if((vtOne.vt & VT_ARRAY) != VT_ARRAY || (vtTwo.vt & VT_ARRAY) != VT_ARRAY)
		return;
	jSize = vtOne.parray->rgsabound->cElements;
	SafeArrayAccessData(vtOne.parray, (void**)&pOne);
	
	nSize = vtTwo.parray->rgsabound->cElements;
	SafeArrayAccessData(vtTwo.parray, (void**)&pTwo);
	
	for(n=0; n<nSize; n++)
	{
		for(j=0; j<jSize; j++)
		{
			if(pOne[j] == pTwo[n])
				qMerge << pOne[j];
		}
	}
	SafeArrayUnaccessData(vtTwo.parray);
	SafeArrayUnaccessData(vtOne.parray);
}

void  CUListener::HTTPEnter(CWebChatContext *pWebChatContext)
{
	int n;
	CComVariant vtMsg;
	vtMsg.vt = VT_I4;
	int nCount = m_aChatContext.GetSize();
	USES_CONVERSION;
	unsigned long ulAddr = inet_addr(OLE2A(pWebChatContext->GetIpAddr().m_str));
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
/*		ATLASSERT(	p->m_vtGroups.vt == (VT_ARRAY|VT_I4) || 
					p->m_vtGroups.vt == (VT_ARRAY|VT_UI4) || 
					p->m_vtGroups.vt == (VT_ARRAY|VT_INT) || 
					p->m_vtGroups.vt == (VT_ARRAY|VT_UINT));

		ATLASSERT(	pWebChatContext->m_vtGroups.vt == (VT_ARRAY|VT_I4) || 
					pWebChatContext->m_vtGroups.vt == (VT_ARRAY|VT_UI4) || 
					pWebChatContext->m_vtGroups.vt == (VT_ARRAY|VT_INT) || 
					pWebChatContext->m_vtGroups.vt == (VT_ARRAY|VT_UINT));*/

		CScopeUQueue	sq;
		Merge(pWebChatContext->m_vtGroups, p->m_vtGroups, *sq);
		if(sq->GetSize() > 0)
		{
			vtMsg.lVal = *((long*)sq->GetBuffer());
			CMsgHolder *pMsgHolder = new CMsgHolder(pWebChatContext->m_bstrUserId, ulAddr, 0, sidHTTP);
			pMsgHolder->m_qGroup->Push(sq->GetBuffer(), sq->GetSize());
			pMsgHolder->PushMessage("enter", vtMsg); 
			p->AddMsg(pMsgHolder);
		}
	}
	m_aChatContext.Add(pWebChatContext);
}

void CUListener::HTTPExit(LPCWSTR strPushSessionId, LPSTR strPeerName, CComBSTR &bstrUserId, CComVariant &vtGroups)
{
	int n;
	USES_CONVERSION;
	CWebChatContext *pExiting = NULL;
	bstrUserId.Empty();
	int nCount = m_aChatContext.GetSize();
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		if(strPushSessionId && strPeerName && 
			wcscmp(p->GetHTTPPushSessionId().m_str, strPushSessionId) == 0 && 
			(strcmp(OLE2A(p->GetIpAddr().m_str), strPeerName) == 0 || strcmp("127.0.0.1", strPeerName) == 0))
		{
			pExiting = p;
			vtGroups = p->m_vtGroups;
			bstrUserId = p->m_bstrUserId;
			m_aChatContext.RemoveAt(n);
			break;
		}
	}

	if(pExiting)
	{
		CComVariant vtMsg;
		vtMsg.vt = VT_I4;
		unsigned long ulAddr= inet_addr(OLE2A(pExiting->GetIpAddr().m_str));
		nCount = m_aChatContext.GetSize();
		for(n=0; n<nCount; n++)
		{
			CWebChatContext *p = m_aChatContext[n];
			CScopeUQueue	sq;
			Merge(pExiting->m_vtGroups, p->m_vtGroups, *sq);
			if(sq->GetSize())
			{
				vtMsg.lVal = *((long*)sq->GetBuffer());
				CMsgHolder *pMsgHolder = new CMsgHolder(pExiting->m_bstrUserId, ulAddr, 0, sidHTTP);
				pMsgHolder->m_qGroup->Push(sq->GetBuffer(), sq->GetSize());
				pMsgHolder->PushMessage("exit", vtMsg); 
				p->AddMsg(pMsgHolder);
			}
		}
		if(pExiting->m_hSocket)
		{
			::shutdown(pExiting->m_hSocket, SD_BOTH);
			::PostClose(pExiting->m_hSocket, 0);
		}
		delete pExiting;
	}
}

CWebChatContext* CUListener::Seek(LPCWSTR strPushSessionId, LPSTR strPeerName)
{
	int n;
	USES_CONVERSION;
	int nCount = m_aChatContext.GetSize();
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		if(strPushSessionId && strPeerName && 
			wcscmp(p->GetHTTPPushSessionId().m_str, strPushSessionId) == 0 && 
			(strcmp(OLE2A(p->GetIpAddr().m_str), strPeerName) == 0 || strcmp("127.0.0.1", strPeerName) == 0))
			return p;
	}
	return NULL;
}

CWebChatContext* CUListener::HTTPSubscribe(LPCWSTR strPushSessionId, LPSTR strPeerName)
{
	return Seek(strPushSessionId, strPeerName);
}

bool CUListener::HTTPSendUserMessage(LPCWSTR strPushSessionId, LPSTR strPeerName, LPCWSTR strUserID, const VARIANT& vtMsg)
{
	int n;
	CComBSTR bstrUserId(strUserID);
	bstrUserId.ToLower();
	CWebChatContext *pSource = Seek(strPushSessionId, strPeerName);
	if(!pSource)
		return false;
	int nCount = m_aChatContext.GetSize();
	if(nCount)
	{
		USES_CONVERSION;
		unsigned long ulAddr = inet_addr(OLE2A(pSource->GetIpAddr().m_str));
		CMsgHolder *pMsgHolder = new CMsgHolder(pSource->m_bstrUserId, ulAddr, 0, sidHTTP);
		if(pSource->m_vtGroups.vt == (VT_ARRAY|VT_I4) || pSource->m_vtGroups.vt == (VT_ARRAY|VT_UI4))
		{
			BYTE *p;
			unsigned long ulSize = pSource->m_vtGroups.parray->rgsabound->cElements;
			::SafeArrayAccessData(pSource->m_vtGroups.parray, (void**)&p);
			pMsgHolder->m_qGroup->Push(p, ulSize*sizeof(unsigned long));
			::SafeArrayUnaccessData(pSource->m_vtGroups.parray);
		}
		pMsgHolder->AddRef();
		pMsgHolder->PushMessage("sendUserMessage", vtMsg); 
		for(n=0; n<nCount; n++)
		{
			CWebChatContext *p = m_aChatContext[n];
			CComBSTR bstr(p->m_bstrUserId);
			bstr.ToLower();
			if(bstrUserId == bstr)
				p->AddMsg(pMsgHolder);
		}
		pMsgHolder->Release();
	}
	return true;
}

bool CUListener::HTTPSpeak(LPCWSTR strPushSessionId, LPSTR strPeerName, const VARIANT& vtMsg, const VARIANT &vtGroups)
{
	int n;
	CWebChatContext *pSource = Seek(strPushSessionId, strPeerName);
	if(!pSource)
		return false;
	int nCount = m_aChatContext.GetSize();
	USES_CONVERSION;
	CScopeUQueue	sq;
	unsigned long ulAddr = inet_addr(OLE2A(pSource->GetIpAddr().m_str));
/*	if(pSource->m_vtGroups.vt == (VT_ARRAY|VT_I4) || pSource->m_vtGroups.vt == (VT_ARRAY|VT_UI4))
	{
		BYTE *p;
		unsigned long ulSize = pSource->m_vtGroups.parray->rgsabound->cElements;
		::SafeArrayAccessData(pSource->m_vtGroups.parray, (void**)&p);
		pMsgHolder->m_qGroup->Push(p, ulSize*sizeof(unsigned long));
		::SafeArrayUnaccessData(pSource->m_vtGroups.parray);
	}*/
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		if(pSource == p)
			continue;
		sq->SetSize(0);
		Merge(vtGroups, p->m_vtGroups, *sq);
		if(sq->GetSize())
		{
			CMsgHolder *pMsgHolder = new CMsgHolder(pSource->m_bstrUserId, ulAddr, 0, sidHTTP);
			pMsgHolder->m_qGroup->Push(sq->GetBuffer(), sq->GetSize());
			pMsgHolder->PushMessage("speak", vtMsg); 
			p->AddMsg(pMsgHolder);	
		}
	}
	return true;
}

void CUListener::XEnter(CUClientThreaded *pUClient, ULONG ulLen, unsigned short usId)
{
	int n;
	int nSize;
	int j, jSize;
	LPSTR	strPeer;
	unsigned short usLen;
	unsigned long ulGroup;
	unsigned long ulAddr;
	unsigned int nPeerPort;
	bool bSelf = false;
	unsigned long *pData;
	g_chatQueue.SetSize(0);
	CComVariant vtGroups;
	CSimpleArray<unsigned long> CurrentGroups;
	CSimpleArray<CChatGroup*> ExistingGroups;
	CSimpleArray<unsigned long> LeavingGroups;
	CSimpleArray<unsigned long> JoinGroups;
	if(g_chatQueue.GetMaxSize() < ulLen)
		g_chatQueue.ReallocBuffer(ulLen);
	unsigned long ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ATLASSERT(ulGet == ulLen);
	g_chatQueue.SetSize(ulGet);
	if(pUClient->GetSvsID() == sidHTTP)
	{
		//??? existing groups for HTTP
	}
	else
		GetJoinedGroup(pUClient->m_hSocket, ExistingGroups);
	if(usId == idXEnter)
	{
		g_chatQueue.PopVT(vtGroups);
		nSize = (int)vtGroups.parray->rgsabound->cElements;
		::SafeArrayAccessData(vtGroups.parray, (void**)&pData);
		for(n=0; n<nSize; n++)
		{
			if(CurrentGroups.Find(pData[n]) == -1 && pData[n] != 0)
				CurrentGroups.Add(pData[n]);
		}
		::SafeArrayUnaccessData(vtGroups.parray);
	}
	else if(usId == idEnter)
	{
		n = 0;
		ulGroup = 1;
		unsigned long ulGroups;
		g_chatQueue.Pop(&ulGroups);
		while(n<32)
		{
			if((ulGroup & ulGroups) == ulGroup)
				CurrentGroups.Add(ulGroup);
			++n;
			ulGroup <<= 1;
		}
	}
	else
	{
		ATLASSERT(FALSE);
	}

	CScopeUQueue sq;
	Merge(CurrentGroups.GetData(), (unsigned long)CurrentGroups.GetSize(), *sq);
	CurrentGroups.RemoveAll();
	while(sq->GetSize() > 0)
	{
		*sq >> ulGroup;
		CurrentGroups.Add(ulGroup);
	}

	ATLASSERT(g_chatQueue.GetSize()==0);
	nSize = ExistingGroups.GetSize();
	for(n=0; n<nSize; n++)
	{
		if(CurrentGroups.Find(ExistingGroups[n]->m_nID) == -1)
			LeavingGroups.Add(ExistingGroups[n]->m_nID);
	}
	
	nSize = CurrentGroups.GetSize();
	for(n=0; n<nSize; n++)
	{
		bool bFound = false;
		ulGroup = CurrentGroups[n];
		jSize = ExistingGroups.GetSize();
		for(j=0; j<jSize; j++)
		{
			if(ExistingGroups[j]->m_nID == ulGroup)
			{
				bFound = true;
				break;
			}
		}
		if(!bFound)
			JoinGroups.Add(ulGroup);
	}

	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = inet_addr(strPeer);
	g_chatQueue.SetSize(0);
	g_chatQueue << pUClient->m_ulSvsID;
	g_chatQueue << ulGroup;
	g_chatQueue << nPeerPort;
	g_chatQueue << ulAddr;
	usLen = 0;
	if(pUClient->m_strUID)
	{
		usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
	}
	g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
	if(usLen)
	{
		g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
	}
	nSize = LeavingGroups.GetSize();
	for(n=0; n<nSize; n++)
	{
		ulGroup = LeavingGroups[n];
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		CSimpleArray<SOCKET> *pClients = XGetJoinedClients(ulGroup);
		if(pClients == NULL)
			continue;
		jSize = pClients->GetSize();
		for(j=0; j<jSize; j++)
		{
			SOCKET hSocket = (*pClients)[j];
			CUClient *pOther = FindClient(hSocket);
			if(pOther == NULL || pOther->GetSvsID() == sidHTTP)
				continue;
			pOther->sendReturnData(idExit, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
		}
		pClients->Remove(pUClient->m_hSocket);
	}
	nSize = JoinGroups.GetSize();
	for(n=0; n<nSize; n++)
	{
		bSelf = true;
		ulGroup = JoinGroups[n];
		CSimpleArray<SOCKET> *pClients = XGetJoinedClients(ulGroup);
		if(pClients == NULL)
			continue;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		if(pUClient->GetSvsID() != sidHTTP && pClients->Find(pUClient->m_hSocket) == -1)
			pClients->Add(pUClient->m_hSocket);
		jSize = pClients->GetSize();
		for(j=0; j<jSize; j++)
		{
			SOCKET hSocket = (*pClients)[j];
			CUClient *pOther = FindClient(hSocket);
			if(pOther == NULL || pOther->GetSvsID() == sidHTTP)
				continue;
			pOther->sendReturnData(usId, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
		}
	}
	
	if(pUClient->GetSvsID() != sidHTTP)
	{
		CScopeUQueue sq;
		CComVariant vtMsg;
		vtMsg.vt = VT_I4;
		jSize = LeavingGroups.GetSize();
		if(jSize)
		{
			vtGroups.Clear();
			SAFEARRAYBOUND sab[1] = {jSize, 0};
			vtGroups.vt = (VT_ARRAY|VT_UI4);
			vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
			::SafeArrayAccessData(vtGroups.parray, (void**)&pData);
			memcpy(pData, LeavingGroups.GetData(), sizeof(unsigned long)*jSize);
			::SafeArrayUnaccessData(vtGroups.parray);
			jSize = m_aChatContext.GetSize();
			for(j=0; j<jSize; j++)
			{
				CWebChatContext *p = m_aChatContext[j];
				sq->SetSize(0);
				Merge(vtGroups, p->m_vtGroups, *sq);
				if(sq->GetSize())
				{
					vtMsg.lVal = *((long*)sq->GetBuffer());
					CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID());
					pMsgHolder->m_qGroup->Push(sq->GetBuffer(), sq->GetSize());
					pMsgHolder->PushMessage("exit", vtMsg); 
					p->AddMsg(pMsgHolder);
				}
			}
		}
		sq->SetSize(0);
		jSize = JoinGroups.GetSize();
		if(jSize)
		{
			vtGroups.Clear();
			SAFEARRAYBOUND sab[1] = {jSize, 0};
			vtGroups.vt = (VT_ARRAY|VT_UI4);
			vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
			::SafeArrayAccessData(vtGroups.parray, (void**)&pData);
			memcpy(pData, JoinGroups.GetData(), sizeof(unsigned long)*jSize);
			::SafeArrayUnaccessData(vtGroups.parray);
			jSize = m_aChatContext.GetSize();
			for(j=0; j<jSize; j++)
			{
				CWebChatContext *p = m_aChatContext[j];
				sq->SetSize(0);
				Merge(vtGroups, p->m_vtGroups, *sq);
				if(sq->GetSize())
				{
					vtMsg.lVal = *((long*)sq->GetBuffer());
					CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID());
					pMsgHolder->m_qGroup->Push(sq->GetBuffer(), sq->GetSize());
					pMsgHolder->PushMessage("enter", vtMsg); 
					p->AddMsg(pMsgHolder);
				}
			}
		}

	}

	if(!bSelf && pUClient->GetSvsID() != sidHTTP)
	{
		ulGroup = 0;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		pUClient->sendReturnData(usId, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}
}


void CUListener::Enter(CUClientThreaded *pUClient, ULONG ulLen)
{
/*	unsigned short usLen;
	ULONG	n;
	ULONG	nCount;
	LPSTR	strPeer;
	unsigned long ulAddr;
	unsigned int nPeerPort;
	DWORD	ulGroups = 0;
	ULONG	ulMyGroups = GetJoinedGroup(pUClient->m_hSocket);
	pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ATLASSERT(ulLen == sizeof(ulGroups));
	g_chatQueue.SetSize(ulLen);
	g_chatQueue.Pop(&ulGroups);
	ATLASSERT(g_chatQueue.GetSize()==0);
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = inet_addr(strPeer);

	ULONG ulUnchangeds = (ulMyGroups & ulGroups);
	ULONG ulExits = (ulMyGroups - ulUnchangeds);
	ULONG ulEnters = (ulGroups - ulUnchangeds);
	ULONG ulActualEnter = 0;

	CSimpleArray<CChatGroup> *pChat = m_pChat;
	if(ulExits > 0)
	{
		CSimpleArray<SOCKET> aJoinedClients;
		GetJoinedClients(ulExits, aJoinedClients);
		nCount = aJoinedClients.GetSize();
		for(n=0; n<nCount; n++)
		{
			DWORD dwMyGroups = GetJoinedGroup(aJoinedClients[n]);
			if(m_ulGroupsNotifiedWhenExiting & dwMyGroups & ulExits)
			{
				CUClient *pOther = FindClient(aJoinedClients[n]);
				ATLASSERT(pOther);
				g_chatQueue.SetSize(0);
				g_chatQueue.Push(&pUClient->m_ulSvsID);
				dwMyGroups &= ulExits;
				g_chatQueue.Push(&dwMyGroups);
				g_chatQueue.Push(&nPeerPort);
				g_chatQueue.Push(&ulAddr);
				usLen = 0;
				if(pUClient->m_strUID)
				{
					usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
				}
				if(pOther->m_HttpReqAttribute.m_HttpRequest == hrUnknown)
					pOther->sendReturnData(idExit, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
			}
		}

		nCount=pChat->GetSize();
		for(n=0; n<nCount; n++)
		{
			int nIndex=(*pChat)[n].m_Listeners.Find(pUClient->m_hSocket);
			if(nIndex != -1)
			{
				DWORD	dwGroup=(*pChat)[n].m_nID;
				if((ulExits & dwGroup))
				{
					(*pChat)[n].m_Listeners.RemoveAt(nIndex);
				}
			}
		}

		if(pUClient->GetSvsID() != sidHTTP)
		{
			CComVariant vtMsg;
			vtMsg.vt = VT_UI4;

			CSimpleArray<CWebChatContext*> aChatContext;
			GetJoinedClients(ulExits, aChatContext);
			nCount = aChatContext.GetSize();
			for(n=0; n<nCount; n++)
			{
				CWebChatContext *p = aChatContext[n];
				DWORD dwMyGroups = p->m_ulGroups;
				vtMsg.ulVal = (m_ulGroupsNotifiedWhenExiting & dwMyGroups & ulExits);
				if(vtMsg.ulVal)
				{
					CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID(), vtMsg.ulVal);
					pMsgHolder->PushMessage("exit", vtMsg); 
					p->AddMsg(pMsgHolder);
				}
			}
		}
	}
	if(ulEnters > 0)
	{
		CSimpleArray<SOCKET> aJoinedClients;
		GetJoinedClients(ulEnters, aJoinedClients);
		nCount = aJoinedClients.GetSize();
		for(n=0; n<nCount; n++)
		{
			DWORD dwMyGroups = GetJoinedGroup(aJoinedClients[n]);
			if((m_ulGroupsNotifiedWhenEntering & ulEnters & dwMyGroups))
			{
				CUClient *pOther = FindClient(aJoinedClients[n]);
				ATLASSERT(pOther);
				if(pOther == pUClient || pOther->GetSvsID() == sidHTTP)
				{
					continue;
				}
				g_chatQueue.SetSize(0);
				g_chatQueue.Push(&pUClient->m_ulSvsID);
				dwMyGroups &= ulEnters;
				g_chatQueue.Push(&dwMyGroups);
				g_chatQueue.Push(&nPeerPort);
				g_chatQueue.Push(&ulAddr);
				usLen = 0;
				if(pUClient->m_strUID)
				{
					usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
				}
				pOther->sendReturnData(idEnter, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
			}
		}

		nCount=pChat->GetSize();
		for(n=0; n<nCount; n++)
		{
			DWORD	dwGroup=(*pChat)[n].m_nID;
			if((ulEnters & dwGroup))
			{
				ulActualEnter += dwGroup;
				if(pUClient->m_HttpReqAttribute.m_HttpRequest == hrUnknown)
					(*pChat)[n].m_Listeners.Add(pUClient->m_hSocket);
			}
		}
		
		if(pUClient->GetSvsID() != sidHTTP)
		{
			CComVariant vtMsg;
			vtMsg.vt = VT_UI4;

			ulMyGroups = GetJoinedGroup(pUClient->m_hSocket);

			CSimpleArray<CWebChatContext*> aChatContext;
			GetJoinedClients(ulEnters, aChatContext);
			nCount = aChatContext.GetSize();
			for(n=0; n<nCount; n++)
			{
				CWebChatContext *p = aChatContext[n];
				DWORD dwMyGroups = p->m_ulGroups;
				vtMsg.ulVal = (m_ulGroupsNotifiedWhenEntering & dwMyGroups & ulEnters);
				if(vtMsg.ulVal)
				{
					CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID(), ulMyGroups);
					pMsgHolder->PushMessage("enter", vtMsg); 
					p->AddMsg(pMsgHolder);
				}
			}
		}
	}
	
	if(pUClient->m_HttpReqAttribute.m_HttpRequest == hrUnknown)
	{
		ulActualEnter += ulUnchangeds;
		g_chatQueue.SetSize(0);
		g_chatQueue.Push(&pUClient->m_ulSvsID);
		g_chatQueue.Push(&ulActualEnter);
		g_chatQueue.Push(&nPeerPort);
		g_chatQueue.Push(&ulAddr);
		usLen = 0;
		if(pUClient->m_strUID)
		{
			usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
		}
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
		}
		pUClient->sendReturnData(idEnter, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}*/
}

void CUListener::Exit(LPCWSTR strUserId, LPCWSTR strIpAddr, const VARIANT &vtGroups)
{
	USES_CONVERSION;
	int n, nCount;
	unsigned long j, jSize;
	unsigned long *pGroups;
	unsigned short usLen;
	unsigned long ulGroup;
	if(!(vtGroups.vt == (VT_ARRAY|VT_UI4) || vtGroups.vt == (VT_ARRAY|VT_I4) || vtGroups.vt == (VT_ARRAY|VT_UINT) || vtGroups.vt == (VT_ARRAY|VT_INT)))
		return;
	int nPeerPort = 0;
	char *strPeer = OLE2A(strIpAddr);
	ULONG ulSvsID = sidHTTP;
	unsigned long ulAddr = inet_addr(strPeer); 
	g_chatQueue.SetSize(0);
	g_chatQueue.Push(&ulSvsID);
	g_chatQueue.Push(&ulGroup);
	g_chatQueue.Push(&nPeerPort);
	g_chatQueue.Push(&ulAddr);
	usLen = 0;
	if(strUserId)
		usLen = ::wcslen(strUserId)*sizeof(WCHAR);
	g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
	if(usLen)
		g_chatQueue.Push((BYTE*)strUserId, usLen);
	jSize = vtGroups.parray->rgsabound->cElements;
	::SafeArrayAccessData(vtGroups.parray, (void**)&pGroups);
	for(j=0; j<jSize; j++)
	{
		ulGroup = pGroups[j];
		memcpy((BYTE*)(g_chatQueue.GetBuffer() + sizeof(ulSvsID)), &ulGroup, sizeof(ulGroup));
		nCount = m_pChat->GetSize();
		for(n=0; n<nCount; n++)
		{
			CChatGroup &cg = (*m_pChat)[n];
			if(cg.m_nID != ulGroup)
				continue;
			int m, mSize = cg.m_Listeners.GetSize();
			for(m=0; m<mSize; m++)
			{
				CUClient *pOther = FindClient(cg.m_Listeners[m]);
				if(pOther == NULL || pOther->GetSvsID() == sidHTTP)
					continue;
				pOther->sendReturnData(idExit, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
			}
		}
	}
	::SafeArrayUnaccessData(vtGroups.parray);
}

void CUListener::Exit(CUClientThreaded *pUClient, ULONG ulLen, bool bOwn)
{
	int	n;
	int	nSize;
	int j, jSize;
	unsigned short usLen;
	unsigned long ulGroup = 0;
	bool bSelf = false;
	CSimpleArray<CChatGroup*> aJoinedGroup;
	GetJoinedGroup(pUClient->m_hSocket, aJoinedGroup);
	LPSTR	strPeer = NULL;
	unsigned long ulAddr = 0;
	unsigned int nPeerPort = 0;
	ATLASSERT(ulLen == 0);
	g_chatQueue.SetSize(0);
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = inet_addr(strPeer); 
	nSize = aJoinedGroup.GetSize();
	g_chatQueue.Push(&pUClient->m_ulSvsID);
	g_chatQueue.Push(&ulGroup);
	g_chatQueue.Push(&nPeerPort);
	g_chatQueue.Push(&ulAddr);
	usLen = 0;
	if(pUClient->m_strUID)
		usLen = (unsigned short)::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
	g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
	if(usLen)
		g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
	for(n=0; n<nSize; n++)
	{
		CChatGroup *pCG = aJoinedGroup[n];
		if(pCG == NULL)
			continue;
		ulGroup = pCG->m_nID;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		jSize = pCG->m_Listeners.GetSize();
		for(j=0; j<jSize; j++)
		{
			CUClient *pOther = FindClient(pCG->m_Listeners[j]);
			if(pOther == NULL || pOther->GetSvsID() == sidHTTP)
				continue;
			if(pOther == pUClient)
				bSelf = true;
			pOther->sendReturnData(idExit, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
		}
	}
	
	nSize = m_pChat->GetSize();
	for(n=0; n<nSize; n++)
	{
		(*m_pChat)[n].m_Listeners.Remove(pUClient->m_hSocket);
	}

	if(pUClient->GetSvsID() != sidHTTP)
	{
		CComVariant vtMsg;
		vtMsg.vt = VT_I4;
		jSize = aJoinedGroup.GetSize();
		if(jSize)
		{
			unsigned long *p;
			CScopeUQueue sq;
			SAFEARRAYBOUND sab[1] = {jSize, 0};
			CComVariant vtGroups;
			vtGroups.vt = (VT_ARRAY|VT_UI4);
			vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
			::SafeArrayAccessData(vtGroups.parray, (void**)&p);
			for(j=0; j<jSize; j++)
				p[j] = aJoinedGroup[j]->m_nID;
			::SafeArrayUnaccessData(vtGroups.parray);
			nSize = m_aChatContext.GetSize();
			for(n=0; n<nSize; n++)
			{
				CWebChatContext *p = m_aChatContext[n];
				sq->SetSize(0);
				Merge(vtGroups, p->m_vtGroups, *sq);
				if(sq->GetSize())
				{
					vtMsg.lVal = *((long*)sq->GetBuffer());
					CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID());
					pMsgHolder->m_qGroup->Push(sq->GetBuffer(), sq->GetSize());
					pMsgHolder->PushMessage("exit", vtMsg); 
					p->AddMsg(pMsgHolder);
				}
			}
		}

	/*
		CSimpleArray<CWebChatContext*> aChatContext;
		GetJoinedClients(ulGroupSelf, aChatContext);
		nCount = aChatContext.GetSize();
		for(n=0; n<nCount; n++)
		{
			CWebChatContext *p = aChatContext[n];
			DWORD dwMyGroups = p->m_ulGroups;
			vtMsg.ulVal = (m_ulGroupsNotifiedWhenExiting & dwMyGroups & ulGroupSelf);
			if(vtMsg.ulVal)
			{
				CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID(), vtMsg.ulVal);
				pMsgHolder->PushMessage("exit", vtMsg); 
				p->AddMsg(pMsgHolder);
			}
		}*/
	}

	if(!bSelf && pUClient->GetSvsID() != sidHTTP)
	{
		ulGroup = 0;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		pUClient->sendReturnData(idExit, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}

/*	DWORD	ulGroupSelf = GetJoinedGroup(pUClient->m_hSocket);
	LPSTR	strPeer = NULL;
	unsigned long ulAddr = 0;
	unsigned int nPeerPort = 0;
	ATLASSERT(ulLen == 0);
	g_chatQueue.SetSize(0);
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = inet_addr(strPeer); 
	//HTTP
	if(pUClient->GetSvsID() != sidHTTP)
	{
		CComVariant vtMsg;
		vtMsg.vt = VT_UI4;
		CSimpleArray<CWebChatContext*> aChatContext;
		GetJoinedClients(ulGroupSelf, aChatContext);
		nCount = aChatContext.GetSize();
		for(n=0; n<nCount; n++)
		{
			CWebChatContext *p = aChatContext[n];
			DWORD dwMyGroups = p->m_ulGroups;
			vtMsg.ulVal = (m_ulGroupsNotifiedWhenExiting & dwMyGroups & ulGroupSelf);
			if(vtMsg.ulVal)
			{
				CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID(), vtMsg.ulVal);
				pMsgHolder->PushMessage("exit", vtMsg); 
				p->AddMsg(pMsgHolder);
			}
		}
	}
	
	CSimpleArray<SOCKET> aJoinedClients;
	GetJoinedClients(ulGroupSelf, aJoinedClients);
	nCount = aJoinedClients.GetSize();
	for(n=0; n<nCount; n++)
	{
		DWORD dwMyGroups = GetJoinedGroup(aJoinedClients[n]);
		if((m_ulGroupsNotifiedWhenExiting & dwMyGroups))
		{
			CUClient *pOther = FindClient(aJoinedClients[n]);
			ATLASSERT(pOther);
			if(pOther == pUClient || pOther->GetSvsID() == sidHTTP)
			{
				continue;
			}
			g_chatQueue.SetSize(0);
			g_chatQueue.Push(&pUClient->m_ulSvsID);
			dwMyGroups = (dwMyGroups & ulGroupSelf);
			g_chatQueue.Push(&dwMyGroups);
			g_chatQueue.Push(&nPeerPort);
			g_chatQueue.Push(&ulAddr);
			usLen = 0;
			if(pUClient->m_strUID)
			{
				usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
			}
			g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
			if(usLen)
			{
				g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
			}
			pOther->sendReturnData(idExit, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
		}
	}

	CSimpleArray<CChatGroup> *pChat = m_pChat;
	nCount=pChat->GetSize();
	for(n=0; n<nCount; n++)
	{
		int nIndex = (*pChat)[n].m_Listeners.Find(pUClient->m_hSocket);
		if(nIndex != -1)
		{
			DWORD	dwGroup=(*pChat)[n].m_nID;
			(*pChat)[n].m_Listeners.RemoveAt(nIndex);
		}
	}
	if(bOwn && pUClient->GetSvsID() != sidHTTP)
	{
		//no group found or tell back
		g_chatQueue.SetSize(0);
		g_chatQueue.Push(&pUClient->m_ulSvsID);
		g_chatQueue.Push(&ulGroupSelf);
		g_chatQueue.Push(&nPeerPort);
		g_chatQueue.Push(&ulAddr);
		usLen = 0;
		if(pUClient->m_strUID)
		{
			usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
		}
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
		}
		
		pUClient->sendReturnData(idExit, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}*/
}

void CUListener::GetAllGroups(CUClientThreaded *pUClient, ULONG ulLen)
{
	unsigned long ulLength;
	unsigned long ul;
	unsigned long ulCount;
	g_chatQueue.SetSize(0);
	ATLASSERT(ulLen==0);
	CSimpleArray<CChatGroup> *pChat = m_pChat;
	ulCount = pChat->GetSize();
	for(ul=0; ul<ulCount; ul++)
	{
		g_chatQueue.Push(&((*pChat)[ul].m_nID));
		ulLength = (*pChat)[ul].m_bstrDescription.Length()*sizeof(WCHAR);
		g_chatQueue.Push(&ulLength);
		g_chatQueue.Push((BYTE*)((*pChat)[ul].m_bstrDescription.m_str), ulLength);
	}
	pUClient->sendReturnData(idGetAllGroups, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
}

void CUListener::GetAllClients(CUClientThreaded *pUClient, ULONG ulLen)
{
	USES_CONVERSION;
	ULONG	n;
	ULONG	nCount;
	LPSTR	strPeer;
	unsigned short usLen;
	unsigned long ulAddr;
	unsigned int nPeerPort;
	pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ATLASSERT(ulLen == 0);
	g_chatQueue.SetSize(0);
	nCount = GetClientCount();
	for(n=0; n<nCount; n++)
	{
		CUClient *pOther = GetClient(n);
		ATLASSERT(pOther);
		if(pOther && pOther->GetSvsID() != sidHTTP)
		{
			DWORD dwGroupID = GetJoinedGroup(pOther->m_hSocket);
			g_chatQueue.Push(&pOther->m_ulSvsID);
			g_chatQueue.Push(&dwGroupID);
			pOther->GetPeerName(nPeerPort, strPeer);
			g_chatQueue.Push(&nPeerPort);
			ulAddr = inet_addr(strPeer); 
			g_chatQueue.Push(&ulAddr);
			usLen = 0;
			if(pOther->GetSvsID() == sidStartup)
			{
				CUClient *pStart = pOther;
				if(pStart->m_strUID)
				{
					usLen = ::wcslen(pStart->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pStart->m_strUID, usLen);
				}
			}
			else if(pOther->GetSvsID() != sidHTTP)
			{
				CUClientThreaded *pUCThread = (CUClientThreaded*)pOther;
				if(pUCThread->m_strUID)
				{
					usLen = ::wcslen(pUCThread->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pUCThread->m_strUID, usLen);
				}
			}
		}	
	}
	nPeerPort = 0;
	unsigned long ulSvsID = sidHTTP;
	nCount = m_aChatContext.GetSize();
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		DWORD dwGroupID = GetJoinedGroup(p->m_vtGroups);
		g_chatQueue.Push(&ulSvsID);
		g_chatQueue.Push(&dwGroupID);
		g_chatQueue.Push(&nPeerPort);
		ulAddr = inet_addr(OLE2A(p->GetIpAddr().m_str)); 
		g_chatQueue.Push(&ulAddr);
		usLen = (unsigned short)p->m_bstrUserId.Length()*sizeof(WCHAR);
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)(p->m_bstrUserId.m_str), usLen);
		}
	}
	pUClient->sendReturnData(idGetAllClients, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
}

void CUListener::GetAllListeners(CUClientThreaded *pUClient, ULONG ulLen)
{
	USES_CONVERSION;
	int	n;
	int	nCount;
	int j, jSize;
	unsigned long	ulGroups;
	unsigned long	ulGroup;
	LPSTR	strPeer;
	unsigned short usLen;
	unsigned long ulAddr;
	unsigned int nPeerPort;
	CComVariant vtGroups;
	CSimpleArray<unsigned long> CurrentGroups;
	g_chatQueue.SetSize(0);
	pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	g_chatQueue.SetSize(ulLen);
	if(ulLen == sizeof(ulGroups))
	{
		g_chatQueue.Pop(&ulGroups);
		n = 0;
		ulGroup = 1;
		while(n<32)
		{
			if((ulGroup & ulGroups) == ulGroup)
				CurrentGroups.Add(ulGroup);
			++n;
			ulGroup <<= 1;
		}
		if(CurrentGroups.GetSize())
		{
			void *p;
			SAFEARRAYBOUND sab[1] = {CurrentGroups.GetSize(), 0};
			vtGroups.vt = (VT_ARRAY|VT_UI4);
			vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
			::SafeArrayAccessData(vtGroups.parray, &p);
			memcpy(p, CurrentGroups.GetData(), CurrentGroups.GetSize()*sizeof(unsigned long));
			::SafeArrayUnaccessData(vtGroups.parray);
		}
	}
	else
	{
		g_chatQueue.PopVT(vtGroups);
		unsigned long *pGroup;
		nCount = vtGroups.parray->rgsabound->cElements;
		::SafeArrayAccessData(vtGroups.parray, (void**)&pGroup);
		for(n=0; n<nCount; n++)
		{
			if(CurrentGroups.Find(pGroup[n]) == -1)
				CurrentGroups.Add(pGroup[n]);
		}
		::SafeArrayUnaccessData(vtGroups.parray);
	}
	ATLASSERT(g_chatQueue.GetSize()==0);
	g_chatQueue.SetSize(0);
	nCount = CurrentGroups.GetSize();
	for(n=0; n<nCount; n++)
	{
		DWORD dwGroupID = CurrentGroups[n];
		jSize = m_pChat->GetSize();
		for(j=0; j<jSize; j++)
		{
			CChatGroup &cg = (*m_pChat)[j];
			if(cg.m_nID == dwGroupID)
			{
				CSimpleArray<SOCKET> &listeners = cg.m_Listeners;
				jSize = listeners.GetSize();
				for(j=0; j<jSize; j++)
				{
					CUClientThreaded *pOther = (CUClientThreaded*)FindClient(listeners[j]);
					if(pOther == NULL || pOther->GetSvsID() == sidHTTP)
						continue;
					g_chatQueue.Push(&pOther->m_ulSvsID);
					g_chatQueue.Push(&dwGroupID);
					pOther->GetPeerName(nPeerPort, strPeer);
					g_chatQueue.Push(&nPeerPort);
					ulAddr = inet_addr(strPeer); 
					g_chatQueue.Push(&ulAddr);
					usLen = 0;
					if(pOther->m_strUID)
						usLen = ::wcslen(pOther->m_strUID)*sizeof(WCHAR);
					g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
					if(usLen)
						g_chatQueue.Push((BYTE*)pOther->m_strUID, usLen);
				}
				break;
			}
		}
	}
	nPeerPort = 0;
	CScopeUQueue sq;
	unsigned long ulSvsID = sidHTTP;
	nCount = m_aChatContext.GetSize();
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		sq->SetSize(0);
		Merge(p->m_vtGroups, vtGroups, *sq);
		jSize = sq->GetSize()/sizeof(unsigned long);
		unsigned long *pGroups = (unsigned long *)sq->GetBuffer();
		for(j=0; j<jSize; j++)
		{
			DWORD dwGroupID = pGroups[j];
			g_chatQueue.Push(&ulSvsID);
			g_chatQueue.Push(&dwGroupID);
			g_chatQueue.Push(&nPeerPort);
			ulAddr = inet_addr(OLE2A(p->GetIpAddr().m_str)); 
			g_chatQueue.Push(&ulAddr);
			usLen = (unsigned short)p->m_bstrUserId.Length()*sizeof(WCHAR);
			g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
			if(usLen)
				g_chatQueue.Push((BYTE*)p->m_bstrUserId.m_str, usLen);
		}
	}
	pUClient->sendReturnData(idGetAllListeners, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());

/*
	CSimpleArray<CChatGroup> *pChat = m_pChat;
	nCount=pChat->GetSize();
	for(n=0; n<nCount; n++)
	{
		DWORD dwGroupID = (*pChat)[n].m_nID;
		if(((*pChat)[n].m_nID & ulGroups))
		{
			unsigned long ul;
			unsigned long ulSize = (*pChat)[n].m_Listeners.GetSize();
			for(ul = 0; ul<ulSize; ul++)
			{
				SOCKET hOther = (*pChat)[n].m_Listeners[ul];
				CUClientThreaded *pOther = (CUClientThreaded*)FindClient(hOther);
				if(pOther == NULL)
					continue;
				g_chatQueue.Push(&pOther->m_ulSvsID);
				g_chatQueue.Push(&dwGroupID);
				pOther->GetPeerName(nPeerPort, strPeer);
				g_chatQueue.Push(&nPeerPort);
				ulAddr = inet_addr(strPeer); 
				g_chatQueue.Push(&ulAddr);
				usLen = 0;
				if(pOther->m_strUID)
				{
					usLen = ::wcslen(pOther->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pOther->m_strUID, usLen);
				}
			}
		}
	}
	nPeerPort = 0;
	unsigned long ulSvsID = sidHTTP;
	nCount = m_aChatContext.GetSize();
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		if((ulGroups & p->m_ulGroups))
		{
			DWORD dwGroupID = p->m_ulGroups;
			g_chatQueue.Push(&ulSvsID);
			g_chatQueue.Push(&dwGroupID);
			g_chatQueue.Push(&nPeerPort);
			ulAddr = inet_addr(OLE2A(p->GetIpAddr().m_str)); 
			g_chatQueue.Push(&ulAddr);
			usLen = (unsigned short)p->m_bstrUserId.Length()*sizeof(WCHAR);
			g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
			if(usLen)
			{
				g_chatQueue.Push((BYTE*)p->m_bstrUserId.m_str, usLen);
			}
		}
	}
	
	pUClient->sendReturnData(idGetAllListeners, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());*/
}

void CUListener::XSpeakEx(CUClientThreaded *pUClient, ULONG ulLen, unsigned short usId)
{
	int n, nSize;
	int j, jSize;
	bool bSelf = false;
	LPSTR			strPeer;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	unsigned long ulGroups, ulGroup;
	CSimpleArray<unsigned long> CurrentGroups;
	BYTE *pMessage = NULL;
	unsigned long ulMessageSize;
	CComVariant vtGroups;
	g_chatQueue.SetSize(0);
	if(g_chatQueue.GetMaxSize() < ulLen)
		g_chatQueue.ReallocBuffer(ulLen);
	unsigned long ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ATLASSERT(ulGet == ulLen);
	g_chatQueue.SetSize(ulGet);
	if(usId == idSpeakEx)
	{
		g_chatQueue.Pop(&ulGroups);
		ulMessageSize = g_chatQueue.GetSize();
		if(g_chatQueue.GetSize())
		{
			pMessage = new BYTE[ulMessageSize];
			g_chatQueue.Pop(pMessage, ulMessageSize);
		}
		n = 0;
		ulGroup = 1;
		while(n<32)
		{
			if((ulGroup & ulGroups) == ulGroup)
				CurrentGroups.Add(ulGroup);
			++n;
			ulGroup <<= 1;
		}
	}
	else if(usId == idXSpeakEx)
	{
		g_chatQueue >> ulMessageSize;
		if(ulMessageSize)
		{
			pMessage = new BYTE[ulMessageSize];
			g_chatQueue.Pop(pMessage, ulMessageSize);
		}
		unsigned long *pGroup = (unsigned long*)g_chatQueue.GetBuffer();
		ATLASSERT((g_chatQueue.GetSize()%sizeof(unsigned long)) == 0);
		nSize = g_chatQueue.GetSize()/sizeof(unsigned long);
		for(n=0; n<nSize; n++)
		{
			if(CurrentGroups.Find(pGroup[n]) == -1 && pGroup[n] != 0)
				CurrentGroups.Add(pGroup[n]);
		}
		g_chatQueue.SetSize(0);
	}
	else
	{
		ATLASSERT(FALSE);
	}
	ATLASSERT(g_chatQueue.GetSize()==0);	
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = ::inet_addr(strPeer); 
	g_chatQueue.SetSize(0);
	g_chatQueue.Push(&pUClient->m_ulSvsID);
	g_chatQueue.Push(&ulGroup);
	g_chatQueue.Push(&nPeerPort);
	g_chatQueue.Push(&ulAddr);
	unsigned short usLen = 0;
	if(pUClient->m_strUID)
		usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
	g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
	if(usLen)
		g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
	g_chatQueue.Push(pMessage, ulMessageSize);
	nSize = CurrentGroups.GetSize();
	for(n=0; n<nSize; n++)
	{
		ulGroup = CurrentGroups[n];
		CSimpleArray<SOCKET> *pClients = XGetJoinedClients(ulGroup);
		if(pClients == NULL)
			continue;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		jSize = pClients->GetSize();
		for(j=0; j<jSize; j++)
		{
			SOCKET hSocket = (*pClients)[j];
			CUClient *pOther = FindClient(hSocket);
			if(pOther == NULL)
				continue;
			bSelf = (pOther == pUClient);
			pOther->sendReturnData(usId, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
		}
	}
	if(!bSelf)
	{
		if(CurrentGroups.GetSize() > 0)
			ulGroup = CurrentGroups[n];
		else
			ulGroup = 0;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		pUClient->sendReturnData(usId, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}
	if(pMessage)
		delete []pMessage;
}

void CUListener::SpeakEx(CUClientThreaded *pUClient, ULONG ulLen)
{
	unsigned long   ulMessageSize;
	ULONG			ulGet;
	ULONG			n;
	ULONG			nCount;
	ULONG			ulMyGroup;
	DWORD			ulGroups;
	LPSTR			strPeer;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	unsigned short  usLen;
	BYTE			*pMessage = NULL;
	ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ulMyGroup = GetJoinedGroup(pUClient->m_hSocket);
	ATLASSERT(ulGet==ulLen);
	ATLASSERT(ulGet>=sizeof(ulGroups));
	g_chatQueue.SetSize(ulLen);
	g_chatQueue.Pop(&ulGroups);
	if(!pUClient->m_bSameEndian)
	{
		ulGroups = ::htonl(ulGroups);
	}
	ulMessageSize = g_chatQueue.GetSize();
	if(g_chatQueue.GetSize())
	{
		pMessage = new BYTE[ulMessageSize];
		g_chatQueue.Pop(pMessage, ulMessageSize);
	}
	ATLASSERT(g_chatQueue.GetSize() == 0);
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = ::inet_addr(strPeer); 

	CSimpleArray<SOCKET> aJoinedClients;

	GetJoinedClients(ulGroups, aJoinedClients);
	
	if(aJoinedClients.Find(pUClient->m_hSocket) == -1)
		aJoinedClients.Add(pUClient->m_hSocket);

	nCount = aJoinedClients.GetSize();
	for(n=0; n<nCount; n++)
	{
		CUClientThreaded *pOther = (CUClientThreaded*)FindClient(aJoinedClients[n]);
		ATLASSERT(pOther != NULL);
		if(pOther && pOther->GetSvsID() != sidHTTP)
		{
			g_chatQueue.SetSize(0);
			g_chatQueue.Push(&pUClient->m_ulSvsID);
			g_chatQueue.Push(&ulMyGroup);
			g_chatQueue.Push(&nPeerPort);
			g_chatQueue.Push(&ulAddr);
			usLen = 0;
			if(pUClient->m_strUID)
			{
				usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
			}
			g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
			if(usLen)
			{
				g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
			}
			g_chatQueue.Push(pMessage, ulMessageSize);
			pOther->sendReturnData(idSpeakEx, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
		}
	}
	if(pMessage != NULL)
		delete []pMessage;
}

void CUListener::GetJoinedClients(LPCWSTR strUserId, CSimpleArray<CWebChatContext*> &aJoinedClients)
{
	int n;
	aJoinedClients.RemoveAll();
	CComBSTR bstrUserId(strUserId);
	bstrUserId.ToLower();
	int nCount = m_aChatContext.GetSize();
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		CComBSTR bstrUID = p->m_bstrUserId;
		bstrUID.ToLower();
		if(bstrUID == bstrUserId)
			aJoinedClients.Add(p);
	}
}

/*
void CUListener::GetJoinedClients(ULONG *pGroups, ULONG nSize, CSimpleArray<CWebChatContext*> &aJoinedClients)
{
	int n;
	aJoinedClients.RemoveAll();
	if(pGroups == NULL || nSize == 0)
		return;
	int nCount = m_aChatContext.GetSize();
	for(n=0; n<nCount; n++)
	{
		CWebChatContext *p = m_aChatContext[n];
		unsigned long ulBit = 0;
		unsigned long ulGroupId = p->m_ulGroups;
		while(ulGroupId && ulBit < 2)
		{
			if((ulGroupId & 0x1) > 0)
				ulBit++;
			ulGroupId >>= 1;
		}
		if(ulBit > 1)
			continue;
		if((p->m_ulGroups & ulGroups) > 0)
			aJoinedClients.Add(p);
	}
}*/

CSimpleArray<SOCKET>* CUListener::XGetJoinedClients(ULONG ulGroup)
{
	int n;
	int nSize;
	if(ulGroup == 0)
		return NULL;
	nSize = m_pChat->GetSize();
	for(n=0; n<nSize; n++)
	{
		CChatGroup &cg = (*m_pChat)[n];
		if(cg.m_nID == ulGroup)
			return &(cg.m_Listeners);
	}
	return NULL;
}

void CUListener::GetJoinedClients(ULONG ulGroups, CSimpleArray<SOCKET> &aJoinedClients)
{
	ULONG			n;
	ULONG			nCount;
	ULONG			ulSize;
	ULONG			j;
	aJoinedClients.RemoveAll();
	if(ulGroups == 0)
		return;
	CSimpleArray<CChatGroup> *pChat = m_pChat;
	nCount = pChat->GetSize();
	for(n=0; n<nCount; n++)
	{
		unsigned long ulBit = 0;
		unsigned long ulGroupId = (*pChat)[n].m_nID;
		while(ulGroupId && ulBit < 2)
		{
			if((ulGroupId & 0x1) > 0)
				ulBit++;
			ulGroupId >>= 1;
		}
		if(ulBit > 1)
			continue;

		if((ulGroupId & ulGroups))
		{
			ulSize = (*pChat)[n].m_Listeners.GetSize();
			for(j=0; j<ulSize; j++)
			{
				SOCKET hSocket = (*pChat)[n].m_Listeners[j];
				if(aJoinedClients.Find(hSocket) == -1)
				{
					aJoinedClients.Add(hSocket);
				}
			}
		}
	}
}

void CUListener::XSpeak(CUClientThreaded *pUClient, ULONG ulLen, unsigned short usId)
{
	int n, nSize;
	int j, jSize;
	bool bSelf = false;
	LPSTR			strPeer;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	unsigned long	*p;
	CComVariant	vtMsg;
	unsigned long ulGroups, ulGroup;
	CSimpleArray<unsigned long> CurrentGroups;
	CComVariant vtGroups;
	g_chatQueue.SetSize(0);
	if(g_chatQueue.GetMaxSize() < ulLen)
		g_chatQueue.ReallocBuffer(ulLen);
	unsigned long ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ATLASSERT(ulGet == ulLen);
	g_chatQueue.SetSize(ulGet);
	if(usId == idSpeak)
		g_chatQueue.Pop(&ulGroups);
	else if(usId == idXSpeak)
		g_chatQueue.PopVT(vtGroups);
	else
	{
		ATLASSERT(FALSE);
	}
	g_chatQueue.PopVT(vtMsg);
	ATLASSERT(g_chatQueue.GetSize()==0);	
	if(usId == idXSpeak)
	{
		unsigned long *pData;
		nSize = (int)vtGroups.parray->rgsabound->cElements;
		::SafeArrayAccessData(vtGroups.parray, (void**)&pData);
		for(n=0; n<nSize; n++)
		{
			if(CurrentGroups.Find(pData[n]) == -1 && pData[n] != 0)
				CurrentGroups.Add(pData[n]);
		}
		::SafeArrayUnaccessData(vtGroups.parray);
	}
	else if(usId == idSpeak)
	{
		n = 0;
		ulGroup = 1;
		while(n<32)
		{
			if((ulGroup & ulGroups) == ulGroup)
				CurrentGroups.Add(ulGroup);
			++n;
			ulGroup <<= 1;
		}
	}
	else
	{
		ATLASSERT(FALSE);
	}
	
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = ::inet_addr(strPeer); 
	g_chatQueue.SetSize(0);
	g_chatQueue.Push(&pUClient->m_ulSvsID);
	g_chatQueue.Push(&ulGroup);
	g_chatQueue.Push(&nPeerPort);
	g_chatQueue.Push(&ulAddr);
	unsigned short usLen = 0;
	if(pUClient->m_strUID)
		usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
	g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
	if(usLen)
		g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
	g_chatQueue.PushVT(vtMsg);
	nSize = CurrentGroups.GetSize();
	for(n=0; n<nSize; n++)
	{
		ulGroup = CurrentGroups[n];
		CSimpleArray<SOCKET> *pClients = XGetJoinedClients(ulGroup);
		if(pClients == NULL)
			continue;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		jSize = pClients->GetSize();
		for(j=0; j<jSize; j++)
		{
			SOCKET hSocket = (*pClients)[j];
			CUClient *pOther = FindClient(hSocket);
			if(pOther == NULL || pOther->GetSvsID() == sidHTTP)
				continue;
			bSelf = (pOther == pUClient);
			pOther->sendReturnData(usId, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
		}
	}
	if(pUClient->GetSvsID() != sidHTTP)
	{
		jSize = m_aChatContext.GetSize();
		if(jSize)
		{
			vtGroups.Clear();
			jSize = CurrentGroups.GetSize();
			SAFEARRAYBOUND sab[1] = {jSize, 0};
			vtGroups.vt = (VT_ARRAY|VT_UI4);
			vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
			::SafeArrayAccessData(vtGroups.parray, (void**)&p);
			memcpy(p, CurrentGroups.GetData(), jSize*sizeof(unsigned long));
			::SafeArrayUnaccessData(vtGroups.parray);
			CScopeUQueue sq;
			jSize = m_aChatContext.GetSize();
			for(j=0; j<jSize; j++)
			{
				CWebChatContext *p = m_aChatContext[j];
				sq->SetSize(0);
				Merge(vtGroups, p->m_vtGroups, *sq);
				if(sq->GetSize())
				{
					CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID());
					pMsgHolder->m_qGroup->Push(sq->GetBuffer(), sq->GetSize());
					pMsgHolder->PushMessage("speak", vtMsg); 
					p->AddMsg(pMsgHolder);
				}
			}
		}
	}

	if(!bSelf && pUClient->GetSvsID() != sidHTTP)
	{
		if(CurrentGroups.GetSize() > 0)
			ulGroup = CurrentGroups[0];
		else
			ulGroup = 0;
		::memcpy((void*)(g_chatQueue.GetBuffer() + sizeof(pUClient->m_ulSvsID)), &ulGroup, sizeof(ulGroup));
		pUClient->sendReturnData(usId, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}
}

void CUListener::Speak(CUClientThreaded *pUClient, ULONG ulLen)
{
/*	ULONG			ulGet;
	ULONG			n;
	ULONG			nCount;
	ULONG			ulMyGroup;
	DWORD			ulGroups;
	LPSTR			strPeer;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	CComVariant		vtMsg;
	g_chatQueue.SetSize(0);
	ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	if(pUClient->GetSvsID() == sidHTTP)
		ulMyGroup = pUClient->m_HttpReqAttribute.m_ulChatGroups;
	else
		ulMyGroup = GetJoinedGroup(pUClient->m_hSocket);
	ATLASSERT(ulGet==ulLen);
	ATLASSERT(ulGet>sizeof(ulGroups));
	g_chatQueue.SetSize(ulLen);
	g_chatQueue.Pop(&ulGroups);
	g_chatQueue.PopVT(vtMsg);
	ATLASSERT(g_chatQueue.GetSize()==0);
	
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = ::inet_addr(strPeer); 
	
	if(pUClient->GetSvsID() != sidHTTP)
	{
		CSimpleArray<CWebChatContext*> aChatContext;
		GetJoinedClients(ulGroups, aChatContext);
		nCount = aChatContext.GetSize();
		for(n=0; n<nCount; n++)
		{
			CWebChatContext *p = aChatContext[n];
			DWORD dwMyGroups = p->m_ulGroups;
			if((dwMyGroups & ulGroups))
			{
				CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID(), ulMyGroup);
				pMsgHolder->PushMessage("speak", vtMsg); 
				p->AddMsg(pMsgHolder);
			}
		}
	}
	
	g_chatQueue.SetSize(0);
	g_chatQueue.Push(&pUClient->m_ulSvsID);
	g_chatQueue.Push(&ulMyGroup);
	g_chatQueue.Push(&nPeerPort);
	g_chatQueue.Push(&ulAddr);
	unsigned short usLen = 0;
	if(pUClient->m_strUID)
	{
		usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
	}
	g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
	if(usLen)
	{
		g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
	}
	g_chatQueue.PushVT(vtMsg);

	CSimpleArray<SOCKET> aJoinedClients;

	GetJoinedClients(ulGroups, aJoinedClients);
	
	if(aJoinedClients.Find(pUClient->m_hSocket) == -1)
		aJoinedClients.Add(pUClient->m_hSocket);

	nCount = aJoinedClients.GetSize();
	for(n=0; n<nCount; n++)
	{
		CUClientThreaded *pOther = (CUClientThreaded*)FindClient(aJoinedClients[n]);
		ATLASSERT(pOther);
		if(pOther->GetSvsID() == sidHTTP)
			continue;
		pOther->sendReturnData(idSpeak, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}*/
}

void CUListener::SpeakToEx(CUClientThreaded *pUClient, ULONG ulLen)
{
	ULONG			ulMessageLen;
	ULONG			ulGet;
	ULONG			n;
	ULONG			ulGroup;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	bool			bNotifySelf = false;
	BYTE			*pMsg = NULL;
	ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ulGroup = GetJoinedGroup(pUClient->m_hSocket);
	ATLASSERT(ulGet==ulLen);
	ATLASSERT(ulGet>=sizeof(ulAddr)+sizeof(nPeerPort));
	g_chatQueue.SetSize(ulLen);
	g_chatQueue.Pop(&ulAddr);
	g_chatQueue.Pop(&nPeerPort);
	if(!pUClient->m_bSameEndian)
	{
		nPeerPort = ::htonl(nPeerPort);	
	}
	ulMessageLen = g_chatQueue.GetSize();
	if(ulMessageLen)
	{
		pMsg = new BYTE [ulMessageLen];
		g_chatQueue.Pop(pMsg, ulMessageLen);
	}
	ATLASSERT(g_chatQueue.GetSize()==0);
	if(ulAddr == INADDR_NONE)
	{
	}
	else if(ulAddr == INADDR_ANY)
	{
		unsigned short usLen;
		ULONG			nCount;
		CUClient *pTarget;
		LPSTR	strPeer;
		pUClient->GetPeerName(nPeerPort, strPeer);
		ulAddr = ::inet_addr(strPeer); 
		bNotifySelf = true;
		nCount=GetClientCount();
		for(n=0; n<nCount; n++)
		{
			pTarget = GetClient(n);
			if(pTarget && pTarget->m_ulSvsID != sidStartup && pTarget->GetSvsID() != sidHTTP)
			{
				g_chatQueue.SetSize(0);
				g_chatQueue.Push(&pUClient->m_ulSvsID);
				g_chatQueue.Push(&ulGroup);
				g_chatQueue.Push(&nPeerPort);
				g_chatQueue.Push(&ulAddr);
				usLen = 0;
				if(pUClient->m_strUID)
				{
					usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
				}
				g_chatQueue.Push(pMsg, ulMessageLen);
				pTarget->sendReturnData(idSpeakToEx, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
			}
		}
	}
	else
	{
		ULONG			nCount;
		nCount=GetClientCount();
		for(n=0; n<nCount; n++)
		{
			LPSTR			strPeer;
			LPSTR			strPeerMe;
			unsigned long	ulAddrMe;
			unsigned int	nPeerPortMe;
			CUClient *pTarget = GetClient(n);	
			pTarget->GetPeerName(nPeerPortMe, strPeerMe);
			ATLASSERT(pTarget);
			ulAddrMe = ::inet_addr(strPeerMe); 
			if(ulAddrMe==ulAddr && nPeerPort==nPeerPortMe)
			{
				unsigned short usLen;
				pUClient->GetPeerName(nPeerPort, strPeer);
				ulAddr = ::inet_addr(strPeer); 
				g_chatQueue.SetSize(0);
				g_chatQueue.Push(&pUClient->m_ulSvsID);
				g_chatQueue.Push(&ulGroup);
				g_chatQueue.Push(&nPeerPort);
				g_chatQueue.Push(&ulAddr);
				usLen = 0;
				if(pUClient->m_strUID)
				{
					usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
				}
				g_chatQueue.Push(pMsg, ulMessageLen);
				if(pTarget->GetSvsID() != sidHTTP)
					pTarget->sendReturnData(idSpeakToEx, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
				if(pTarget == pUClient)
				{
					bNotifySelf = true;
				}
				break;
			}
		}
	}
	if(!bNotifySelf && pUClient->GetSvsID() != sidHTTP)
	{
		LPSTR		strPeer;
		unsigned short usLen;
		pUClient->GetPeerName(nPeerPort, strPeer);
		ulAddr = ::inet_addr(strPeer); 
		g_chatQueue.SetSize(0);
		g_chatQueue.Push(&pUClient->m_ulSvsID);
		g_chatQueue.Push(&ulGroup);
		g_chatQueue.Push(&nPeerPort);
		g_chatQueue.Push(&ulAddr);
		usLen = 0;
		if(pUClient->m_strUID)
		{
			usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
		}
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
		}
		g_chatQueue.Push(pMsg, ulMessageLen);
		pUClient->sendReturnData(idSpeakToEx, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}
	if(pMsg)
		delete []pMsg;
}

void CUListener::SendUserMessage(CUClientThreaded *pUClient, ULONG ulLen)
{
	ULONG			ulGet;
	UINT			n;
	UINT			nCount;
	ULONG			ulGroup;
	LPSTR			strPeer = NULL;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	bool			bNotifySelf = false;
	CComVariant		vtMsg;
	CComBSTR		bstrUser;
	CComBSTR		bstrTUser;
	ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ATLASSERT(ulGet==ulLen);
	g_chatQueue.SetSize(ulLen);
	g_chatQueue >> bstrUser;
	g_chatQueue.PopVT(vtMsg);
	ATLASSERT(g_chatQueue.GetSize() == 0);
	bstrUser.ToUpper();
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = ::inet_addr(strPeer); 
	if(pUClient->GetSvsID() == sidHTTP)
		ulGroup = pUClient->m_HttpReqAttribute.m_ulChatGroups;
	else
		ulGroup = GetJoinedGroup(pUClient->m_hSocket);
	
	if(pUClient->GetSvsID() != sidHTTP)
	{
		CSimpleArray<CWebChatContext*> aChatContext;
		GetJoinedClients(bstrUser.m_str, aChatContext);
		nCount = aChatContext.GetSize();
		for(n=0; n<nCount; n++)
		{
			CWebChatContext *p = aChatContext[n];
			CComBSTR bstr = p->m_bstrUserId;
			bstr.ToUpper();
			if(bstr == bstrUser)
			{
				CMsgHolder *pMsgHolder = new CMsgHolder(pUClient->m_strUID, ulAddr, nPeerPort, pUClient->GetSvsID());
				pMsgHolder->m_qGroup->PushVT(p->m_vtGroups);
				//remove VT and unsigned long
				pMsgHolder->m_qGroup->Pop((unsigned long)6);
				pMsgHolder->m_qGroup->SetHeadPosition();
				pMsgHolder->PushMessage("sendUserMessage", vtMsg); 
				p->AddMsg(pMsgHolder);
			}
		}
	}

	nCount=GetClientCount();
	for(n=0; n<nCount; n++)
	{
		CUClient *pTarget = GetClient(n);
		if(pTarget->GetSvsID() == sidHTTP)
			continue;
		bstrTUser = pTarget->m_strUID;
		bstrTUser.ToUpper();
		if(bstrUser == bstrTUser)
		{
			g_chatQueue.SetSize(0);
			g_chatQueue.Push(&pUClient->m_ulSvsID);
			g_chatQueue.Push(&ulGroup);
			g_chatQueue.Push(&nPeerPort);
			g_chatQueue.Push(&ulAddr);
			unsigned short usLen = 0;
			if(pUClient->m_strUID)
			{
				usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
			}
			g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
			if(usLen)
			{
				g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
			}
			g_chatQueue.PushVT(vtMsg);
			pTarget->sendReturnData(idSendUserMessage, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
			if(pTarget == pUClient)
			{
				bNotifySelf = true;
			}
		}
	}

	if(!bNotifySelf && pUClient->GetSvsID() != sidHTTP)
	{
		unsigned short usLen;
		g_chatQueue.SetSize(0);
		g_chatQueue.Push(&pUClient->m_ulSvsID);
		g_chatQueue.Push(&ulGroup);
		g_chatQueue.Push(&nPeerPort);
		g_chatQueue.Push(&ulAddr);
		usLen = 0;
		if(pUClient->m_strUID)
		{
			usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
		}
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
		}
		g_chatQueue.PushVT(vtMsg);
		pUClient->sendReturnData(idSendUserMessage, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}
}

void CUListener::SendUserMessageEx(CUClientThreaded *pUClient, ULONG ulLen)
{
	ULONG			ulGroup;
	ULONG			ulGet;
	UINT			n;
	UINT			nCount;
	LPSTR			strPeer = NULL;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	bool			bNotifySelf = false;
	CComVariant		vtMsg;
	CComBSTR		bstrUser;
	CComBSTR		bstrTUser;
	BYTE			*pMessage = NULL;
	ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ATLASSERT(ulGet==ulLen);
	g_chatQueue.SetSize(ulLen);
	g_chatQueue >> bstrUser;
	ulGet = g_chatQueue.GetSize();
	if(ulGet > 0)
	{
		pMessage = new BYTE[ulGet];
		g_chatQueue.Pop(pMessage, ulGet);
	}
	ulGroup = GetJoinedGroup(pUClient->m_hSocket);
	pUClient->GetPeerName(nPeerPort, strPeer);
	ulAddr = ::inet_addr(strPeer); 
	bstrUser.ToUpper();
	nCount=GetClientCount();
	for(n=0; n<nCount; n++)
	{
		CUClient *pTarget = GetClient(n);
		if(pTarget->GetSvsID() == sidHTTP)
			continue;
		bstrTUser = pTarget->m_strUID;
		bstrTUser.ToUpper();
		if(bstrUser == bstrTUser)
		{
			g_chatQueue.SetSize(0);
			g_chatQueue.Push(&pUClient->m_ulSvsID);
			g_chatQueue.Push(&ulGroup);
			g_chatQueue.Push(&nPeerPort);
			g_chatQueue.Push(&ulAddr);
			unsigned short usLen = 0;
			if(pUClient->m_strUID)
			{
				usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
			}
			g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
			if(usLen)
			{
				g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
			}
			g_chatQueue.Push(pMessage, ulGet);
			pTarget->sendReturnData(idSendUserMessageEx, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
			if(pTarget == pUClient)
			{
				bNotifySelf = true;
			}
		}
	}
	if(!bNotifySelf && pUClient->GetSvsID() != sidHTTP)
	{
		unsigned short usLen;
		g_chatQueue.SetSize(0);
		g_chatQueue.Push(&pUClient->m_ulSvsID);
		g_chatQueue.Push(&ulGroup);
		g_chatQueue.Push(&nPeerPort);
		g_chatQueue.Push(&ulAddr);
		usLen = 0;
		if(pUClient->m_strUID)
		{
			usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
		}
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
		}
		g_chatQueue.Push(pMessage, ulGet);
		pUClient->sendReturnData(idSendUserMessageEx, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}
	if(pMessage != NULL)
		delete []pMessage;
}

void CUListener::SpeakTo(CUClientThreaded *pUClient, ULONG ulLen)
{
	ULONG			ulGet;
	ULONG			n;
	ULONG			nCount;
	ULONG			ulGroup;
	unsigned long	ulAddr;
	unsigned int	nPeerPort;
	bool			bNotifySelf = false;
	CComVariant		vtMsg;
	LPSTR			strPeer = NULL;
	ulGet = pUClient->GetRecvBuffer((BYTE*)g_chatQueue.GetBuffer(), ulLen);
	ulGroup = GetJoinedGroup(pUClient->m_hSocket);
	ATLASSERT(ulGet==ulLen);
	ATLASSERT(ulGet>sizeof(ulAddr)+sizeof(nPeerPort));
	g_chatQueue.SetSize(ulLen);
	g_chatQueue.Pop(&ulAddr);
	g_chatQueue.Pop(&nPeerPort);
	g_chatQueue.PopVT(vtMsg);
	ATLASSERT(g_chatQueue.GetSize()==0);
	if(ulAddr == INADDR_NONE)
	{

	}
	else if(ulAddr == INADDR_ANY)
	{
		unsigned short usLen;
		CUClient *pTarget;
		bNotifySelf = true;
		nCount=GetClientCount();
		g_chatQueue.SetSize(0);
		g_chatQueue.Push(&pUClient->m_ulSvsID);
		g_chatQueue.Push(&ulGroup);
		pUClient->GetPeerName(nPeerPort, strPeer);
		ulAddr = ::inet_addr(strPeer); 
		g_chatQueue.Push(&nPeerPort);
		g_chatQueue.Push(&ulAddr);
		usLen = 0;
		if(pUClient->m_strUID)
		{
			usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
		}
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
		}
		g_chatQueue.PushVT(vtMsg);
		for(n=0; n<nCount; n++)
		{
			pTarget = GetClient(n);
			if(pTarget && pTarget->m_ulSvsID != sidStartup && pTarget->GetSvsID() != sidHTTP)
			{
				pTarget->sendReturnData(idSpeakTo, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
			}
		}
	}
	else
	{
		nCount=GetClientCount();
		for(n=0; n<nCount; n++)
		{
			LPSTR			strPeer;
			LPSTR			strPeerMe;
			unsigned long	ulAddrMe;
			unsigned int	nPeerPortMe;
			CUClient *pTarget = GetClient(n);	
			if(pTarget == NULL || pTarget->GetSvsID() == sidHTTP)
				continue;
			pTarget->GetPeerName(nPeerPortMe, strPeerMe);
			ATLASSERT(pTarget);
			ulAddrMe = ::inet_addr(strPeerMe); 
			if(ulAddrMe==ulAddr && nPeerPort==nPeerPortMe)
			{
				unsigned short usLen;
				pUClient->GetPeerName(nPeerPort, strPeer);
				ulAddr = ::inet_addr(strPeer); 
				g_chatQueue.SetSize(0);
				g_chatQueue.Push(&pUClient->m_ulSvsID);
				g_chatQueue.Push(&ulGroup);
				g_chatQueue.Push(&nPeerPort);
				g_chatQueue.Push(&ulAddr);
				usLen = 0;
				if(pUClient->m_strUID)
				{
					usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
				}
				g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
				if(usLen)
				{
					g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
				}
				g_chatQueue.PushVT(vtMsg);
				pTarget->sendReturnData(idSpeakTo, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
				if(pTarget == pUClient)
				{
					bNotifySelf = true;
				}
				break;
			}
		}
	}
	if(!bNotifySelf && pUClient->GetSvsID() != sidHTTP)
	{
		LPSTR		strPeer;
		unsigned short usLen;
		pUClient->GetPeerName(nPeerPort, strPeer);
		ulAddr = ::inet_addr(strPeer); 
		g_chatQueue.SetSize(0);
		g_chatQueue.Push(&pUClient->m_ulSvsID);
		g_chatQueue.Push(&ulGroup);
		g_chatQueue.Push(&nPeerPort);
		g_chatQueue.Push(&ulAddr);
		usLen = 0;
		if(pUClient->m_strUID)
		{
			usLen = ::wcslen(pUClient->m_strUID)*sizeof(WCHAR);
		}
		g_chatQueue.Push((BYTE*)&usLen, sizeof(usLen));
		if(usLen)
		{
			g_chatQueue.Push((BYTE*)pUClient->m_strUID, usLen);
		}
		g_chatQueue.PushVT(vtMsg);
		pUClient->sendReturnData(idSpeakTo, g_chatQueue.GetSize(), g_chatQueue.GetBuffer());
	}
}

void CUListener::OnChatRequestArrive(SOCKET hSocket, unsigned short usRequestID, unsigned long ulLen)
{
	CAutoLock AutoLock(&m_csLock);
	if(m_OnChatRequestComing)
	{
		ULONG ulCount = RemoveLock();
		m_OnChatRequestComing(hSocket, usRequestID, ulLen);
		Relock(ulCount);
	}
	g_chatQueue.SetSize(0);
	if(ulLen > g_chatQueue.GetMaxSize())
	{
		g_chatQueue.ReallocBuffer(ulLen + 1024);
	}
	CUClientThreaded *pUClient = (CUClientThreaded*)FindClient(hSocket);
	ATLASSERT(pUClient);
	if(!pUClient)
		return;
	switch (usRequestID)
	{
	case idEnter:
		XEnter(pUClient, ulLen, idEnter);
		break;
	case idExit:
		Exit(pUClient, ulLen);
		break;
	case idGetAllGroups:
		GetAllGroups(pUClient, ulLen);
		break;
	case idGetAllClients:
		GetAllClients(pUClient, ulLen);
		break;
	case idGetAllListeners:
		GetAllListeners(pUClient, ulLen);
		break;
	case idSpeakEx:
		XSpeakEx(pUClient, ulLen, idSpeakEx);
		break;
	case idSpeak:
		XSpeak(pUClient, ulLen, idSpeak);
		break;
	case idSpeakTo:
		SpeakTo(pUClient, ulLen);
		break;
	case idSpeakToEx:
		SpeakToEx(pUClient, ulLen);
		break;
	case idSendUserMessage:
		SendUserMessage(pUClient, ulLen);
		break;
	case idSendUserMessageEx:
		SendUserMessageEx(pUClient, ulLen);
		break;
	case idXEnter:
		XEnter(pUClient, ulLen);
		break;
	case idXSpeak:
		XSpeak(pUClient, ulLen, idXSpeak);
		break;
	case idXSpeakEx:
		XSpeakEx(pUClient, ulLen, idXSpeakEx);
		break;
	default:
		ATLASSERT(FALSE);
		break;
	}
	
	if(m_OnChatRequestCame)
	{
		ULONG ulCount = RemoveLock();
		m_OnChatRequestCame(hSocket, usRequestID, 0);
		Relock(ulCount);
	}
}

bool CUListener::LoadOpenSSLKeyCert()
{
	USES_CONVERSION;
	int nRtn;
	LPSTR strFile = OLE2A(m_strPfxFile);
	LPSTR strPass = OLE2A(m_strPassword);
	BIO *fp = (BIO *)NULL;
	PKCS12 *p12 = (PKCS12 *)NULL;
	fp = g_pStartup->BIO_new_file(strFile, "r");
	if(fp == NULL)
	{
		::SetLastError(ERROR_FILE_NOT_FOUND);
		return false;
	}
	p12 = g_pStartup->d2i_PKCS12_bio( fp, (PKCS12 **)NULL );
	g_pStartup->BIO_free( fp );
	nRtn = g_pStartup->PKCS12_parse(p12, strPass, &m_pkey, &m_pCert, NULL);
	if(nRtn == 0)
	{
		DWORD dwError = g_pStartup->ERR_get_error();
		::SetLastError(dwError);
	}
	g_pStartup->PKCS12_free(p12);
	return (nRtn > 0);
}

bool CUListener::StartIOPump()
{
	BOOL			bSuc;
	DWORD			dwNumberOfBytesTransferred;
	DWORD			dwKey;

	if(m_bUseMessagePump)
		return false;
	LPOVERLAPPED	pOverLapped = NULL;
	do
	{
		pOverLapped = NULL;
		bSuc = g_pStartup->GetQueuedCompletionStatus(m_hCompletionPort, &dwNumberOfBytesTransferred, &dwKey, &pOverLapped, m_ulTimerElapse);
		if(bSuc && dwNumberOfBytesTransferred == 0 && pOverLapped == &m_IOPortContext)
		{
aa:			MSG msg;
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				if(m_UMsgQueue.GetSize() >= sizeof(msg))
					m_UMsgQueue.PopMsg(msg);
				else
					continue;
			}
			if(dwKey == (DWORD)this)
			{
				if(msg.message == WM_SOCKET_SVR_NOTIFY)
				{
					switch(msg.lParam)
					{
					case MLPARAM:
						{
							CUClientThreaded *pClient = (CUClientThreaded*)msg.wParam;
							CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
							pClient->OnSend(0);
						}
						break;
					case FD_ACCEPT:
						{
							int err;
							DWORD dwFlags = 0;
							CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
							CUClient *p = PostProcess((CUClientThreaded*)msg.wParam); //PostProcess(msg.wParam);
							SOCKET hSocket = p->m_hSocket;
							ATLASSERT(p != NULL);
							if(p != NULL)
							{
								HANDLE hPort = g_pStartup->CreateIoCompletionPort((HANDLE)hSocket, m_hCompletionPort, (DWORD)p, 0);
								ATLASSERT(hPort == m_hCompletionPort);
								DWORD dwFlags = 0;
								p->OnSend(0);
								u_long ulArg = (FD_READ|FD_WRITE); 
								m_nRtn = ::ioctlsocket(p->m_hSocket, FIONBIO, &ulArg); //you may get WSAEWOULDBLOCK
								memset(&p->m_RcvIOContext, 0, sizeof(CIOPortContext));
								p->m_RcvIOContext.m_dwTransfered = (NO_DATA_TRANSFERED - 1);
								err = ::WSARecv(p->m_hSocket, &p->m_RcvIOContext.m_RcvWSABuf, 1, &p->m_RcvIOContext.m_dwTransfered, &dwFlags, &p->m_RcvIOContext, NULL);
								p->m_RcvIOContext.m_dwTransfered = NO_DATA_TRANSFERED;
								if(err == -1)
								{
									err = ::WSAGetLastError();
								}
							}
						}
						break;
					default:
						UWindowProc(msg.hwnd, msg.message, msg.wParam, msg.lParam);
						break;
					}
				}
				else if(msg.message == WM_QUIT)
				{
					CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
					int nSize = g_mapUClient.GetSize();
					if(nSize == 0)
					{
						break;
					}
					else
					{
						while(g_mapUClient.GetSize())
						{
							UWindowProc(GetWin(), WM_SOCKET_SVR_NOTIFY, g_mapUClient.GetKeyAt(g_mapUClient.GetSize()-1), WSAMAKESELECTREPLY(FD_CLOSE, 0));
						}
						UPostMessage(GetWin(), WM_QUIT, 0, 0);
					}
				}
				else
				{
					UWindowProc(msg.hwnd, msg.message, msg.wParam, msg.lParam);
				}
			}
			else
			{
				ATLASSERT(FALSE);	
			}
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				if(m_UMsgQueue.GetSize() > 0)
					goto aa;
			}
		}
		else if(bSuc && pOverLapped != NULL && dwKey != 0)
		{
			DWORD dwNow = ::GetTickCount();
			CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
			if(dwNow > m_dwLastTimeCount && (dwNow - m_dwLastTimeCount) > m_ulTimerElapse)
			{
				UTimerProc(GetWin(), WM_TIMER, 121, dwNow);
				m_dwLastTimeCount = dwNow;
//				ATLTRACE("m_dwLastTimeCount = dwNow\n");
			}
			
			CUClientThreaded *pClient = (CUClientThreaded*)dwKey;
			if(pClient->m_hSocket != 0 && pClient->m_hSocket != INVALID_SOCKET && !pClient->m_bClosing)
			{
				if(pOverLapped == &pClient->m_RcvIOContext)
				{
					pClient->m_RcvIOContext.m_dwTransfered = 0;
					try
					{
						pClient->OnReceive(0);
					}
					catch(...)
					{
						::PostClose(pClient->m_hSocket, ERROR_UEXCEPTION_CAUGHT);
					}
				}
				else if(pOverLapped == &pClient->m_SndIOContext)
				{
					if(pClient->m_SndIOContext.m_dwTransfered == NO_DATA_TRANSFERED)
					{
						if(g_pSocketSvr->m_EncryptionMethod == MSSSL || g_pSocketSvr->m_EncryptionMethod == MSTLSv1)
						{
//							ULONG ulTransfered = 0;
//							BOOL bSuc = ::GetOverlappedResult((HANDLE)pClient->m_hSocket, &pClient->m_SndIOContext, &ulTransfered, TRUE);
//							ATLASSERT(bSuc);
//							ATLASSERT(pClient->m_pSspiServer->m_UQueueSend.GetSize()>=ulTransfered);
//							pClient->m_pSspiServer->m_UQueueSend.Pop(ulTransfered);
//							pClient->m_pSspiServer->m_UQueueSend.SetHeadPosition();
							//Add three sleep to solve SEC_I_INVALID_TOKEN on client side
							ATLTRACE("=== IO sending completion port ===\n");
							pClient->m_pSspiServer->m_UQueueSend.SetSize(0);
						}
						pClient->m_SndIOContext.m_dwTransfered = 0;
						try
						{
							pClient->OnSend(0);
						}
						catch(...)
						{
							::PostClose(pClient->m_hSocket, ERROR_UEXCEPTION_CAUGHT);
						}
					}
				}
				else
				{
					ATLASSERT(FALSE);
				}
			}
		}
		else
		{
			DWORD dwError = ::GetLastError();
			if(dwError == WAIT_TIMEOUT)
			{
				int n;
				DWORD dwTime = ::GetTickCount();
				UTimerProc(GetWin(), WM_TIMER, 121, dwTime);
				CAutoLock AutoLock(&m_csLock);
				while(m_aPool.GetSize() < m_nDeadPoolSize)
				{
					CUClientThreaded *pClient = new CUClientThreaded;
					m_aPool.Add(pClient);
				}
				m_dwLastTimeCount = dwTime;
				int nSize = m_mapAddrCount.GetSize();
				for(n=nSize-1; n>=0; --n)
				{
					unsigned long &count = m_mapAddrCount.GetValueAt(n);
					if(count == 0)
						m_mapAddrCount.RemoveAt(count);
				}

			}
			else if(dwError == ERROR_OPERATION_ABORTED)
			{
				//call OnClose directly
				ATLASSERT(TRUE);
			}
			else if(dwError == ERROR_NETNAME_DELETED)
			{
				ATLTRACE(" ----> The specified network name is no longer available <----\n");
			}
			else
			{
				ATLASSERT(FALSE);
			}
		}		
	}while(true);
	CleanWebChat();
	return true;
}

void CUListener::SetRegInfo()
{
	USES_CONVERSION;
	CComBSTR bstr;
	CComBSTR bstrXML;
	m_dwTickStart = ::GetTickCount();
	HRESULT hr = ::CoInitialize(NULL);
	bool bSuc = GetMotherBoadSerialNumber(bstr);
	CComBSTR bstrSN(bstr);
	bSuc = SetSocketProConfig(bstr, &m_RegInfo.m_bstrFileName, &bstrXML);
	do
	{
		bstr = L"<SmartDevice>";
		LPOLESTR strHead = wcsstr(bstrXML, bstr);
		LPOLESTR strEnd = wcsstr(bstrXML, L"</SmartDevice>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bSmartDevice = atoi(OLE2A(bstrMid)) ? true : false;
		}

		bstr = L"<JavaScript>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</JavaScript>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bWeb = atoi(OLE2A(bstrMid)) ? true : false;
		}

		bstr = L"<Java>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</Java>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bJava = atoi(OLE2A(bstrMid)) ? true : false;
		}

		bstr = L"<Unix>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</Unix>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bUnix = atoi(OLE2A(bstrMid)) ? true : false;
		}

		bstr = L"<PLG>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</PLG>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bPLG = atoi(OLE2A(bstrMid)) ? true : false;
		}

		bstr = L"<MachineID>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</MachineID>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrTemp(strHead - bstrXML.m_str, bstrXML);
			bstrTemp += L"<MachineID>";
			bstrTemp += bstrSN;
			bstrTemp += strEnd;
			if(bstrTemp != bstrXML)
			{
				bstrXML = bstrTemp;
			}
		}

		bstr = L"<Other>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</Other>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bOther = atoi(OLE2A(bstrMid)) ? true : false;
		}

		bstr = L"<Key>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</Key>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bstrKey = bstrMid;
		}

		bstr = L"<MachineID>";
		strHead = wcsstr(bstrXML, bstr);
		strEnd = wcsstr(bstrXML, L"</MachineID>");
		if(strHead != NULL && strEnd != NULL)
		{
			CComBSTR bstrMid(strEnd-strHead-bstr.Length(), strHead + bstr.Length());
			m_RegInfo.m_bstrMachineID = bstrMid;
		}
	}while(0);
	if(hr == S_OK)
		::CoUninitialize();
	m_RegInfo.m_bstrFileName.ToLower();
	m_RegInfo.m_bstrMachineID.ToLower();
	m_RegInfo.m_bstrKey.ToUpper();
	int nSalt = 12344321;
	
	//machine-application
	char strText[1025] = {0};
	::sprintf(strText, "%d%s%d%d%d%s_sp%d%d%d", m_RegInfo.m_bOther, OLE2A(m_RegInfo.m_bstrMachineID), m_RegInfo.m_bSmartDevice ? 1 : 0,
		m_RegInfo.m_bWeb ? 1 : 0, m_RegInfo.m_bJava ? 1: 0, OLE2A(m_RegInfo.m_bstrFileName), m_RegInfo.m_bPLG, m_RegInfo.m_bUnix, nSalt);
	CSHA1 sha1;
	sha1.Update((unsigned __int8*)strText, ::strlen(strText));
	sha1.Final();
	memset(strText, 0, sizeof(strText));
	sha1.ReportHash(strText, CSHA1::REPORT_HEX);
	bstr = strText;
	g_bRegistered = (bstr == m_RegInfo.m_bstrKey);

	if(g_bRegistered)
		return;
	
	CSHA1 sha2;
	//machine
	memset(strText, 0, sizeof(strText));
	::sprintf(strText, "%d%d%d%d%s_sp%d%d%d", m_RegInfo.m_bOther, m_RegInfo.m_bSmartDevice ? 1 : 0,
		m_RegInfo.m_bWeb ? 1 : 0, m_RegInfo.m_bJava ? 1: 0, OLE2A(m_RegInfo.m_bstrFileName), m_RegInfo.m_bPLG, m_RegInfo.m_bUnix, nSalt);
	sha2.Update((unsigned __int8*)strText, ::strlen(strText));
	sha2.Final();
	memset(strText, 0, sizeof(strText));
	sha2.ReportHash(strText, CSHA1::REPORT_HEX);
	bstr = strText;
	g_bRegistered = (bstr == m_RegInfo.m_bstrKey);
}

bool CUListener::Listen(int nMaxBacklog)
{
	{
		USES_CONVERSION;
		CAutoLock AutoLock(&m_csLock);
		m_dwAcceptThreadCount = 0;
		m_hAcceptExPort = INVALID_HANDLE_VALUE;
		m_mapAddrCount.RemoveAll();
		m_suAddr.ReallocBuffer(512*1024);
		SetRegInfo();
		HANDLE h = ::OpenMutex(MUTEX_ALL_ACCESS, FALSE, OLE2A(m_RegInfo.m_bstrFileName));
		if(h != NULL)
		{
			::CloseHandle(h);
			::SetLastError(ERROR_EXCL_SEM_ALREADY_OWNED);
			return false;
		}
		else
		{
			m_UniqueName = ::CreateMutex(NULL, FALSE, OLE2A(m_RegInfo.m_bstrFileName));
		}

		m_dwLastTimeCount = ::GetTickCount();
		if(m_EncryptionMethod==TLSv1 || m_EncryptionMethod ==SSL23)
		{
			bool bSuc = true;
			if(!g_pStartup->LoadOpenSSL(m_EncryptionMethod==SSL23))
				return false;
			if(!g_pStartup->StartOpenSSL())
				return false;
			if(m_strPfxFile.Length() > 0)
			{
				bSuc = LoadOpenSSLKeyCert();
				if(m_strPassword.Length() > 0)
				{
					memset(m_strPassword.m_str, 0, m_strPassword.Length()*sizeof(WCHAR));
					m_strPassword.Empty();
				}
				if(!bSuc)
					return false;
			}
			else
			{
				if(!g_pStartup->SSL_CTX_use_certificate_file(g_pStartup->m_pCtx, m_strCertFile, SSL_FILETYPE_PEM))
					return false;
				if(!g_pStartup->SSL_CTX_use_PrivateKey_file(g_pStartup->m_pCtx, m_strPrivateKeyFile, SSL_FILETYPE_PEM))
					return false;
				if(!g_pStartup->SSL_CTX_check_private_key(g_pStartup->m_pCtx))
					return false;
			}	
		}
		else if(m_EncryptionMethod == MSTLSv1 || m_EncryptionMethod == MSSSL)
		{
			USES_CONVERSION;
			bool bSuc = true;
			if(m_strPfxFile.Length() > 0)
			{
				bSuc = g_pStartup->StartSSPI(m_strPfxFile, m_strPassword);
			}
			if(m_strPassword.Length() > 0)
			{
				memset(m_strPassword.m_str, 0, m_strPassword.Length()*sizeof(WCHAR));
				m_strPassword.Empty();
			}
			if(!bSuc)
				return false;
			if(m_strPfxFile.Length() == 0)
			{
				if(!g_pStartup->StartSSPI(m_bMachine, m_bRoot))
				{
					return false;
				}
			}
			SECURITY_STATUS Status = CSspiServer::Open((m_EncryptionMethod == MSSSL) ? SP_PROT_SSL3TLS1 /*(SP_PROT_SSL3|SP_PROT_TLS1_CLIENT)*/ : SP_PROT_SSL3TLS1/*(SP_PROT_TLS1|SP_PROT_SSL3_CLIENT)*/, OLE2T(m_bstrSubject));
			if(Status != SEC_E_OK)
			{
				::SetLastError(Status);
				return false;
			}
		}
		
		StartThreadPools();
		m_nRtn=::listen(m_hSocket, nMaxBacklog);
		if(m_nRtn == -1)
		{
			CloseSocket();
			return false;
		}
		if(!m_bUseMessagePump)
		{
			m_hCompletionPort = g_pStartup->CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, (DWORD)this, 0);
			m_hListenThread = ::CreateThread(NULL, 0, LThreadProc, this, 0, &m_dwListenThread);
			if(m_EncryptionMethod == MSTLSv1 || m_EncryptionMethod == MSSSL)
				m_hMThread = ::CreateThread(NULL, 0, MThreadProc, this, 0, &m_dwMThreadId);
		}
		g_tempQueue.ReallocBuffer(50*1460);
	}
	
	if(m_bUseMessagePump)
	{
		g_pStartup->SetTimer(GetWin(), m_ulTimerElapse);
	}
	while(m_aPool.GetSize() < m_nDeadPoolSize)
	{
		CUClientThreaded *pClient = new CUClientThreaded;
		m_aPool.Add(pClient);
	}
	return true;
}

CUQueue CUListener::m_suAddr;

CUListener::CUListener()
{
	m_nDeadPoolSize = 200;
	m_dwMainThreadID = 0;
	::InitializeCriticalSection(&m_csLock);
	m_hWnd = NULL;
	m_ulSMInterval = 60000;
	memset(m_strCertFile, 0, sizeof(m_strCertFile));
	memset(m_strPrivateKeyFile, 0, sizeof(m_strPrivateKeyFile));
	m_ulTimerElapse = 1000;
	m_pThreadPool = NULL;
	g_pThreadPool = NULL;
	m_ulPingInterval = 60000;
	m_ulRecycleGlobalMemoryInterval = 1200000;
	m_dwTick = ::GetTickCount();
	m_ulMaxConnectionsPerClient = 32;
	m_pChat = new CSimpleArray<CChatGroup>;
	m_ulGroupsNotifiedWhenEntering = (~0);
	m_ulGroupsNotifiedWhenExiting = (~0);
	m_ulMaxThreadIdleTimeBeforeSuicide = 60000;
	m_ulCleanPoolInterval = 60000;
	m_OnChatRequestComing = NULL;
	m_OnChatRequestCame = NULL;
	m_OnWinMessage = NULL;
	m_OnAccept = NULL;
	m_OnSwitchTo = NULL;
	m_OnIsPermitted = NULL;
	m_OnClose = NULL;
	m_OnSend = NULL;
	m_OnSSLEvent = NULL;
	m_ulMinSwitchTime = 60000;
	m_bRejected = false;
	m_am = amOwn;
	m_bSharedAM = false;
	m_bMachine = false;
	m_bRoot = false;
	m_pkey = NULL;
	m_pCert = NULL;
	m_bUseMessagePump = false;
	m_hListenThread = NULL;
	m_dwListenThread = 0;
	m_hCompletionPort = 0;
	m_dwLastTimeCount = ::GetTickCount();
	m_h0 = NULL;
	m_h1 = NULL;
	m_UniqueName = NULL;
	m_bHTTPServerPush = true;
	m_hMEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
	m_dwMThreadId = 0;
	m_hMThread = NULL;
	m_hAcceptExPort = INVALID_HANDLE_VALUE;
}

CUListener::~CUListener()
{
	CleanWebChat();
	CUClient *pUClient;
	while(m_aPool.GetSize() > 0)
	{
		pUClient = m_aPool[0];
		ATLASSERT(pUClient);
		delete pUClient;
		m_aPool.RemoveAt(0);
	}
	m_mapSvs.RemoveAll();
	m_mapSvsSlowRequest.RemoveAll();
	g_chatQueue.Empty();
	if(m_pChat)
	{
		delete m_pChat;
		m_pChat = NULL;
	}
	CloseSocket();
	::DeleteCriticalSection(&m_csLock);
	if(m_hWnd)
	{
		::DestroyWindow(m_hWnd);
	}
	if(m_pThreadPool)
	{
		delete (CThreadPool*)m_pThreadPool;
		m_pThreadPool = NULL;
	}

	CleanMutex();
	if(m_UniqueName != NULL)
	{
		::CloseHandle(m_UniqueName);
	}
	::CloseHandle(m_hMEvent);
	if(!m_hMThread)
	{
		::CloseHandle(m_hMThread);
	}
//	g_pSocketSvr = NULL;
}

HWND CUListener::GetWin()
{
//	CAutoLock AutoLock(&m_csLock);
	return m_hWnd;
}

bool CUListener::CreateWnd()
{
	if(m_hWnd)
	{
		return true;
	}
	HINSTANCE hInstance=::GetModuleHandle(NULL);
	if(hInstance==NULL)
		return false;
	WNDCLASSEX	WndClassEx;
	WNDCLASS	wndcls;
	memset(&WndClassEx, 0, sizeof(WndClassEx));
	memset(&wndcls, 0, sizeof(wndcls));
    WndClassEx.cbSize           = sizeof(WndClassEx);
	WndClassEx.lpfnWndProc		= UWindowProc;
    WndClassEx.hInstance        = hInstance;
    WndClassEx.lpszClassName    = _T("UDAPartSocketServer");
	if (!GetClassInfo(WndClassEx.hInstance, WndClassEx.lpszClassName, &wndcls))
	{
		if (!RegisterClassEx(&WndClassEx))
		{
			if(::GetLastError()!=ERROR_CLASS_ALREADY_EXISTS)
			{
				ATLTRACE("Error info in creating a window, error code = %d\n", ::GetLastError());
				return false;
			}
		}
	}
	m_hWnd=CreateWindowEx(0, WndClassEx.lpszClassName, _T("UDAPartSocketServer Sink"), 0, 0, 0, 0, 0, NULL, NULL, hInstance, NULL);
	return (m_hWnd ? true : false);
}

int CALLBACK CUListener::ConditionFunc(LPWSABUF lpCallerId, LPWSABUF lpCallerData, LPQOS lpSQOS, LPQOS lpGQOS, LPWSABUF lpCalleeId, LPWSABUF lpCalleeData, GROUP *g, DWORD_PTR dwCallbackData)
{
	SOCKADDR_IN *pSockAddr = (SOCKADDR_IN *)(lpCallerId->buf);
	u_long addr = pSockAddr->sin_addr.S_un.S_addr;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	int index = m_mapAddrCount.FindKey(addr);
	if(index == -1)
	{
		g_pSocketSvr->m_bRejected = false;
		unsigned long count = 1;
		m_mapAddrCount.Add(addr, count);
	}
	else
	{
		unsigned long &count = m_mapAddrCount.GetValueAt(index);
		if(count >= g_pSocketSvr->m_ulMaxConnectionsPerClient)
			g_pSocketSvr->m_bRejected = true;
		else
			g_pSocketSvr->m_bRejected = false;
		count++;
	}
	return CF_ACCEPT;
}

/*
int CALLBACK CUListener::ConditionFunc(LPWSABUF lpCallerId, LPWSABUF lpCallerData, LPQOS lpSQOS, LPQOS lpGQOS, LPWSABUF lpCalleeId, LPWSABUF lpCalleeData, GROUP *g, DWORD_PTR dwCallbackData)
{
	LPSTR	strOther;
	UINT	nPeerPort;
	CUClient	*pClient;
	int	nRtn=CF_ACCEPT;
	DWORD dwCount;
	DWORD i;
	DWORD dwSum=0;
	char	strThis[256]={0};
	u_short nPort = ntohs(((SOCKADDR_IN *)(lpCallerId->buf))->sin_port);
	LPSTR	strPeer = inet_ntoa(((SOCKADDR_IN *)(lpCallerId->buf))->sin_addr);
	strcpy(strThis, strPeer);
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	dwCount=g_pSocketSvr->GetClientCount();
	for(i=0; i<dwCount; i++)
	{
		pClient=g_pSocketSvr->GetClient(i);
		if(pClient)
		{
			pClient->GetPeerName(nPeerPort, strOther);
			if(strOther && strPeer && (strcmp(strThis, strOther)==0))
			{
				dwSum++;
			}
		}
	}

	if(dwSum>=g_pSocketSvr->m_ulMaxConnectionsPerClient)
	{
		g_pSocketSvr->m_bRejected = true;
	}
	else
	{
		g_pSocketSvr->m_bRejected = false;
	}
	return nRtn;	//or CF_REJECT, or CF_DEFER
}
*/

/*
unsigned long CUListener::GetJoinedGroup(LPCSTR strChatSession, LPCSTR strIpAddr)
{
	int n;
	CAutoLock AutoLock(GetCriticalSection());
	unsigned long ulGroups = 0;
	ATLASSERT(FALSE);
	int nSize = m_aChatContext.GetSize();
	for(n=0; n<nSize; n++)
	{
		unsigned long ulBit = 0;
		CWebChatContext *p = m_aChatContext[n];
		unsigned long ulGroupId = p->m_ulGroups;
		while(ulGroupId && ulBit < 2){
			if((ulGroupId & 0x1))
				ulBit++;
			ulGroupId >>= 1;
		}
		if(ulBit > 1)
			continue;
		if(p->GetHTTPPushSessionId() == strChatSession && p->GetIpAddr() == strIpAddr)
		{
			ulGroups = p->m_ulGroups;
			break;
		}
	}
	return ulGroups;
}*/

unsigned long CUListener::GetChatGroups()
{
	ULONG	ulGroup = 0;
	ULONG	n;
	CAutoLock AutoLock(GetCriticalSection());
	CSimpleArray<CChatGroup> *pChat = m_pChat;
	if(pChat == NULL)
		return 0;
	ULONG nCount=pChat->GetSize();	
	for(n=0; n<nCount; n++)
	{
		//return (*pChat)[n].m_nID;
		ulGroup += (*pChat)[n].m_nID;
	}
	return ulGroup;
}

void CUListener::GetJoinedGroup(SOCKET hSocket, CSimpleArray<CChatGroup*> &groups)
{
	ULONG	n;
	ULONG	ulGroup = 0;
	groups.RemoveAll();
	CAutoLock AutoLock(GetCriticalSection());
	ULONG nCount = m_pChat->GetSize();	
	for(n=0; n<nCount; n++)
	{
		CChatGroup &cg = (*m_pChat)[n];
		if(cg.m_Listeners.Find(hSocket) != -1)
			groups.Add(&cg);
	}
}

unsigned long CUListener::GetJoinedGroup(unsigned long *pGroup, unsigned long ulSize)
{
	unsigned long n;
	unsigned long ulGroups = 0;
	for(n=0; pGroup != NULL && n<ulSize; n++)
	{
		ulGroups |= pGroup[n];
	}
	return ulGroups;
}

unsigned long CUListener::GetJoinedGroup(const VARIANT &vtGroups)
{
	unsigned long ulGroups = 0;
	if(vtGroups.vt == (VT_ARRAY|VT_UI4) || vtGroups.vt == (VT_ARRAY|VT_I4) || vtGroups.vt == (VT_ARRAY|VT_UINT) || vtGroups.vt == (VT_ARRAY|VT_INT))
	{
		unsigned long *p;
		unsigned long n, nSize = vtGroups.parray->rgsabound->cElements;
		::SafeArrayAccessData(vtGroups.parray, (void**)&p);
		for(n=0; n<nSize; n++)
			ulGroups |= p[n];
		::SafeArrayUnaccessData(vtGroups.parray);
	}
	return ulGroups;
}

unsigned long CUListener::GetJoinedGroup(SOCKET hSocket)
{
	ULONG	ulGroup = 0;
	ULONG	n;
	CAutoLock AutoLock(GetCriticalSection());
	CSimpleArray<CChatGroup> *pChat = m_pChat;
	if(pChat == NULL)
		return 0;
	ULONG nCount=pChat->GetSize();	
	for(n=0; n<nCount; n++)
	{
		if((*pChat)[n].m_Listeners.Find(hSocket) != -1)
		{
			unsigned long ulBit = 0;
			unsigned long ulGroupId = (*pChat)[n].m_nID;
			while(ulGroupId){
				if((ulGroupId & 0x1) > 0)
					ulBit++;
				if(ulBit > 1)
					break;
				ulGroupId >>= 1;
			}
			if(ulBit > 1)
				continue;
			//return (*pChat)[n].m_nID;
			ulGroup += (*pChat)[n].m_nID;
		}
	}
	return ulGroup;
}

bool CUListener::AddSlowRequest(unsigned long ulSvsID, unsigned short usRequestID)
{
	CAutoLock AutoLock(&m_csLock);
	int nIndex = m_mapSvs.FindKey(ulSvsID);
	if(nIndex == -1)
		return false;
	nIndex = m_mapSvsSlowRequest.FindKey(ulSvsID);
	if(nIndex != -1)
	{
		CRequestArray& aSlowRequest = m_mapSvsSlowRequest.GetValueAt(nIndex);
		nIndex = aSlowRequest.Find(usRequestID);
		if(nIndex == -1)
		{
			aSlowRequest.Add(usRequestID);
			return true;
		}
	}
	else
	{
		CRequestArray aSlowRequest;
		aSlowRequest.Add(usRequestID);
		m_mapSvsSlowRequest.Add(ulSvsID, aSlowRequest);
		return true;
	}
	return false;
}

unsigned long CUListener::GetClientCount()
{
//	CAutoLock AutoLock(&m_csLock); //This function is already locked by caller function
	return g_mapUClient.GetSize();
}

void CUListener::RemoveIdleWebContext()
{
	int n;
	USES_CONVERSION;
	CAutoLock AutoLock(&m_csLock);
	for(n=0; n<m_aChatContext.GetSize(); ++n)
	{
		CWebChatContext *p = m_aChatContext[n];
		p->SendTimeoutMessage();
		if(p->CanDie())
		{
			CComBSTR bstrUserId;
			CComBSTR bstrIpAddr = p->GetIpAddr();
			CComVariant vtGroups;
			HTTPExit(p->GetHTTPPushSessionId().m_str, OLE2A(p->GetIpAddr().m_str), bstrUserId, vtGroups);
			Exit(bstrUserId.m_str, bstrIpAddr.m_str, vtGroups);
			if(m_aChatContext.Remove(p))
				delete p;
			n--;
		}
	}
}

void CUListener::ShutdownHTTP(unsigned int hSocket)
{
	int n;
	USES_CONVERSION;
	CAutoLock AutoLock(&m_csLock);
	for(n=0; n<m_aChatContext.GetSize(); ++n)
	{
		CWebChatContext *p = m_aChatContext[n];
		if(hSocket == p->m_hSocket)
		{
			CComBSTR bstrUserId;
			CComBSTR bstrIpAddr = p->GetIpAddr();
			CComVariant vtGroups;
			HTTPExit(p->GetHTTPPushSessionId().m_str, OLE2A(p->GetIpAddr().m_str), bstrUserId, vtGroups);
			::SetUserID(hSocket, bstrUserId.m_str);
			Exit(bstrUserId.m_str, bstrIpAddr.m_str, vtGroups);
			if(m_aChatContext.Remove(p))
				delete p;
			break;
		}
	}
}

void CUListener::CleanWebChat()
{
	int n;
	{
		CAutoLock AutoLock(&m_csLock);
		for(n=0; n<m_aChatContext.GetSize(); ++n)
		{
			CWebChatContext *p = m_aChatContext[n];
			p->SendShutdownMessage();			
			delete p;
		}
		m_aChatContext.RemoveAll();
	}
	CScopeUQueue::CleanUQueuePool();
}

void CUListener::CloseSocket()
{
	CleanWebChat();
	{
		CAutoLock AutoLock(&m_csLock);
		if(m_pkey != NULL)
		{
			g_pStartup->EVP_PKEY_free(m_pkey);
			m_pkey = NULL;
		}
		if(m_pCert != NULL)
		{
			g_pStartup->X509_free(m_pCert);
			m_pCert = NULL;
		}
		g_tempQueue.Empty();
		g_tempQueueSnd.Empty();
		CUClient *pUClient;
		{
			while(g_mapUClient.GetSize())
			{
				pUClient = g_mapUClient.GetValueAt(0);
				if(pUClient)
				{
					pUClient->OnClose(0);
					pUClient->CloseSocket();
					delete pUClient;
				}

			}

			while(m_aPool.GetSize() > 0)
			{
				pUClient = m_aPool[0];
				delete pUClient;
				m_aPool.RemoveAt(0);
			}
		}
	}
	
	ShutdownThreadPools();

	if(m_hListenThread != NULL)
	{
		CAutoLock AutoLock(&m_csLock);
		ATLASSERT(m_dwListenThread != 0);
		::CloseHandle(m_hListenThread);
		m_hListenThread = NULL;
		m_dwListenThread = 0;
	}

	if(m_hCompletionPort != NULL)
	{
		CAutoLock AutoLock(&m_csLock);
		::CloseHandle(m_hCompletionPort);
		m_hCompletionPort = NULL;
	}

	if(m_hWnd)
	{
		::DestroyWindow(m_hWnd);
		m_hWnd = NULL;
	}
	
	{
		CAutoLock AutoLock(&m_csLock);
		CleanMutex();
		if(m_UniqueName != NULL)
		{
			::CloseHandle(m_UniqueName);
			m_UniqueName = NULL;
		}
	}

	CSktBase::CloseSocket();

	CAutoLock AutoLock(&m_csLock);
	int n, nSize = m_aChildAcceptThread.GetSize();
	for(n=0; n<nSize; ++n)
	{
		::CloseHandle(m_aChildAcceptThread[n]);
	}
	m_aChildAcceptThread.RemoveAll();
}

CUClient* CUListener::GetClient(UINT nIndex)
{
//	CAutoLock AutoLock(&m_csLock); //This is already locked by caller founction
	if((int)nIndex>=g_mapUClient.GetSize())
		return NULL;
	return g_mapUClient.GetValueAt(nIndex);
}

CUClient* CUListener::FindClient(SOCKET hSocket)
{
//	CAutoLock AutoLock(&m_csLock); //This is already locked by caller founction
	return g_mapUClient.Lookup(hSocket);
}

CUClient* CUListener::FindClient(BIO *pBio)
{
	int n;
	CUClient *p;
//	CAutoLock AutoLock(&m_csLock); //This is already locked by caller founction
	int nSize = g_mapUClient.GetSize();
	for(n=0; n<nSize; n++)
	{
		p = g_mapUClient.GetValueAt(n);
		if(p && p->m_pSSL && p->m_pSSL->GetBioIn() == pBio)
			return p;
	}
	return NULL;
}

void CUListener::OnAccept(int nError)
{
	if(nError == S_OK)
	{
		Accept();
		ATLTRACE("---> Clients = %d <---\n", g_mapUClient.GetSize());
	}
}

void CUListener::OnMessage(HWND hWnd, UINT uMsg, WPARAM wParam,  LPARAM lParam)
{
	CAutoLock AutoLock(&m_csLock);
	switch(uMsg)
	{
	case WM_WORKER_THREAD_DYING:
		if(m_pThreadPool != NULL)
		{
			((CThreadPool*)m_pThreadPool)->OnThreadDead(wParam, lParam);
		}
		break;
	default:
//		OnMessage(hWnd, uMsg, wParam, lParam);
		break;
	}
	if(m_OnWinMessage)
	{
		ULONG ulCount = RemoveLock();
		m_OnWinMessage(hWnd, uMsg, wParam, lParam);
		Relock(ulCount);
	}
}

bool CUListener::CheckOther0(bool &bSecond)
{
	bSecond = false;
	bool b0 = false;
	if(m_h0 == NULL)
	{
		HANDLE h;
		h = ::OpenMutex(MUTEX_ALL_ACCESS, FALSE, ALLCOUNT0);
		if(h != NULL)
		{
			b0 = true;
			::ReleaseMutex(h);
			::CloseHandle(h);
		}
	}

	if(m_h1 == NULL)
	{
		HANDLE h;
		h = ::OpenMutex(MUTEX_ALL_ACCESS, FALSE, ALLCOUNT1);
		if(h != NULL)
		{
			bSecond = true;
			::ReleaseMutex(h);
			::CloseHandle(h);
		}
	}

	return b0;
}

void CUListener::CheckCount()
{
	DWORD dwNow = ::GetTickCount();
	CAutoLock AutoLock(&m_csLock);
	if(!IsRegistered() && (dwNow%60000)<10500) //1 minute
	{
		UINT n;
		UINT nBad = 0;
		UINT nCount = g_pSocketSvr->GetClientCount();
		for(n=0; n<nCount; n++)
		{
			CUClient *pUClient = g_pSocketSvr->GetClient(n);
			if(pUClient && !pUClient->IsRegistered() && pUClient->GetSvsID() != sidStartup)
			{
				nBad++;
				break;
			}
		}
/*		
		//since we prompt nag window on both client and server side. There is no need to memory leaking
		if(nBad)
		{
			BYTE *p = new BYTE[10240000]; //10 mega bytes
		} */
/*
		switch(nBad)
		{
		case 0:
			CleanMutex();
			break;
		case 1:
			{
				bool b1;
				bool b0 = CheckOther0(b1);
				
				if(b1 && b0)
				{
					::MessageBox(NULL, REG_MESSAGE, _T("SocketPro"), MB_OK);
					g_ulPopCount++;
					::Sleep(15000);
				}
				else if(b1 == false && b0 == false)
				{
					CreateMutex(true);
				}
				else if(b1) 
				{
					CreateMutex(true);
				}
				else //b0
				{
					CreateMutex(false);
				}
			}
			break;
		case 2:
			{
				bool b1;
				bool b0 = CheckOther0(b1);
				if(b1 || b0)
				{
					if(b0)
					{
						CreateMutex(false);
					}
					else
					{
						CreateMutex(true);
					}
					::MessageBox(NULL, REG_MESSAGE, _T("SocketPro"), MB_OK);
					g_ulPopCount++;
					::Sleep(15000);
				}
				
			}
			break;
		default:
			::MessageBox(NULL, REG_MESSAGE, _T("SocketPro"), MB_OK);
			::Sleep(15000);
			break;
		}*/
	}
}

void CUListener::CreateMutex(bool bZero)
{
	if(m_h0 == NULL && bZero)
	{
		m_h0 = ::CreateMutex(NULL, FALSE, ALLCOUNT0);
	}

	if(m_h1 == NULL && bZero == false)
	{
		m_h1 = ::CreateMutex(NULL, FALSE, ALLCOUNT1);
	}
}
	

void CUListener::OnTimer(DWORD dwTime)
{
	RemoveIdleWebContext();

	CUClient *pUClient;
	unsigned long ul;
	if((dwTime%m_ulCleanPoolInterval) < m_ulTimerElapse)
	{
		int ul;
		int ulCount;
		CAutoLock AutoLock(GetCriticalSection());
		ulCount = m_aPool.GetSize();
		for(ul = m_nDeadPoolSize; ul<ulCount; ul++)
		{
			if(dwTime>m_aPool[ul]->m_dwTimeTrackRcv && (dwTime-m_aPool[ul]->m_dwTimeTrackRcv) > m_ulCleanPoolInterval)
			{
				pUClient = m_aPool[ul];
				ATLASSERT(pUClient);
				delete pUClient;
				m_aPool.RemoveAt(ul);
				ul--;
				ulCount--;
			}
		}
		ulCount = m_mapSvs.GetSize();
		for(ul=0; ul<ulCount; ul++)
		{
			CSvsContextEx &SvsContext = m_mapSvs.GetValueAt(ul);
			if(SvsContext.m_OnCleanPool != NULL)
			{
				SvsContext.m_OnCleanPool(m_mapSvs.GetKeyAt(ul), dwTime);
			}
		}
	}

	CheckCount();
	
	CAutoLock AutoLock(GetCriticalSection());
	if(dwTime>m_dwTick && (dwTime-m_dwTick)>m_ulRecycleGlobalMemoryInterval)
	{
//		CAutoLock AutoLock(&m_csLock);
		if(g_tempQueue.GetMaxSize() > 100*1024)
			g_tempQueue.ReallocBuffer(100*1024);
		if(g_tempQueueSnd.GetMaxSize()> 100*1024)
			g_tempQueueSnd.ReallocBuffer(100*1024);
		g_pStartup->ShrinkZipQueue();
		m_dwTick = dwTime;
	}
	unsigned long ulCount = GetClientCount();
	for(ul = 0; ul<ulCount; ul++)
	{
		pUClient = g_mapUClient.GetValueAt(ul);
		if(pUClient)
		{
			long lBytes = 0;
			DWORD dwLastRcvTime = pUClient->GetLastRcvTime();
			DWORD dwLastSndTime = pUClient->GetLastSndTime();
			
			if(pUClient->GetSndBytesInQueue())
			{
				ATLTRACE("***** Send %d bytes of data buffer from timer *****\n", pUClient->GetSndBytesInQueue());
				pUClient->Send();
			}

			if(dwTime>dwLastRcvTime && (dwTime-dwLastRcvTime)>m_ulSMInterval && dwTime>dwLastSndTime && (dwTime-dwLastSndTime)>m_ulSMInterval && !pUClient->m_bProcessingSlowRequest)
			{
				pUClient->ShrinkMemory();
			}
			if(dwTime>dwLastRcvTime && dwTime>dwLastSndTime && (dwTime-dwLastSndTime)>m_ulPingInterval && (dwTime-dwLastRcvTime)>m_ulPingInterval && !pUClient->m_bProcessingSlowRequest)
			{
				if(pUClient->m_sndQueue.GetSize()>10240)
				{
					::PostClose(pUClient->m_hSocket, seTimedOut);
				}
				else if(pUClient->m_HttpReqAttribute.m_dHttpVersion < 0.1)
				{
					pUClient->sendReturnData(idPing, 0, NULL);
					if(::IsBatching(pUClient->m_hSocket))
					{
						::CommitBatching(pUClient->m_hSocket);
						::StartBatching(pUClient->m_hSocket);
					}
				}
			}
			
			if(pUClient->GetSvsID() == sidStartup)
			{
				unsigned long ulIdle = g_pSocketSvr->m_ulMinSwitchTime;
				if(dwTime>dwLastRcvTime && dwTime>dwLastSndTime && (dwTime-dwLastSndTime)>ulIdle && (dwTime-dwLastRcvTime)>ulIdle)
				{
					pUClient->OnClose(uecClientRejected);
					g_pSocketSvr->m_aPool.Add((CUClientThreaded*)pUClient);
					ulCount--;
					ul--;
				}
			}

			if(pUClient->GetSvsID() == sidHTTP)
			{
				unsigned long ulIdle = pUClient->m_HttpReqAttribute.m_nKeepAlive * 1000;
				if(ulIdle == 0)
					ulIdle = g_pSocketSvr->m_ulMinSwitchTime;
				if(dwTime>dwLastRcvTime && dwTime>dwLastSndTime && (dwTime-dwLastSndTime)>ulIdle && (dwTime-dwLastRcvTime)>ulIdle)
				{
					pUClient->OnClose(uecClientRejected);
					g_pSocketSvr->m_aPool.Add((CUClientThreaded*)pUClient);
					ulCount--;
					ul--;
				}
			}

			if(g_pSocketSvr->m_EncryptionMethod == BlowFish)
			{
				unsigned long ulIdle = g_pSocketSvr->m_ulMinSwitchTime;
				if(dwTime>dwLastRcvTime && (dwTime-dwLastRcvTime)>ulIdle && !pUClient->m_bVerify)
				{
					pUClient->OnClose(uecClientRejected);
					g_pSocketSvr->m_aPool.Add((CUClientThreaded*)pUClient);
					ulCount--;
					ul--;
				}
			}

			pUClient->IOCtl(&lBytes);
			if(lBytes || pUClient->GetRcvBytesInQueue() && !pUClient->m_bProcessingSlowRequest)
			{
#ifdef _DEBUG
				if(m_EncryptionMethod == MSTLSv1 || m_EncryptionMethod == MSSSL)
				{
					ATLTRACE("***** Socket Bytes = %d bytes, Rcv Buffer = %d, SSL rcv bytes = %d, Transfer = %d *****\n", lBytes, pUClient->GetRcvBytesInQueue(), pUClient->m_pSspiServer->m_UQueueRecv.GetSize(), pUClient->m_RcvIOContext.m_dwTransfered);
				}
#endif
				pUClient->OnReceive(0);
			}
		}
	}
}

void CUClientThreaded::SvsSwitch(unsigned long ulLen)
{
	m_dwTimeTrackRcv = ::GetTickCount();
	//when a client sends the request SwitchTo, it sends client info, user id and password
	RetrieveClientSwitchInfo(ulLen);
	if(m_ClientInfo.m_ulSvsID == 0 || (m_ClientInfo.m_ulSvsID == GetSvsID() && m_ClientInfo.m_ulSvsID == sidStartup))
	{
		HRESULT lResult = uecUnexpected; 
		sendReturnData(idSwitchTo, sizeof(lResult), (unsigned char*)&lResult); 
		UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, ERROR_UWRONG_SWITCH));
		m_bProcessingSlowRequest = true;
		return;
	}
	if(m_ClientInfo.m_ulSvsID == GetSvsID())
	{
		CleanPassword();
		CRtnNormal	RtnNormal;
		RtnNormal.m_hr = m_bRegistered ? uecOK : uecSvrNotRegistered;
		RtnNormal.m_SwitchInfo = m_ServerInfo;
		ATLASSERT(sizeof(RtnNormal)==sizeof(CSwitchInfo)+sizeof(HRESULT));
		sendReturnData(idSwitchTo, sizeof(RtnNormal), (unsigned char*)&RtnNormal);
		return;
	}
	if(m_ClientInfo.m_ulSvsID == sidStartup)
	{
		CleanPassword();
		unsigned long ulSvsID = m_ulSvsID;
		m_OnFastRequestArrive = NULL;
		m_OnRequestProcessed = NULL;
		m_OnClose = NULL;
		m_OnReceive = NULL;
		m_OnSendReturnData = NULL;
		m_OnThreadCreated = NULL;
		m_OnSend = NULL;
		m_OnBaseRequestCame = NULL;
		m_OnIsPermitted = NULL;

		ULONG ulCount = RemoveLock();
		if(m_OnSwitchTo)
		{
			m_OnSwitchTo(m_hSocket, ulSvsID, m_ClientInfo.m_ulSvsID);
			m_OnSwitchTo = NULL;
		}
		if(g_pSocketSvr->m_OnSwitchTo)
		{
			g_pSocketSvr->m_OnSwitchTo(m_hSocket, ulSvsID, m_ClientInfo.m_ulSvsID);
		}
		Relock(ulCount);

		m_ulSvsID = m_ClientInfo.m_ulSvsID;
		m_ServerInfo.m_ulSvsID = m_ClientInfo.m_ulSvsID;
		if(m_SockThreadContext.m_enumTA == taApartment && m_pUThread)
		{
			m_pUThread->KillThread(0);
		}
		m_SockThreadContext.m_enumTA = taNone;
		m_SockThreadContext.m_SlowProcess = NULL;
		m_SockThreadContext.m_PreTranslateMessage = NULL;
		m_SockThreadContext.m_ThreadDying = NULL;
		m_SockThreadContext.m_ThreadStarted = NULL;
		m_OnSwitchTo = NULL;
		
		if(m_HttpReqAttribute.m_dHttpVersion < 1.0)
		{
			
			CRtnNormal	RtnNormal;
			RtnNormal.m_hr = m_bRegistered ? uecOK : uecSvrNotRegistered;
			RtnNormal.m_SwitchInfo = m_ServerInfo;
			ATLASSERT(sizeof(RtnNormal)==sizeof(CSwitchInfo)+sizeof(HRESULT));
			sendReturnData(idSwitchTo, sizeof(RtnNormal), (unsigned char*)&RtnNormal); 
		}
		m_HttpReqAttribute.m_HttpRequest = hrUnknown;
		return;
	}

	{
		int nIndex = g_pSocketSvr->m_mapSvs.FindKey(m_ClientInfo.m_ulSvsID);
		if(nIndex == -1)
		{
			HRESULT lResult = uecSvsNotAvailable;
			sendReturnData(idSwitchTo, sizeof(lResult), (unsigned char*)&lResult); 
			UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, ERROR_USERVICE_NOT_FOUND));
			m_bProcessingSlowRequest = true;
			return;
		}

		ULONG ulCount = RemoveLock();
		if(m_OnSwitchTo != NULL)
		{
			m_OnSwitchTo(m_hSocket, m_ulSvsID, m_ClientInfo.m_ulSvsID);
		}
		if(g_pSocketSvr->m_OnSwitchTo)
		{
			g_pSocketSvr->m_OnSwitchTo(m_hSocket, m_ulSvsID, m_ClientInfo.m_ulSvsID);
		}
		Relock(ulCount);

		CSvsContextEx &SvsContext = g_pSocketSvr->m_mapSvs.GetValueAt(nIndex);
		if(!m_bLocal && m_bRegistered)
		{
			if(SvsContext.m_bRandom && (!g_pSocketSvr->m_RegInfo.m_bPLG))
				m_bRegistered = false;
		}
		m_OnFastRequestArrive = SvsContext.m_OnFastRequestArrive;
		m_OnRequestProcessed = SvsContext.m_OnRequestProcessed;
		m_OnClose = SvsContext.m_OnClose;
		m_SockThreadContext.m_enumTA = SvsContext.m_enumTA;
		m_SockThreadContext.m_SlowProcess = SvsContext.m_SlowProcess;
		m_SockThreadContext.m_PreTranslateMessage = SvsContext.m_PreTranslateMessage;
		m_SockThreadContext.m_ThreadDying = SvsContext.m_ThreadDying;
		m_SockThreadContext.m_ThreadStarted = SvsContext.m_ThreadStarted;
		
		m_OnSendReturnData = SvsContext.m_OnSendReturnData;
		m_OnThreadCreated = SvsContext.m_OnThreadCreated;
		m_OnReceive = SvsContext.m_OnReceive;
		m_OnSend = SvsContext.m_OnSend;
	
		m_OnBaseRequestCame = SvsContext.m_OnBaseRequestCame;
		m_OnIsPermitted = SvsContext.m_OnIsPermitted;
		m_OnSwitchTo = SvsContext.m_OnSwitchTo;
	}
	
	bool bOk = IsPermitted(m_ClientInfo.m_ulSvsID);
	if(!bOk) 
	{
		HRESULT lResult = uecAuthenticationFailed;
		sendReturnData(idSwitchTo, sizeof(lResult), (unsigned char*)&lResult); 
		UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, ERROR_UAUTHENTICATION_FAILED));
		m_bProcessingSlowRequest = true;
		return;
	}
	{
		unsigned long ulPrevSvsID = m_ulSvsID;
		m_ulSvsID = m_ClientInfo.m_ulSvsID;
		m_ServerInfo.m_ulSvsID = m_ClientInfo.m_ulSvsID;
		if(m_ClientInfo.m_ulSvsID != sidHTTP)
			m_HttpReqAttribute.m_nMaxMessageSize = (~0);
		ULONG ulCount = RemoveLock();
		if(m_OnSwitchTo)
		{
			m_OnSwitchTo(m_hSocket, ulPrevSvsID, m_ClientInfo.m_ulSvsID);
		}
		if(g_pSocketSvr->m_OnSwitchTo)
		{
			g_pSocketSvr->m_OnSwitchTo(m_hSocket, ulPrevSvsID, m_ClientInfo.m_ulSvsID);
		}
		Relock(ulCount);
		if(m_HttpReqAttribute.m_HttpRequest != hrUnknown)
		{
		}
		else if(g_pSocketSvr->m_EncryptionMethod != BlowFish || m_bVerify)
		{
			CRtnNormal	RtnNormal;
			RtnNormal.m_hr = m_bRegistered ? uecOK : uecSvrNotRegistered;
			int nIndex = g_pSocketSvr->m_mapSvs.FindKey(m_ServerInfo.m_ulSvsID);
			if(nIndex != -1)
			{
				CSvsContextEx &SvsContext = g_pSocketSvr->m_mapSvs.GetValueAt(nIndex);
				m_ServerInfo.m_usUSockMinor |= (SvsContext.m_bRandom ? RETURN_RESULT_RANDOM : 0);
			}
			RtnNormal.m_SwitchInfo = m_ServerInfo;
			ATLASSERT(sizeof(RtnNormal)==sizeof(CSwitchInfo)+sizeof(HRESULT));
			sendReturnData(idSwitchTo, sizeof(RtnNormal), (unsigned char*)&RtnNormal); 
		}
		else
		{
			g_pSocketSvr->m_queueBlowfish.SetSize(0);
			CRtnNormal	RtnNormal;
			RtnNormal.m_hr = m_bRegistered ? uecOK : uecSvrNotRegistered;
			int nIndex = g_pSocketSvr->m_mapSvs.FindKey(m_ServerInfo.m_ulSvsID);
			if(nIndex != -1)
			{
				CSvsContextEx &SvsContext = g_pSocketSvr->m_mapSvs.GetValueAt(nIndex);
				m_ServerInfo.m_usUSockMinor |= (SvsContext.m_bRandom ? RETURN_RESULT_RANDOM : 0);
			}
			RtnNormal.m_SwitchInfo = m_ServerInfo;
			g_pSocketSvr->m_queueBlowfish.Push((BYTE*)&RtnNormal, sizeof(RtnNormal));
			g_pSocketSvr->m_queueBlowfish << m_guid;
			BYTE pHash[20];
			m_Sha1.GetHash((UINT_8*)pHash);
			g_pSocketSvr->m_queueBlowfish.Push(pHash, 20);
			tagEncryptionMethod tagEM = m_EncryptionMethod; 
			m_EncryptionMethod = NoEncryption;
			sendReturnData(idSwitchTo, g_pSocketSvr->m_queueBlowfish.GetSize(), g_pSocketSvr->m_queueBlowfish.GetBuffer()); 
			m_EncryptionMethod = tagEM;
		}
	}	
}