// UMsgQueue.h: interface for the CUMsgQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UMSGQUEUE_H__1970CA6A_0FD0_4798_952E_9E9A1C2265F5__INCLUDED_)
#define AFX_UMSGQUEUE_H__1970CA6A_0FD0_4798_952E_9E9A1C2265F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "uqueue.h"

class CUMsgQueue : public CUQueue  
{
public:
	CUMsgQueue();
	~CUMsgQueue();

public:
	ULONG GetCount();
	void PushMsg(const MSG &msg);
	ULONG PopMsg(MSG &msg);
	bool CheckCancel();
};

#endif // !defined(AFX_UMSGQUEUE_H__1970CA6A_0FD0_4798_952E_9E9A1C2265F5__INCLUDED_)
