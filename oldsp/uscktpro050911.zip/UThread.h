// UThread.h: interface for the CUThread class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __UTHREAD_SERVER_POOL_H__
#define __UTHREAD_SERVER_POOL_H__

#define	MIN_IDLE_TIME					1000
#define	DEFAULT_MAX_IDLE_TIME			60000

class CUClient;
#include "ULSocket.h"
class CThreadPool;

#include "UMsgQueue.h"

void CALLBACK UThreadTimerProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime);

class CUThread  
{
public:
	CUThread();
	virtual ~CUThread();

public:
	DWORD	GetMaxIdleTime();
	void	SetMaxIdleTime(DWORD dwMaxIdleTime = DEFAULT_MAX_IDLE_TIME);
	HANDLE	GetThread() const;
	DWORD	GetThreadId();
	bool	IsOnIdle();
	DWORD	GetRequestProcessedTime();
	bool	ResetSlowProcess();
	bool	ResetPreTransFunc();
	bool	CreateThread(DWORD dwCreationFlags = 0, DWORD dwStackSize=0);
	DWORD	KillThread(DWORD dwWaitTime = INFINITE);
	bool	AskForProcessing(unsigned long ulBufferLen, DWORD dwUsedBy);
	bool	Cancel();
	bool	IsDead();
	DWORD	ResumeThread();
	DWORD	SuspendThread();
	bool	SetThreadPriority(int nPriority);
	int		GetThreadPriority();
	enumThreadApartment GetTA();
	BOOL	PostThreadMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

public:
	bool					m_bSuicidable;
	PTHREAD_STARTED			m_ThreadStarted;
	PPRETRANSLATEMESSAGE	m_PreTranslateMessage;
	PSLOW_PROCESS			m_SlowProcess;
	PTHREAD_DYING			m_ThreadDying;
	CUClient				*m_pUClient;
	unsigned long			m_ulSvsID;
	unsigned int			m_hSocket;
	POnThreadCreated		m_OnThreadCreated;
	CUMsgQueue				m_UMsgQueue;

private:
	DWORD				m_dwMaxIdleTime; //at least 1000
	DWORD				m_dwThreadId;
	HANDLE				m_hThread;
	HANDLE				m_hWaitEvent;
	DWORD				m_dwRequestProcessedTime;
	bool				m_bIsOnIdle;
	enumThreadApartment	m_TA;
	static DWORD WINAPI UThreadProc(LPVOID lpParameter);
	friend void CALLBACK UThreadTimerProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime);
	friend CThreadPool;	
};

class CThreadPool  
{
public:
	CThreadPool();
	virtual ~CThreadPool();

public:
	void EnableThreadSuicidable(DWORD dwThreadID, bool bSuicidable=true);
	void DestroyAllThread();
	CUThread* GetAThread(enumThreadApartment TA, PSLOW_PROCESS SlowProcess, PPRETRANSLATEMESSAGE PreTranslateMessage=NULL, PTHREAD_DYING ThreadDying=NULL, PTHREAD_STARTED ThreadStarted=NULL, bool bSuicidable=true, unsigned long ulMaxIdleTime=DEFAULT_MAX_IDLE_TIME);
	virtual void OnThreadDead(DWORD dwThreadId, DWORD dwRtn);

public:
	unsigned long			m_ulSvsID;
	SOCKET					m_hSocket;
	POnThreadCreated		m_OnThreadCreated;
};

#endif // !defined(AFX_UTHREAD_H__F884A13A_882E_4B7D_8ADF_3199DF47965B__INCLUDED_)
