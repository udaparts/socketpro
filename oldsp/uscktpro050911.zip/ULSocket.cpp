// ULSocket.cpp: implementation of the CSktBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ULSocket.h"
#include "Startup.h"
#include "context.h"
#include "UThread.h"
#include "ChatRoom.h"
#include "UZip.h"
#include <time.h>


#define MAX_CONTINUE	256

#define IF_TABLE_SIZE  (2*1024)

ULONG	g_ulPopCount = 0;

CStartup	*g_pStartup = NULL;
extern CUQueue	g_chatQueue;
CUQueue	g_cancelQueue;
CUQueue	g_tempQueue;
CUQueue	g_tempQueueSnd;
CUQueue	g_upQueue;

extern CSimpleMap<SOCKET, CUClient*> g_mapUClient;

void SSLCallback(const SSL *pSSL, int nWhere, int nRtn)
{
	if(pSSL)
	{
		CUClient	*pClient = NULL;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		BIO *p = g_pStartup->SSL_get_rbio((SSL *)pSSL);
		if(p != NULL)
		{
			pClient = g_pSocketSvr->FindClient(p);
		}
		ATLASSERT(g_pSocketSvr->GetMainThreadID() == ::GetCurrentThreadId());
		if(pClient)
		{
			pClient->OnSSLEvent(nWhere, nRtn);
		}
	}
}

LRESULT CALLBACK UWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_REQUEST_PROCESSED:
		{
			CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
			CUClient* pSocket = g_mapUClient.Lookup(wParam);
			if(pSocket)
			{
				if(pSocket->m_bClosing)
				{
					pSocket->OnClose(0);
					if(pSocket->m_HttpReqAttribute.m_dHttpVersion < 1.0)
						pSocket->ShrinkMemory();
					g_pSocketSvr->m_aPool.Add((CUClientThreaded*)pSocket);
				}
				else
				{
					pSocket->OnRequestProcessed((unsigned short)lParam);
				}
			}
		}
		break;
	case WM_CONTINUE_PROCESSING:
		{
			CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
			CUClient* pSocket = g_mapUClient.Lookup(wParam);
			if(pSocket)
			{
				pSocket->OnContinueProcessing((unsigned short)lParam);
			}
		}
		break;
	case WM_SOCKET_SVR_NOTIFY:
		{
			short nEvent=WSAGETSELECTEVENT(lParam);
			LPARAM lError=WSAGETSELECTERROR(lParam);
			switch (nEvent)
			{
			case FD_READ:
				{
					CUClient* pSocket;
					CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
					pSocket = g_mapUClient.Lookup(wParam);
					if(pSocket)
					{
						try
						{
							pSocket->OnReceive(lError);
						}
						catch(...)
						{
							DWORD dwError = ERROR_UEXCEPTION_CAUGHT;
							pSocket->m_bProcessingSlowRequest = true;
							UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, wParam, WSAMAKESELECTREPLY(FD_CLOSE, dwError));
						}
					}
				}
				break;
			case FD_WRITE:
				{
					CUClient* pSocket;
					CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
					pSocket = g_mapUClient.Lookup(wParam);
					if(pSocket)
					{
						pSocket->OnSend(lError);
					}
				}
				break;
			case FD_CLOSE:
				{
					CUClient* pSocket;
					CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
					pSocket = g_mapUClient.Lookup(wParam);
					if(pSocket)
					{
						::SetLastError(lParam);
						pSocket->m_bProcessingSlowRequest = true;
						if(GetAssociatedThreadID(wParam) != GetMainThreadID())
						{
							if(((CUClientThreaded*)pSocket)->m_pUThread && !((CUClientThreaded*)pSocket)->m_pUThread->IsOnIdle() && !pSocket->m_bClosing)
							{
								pSocket->m_bClosing = true;
							}
							else
							{
								pSocket->m_bClosing = true;
								pSocket->OnClose(lError);
								if(pSocket->m_HttpReqAttribute.m_dHttpVersion < 1.0)
									pSocket->ShrinkMemory();
								g_pSocketSvr->m_aPool.Add((CUClientThreaded*)pSocket);
							}
						}
						else
						{
							pSocket->m_bClosing = true;
							pSocket->OnClose(lError);
							if(pSocket->m_HttpReqAttribute.m_dHttpVersion < 1.0)
								pSocket->ShrinkMemory();
							g_pSocketSvr->m_aPool.Add((CUClientThreaded*)pSocket);
						}
					}
				}
				break;
			case FD_ACCEPT:
				{
					CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
					g_pSocketSvr->OnAccept(lError);
				}
				break;
			default:
				ATLASSERT(FALSE);
				break;
			}
		}
		break;
	default:
		{
			if(uMsg>=WM_USER)
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				g_pSocketSvr->OnMessage(hWnd, uMsg, wParam, lParam);
			}
		}
		break;
	}
	return TRUE;
}



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

bool WINAPI InitSocketProServer(int nParam)
{
	g_pStartup = new CStartup();
	g_pSocketSvr = new CUListener();
	g_pSocketSvr->m_bUseMessagePump = (g_pStartup->CreateIoCompletionPort == NULL);
	
/*	CRegKey	RegKey;
	LONG lError = RegKey.Create(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\udaparts\\UDAPARTSTEST"));
	if(lError == ERROR_SUCCESS)
	{
		g_bMachine = true;
		RegKey.Close();
		lError = RegKey.Open(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\udaparts"));
		lError = RegKey.DeleteSubKey(_T("UDAPARTSTEST"));
	}
	else
	{
		g_bMachine = false;
	}*/

/*	CreateUDASocketProReg();
	g_bRegistered=OpenLock();
	if(!g_bRegistered)
	{
		g_bRegistered=CheckValid();
	}*/

	if(g_pStartup->Startup())
		return true;
	else
		return false;
}

void WINAPI UninitSocketProServer()
{
	if(g_pStartup)
	{
		g_pStartup->KillTimer();
	}
	if(g_pSocketSvr)
	{
		g_pSocketSvr->m_mapSvs.RemoveAll();
		g_pSocketSvr->m_mapSvsSlowRequest.RemoveAll();
	}
	if(g_pSocketSvr)
	{
		delete g_pSocketSvr;
		g_pSocketSvr = NULL;
	}

	g_cancelQueue.SetSize(0);
	g_mapUClient.RemoveAll();
	
	if(g_pStartup)
	{
		g_pStartup->StopOpenSSL();
		g_pStartup->UnloadOpenSSL();
		g_pStartup->Cleanup();
		delete g_pStartup;
		g_pStartup = NULL;
	}
	SocketProAdapter::CScopeUQueue::DestroyUQueuePool();
}



//////////////////////////////////////////////////////////////////////
// CUClient Class
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUClient::CUClient()
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	m_pSspiServer = NULL;
	m_pIOUQueueSnd = NULL;
	m_pSSL = NULL;
	m_EncryptionMethod = g_pSocketSvr->m_EncryptionMethod;
	m_ulStartBlocking = g_pSocketSvr->m_ulStartBlocking;
	m_bZip = g_pSocketSvr->m_bZip;
//	memset(m_strKey, 0, sizeof(m_strKey));
	m_bKeyLen = 0;
	m_bBatching = false;
	m_llBytesIn = 0;
	m_llBytesOut = 0;
	m_dwTimeTrackSnd = m_dwTimeTrackRcv = ::GetTickCount();
	m_bProcessingSlowRequest = false;
	m_bSendingTooFast = false;
	memset(&m_ClientInfo, 0, sizeof(m_ClientInfo));
	memset(&m_ServerInfo, 0, sizeof(m_ServerInfo));
	m_ServerInfo.m_usUSockMinor = 7;
	m_ServerInfo.m_ulParam1 = g_pStartup->m_ulOS;
	m_ServerInfo.m_ulParam2 = g_pSocketSvr->m_ulPingInterval/1000;
	m_ServerInfo.m_ulParam2 += g_pSocketSvr->m_am*0x00010000;
	m_OnReceive = NULL;
	m_OnSend = NULL;
	m_strUID=NULL;
	m_strPassword=NULL;
	m_ulSvsID = sidStartup;
	m_ulTimeOut = 60000;
	m_OnIsPermitted = NULL;
	m_OnBaseRequestCame = NULL;
	m_OnSendReturnData = NULL;
	m_OnThreadCreated = NULL;
	m_pHttpChatContext = NULL;

	m_dwMaxBuffer = g_pSocketSvr->m_ulStartBlocking;
	memset(&m_StreamHeader,  0, sizeof(m_StreamHeader));
	m_pBlowFish = NULL;
	m_pUThread = NULL;
	m_bSameEndian = true;
	m_ulSpeed = 0;
	m_bClosing = false;
	m_bRegistered = g_bRegistered;
	m_bCleanFromSvr = false;
	m_bZipping = false;
	m_bVerify = false;
	m_guid = IID_NULL;
	m_ZipLevel = zlDefault;
	if(g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
	{
		m_pSspiServer = new CSspiServer();
	}
	if(g_pSocketSvr->m_bUseMessagePump)
	{
		m_pIOUQueueSnd = NULL;
	}
	else if(g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
	{
		m_pIOUQueueSnd = &m_pSspiServer->m_UQueueSend;
	}
	else
	{
		m_pIOUQueueSnd = new CUQueue(UIO_SND_BUFFER_SIZE + 128);
	}
	m_HttpReqAttribute.m_HttpRequest = hrUnknown;
	m_HttpReqAttribute.m_dHttpVersion = 0.0;
	m_HttpReqAttribute.m_bRequestChunked = false;
	m_HttpReqAttribute.m_bResponseChunked = false;
	m_HttpReqAttribute.m_bKeepAlive = false;
	m_HttpReqAttribute.m_nKeepAlive = 0;
	m_HttpReqAttribute.m_nResponseCode = 200;
	m_HttpReqAttribute.m_bHeaderSent = false;
	m_HttpReqAttribute.m_nMaxMessageSize = DEFAULT_MAX_HTTP_MSG_SIZE;
	m_HttpReqAttribute.m_bServerMessage = false;
	m_HttpReqAttribute.m_bAutoPartition = true;
	m_HttpReqAttribute.m_nResponseLength = 0;
	m_HttpReqAttribute.m_nRequestLen = 0;
	m_ulAddr = 0;
	m_bRejected = false;
}

CUClient::~CUClient()
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_pSSL)
	{
		g_pStartup->SSL_set_info_callback(m_pSSL->GetSSL(), NULL);
//		g_pStartup->SSL_shutdown(m_pSSL->GetSSL());
		delete m_pSSL;
		m_pSSL=NULL;
	}
	if(m_pIOUQueueSnd != NULL && g_pSocketSvr->m_EncryptionMethod != MSTLSv1 && g_pSocketSvr->m_EncryptionMethod != MSSSL)
	{
		delete m_pIOUQueueSnd;
	}
	if(m_pSspiServer != NULL)
	{
		delete m_pSspiServer;
	}
	m_sndQueue.Empty();
	m_rcvQueue.Empty();
	m_batchQueue.Empty();
	m_MySpecificBytes.Empty();
	if(m_strUID)
	{
		::free(m_strUID);
		m_strUID = NULL;
	}
	CleanPassword();
	if(m_pSSL || m_hSocket!=INVALID_SOCKET)
		CloseSocket();
	if(m_pBlowFish)
	{
		delete m_pBlowFish;
		m_pBlowFish = NULL;
	}
}

unsigned long CUClient::sendReturnData(unsigned short usRequestId, unsigned long ulLen, const unsigned char *pBuffer)
{
	if(m_HttpReqAttribute.m_HttpRequest != hrUnknown)
	{
		char *str;
//		m_sndQueue.CleanTrack();
		switch(usRequestId)
		{
		case idGet:
		case idPost:
		case idPut:
		case idDelete:
		case idOptions:
		case idTrace:
		case idHead:
		case idConnect:
		case idHeader:
			break;
		default:
			return RETURN_DATA_INTERCEPTED;
			break;
		}
		CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
		unsigned long lStart = m_sndQueue.GetSize();
		if(m_HttpReqAttribute.m_bHeaderSent)
		{
			if(m_HttpReqAttribute.m_bResponseChunked)
			{
				char strLen[17] = {0};

				if(!pBuffer)
					ulLen = 0;
				_itoa(ulLen, strLen, 16);
				m_sndQueue.Push(strLen);
				m_sndQueue.Push((unsigned char*)"\r\n", 2);
				if(pBuffer && ulLen)
				{
					m_sndQueue.Push(pBuffer, ulLen);
					m_sndQueue.Push((unsigned char*)"\r\n", 2);
				}
				else
				{
					m_sndQueue.Push((unsigned char*)"\r\n", 2);
					m_HttpReqAttribute.m_nRequestLen = 0;
				}
				if(ulLen == 0 || pBuffer == NULL)
					m_HttpReqAttribute.m_bResponseChunked = false;
				lStart = m_sndQueue.GetSize() - lStart;
				str = (char*)m_sndQueue.GetBuffer();
				Send();
				return lStart;
			}
			else if(m_MySpecificBytes.GetSize() > 1)
			{
				if(pBuffer && ulLen)
				{
					m_sndQueue.Push(m_batchQueue.GetBuffer(), m_batchQueue.GetSize());
					m_batchQueue.SetSize(0);
					m_batchQueue.CleanTrack();
					m_sndQueue.Push("\r\n", 2);
					
					m_sndQueue.Push(pBuffer, ulLen);
					m_sndQueue.Push("\r\n", 2);
					m_sndQueue.Push("--", 2);
					m_sndQueue.Push(m_MySpecificBytes.GetBuffer(), m_MySpecificBytes.GetSize()-1);
					m_sndQueue.Push("\r\n", 2);
				}
				else
				{
					m_sndQueue.Push("Content-Type: text\r\n");
					m_sndQueue.Push("\r\n--", 4);
					m_sndQueue.Push(m_MySpecificBytes.GetBuffer(), m_MySpecificBytes.GetSize()-1);
					m_sndQueue.Push("--\r\n", 4);
					m_MySpecificBytes.SetSize(0);
					m_HttpReqAttribute.m_nRequestLen = 0;
				}
				str = (char*)m_sndQueue.GetBuffer();
				lStart = m_sndQueue.GetSize() - lStart;
				Send();
				return lStart;
			}
			else if(m_HttpReqAttribute.m_bServerMessage)
			{
				m_sndQueue.Push(pBuffer, ulLen);
				lStart = m_sndQueue.GetSize() - lStart;
				Send();
				m_HttpReqAttribute.m_nRequestLen = 0;
				return lStart;
			}
			else if(m_HttpReqAttribute.m_nResponseLength > 0)
			{
				unsigned int len = (pBuffer != NULL) ? ulLen : 0;
				m_sndQueue.Push(pBuffer, ulLen);
				lStart = m_sndQueue.GetSize() - lStart;
				Send();
				if(len == 0)
				{
					m_HttpReqAttribute.m_nResponseLength = 0;
					m_HttpReqAttribute.m_nRequestLen = 0;
				}
				else if(m_HttpReqAttribute.m_nResponseLength > len)
					m_HttpReqAttribute.m_nResponseLength -= len;
				else
				{
					m_HttpReqAttribute.m_nResponseLength = 0;
					m_HttpReqAttribute.m_nRequestLen = 0;
				}
				return lStart;
			}
			else
			{
				return RETURN_DATA_INTERCEPTED;
			}
		}

		
		m_sndQueue.Push((unsigned char*)"HTTP/1.1 ", 9);
		
		switch(m_HttpReqAttribute.m_nResponseCode)
		{
		case 100:
			m_sndQueue.Push("100 Continue");
			break;
		case 101:
			m_sndQueue.Push("101 Switching Protocols");
			break;
		case 102:
			m_sndQueue.Push("102 Processing");
			break;
		case 200:
			m_sndQueue.Push("200 OK");
			break;
		case 201:
			m_sndQueue.Push("201 Created");
			break;
		case 202:
			m_sndQueue.Push("202 Accepted");
			break;
		case 203:
			m_sndQueue.Push("203 Non-authoritative Information");
			break;
		case 204:
			m_sndQueue.Push("204 No Content");
			break;
		case 205:
			m_sndQueue.Push("205 Reset Content");
			break;
		case 206:
			m_sndQueue.Push("206 Partial Content");
			break;
		case 207:
			m_sndQueue.Push("207 Multi-Status");
			break;
		case 300:
			m_sndQueue.Push("300 Multiple Choices");
			break;
		case 301:
			m_sndQueue.Push("301 Moved Permanently");
			break;
		case 302:
			m_sndQueue.Push("302 Found");
			break;
		case 303:
			m_sndQueue.Push("303 See Other");
			break;
		case 304:
			m_sndQueue.Push("304 Not Modified");
			break;
		case 305:
			m_sndQueue.Push("305 Use Proxy");
			break;
		case 306:
			m_sndQueue.Push("306 Unused");
			break;
		case 307:
			m_sndQueue.Push("307 Temporary Redirect");
			break;
		case 400:
			m_sndQueue.Push("400 Bad Request");
			break;
		case 401:
			m_sndQueue.Push("401 Unauthorized");
			break;
		case 402:
			m_sndQueue.Push("402 Payment Required");
			break;
		case 403:
			m_sndQueue.Push("403 Forbidden");
			break;
		case 404:
			m_sndQueue.Push("404 Not Found");
			break;
		case 405:
			m_sndQueue.Push("405 Method Not Allowed");
			break;
		case 406:
			m_sndQueue.Push("406 Not Acceptable");
			break;
		case 407:
			m_sndQueue.Push("407 Proxy Authentication Required");
			break;
		case 408:
			m_sndQueue.Push("408 Request Timeout");
			break;
		case 409:
			m_sndQueue.Push("409 Conflict");
			break;
		case 410:
			m_sndQueue.Push("410 Gone");
			break;
		case 411:
			m_sndQueue.Push("411 Length Required");
			break;
		case 412:
			m_sndQueue.Push("412 Precondition Failed");
			break;
		case 413:
			m_sndQueue.Push("413 Request Entity Too Large");
			break;
		case 414:
			m_sndQueue.Push("414 Request-url Too Long");
			break;
		case 415:
			m_sndQueue.Push("415 Unsupported Media Type");
			break;
		case 416:
			m_sndQueue.Push("Requested Range Not Satisfiable");
			break;
		case 417:
			m_sndQueue.Push("417 Expectation Failed");
			break;
		case 418:
			m_sndQueue.Push("418 I'm a teapot");
			break;
		case 422:
			m_sndQueue.Push("422 Unprocessable Entity");
			break;
		case 423:
			m_sndQueue.Push("423 Locked");
			break;
		case 424:
			m_sndQueue.Push("424 Failed Dependency");
			break;
		case 425:
			m_sndQueue.Push("425 Unordered Collection");
			break;
		case 426:
			m_sndQueue.Push("426 Upgrade Required");
			break;
		case 449:
			m_sndQueue.Push("449 Retry With");
			break;
		case 500:
			m_sndQueue.Push("500 Internal Server Error");
			break;
		case 501:
			m_sndQueue.Push("501 Not Implemented");
			break;
		case 502:
			m_sndQueue.Push("502 Bad Gateway");
			break;
		case 503:
			m_sndQueue.Push("503 Service Unavailable");
			break;
		case 504:
			m_sndQueue.Push("504 Gateway Timeout");
			break;
		case 505:
			m_sndQueue.Push("505 HTTP Version Not Supported");
			break;
		case 506:
			m_sndQueue.Push("506 Variant Also Negotiates");
			break;
		case 507:
			m_sndQueue.Push("507 Insufficient Storage");
			break;
		case 509:
			m_sndQueue.Push("509 Bandwidth Limit Exceeded");
			break;
		case 510:
			m_sndQueue.Push("510 Not Extended");
			break;
		default:
			{
				char strCode[20] = {0};
				_itoa(m_HttpReqAttribute.m_nResponseCode, strCode, 10);
				m_sndQueue.Push(strCode);
				m_sndQueue.Push(" Unknown Error");
			}
			break; 
		}
		m_sndQueue.Push((unsigned char*)"\r\n", 2);
		unsigned long len;
		m_MySpecificBytes.SetSize(0);
		char *strUTF8Header = GetBoundary(len);
		if(strUTF8Header && len > 0)
		{
			char cEnd = 0;
			m_MySpecificBytes.Push(strUTF8Header, len);
			m_MySpecificBytes.Push(&cEnd, 1);
//			RemoveHTTPResponseHeader("Content-Type");
		}
		
		PrepareResponseHeader();
		str = (char*)m_batchQueue.GetBuffer();
		strUTF8Header = ::StrStrI(str, "Transfer-Encoding: ");
		if(strUTF8Header != NULL)
		{
			m_HttpReqAttribute.m_bResponseChunked = (::strncmp(strUTF8Header + 19, "chunked", 7) == 0);
			RemoveHTTPResponseHeader("Transfer-Encoding");
		}
		
		if(m_HttpReqAttribute.m_dHttpVersion > 1.0)
			m_HttpReqAttribute.m_bKeepAlive = true;
		strUTF8Header = ::StrStrI(str, "Connection: ");
		if(strUTF8Header != NULL)
		{
			m_HttpReqAttribute.m_bKeepAlive = (::strncmp(strUTF8Header + 12, "close", 5) != 0);
			RemoveHTTPResponseHeader("Connection");
		}

		strUTF8Header = ::StrStrI(str, "Content-Type: ");
		if(strUTF8Header != NULL)
		{
			m_HttpReqAttribute.m_bServerMessage = (::strncmp(strUTF8Header + 14, "application/x-dom-event-stream", 30) == 0);
		}

		if(m_HttpReqAttribute.m_bServerMessage)
		{
			m_HttpReqAttribute.m_bKeepAlive = true;
			m_HttpReqAttribute.m_bResponseChunked = false;
			m_MySpecificBytes.SetSize(0);
		}

		strUTF8Header = ::StrStrI(str, "Keep-Alive: ");
		if(strUTF8Header != NULL)
		{
			m_HttpReqAttribute.m_nKeepAlive = atoi(strUTF8Header + 12);
			RemoveHTTPResponseHeader("Keep-Alive");
		}
		else
			m_HttpReqAttribute.m_nKeepAlive = GetSwitchTime()/1000;

		if(m_MySpecificBytes.GetSize() > 0)
		{
			m_HttpReqAttribute.m_bResponseChunked = false;
		}
		
		char strLen[24] = {0};
		if(!m_HttpReqAttribute.m_bResponseChunked && m_MySpecificBytes.GetSize() == 0)
		{
			m_sndQueue.Push("Content-Length: ", 16);
			unsigned int lenCL = (ulLen && pBuffer) ? ulLen : 0;
			if(m_HttpReqAttribute.m_bServerMessage)
				m_HttpReqAttribute.m_nResponseLength = 0;
			else
			{
				char *strContentLength = ::StrStrI(str, "Content-Length: ");
				if(strContentLength != NULL)
				{
					unsigned int nMyLen = atoi(strContentLength + 16);
					if(nMyLen > lenCL)
					{
						m_HttpReqAttribute.m_nResponseLength = (nMyLen - lenCL);
						lenCL = nMyLen;
					}
				}
			}
			_itoa(lenCL, strLen, 10);
			m_sndQueue.Push(strLen);
			m_sndQueue.Push((unsigned char*)"\r\n", 2);
		}
		RemoveHTTPResponseHeader("Content-Length");
		m_sndQueue.Push(m_batchQueue.GetBuffer(), m_batchQueue.GetSize());
		m_batchQueue.SetSize(0);
		m_batchQueue.CleanTrack();
		
//		m_HttpReqAttribute.m_bKeepAlive = false;
		if(m_HttpReqAttribute.m_bKeepAlive)
		{
			m_sndQueue.Push("Connection: ");
			m_sndQueue.Push("keep-alive\r\n");
			m_sndQueue.Push("Keep-Alive: ");
			memset(strLen, 0, sizeof(strLen));
			_itoa(m_HttpReqAttribute.m_nKeepAlive, strLen, 10);
			m_sndQueue.Push(strLen);
			m_sndQueue.Push((unsigned char*)"\r\n", 2);
		}
		else
		{
			m_sndQueue.Push("Connection: ");
			m_sndQueue.Push("close\r\n");
		}

		if(m_HttpReqAttribute.m_bResponseChunked)
		{
			m_sndQueue.Push("Transfer-Encoding: chunked\r\n");
			
			m_sndQueue.Push((unsigned char*)"\r\n", 2);
			char strLen[17] = {0};
			if(!pBuffer)
				ulLen = 0;
			_itoa(ulLen, strLen, 16);
			m_sndQueue.Push(strLen);
			m_sndQueue.Push((unsigned char*)"\r\n", 2);

		}
		
		if(!m_HttpReqAttribute.m_bResponseChunked)
			m_sndQueue.Push((unsigned char*)"\r\n", 2);
		m_sndQueue.Push(pBuffer, ulLen);
		str = (char*)m_sndQueue.GetBuffer();
		if(m_HttpReqAttribute.m_bResponseChunked)
			m_sndQueue.Push((unsigned char*)"\r\n", 2);
		
		if(m_MySpecificBytes.GetSize())
		{
			m_sndQueue.Push("--", 2);
			m_sndQueue.Push(m_MySpecificBytes.GetBuffer(), m_MySpecificBytes.GetSize()-1);
			m_sndQueue.Push((unsigned char*)"\r\n", 2);
		}
		
		ulLen = m_sndQueue.GetSize();
		m_HttpReqAttribute.m_bHeaderSent = true;
		lStart = m_sndQueue.GetSize() - lStart;
		if(!m_HttpReqAttribute.m_bRequestChunked && m_HttpReqAttribute.m_qRMult.GetSize() == 0 && !m_HttpReqAttribute.m_bServerMessage && m_HttpReqAttribute.m_nResponseLength == 0)
		{
			m_HttpReqAttribute.m_nRequestLen = 0;
		}
		Send();
/*		if(m_HttpReqAttribute.m_bKeepAlive)
		{
			long lData = 0;
			FakeSwitchToHttp(sidStartup);
			m_rcvQueue << m_ClientInfo;
			m_rcvQueue << lData;
			m_StreamHeader.m_nRequestID = idSwitchTo;
			m_StreamHeader.m_bRatio = 0;
			m_StreamHeader.m_bTreat = false;
			m_StreamHeader.m_ulLen = m_rcvQueue.GetSize();
		}*/
		return lStart;
	}
	
	bool bZip = false;
	if(usRequestId == idReservedOne || usRequestId == idReservedTwo || m_bClosing)
	{
		return SOCKET_NOT_FOUND;
	}
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	{
		if(m_OnSendReturnData)
		{
			ULONG ulCount = RemoveLock();
			if(m_OnSendReturnData(m_hSocket, usRequestId, ulLen, pBuffer))
			{
				Relock(ulCount);
				return RETURN_DATA_INTERCEPTED;
			}
			Relock(ulCount);
		}
	}

	CStreamHeader	StreamHeader;
	StreamHeader.m_ulLen = ulLen;
	StreamHeader.m_bRatio = 0;
	StreamHeader.m_bTreat = 0;
	StreamHeader.m_nRequestID = usRequestId;

	if(m_bBatching)
	{
		m_batchQueue.Push(&StreamHeader);
		if(ulLen && pBuffer)
		{
			m_batchQueue.Push(pBuffer, ulLen);
		}
	}
	else
	{
		bZip = m_bZip;
		ULONG ulIndex;
		unsigned long ul = 0;
		CUQueue *zipQueue = NULL;
		if(m_bZip && ulLen > (unsigned long)((m_ZipLevel == zlBestSpeed) ? 260 : 16) && pBuffer && usRequestId != idEncrypted)
		{
			zipQueue = g_pStartup->LockQueue(ulIndex);
		}
		if(zipQueue != NULL)
		{
			m_bZip = false; //temporally disable zipping
			if(m_ZipLevel == zlBestSpeed)
			{
				ul = ulLen + 36008;
			}
			else
			{
				ul = (unsigned long)(1.1*ulLen) + 3000;
			}
			if(ul>zipQueue->GetMaxSize())
			{
				zipQueue->ReallocBuffer(ul);
				g_pSocketSvr->m_dwTick = ::GetTickCount();
			}
			m_bZipping = true;
			ULONG ulCount = RemoveLock();
			zipQueue->SetSize(0);
			unsigned short usRatio;
			g_pStartup->m_pUZip[ulIndex].m_ZipLevel = m_ZipLevel;
			if(!g_pStartup->m_pUZip[ulIndex].Compress((void*)pBuffer, ulLen, (BYTE*)zipQueue->GetBuffer(), ul))
			{
				Relock(ulCount);
				m_bZipping = false;
				g_pStartup->UnlockQueue(ulIndex);
				OnClose(uecFailedInZip);
				g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
				return 0;
			}
			zipQueue->SetSize(ul);
			usRatio = (unsigned short)(ulLen/ul) + 1;
			StreamHeader.m_bTreat = usRatio/256;
			StreamHeader.m_bRatio = (usRatio%256);
			switch(m_ZipLevel)
			{
			case zlBestCompression:
				StreamHeader.m_bTreat = (StreamHeader.m_bTreat|odFastZip);
				break;
			case zlBestSpeed:
				StreamHeader.m_bTreat = (StreamHeader.m_bTreat|odFastZip);
			default:
				StreamHeader.m_bTreat = (StreamHeader.m_bTreat|odZipped);
				break;
			}
			StreamHeader.m_ulLen = ul;
			Relock(ulCount);
			m_bZipping = false;
			if(m_bClosing)
			{
				g_pStartup->UnlockQueue(ulIndex);
				return SOCKET_NOT_FOUND;
			}
			g_tempQueue.SetSize(0);
			if(ul > 0)
			{
				ATLASSERT(ul == zipQueue->GetSize());
				g_tempQueue.Push(zipQueue->GetBuffer(), ul);
			}
			g_pStartup->UnlockQueue(ulIndex);
			m_bZip = true; //set back
		}
		if(ul == 0)
		{
			g_tempQueue.SetSize(0);
		}
		if(m_EncryptionMethod == BlowFish && m_pBlowFish != NULL)
		{
			if(m_bKeyLen <= 1 || m_bKeyLen>56)
			{
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, ERROR_UBLOWFISH_KEY_WRONG));
				return 0;
			}
			g_tempQueueSnd.SetSize(0);
			if(StreamHeader.m_nRequestID != idEncrypted)
			{
				g_tempQueueSnd.Push(&StreamHeader);
			}
			if(g_tempQueue.GetSize())
			{
				g_tempQueueSnd.Push(g_tempQueue.GetBuffer(), StreamHeader.m_ulLen);
			}
			else
				g_tempQueueSnd.Push(pBuffer, ulLen);
		

			StreamHeader.m_nRequestID = idEncrypted;
			if(g_tempQueueSnd.GetSize()%8)
			{
				BYTE	pbBytes[7]= {0};
				ul = g_tempQueueSnd.GetSize() + 8 - (g_tempQueueSnd.GetSize()%8);
				g_tempQueueSnd.Push(pbBytes, ul-g_tempQueueSnd.GetSize());
			}
			else
				ul = g_tempQueueSnd.GetSize();
			if(g_tempQueueSnd.GetMaxSize()<ul)
			{
				g_tempQueueSnd.ReallocBuffer(ul);
				g_pSocketSvr->m_dwTick = ::GetTickCount();
			}
			m_pBlowFish->Encrypt((BYTE*)g_tempQueueSnd.GetBuffer(), ul);
			StreamHeader.m_ulLen = ul;
			StreamHeader.m_bRatio = 0;
			StreamHeader.m_bTreat = 0;
			g_tempQueueSnd.Insert(&StreamHeader);
			m_sndQueue.Push(g_tempQueueSnd.GetBuffer(), g_tempQueueSnd.GetSize());
			if(g_tempQueueSnd.GetMaxSize() > 14600)
				g_pSocketSvr->m_dwTick = ::GetTickCount();
			g_tempQueueSnd.SetSize(0);
		}
		else
		{
			m_sndQueue.Push(&StreamHeader);
			if(g_tempQueue.GetSize())
			{
				m_sndQueue.Push(g_tempQueue.GetBuffer(), StreamHeader.m_ulLen);
			}
			else
			{
				m_sndQueue.Push(pBuffer, ulLen);
			}
			if(g_tempQueue.GetMaxSize() > 14600)
				g_pSocketSvr->m_dwTick = ::GetTickCount();
			g_tempQueue.SetSize(0);
		}
//		ATLTRACE("SndBufferSize = %d, CurID = %d\n", m_sndQueue.GetSize(), usRequestId);
		Send();
//		ATLTRACE("SndBufferSize = %d, CurID = %d\n", m_sndQueue.GetSize(), usRequestId);
	}
	return ulLen;
}

void CUClient::CheckCancel()
{
	ULONG ulReq;
	CStreamHeader	StreamHeader;
	CReqPos			ReqPos;
//	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	unsigned long ulRtns = 0;
	unsigned long ulStartPos = 0;
	if(m_StreamHeader.m_nRequestID)
	{
		if(m_StreamHeader.m_nRequestID == idCancel)
		{
			ATLASSERT(m_StreamHeader.m_ulLen == sizeof(unsigned long));
			m_rcvQueue.Pop(&ulReq);
			if(!m_bSameEndian)
			{
				ulReq = ::htonl(ulReq);
			}
			ATLASSERT(ulReq);
			ulReq = 0;
			if(m_pUThread && m_pUThread->m_pUClient==this && !m_pUThread->IsOnIdle() && m_pUThread->GetThread())
			{
				ulReq++;
				while(!m_pUThread->PostThreadMessage(WM_CANCEL_REQUEST, 0, 0))
				{
					::Sleep(1);
				}
			}
			sendReturnData(idCancel, sizeof(ulReq), (BYTE*)&ulReq);
			OnBaseRequestCame(idCancel);
			m_StreamHeader.m_nRequestID = 0;
			m_StreamHeader.m_ulLen = 0;
			m_StreamHeader.m_bRatio = 0;
			m_StreamHeader.m_bTreat = 0;
			return;
			if(m_rcvQueue.GetSize()>=sizeof(CStreamHeader))
			{
				m_rcvQueue.Pop(&m_StreamHeader);
				if(!m_bSameEndian)
				{
					m_StreamHeader.m_nRequestID = ::htons(m_StreamHeader.m_nRequestID);
					m_StreamHeader.m_ulLen = ::htonl(m_StreamHeader.m_ulLen);
				}
				ulStartPos = m_StreamHeader.m_ulLen;
			}
			else
			{
				ulStartPos = 0;
			}
		}
		else
		{
			ulStartPos = m_StreamHeader.m_ulLen;
		}
	}
	g_cancelQueue.SetSize(0);
	while(ulStartPos+sizeof(CStreamHeader)+sizeof(ulReq)<=m_rcvQueue.GetSize())
	{
		CStreamHeader	*pStreamHeader = (CStreamHeader	*)m_rcvQueue.GetBuffer(ulStartPos);
		if(pStreamHeader->m_nRequestID == idCancel || (!m_bSameEndian && pStreamHeader->m_nRequestID == idCancel*256))
		{
			unsigned long ul;
			unsigned long ulCancel;
			CReqPos		tempReqPos;
			m_rcvQueue.Pop(&StreamHeader, ulStartPos);
			m_rcvQueue.Pop(&ulReq, ulStartPos);
			if(!m_bSameEndian)
			{
				StreamHeader.m_nRequestID = ::htons(StreamHeader.m_nRequestID);
				StreamHeader.m_ulLen = ::htonl(StreamHeader.m_ulLen);
				ATLASSERT(StreamHeader.m_ulLen == sizeof(unsigned long));
				ATLASSERT(StreamHeader.m_nRequestID == idCancel);
				ulReq = ::htonl(ulReq);
			}
			ATLASSERT(ulReq);
			ulCancel = (ulReq > ulRtns) ? ulRtns : ulReq;
			ulReq = 0;	
			for(ul = 0; ul<ulCancel; ul++)
			{
				g_cancelQueue.Pop(&tempReqPos);
				if(tempReqPos.m_StreamHeader.m_nRequestID == idBatchZipped)
					break;
				else
				{
					unsigned long ulSize = sizeof(CStreamHeader) + tempReqPos.m_StreamHeader.m_ulLen;
					m_rcvQueue.Pop(ulSize, tempReqPos.m_ulPos);
					ulReq++;
					ulStartPos -= ulSize;
				}
			}
			if(m_pUThread && m_pUThread->m_pUClient==this && !m_pUThread->IsOnIdle() && m_pUThread->GetThread())
			{
				ulReq++;
				while(!m_pUThread->PostThreadMessage(WM_CANCEL_REQUEST, 0, 0))
				{
					::Sleep(1);
				}
			}
			sendReturnData(idCancel, sizeof(ulReq), (BYTE*)&ulReq);
			OnBaseRequestCame(idCancel);
			break;
		}
		ReqPos.m_StreamHeader = *pStreamHeader;
		if(!m_bSameEndian)
		{
			ReqPos.m_StreamHeader.m_ulLen = ::htonl(ReqPos.m_StreamHeader.m_ulLen);
			ReqPos.m_StreamHeader.m_nRequestID = ::htons(ReqPos.m_StreamHeader.m_nRequestID);
		}
		ReqPos.m_ulPos = ulStartPos;
		g_cancelQueue.Insert(&ReqPos);
		ulStartPos +=(ReqPos.m_StreamHeader.m_ulLen+sizeof(CStreamHeader));
		ulRtns++;
	}
}

//Mon, 07 Jul 2008 03:08:52 GMT
void CUClient::PrepareResponseHeader()
{
	USES_CONVERSION;
	char *strWeekday;
	char *strMonth;
	char str[256] = {0};
	SYSTEMTIME st;
	::GetSystemTime(&st);
	switch(st.wDayOfWeek)
	{
	case 0:
		strWeekday = "Sun";
		break;
	case 1:
		strWeekday = "Mon";
		break;
	case 2:
		strWeekday = "Tus";
		break;
	case 3:
		strWeekday = "Wed";
		break;
	case 4:
		strWeekday = "Thu";
		break;
	case 5:
		strWeekday = "Fri";
		break;
	case 6:
		strWeekday = "Sat";
		break;
	default:
		strWeekday = "";
		break;
	}

	switch(st.wMonth)
	{
	case 1:
		strMonth = "Jan";
		break;
	case 2:
		strMonth = "Feb";
		break;
	case 3:
		strMonth = "Mar";
		break;
	case 4:
		strMonth = "Apr";
		break;
	case 5:
		strMonth = "May";
		break;
	case 6:
		strMonth = "Jun";
		break;
	case 7:
		strMonth = "Jul";
		break;
	case 8:
		strMonth = "Aug";
		break;
	case 9:
		strMonth = "Sep";
		break;
	case 10:
		strMonth = "Oct";
		break;
	case 11:
		strMonth = "Nov";
		break;
	case 12:
		strMonth = "Dec";
		break;
	default:
		strMonth = "";
		break;
	}

	char *strLineSep = "\r\n";
	
	//Mon, 07 Jul 2008 03:08:52 GMT
	::sprintf(str, "%s, %.2d %s %d %.2d:%.2d:%.2d GMT", strWeekday, st.wDay, strMonth, st.wYear, st.wHour, st.wMinute, st.wSecond);
	m_sndQueue.Push((unsigned char*)"Date: ", 6);
	m_sndQueue.Push((unsigned char*)str, 29);
	m_sndQueue.Push((unsigned char*)strLineSep, 2);
	m_sndQueue.Push((unsigned char*)"Server: ", 8);
	m_sndQueue.Push(OLE2A(g_pSocketSvr->m_RegInfo.m_bstrFileName));
	m_sndQueue.Push((unsigned char*)strLineSep, 2);
}

void CUClient::ProcessHTTPRequest()
{
	if(m_rcvQueue.GetSize() > 17)
	{
		int nLen = 0;
		char *str = (char*)m_rcvQueue.GetBuffer();
		char *strSep = ::strstr(str, "\r\n\r\n" );
		if(strSep != NULL)
		{
			CStreamHeader sh;
			sh.m_bRatio = 0;
			sh.m_bTreat = 0;
			m_tempQueue.SetSize(0);
			m_tempQueue.CleanTrack();
			
			char *strContentType = ::StrStrI(str, "Content-Type: multipart/");
			if(strContentType)
			{
				char cEnd = 0;
				bool bOk = false;
				char *strEnd = ::strstr(strContentType, "\r\n");
				do
				{
					if(!strEnd)
						break;
					m_batchQueue.Push(strContentType, (strEnd - strContentType) + 2);
					if(m_batchQueue.GetSize() == m_batchQueue.GetMaxSize())
					{
						m_batchQueue.Push(&cEnd, 1);
						m_batchQueue.SetSize(m_batchQueue.GetSize() - 1);
					}
					else
						m_batchQueue.CleanTrack();
					unsigned long lLen;
					char *strBoundary = GetBoundary(lLen);
					if(strBoundary == NULL || lLen == 0)
						break;
					m_HttpReqAttribute.m_qRMult.Push("--", 2);
					m_HttpReqAttribute.m_qRMult.Push(strBoundary, lLen);
//					m_HttpReqAttribute.m_qRMult.Push("\r\n", 2);
					if(m_HttpReqAttribute.m_qRMult.GetMaxSize() == m_HttpReqAttribute.m_qRMult.GetSize())
					{
						m_HttpReqAttribute.m_qRMult.Push(&cEnd, 1);
						m_HttpReqAttribute.m_qRMult.SetSize(m_HttpReqAttribute.m_qRMult.GetSize() - 1);
					}
					m_HttpReqAttribute.m_qRMult.CleanTrack();
					m_batchQueue.SetSize(0);
					bOk = true;
				}while(false);
				
				if(!bOk)
				{
					m_HttpReqAttribute.m_bResponseChunked = false;
					m_HttpReqAttribute.m_nResponseCode = 406;
					m_HttpReqAttribute.m_bKeepAlive = false;
					m_HttpReqAttribute.m_nKeepAlive = 0;
					sendReturnData(idPost, 0, NULL);
					m_bProcessingSlowRequest = true;
					PostClose(m_hSocket, ERROR_BAD_HTTP_REQUEST);
					return;
				}
			}

			m_batchQueue.CleanTrack();

			unsigned char cEnd = 0;
			unsigned int len = strSep - str;
			if(GetSvsID() == sidStartup)
			{
/*				int nIndex = g_pSocketSvr->m_mapSvs.FindKey(sidHttp);
				if(nIndex != -1)
				{
					CSvsContextEx &context = g_pSocketSvr->m_mapSvs.GetValueAt(nIndex);
					sh.m_nRequestID = idStartJob;
					sh.m_ulLen = 0;
					m_tempQueue << sh;
				}*/
				sh.m_nRequestID = idHeader;
				sh.m_ulLen = len;
				m_tempQueue << sh;
				m_tempQueue.Push((unsigned char*)str, len);
				m_rcvQueue.Pop(len + 4); //remove "\r\n\r\n"
				str = ::StrStrI((char*)m_tempQueue.GetBuffer() + sizeof(sh), "Content-Length: ");
			}
			else
			{
				m_StreamHeader.m_nRequestID = idHeader;
				m_StreamHeader.m_ulLen = len;
				m_tempQueue.Push((unsigned char*)str, len);
				m_rcvQueue.Pop(len + 4); //remove "\r\n\r\n"
				str = ::StrStrI((char*)m_tempQueue.GetBuffer(), "Content-Length: ");
			}
			
			if(str != NULL)
			{
				nLen = atoi(str + 16);
				if(nLen < 0)
				{
					m_tempQueue.SetSize(0);
					m_HttpReqAttribute.m_bResponseChunked = false;
					m_HttpReqAttribute.m_nResponseCode = 400;
					m_HttpReqAttribute.m_bKeepAlive = false;
					m_HttpReqAttribute.m_nKeepAlive = 0;
					sendReturnData(idGet, 0, NULL);
					m_bProcessingSlowRequest = true;
					PostClose(m_hSocket, ERROR_BAD_HTTP_REQUEST);
					return; //error code
				}
				m_HttpReqAttribute.m_nRequestLen = nLen;
				ATLASSERT((unsigned long)nLen >= m_rcvQueue.GetSize());
			}
			m_rcvQueue.SetHeadPosition();
			sh.m_ulLen = nLen;	
			switch(m_HttpReqAttribute.m_HttpRequest)
			{
			case hrGet:
				sh.m_nRequestID = idGet;
				break;
			case hrPost:
				sh.m_nRequestID = idPost;
				break;
			case hrHead:
				sh.m_nRequestID = idHead;
				break;
			case hrDelete:
				sh.m_nRequestID = idDelete;
				break;
			case hrOptions:
				sh.m_nRequestID = idOptions;
				break;
			case hrTrace:
				sh.m_nRequestID = idTrace;
				break;
			case hrConnect:
				sh.m_nRequestID = idConnect;
				break;
			case hrPut:
				sh.m_nRequestID = idPut;
				break;
			default:
				break;
			}
			m_tempQueue << sh;
			m_rcvQueue.Insert(m_tempQueue.GetBuffer(), m_tempQueue.GetSize(), 0);
			m_tempQueue.SetSize(0);
		}
	}
}

char* CUClient::GetHTTPPartHead(const char *strBoundary, unsigned long nBlen, unsigned char *strBuffer, unsigned long nLen)
{
	if(!strBuffer || !nLen)
		return NULL;
	char *strStart = (char*)strBuffer;
	char *str = NULL;
	nBlen += 2; //Boundary + \r\n
	while(nLen >= nBlen) //Boundary
	{
		unsigned long len = strlen(strStart);
		if(len >= nBlen)
		{
			str = ::strstr(strStart, strBoundary);
			if(str != NULL)
				break;
		}
		nLen -= len;
		if(nLen < nBlen)
			break;
		nLen -= 3;		//remove one byte for null
		len += 3;		//end 
		strStart += len;
	}
	return str;	
}

void CUClient::Partition(unsigned long len)
{
	CStreamHeader sh;
	sh.m_bRatio = 0;
	sh.m_bTreat = 0;
	sh.m_nRequestID = idMultiPart;
	sh.m_ulLen = len - m_HttpReqAttribute.m_nMaxMessageSize;
	m_HttpReqAttribute.m_nRequestLen = sh.m_ulLen;
	m_StreamHeader.m_ulLen = m_HttpReqAttribute.m_nMaxMessageSize;
	m_rcvQueue.Insert((unsigned char*)&sh, sizeof(sh), m_StreamHeader.m_ulLen);
}

void CUClient::PostProcessOnReceive(int nError)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_bProcessingSlowRequest || m_rcvQueue.GetSize()<sizeof(CStreamHeader))
	{
		return;
	}

	//To support HTTP, it is necessary to disable below code
/*	if(GetSvsID() == sidStartup)
	{
		unsigned long sidHttp = sidHTTP;
		if(m_rcvQueue.GetSize()>14600 && g_pSocketSvr->m_mapSvs.FindKey(sidHttp) == -1)
		{
			OnClose(uecUnexpected);
			g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
			return;
		}
	}*/
	bool  bHandleRequest = false;
	do
	{
		if(!HandleHeader())
			return;
		
		if(m_HttpReqAttribute.m_HttpRequest != hrUnknown && m_HttpReqAttribute.m_qRMult.GetSize() > 0 && (m_StreamHeader.m_nRequestID == idPost || m_StreamHeader.m_nRequestID == idMultiPart))
		{
			char cEnd = 0;
			char *strBHead = NULL;
			unsigned int len = m_StreamHeader.m_ulLen;
			CStreamHeader sh;
			sh.m_bRatio = 0;
			sh.m_bTreat = 0;
			m_rcvQueue.SetHeadPosition();
			m_rcvQueue.Push(&cEnd, 1);
			m_rcvQueue.SetSize(m_rcvQueue.GetSize() - 1);
			char *strBound = (char*)m_HttpReqAttribute.m_qRMult.GetBuffer();
			unsigned int lenB = strlen(strBound);
			unsigned int autoLen = lenB + 2;
			if(m_rcvQueue.GetSize() <= m_HttpReqAttribute.m_nSeeked)
				m_HttpReqAttribute.m_nSeeked = 0;
			strBHead = GetHTTPPartHead(strBound, lenB, (unsigned char*)m_rcvQueue.GetBuffer() + m_HttpReqAttribute.m_nSeeked, m_rcvQueue.GetSize() - m_HttpReqAttribute.m_nSeeked);
			if(strBHead == NULL)
				m_HttpReqAttribute.m_nSeeked = m_rcvQueue.GetSize() - autoLen;
			else
				m_HttpReqAttribute.m_nSeeked = 0;
			char *str = (char*)m_rcvQueue.GetBuffer();
			if(strBHead == str)
			{
				do
				{
					if(m_rcvQueue.GetSize() >= (lenB + 4) && strncmp(strBHead + lenB, "--\r\n", 4) == 0)
					{
						//end found
						m_rcvQueue.Pop(lenB + 4);
						m_StreamHeader.m_ulLen -= (lenB + 4);
						m_StreamHeader.m_nRequestID = idPost;
						ATLASSERT(m_StreamHeader.m_ulLen == 0);
						m_StreamHeader.m_ulLen = 0;
						m_HttpReqAttribute.m_nRequestLen = 0;
						break;
					}
					
					if(m_rcvQueue.GetSize() < lenB + 2)
						return;
					
					if(::strncmp(strBHead + lenB, "\r\n", 2) != 0)
					{
						m_HttpReqAttribute.m_bResponseChunked = false;
						m_HttpReqAttribute.m_nResponseCode = 406;
						m_HttpReqAttribute.m_bKeepAlive = false;
						m_HttpReqAttribute.m_nKeepAlive = 0;
						sendReturnData(idPost, 0, NULL);
						m_bProcessingSlowRequest = true;
						PostClose(m_hSocket, ERROR_BAD_HTTP_REQUEST);
						return;
					}

					char *strSubheadEnd = strstr(strBHead, "\r\n\r\n");
					if(!strSubheadEnd)
						return;

					m_StreamHeader.m_nRequestID = idHeader;
					m_StreamHeader.m_ulLen = strSubheadEnd - strBHead - lenB - 2;
					m_tempQueue.SetSize(0);
//					m_tempQueue.CleanTrack(); //save CPU
					m_tempQueue.Push(strBHead + lenB + 2, m_StreamHeader.m_ulLen);
					unsigned long nRemove = strSubheadEnd - str + 4;
					m_rcvQueue.Pop(nRemove); //lenB + "\r\n\r\n"
					m_rcvQueue.SetHeadPosition();
					if(len > nRemove)
						sh.m_ulLen = len - nRemove;
					else
						sh.m_ulLen = 0;
					m_HttpReqAttribute.m_nRequestLen = sh.m_ulLen;
					sh.m_nRequestID = idMultiPart;
					m_tempQueue << sh;
					m_rcvQueue.Insert(m_tempQueue.GetBuffer(), m_tempQueue.GetSize(), 0);
					m_tempQueue.SetSize(0);
					m_HttpReqAttribute.m_nSeeked = 0;
				}while(false);
			}
			else if(strBHead)
			{
				unsigned long size = strBHead - str - 2;
				if(size > m_HttpReqAttribute.m_nMaxMessageSize)
				{
					Partition(m_StreamHeader.m_ulLen);
				}
				else
				{
					m_StreamHeader.m_ulLen = size;
					if(len > size + 2)
						sh.m_ulLen = len - size - 2;
					else
						sh.m_ulLen = 0;
					sh.m_nRequestID = idMultiPart;
					m_HttpReqAttribute.m_nRequestLen = sh.m_ulLen;
					m_rcvQueue.Pop((unsigned long)2, size); //remove \r\n
					m_rcvQueue.Insert((unsigned char*)&sh, sizeof(sh), size);
				}
			}
			else if(m_HttpReqAttribute.m_bAutoPartition && 
				m_rcvQueue.GetSize() >= (m_HttpReqAttribute.m_nMaxMessageSize + autoLen) && 
				m_StreamHeader.m_nRequestID == idMultiPart && 
				m_StreamHeader.m_ulLen >= (m_HttpReqAttribute.m_nMaxMessageSize + autoLen))
			{
				Partition(len);
				m_HttpReqAttribute.m_nSeeked = 0;
			}
		}
		if(GetSvsID() == sidHTTP && 
			m_StreamHeader.m_ulLen > m_HttpReqAttribute.m_nMaxMessageSize && 
			!(m_HttpReqAttribute.m_bAutoPartition && m_HttpReqAttribute.m_qRMult.GetSize() > 0))
		{
			m_bProcessingSlowRequest = true;
			m_HttpReqAttribute.m_bResponseChunked = false;
			m_HttpReqAttribute.m_nResponseCode = 400;
			m_HttpReqAttribute.m_bKeepAlive = false;
			m_HttpReqAttribute.m_nKeepAlive = 0;
			sendReturnData(idGet, 0, NULL);
			PostClose(m_hSocket, ERROR_BAD_HTTP_SIZE);
			return;
		}
		if(m_StreamHeader.m_ulLen > m_rcvQueue.GetSize())
			break;
		if(m_StreamHeader.m_nRequestID !=0)
		{
			if(!HandleEncryption())
				return;

			if(!HandleUnzip())
				return;

			if(g_pSocketSvr->m_EncryptionMethod == BlowFish && !m_bVerify 
				&& GetSvsID() != sidStartup && 
				m_StreamHeader.m_nRequestID != idVerifySalt)
			{
				m_bProcessingSlowRequest = true;
				OnClose(ERROR_VERIFY_SALT);
				g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
				return;
			}

//			HandleTooFast();
			if(GetSvsID() == sidStartup)
			{
				OnRequestArrive(m_StreamHeader.m_nRequestID, m_StreamHeader.m_ulLen);
			}
			else if(m_StreamHeader.m_nRequestID == idCancel)
			{
				CheckCancel();
			}
			else if(m_StreamHeader.m_nRequestID == idVerifySalt)
			{
				if(m_rcvQueue.GetSize() >= sizeof(GUID) && m_StreamHeader.m_ulLen == sizeof(GUID) && m_rcvQueue.GetSize() < 14600)
				{
					GUID guid;
					m_rcvQueue >> guid;
					if(::memcmp(&guid, &m_guid, sizeof(GUID)) == 0 && !m_bVerify)
					{
						sendReturnData(idVerifySalt, 0, NULL);
						m_StreamHeader.m_ulLen = 0;
						m_bVerify = true;
						OnBaseRequestCame(idVerifySalt);
					}
					else
					{
						m_bProcessingSlowRequest = true;
						OnClose(ERROR_VERIFY_SALT);
						g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
						return;
					}
				}
				else
				{
					m_bProcessingSlowRequest = true;
					OnClose(ERROR_VERIFY_SALT);
					g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
					return;
				}
			}
			else
			{
				HandleRequest();
				bHandleRequest = true;
			}
			if(m_bProcessingSlowRequest)
				break;
			if(m_StreamHeader.m_ulLen == 0)
			{
				ATLASSERT(m_StreamHeader.m_bRatio == 0 && m_StreamHeader.m_bTreat == 0);
				m_StreamHeader.m_nRequestID = 0;
			}
		}
		if(m_bProcessingSlowRequest)
			break;
		if(bHandleRequest)
		{
			bHandleRequest = false;
		}
		if(m_rcvQueue.GetSize() < sizeof(m_StreamHeader))
		{
			break;
		}
		if(m_StreamHeader.m_nRequestID == 0 && m_StreamHeader.m_ulLen > 0)
		{
			::MessageBox(NULL, _T("Please report the error to support@udaparts.com"), _T("Stream Processing Error"), MB_ICONERROR);
		}

	}while(true);
	
	if(!m_bProcessingSlowRequest && (m_RcvIOContext.m_dwTransfered != NO_DATA_TRANSFERED) && (m_rcvQueue.GetSize() > 0 || m_StreamHeader.m_nRequestID > 0))
	{
		long lBytes = 0;
		IOCtl(&lBytes);
		if(lBytes > 0)
		{
			UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, FD_READ);
//			ATLTRACE("UPostMessage size = %d, %d\n", lBytes, m_rcvQueue.GetSize());
		}
	
	}
	m_rcvQueue.SetHeadPosition();
}

void CUClient::OnReceive(int nError)
{
	if(m_OnReceive != NULL)
	{
		ULONG ulCount = RemoveLock();
		m_OnReceive(m_hSocket, nError);
		Relock(ulCount);
	}
	if(nError == 0 && g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
	{
		if(m_pSspiServer->GetSSLState() != ssFinished)
		{
			ATLTRACE("Hand shake ....\n");
			if(m_pSspiServer->GetSSLState() == ssUnknown || m_pSspiServer->GetSSLState() == ssClientHello)
			{
				OnSSLEvent(ssleHandshakeStarted, 0);
			}
			else
			{
				OnSSLEvent(ssleHandshakeLoop, 0);
			}
			HRESULT hr = m_pSspiServer->ClientHandshakeLoop(m_hSocket, true);
			if(FAILED(hr))
			{
				::SetLastError(hr);
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, hr));
				return;
			}
			if(m_pSspiServer->GetSSLState()  == ssFinished)
			{
				OnSSLEvent(ssleHandshakeDone, 0);
				if(!g_pSocketSvr->m_bUseMessagePump)
					return;
			}
			else
			{
				OnSSLEvent(ssleHandshakeLoop, 0);
				return;
			}
		}
	}
	
	if(g_pSocketSvr->m_bUseMessagePump)
	{
		Recv();
	}
	else
	{
		if (g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
		{
			IOPortRecvSSL();
		}
		else
		{
			IOPortRecv();
		}
	}
	PostProcessOnReceive(nError);
}

void CUClient::OnSend(int nError)
{
	if(nError == 0)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		unsigned long ulOri = m_sndQueue.GetSize();
		if(ulOri || (m_pSspiServer && m_pSspiServer->GetDataInBuffer() > 0))
		{
			Send();
		}
		ULONG ulCount = RemoveLock();
		if(m_OnSend)
		{
			m_OnSend(m_hSocket, nError);
		}
		if(g_pSocketSvr->m_OnSend)
		{
			g_pSocketSvr->m_OnSend(m_hSocket, nError);
		}
		Relock(ulCount);
	}
	else
	{
		UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, nError));
	}
	
}

void CUClient::OnRequestProcessed(unsigned short usRequestID)
{
	{
//		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
//		m_rcvQueue.SetHeadPosition();
		m_bProcessingSlowRequest = false;
		if(m_StreamHeader.m_ulLen==0)
		{
			ATLASSERT(m_StreamHeader.m_bRatio == 0);
			ATLASSERT(m_StreamHeader.m_bTreat == 0);
			m_StreamHeader.m_nRequestID = 0;
		}
	}
	OnSend(0);
	{
//		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(m_bCleanFromSvr)
		{
			m_bCleanFromSvr = false;
			OnBaseRequestCame(idCleanTrack);
		}
		OnReceive(0);
	}

	DebugCheck();
}

void CUClient::CleanPassword()
{
	if(m_strPassword)
	{
		memset(m_strPassword, 0, ::wcslen(m_strPassword)*sizeof(WCHAR));
		::free(m_strPassword);
		m_strPassword = NULL;
	}
}

void CUClient::OnClose(int nError)
{
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		m_bVerify = false;
		CleanPassword();
		if(m_strUID)
		{
			::free(m_strUID);
			m_strUID = NULL;
		}
		g_mapUClient.Remove(m_hSocket);
		ATLTRACE("++++ Clients = %d, error code = %d ++++\n", g_mapUClient.GetSize(), nError);
		ShrinkMemory();
	}
	CloseSocket();	
}
//////////////////////////////////////////////////////////////////////
// CUListener Class
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
unsigned long CUClient::GetRcvBufferSize()
{
	return m_rcvQueue.GetMaxSize();
}

unsigned long CUClient::GetReqIDsInQueue(unsigned short *pusRequestID, unsigned long ulSize)
{
	if(pusRequestID == NULL || ulSize == 0)
	{
		return 0;
	}
	unsigned long ulRtns = 0;
	unsigned long ulStartPos = 0;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_StreamHeader.m_nRequestID)
	{
		ulRtns = 1;
		ulStartPos = m_StreamHeader.m_ulLen;
		pusRequestID[0] = m_StreamHeader.m_nRequestID;
	}
	while(ulRtns<ulSize && ulStartPos+sizeof(CStreamHeader)<=m_rcvQueue.GetSize())
	{
		CStreamHeader	*pStreamHeader = (CStreamHeader	*)m_rcvQueue.GetBuffer(ulStartPos);
		pusRequestID[ulRtns] = pStreamHeader->m_nRequestID;
		ulStartPos +=(pStreamHeader->m_ulLen+sizeof(CStreamHeader));
		ulRtns++;
	}
	return ulRtns;
}

unsigned long CUClient::QueryRequestsInQueue()
{
	unsigned long ulRtns = 0;
	unsigned long ulStartPos = 0;
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_StreamHeader.m_nRequestID)
	{
		ulRtns = 1;
		ulStartPos = m_StreamHeader.m_ulLen;
	}
	if(m_ulSvsID == sidHTTP)
	{
		if(m_HttpReqAttribute.m_qRMult.GetSize() > 0 && m_HttpReqAttribute.m_bAutoPartition)
		{
			ulRtns += m_rcvQueue.GetSize()/( m_HttpReqAttribute.m_nMaxMessageSize + m_HttpReqAttribute.m_qRMult.GetSize() + 10);
			return ulRtns;
		}
	}

	while(ulStartPos+sizeof(CStreamHeader)<=m_rcvQueue.GetSize())
	{
		CStreamHeader	*pStreamHeader = (CStreamHeader	*)m_rcvQueue.GetBuffer(ulStartPos);
		if(pStreamHeader->m_ulLen > m_HttpReqAttribute.m_nMaxMessageSize)
		{
			m_bProcessingSlowRequest = true;
			::PostClose(m_hSocket, ERROR_REQUEST_TOO_LARGE);
			return ERROR_REQUEST_TOO_LARGE;
		}
		if(m_ulSvsID > 0 && m_ulSvsID != sidStartup)
		{
			if(g_pSocketSvr->m_EncryptionMethod == BlowFish && !m_bVerify 
			&& pStreamHeader->m_ulLen > 14600)
			{
				m_bProcessingSlowRequest = true;
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, ERROR_VERIFY_SALT));
				return 1000;
			}

			if(m_ulSvsID == sidHTTP)
			{
				ulRtns++;
				break;
			}

			if(pStreamHeader->m_ulLen > m_rcvQueue.GetMaxSize())
			{
				m_rcvQueue.ReallocBuffer(pStreamHeader->m_ulLen + m_rcvQueue.GetBlockSize());
				if(ulRtns == 0)
					ulRtns = 1;
				break;
			}
		}
		ulStartPos +=(pStreamHeader->m_ulLen+sizeof(CStreamHeader));
		ulRtns++;
	}
	return ulRtns;
}

unsigned long CUClient::GetSndBufferSize()
{
	return m_sndQueue.GetMaxSize();
}

unsigned long CUClient::GetLastRcvTime()
{
	return m_dwTimeTrackRcv;
}

unsigned long CUClient::GetLastSndTime()
{
	return m_dwTimeTrackSnd;
}

void CUClient::OnSSLEvent(int nWhere, int nRtn)
{
	switch (nWhere)
	{
	case ssleHandshakeStarted:
		ATLTRACE("Handshake started, nRtn = %d\n", nRtn);
		break;
	case ssleHandshakeDone:
		ATLTRACE("Handshake done, nRtn = %d\n", nRtn);
		break;
	case /*ssleHandshakeLoop*/(SSL_ST_ACCEPT|SSL_CB_LOOP):
		ATLTRACE("Handshake looping, nRtn = %d\n", nRtn);
		break;
	case /*ssleHandshakeExit*/(SSL_ST_ACCEPT|SSL_CB_EXIT):
		ATLTRACE("Handshake exit, nRtn = %d\n", nRtn);
		break;
	case ssleReadAlert:
		ATLTRACE("Read alert, nRtn = %d\n", nRtn);
		break;
	case ssleHandshakeLoop:
		ATLTRACE("Handshake looping, nRtn = %d\n", nRtn);
		break;
	case ssleWriteAlert:
		ATLTRACE("Write alert, nRtn = %d\n", nRtn);
		break;
	default:
		ATLTRACE("Unknown SSL events\n");
		break;
	}
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(g_pSocketSvr->m_OnSSLEvent)
	{
		ULONG ulCount = RemoveLock();
		g_pSocketSvr->m_OnSSLEvent(m_hSocket, nWhere, nRtn);
		Relock(ulCount);
	}
}

void CUClient::IOPortOpenSSLSend()
{
	int err;
	int nLen;
	unsigned long ulBatch;
	ULONG ulSent = 0;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_SndIOContext.m_dwTransfered == NO_DATA_TRANSFERED || m_bClosing)
		return;
	m_nRtn = 0;
	CUQueue &temp = m_pSSL->GetOut();
	while(temp.GetSize() > 1460)
	{
		err = ::send(m_hSocket, (char*)temp.GetBuffer(), temp.GetSize(), 0);
		if(err > 0)
			temp.Pop((unsigned long)err);
		else
		{
			break;
		}
	}
d1:	ulBatch = m_sndQueue.GetSize();
	while(ulBatch > 0)
	{
		if(ulBatch > UIO_SND_BUFFER_SIZE)
		{
			ulBatch = UIO_SND_BUFFER_SIZE;
		}
		err = m_pSSL->Encrypt((char*)m_sndQueue.GetBuffer(), ulBatch);
		if(err == 0)
			break;
		m_sndQueue.Pop(ulBatch);
		m_llBytesOut += ulBatch;
		ulSent += ulBatch;
		err = 0;
		while(temp.GetSize() > 0)
		{
			nLen = ::send(m_hSocket, (char*)temp.GetBuffer(), temp.GetSize(), 0);
			if(nLen > 0)
			{
				err += nLen;
				temp.Pop((unsigned long)nLen);
			}
			else
				break;
		}
		if(temp.GetSize() > 0)
			break;
		ulBatch = m_sndQueue.GetSize();
	}
	ulBatch = temp.GetSize();
	while(ulBatch)
	{
		ulBatch = temp.Pop((BYTE*)m_pIOUQueueSnd->GetBuffer(), ulBatch);
		ulSent += ulBatch;
		memset(&m_SndIOContext, 0, sizeof(OVERLAPPED));
		m_SndIOContext.m_RcvWSABuf.buf = (char*)m_pIOUQueueSnd->GetBuffer();
		m_SndIOContext.m_RcvWSABuf.len = ulBatch;
		m_SndIOContext.m_dwTransfered = 0;
		err = ::WSASend(m_hSocket, &m_SndIOContext.m_RcvWSABuf, 1, &m_SndIOContext.m_dwTransfered, 0, /*NULL*/&m_SndIOContext, NULL); 
		if(err == -1)
		{
			err = ::WSAGetLastError();
			if(err == WSA_IO_PENDING)
			{
				m_SndIOContext.m_dwTransfered = NO_DATA_TRANSFERED;
				break;
			}
			else if(err != 0)
			{
				m_nRtn = -1;
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
				break;
			}
		}
		else
		{
			if(m_SndIOContext.m_dwTransfered)
			{
				ulBatch = temp.GetSize();
			}
			else
			{
//				ATLASSERT(FALSE);
				goto d1;
			}
		}	
	}
	if(ulSent > 0)
	{
		m_llBytesOut += ulSent;
		m_dwTimeTrackSnd = ::GetTickCount();
		m_sndQueue.SetHeadPosition();
	}
}

void CUClient::IOPortSend()
{
	int err;
	unsigned long ulBatch;
	ULONG ulSent = 0;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_SndIOContext.m_dwTransfered == NO_DATA_TRANSFERED || m_bClosing)
		return;
	m_nRtn = 0;
	ulBatch = m_sndQueue.GetSize();
	while(ulBatch > 0)
	{
		if(ulBatch > UIO_SND_BUFFER_SIZE)
		{
			ulBatch = UIO_SND_BUFFER_SIZE;
		}
		
		err = ::send(m_hSocket, (const char*)m_sndQueue.GetBuffer(), ulBatch, 0);
		if(err > 0)
		{
			ulSent += (ULONG)err;
			m_sndQueue.Pop((unsigned long)err);
		}
		else
		{
			break;
		}
		
		if(err < (long)ulBatch)
			break;
		ulBatch = m_sndQueue.GetSize();
	}

	ulBatch = m_sndQueue.GetSize();
	while(ulBatch)
	{
		if(ulBatch > UIO_SND_BUFFER_SIZE)
		{
			ulBatch = UIO_SND_BUFFER_SIZE;
		}

		ulBatch = m_sndQueue.Pop((BYTE*)m_pIOUQueueSnd->GetBuffer(), ulBatch);
		ulSent += ulBatch;

		memset(&m_SndIOContext, 0, sizeof(OVERLAPPED));
		m_SndIOContext.m_RcvWSABuf.buf = (char*)m_pIOUQueueSnd->GetBuffer();
		m_SndIOContext.m_RcvWSABuf.len = ulBatch;
		m_SndIOContext.m_dwTransfered = 0;
		err = ::WSASend(m_hSocket, &m_SndIOContext.m_RcvWSABuf, 1, &m_SndIOContext.m_dwTransfered, 0, /*NULL*/&m_SndIOContext, NULL); 
		if(err == -1)
		{
			err = ::WSAGetLastError();
			if(err == WSA_IO_PENDING)
			{
				m_SndIOContext.m_dwTransfered = NO_DATA_TRANSFERED;
				break;
			}
			else if(err != 0)
			{
				m_nRtn = -1;
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
				break;
			}
		}
		else
		{
			if(m_SndIOContext.m_dwTransfered)
			{
				ulBatch = m_sndQueue.GetSize();
			}
			else
			{
				ATLASSERT(FALSE);
				break;
			}
		}	
	}
	if(ulSent > 0)
	{
		m_llBytesOut += ulSent;
		m_dwTimeTrackSnd = ::GetTickCount();
		m_sndQueue.SetHeadPosition();
	}
}

void CUClient::HTTPAutoClose()
{
	if(	m_HttpReqAttribute.m_dHttpVersion >= 1.0 && 
			!m_HttpReqAttribute.m_bKeepAlive && 
			!m_HttpReqAttribute.m_bResponseChunked && 
			m_HttpReqAttribute.m_bHeaderSent &&
			m_MySpecificBytes.GetSize() == 0 &&
			!m_HttpReqAttribute.m_bServerMessage &&
			m_HttpReqAttribute.m_nResponseLength == 0 &&
			m_HttpReqAttribute.m_nRequestLen == 0 && 
			m_rcvQueue.GetSize() == 0
			)
	{
		if(GetSndBytesInQueue() == 0)
		{
			m_bProcessingSlowRequest = true;
			::shutdown(m_hSocket, SD_BOTH);
			::PostClose(m_hSocket, 0);
		}
	}
}

void CUClient::Send()
{
	if(!g_pSocketSvr->m_bUseMessagePump)
	{
		if (g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
		{
			IOPortSendSSL();
		}
		else if(m_pSSL)
		{
			IOPortOpenSSLSend();
		}
		else
		{
			IOPortSend();
		}
		HTTPAutoClose();
		return;
	}
	int err;
	unsigned long ulBatch;
	m_nRtn = 0;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_pSSL)
	{
		CUQueue &temp = m_pSSL->GetOut();
		while(temp.GetSize() > 1460)
		{
			err = ::send(m_hSocket, (char*)temp.GetBuffer(), temp.GetSize(), 0);
			if(err > 0)
				temp.Pop((unsigned long)err);
			else
			{
				return;
			}
		}
	}
	else if(m_pSspiServer && m_pSspiServer->GetDataInBuffer() > 0)
	{
		m_pSspiServer->SendData(m_hSocket, NULL, 0);
	}

	ulBatch = m_sndQueue.GetSize();
	while(ulBatch || (m_pSspiServer && m_pSspiServer->GetDataInBuffer() > 0) || (m_pSSL && m_pSSL->GetOut().GetSize()))
	{
		if(ulBatch && m_bSendingTooFast)
		{
			m_bSendingTooFast = false;
//			::Sleep(1);
		}
		if(ulBatch > 14600)
		{
			ulBatch = 14600;
		}
		if(m_pSSL)
		{
			CUQueue &temp = m_pSSL->GetOut();
			while(temp.GetSize() > 1460)
			{
				err = ::send(m_hSocket, (char*)temp.GetBuffer(), temp.GetSize(), 0);
				if(err > 0)
					temp.Pop((unsigned long)err);
				else
					break;
			}
			err = m_pSSL->Encrypt((char*)m_sndQueue.GetBuffer(), ulBatch);
			if(err == 0)
				break;
			m_sndQueue.Pop(ulBatch);
			m_llBytesOut += ulBatch;
			m_dwTimeTrackSnd = ::GetTickCount();
			while(temp.GetSize() > 0)
			{
				err = ::send(m_hSocket, (char*)temp.GetBuffer(), temp.GetSize(), 0);
				if(err > 0)
					temp.Pop((unsigned long)err);
				else
					break;
			}
		}
		else if(g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
		{
			if(ulBatch > m_pSspiServer->GetMaxSize())
				ulBatch = m_pSspiServer->GetMaxSize();
			err = m_pSspiServer->SendData(m_hSocket, m_sndQueue.GetBuffer(), ulBatch);
			if(err == -1)
			{
				err = ::WSAGetLastError();
				if(err == seWouldBlock || err == seNoBufs)
				{
					break;
				}
				else
				{
					m_nRtn = -1;
					UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
					break;
				}
			}
			else
			{
				if(err > 0)
				{
					m_sndQueue.Pop(err);
					m_llBytesOut += (ULONG)err;
					m_dwTimeTrackSnd = ::GetTickCount();
//					ATLTRACE("Data sent = %d, Socket = %d\n", ulBatch, m_hSocket);
				}
				else
				{
					break;
				}
			}
		}
		else
		{
			WSABUF	wsaBuf;
			wsaBuf.buf = (char*)m_sndQueue.GetBuffer();
			wsaBuf.len = ulBatch;
			ulBatch = 0;
			err = ::WSASend(m_hSocket, &wsaBuf, 1, &ulBatch, 0, NULL, NULL); 
			if(err == -1)
			{
				err = ::WSAGetLastError();
				if(err == seWouldBlock || err == seNoBufs)
				{
					break;
				}
				else
				{
					m_nRtn = -1;
					UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
					break;
				}
			}
			else
			{
				if(ulBatch)
				{
					m_sndQueue.Pop(ulBatch);
					m_llBytesOut += ulBatch;
					m_dwTimeTrackSnd = ::GetTickCount();
//					ATLTRACE("Data sent = %d, Socket = %d\n", ulBatch, m_hSocket);
				}
				else
				{
					break;
				}
			}
		}
		ulBatch = m_sndQueue.GetSize();
	}
	m_sndQueue.SetHeadPosition();
	HTTPAutoClose();
}

void CUClient::IOPortSendSSL()
{
	int err;
	unsigned long ulBatch;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_bClosing || m_SndIOContext.m_dwTransfered == NO_DATA_TRANSFERED)
		return;
	m_nRtn = 0;
	ulBatch = m_sndQueue.GetSize();
	while(ulBatch && m_SndIOContext.m_dwTransfered != NO_DATA_TRANSFERED)
	{
		if(ulBatch > UIO_SND_BUFFER_SIZE)
		{
			ulBatch = UIO_SND_BUFFER_SIZE;
		}

		if(ulBatch > m_pSspiServer->GetMaxSize())
		{
			ulBatch = m_pSspiServer->GetMaxSize();
		}

		err = m_pSspiServer->SendDataIOPort(m_hSocket, m_sndQueue.GetBuffer(), ulBatch);
		if(err == -1)
		{
			err = ::WSAGetLastError();
			if(err == seWouldBlock || err == seNoBufs)
			{
				break;
			}
			else if(err != 0)
			{
				m_nRtn = -1;
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
				break;
			}
		}
		else
		{
			if(err > 0)
			{
				m_sndQueue.Pop((ULONG)err);
				m_llBytesOut += err;
				m_dwTimeTrackSnd = ::GetTickCount();
			}
			else
			{
				break;
			}
		}
		ulBatch = m_sndQueue.GetSize();
	}
	m_sndQueue.SetHeadPosition();
}

void CUClient::IOPortRecvSSL()
{
	bool		bWSA = false;
	DWORD		dwFlags;
	DWORD		dwDiff;
	DWORD		dwPrev;
	int			err;
	BYTE		*pBuffer;
	SECURITY_STATUS ss;

	if(m_RcvIOContext.m_dwTransfered == NO_DATA_TRANSFERED)
		return;

	if(m_rcvQueue.GetSize() > m_ulStartBlocking && m_ulSvsID != sidStartup && QueryRequestsInQueue()>1 )
		return;

	g_tempQueue.SetSize(0);
	if(g_tempQueue.GetMaxSize() < UIO_RCV_BUFFER_SIZE)
	{
		g_tempQueue.ReallocBuffer(UIO_RCV_BUFFER_SIZE);
	}

	m_nRtn = 0;
	DWORD dwGet = 0;
	dwPrev = m_rcvQueue.GetSize();
	ss = m_pSspiServer->GetDataIOPort(m_hSocket, m_rcvQueue);
	dwDiff = m_rcvQueue.GetSize() - dwPrev;
	dwGet += dwDiff;
	pBuffer = (BYTE*)g_tempQueue.GetBuffer();
	while(true)
	{
		err = ::recv(m_hSocket, (char*)pBuffer, UIO_RCV_BUFFER_SIZE, 0);
		if(err > 0)
		{
			dwPrev = m_rcvQueue.GetSize();
			m_pSspiServer->m_UQueueRecv.Push(pBuffer, (ULONG)err);
			ss = m_pSspiServer->GetDataIOPort(m_hSocket, m_rcvQueue);
			dwDiff = m_rcvQueue.GetSize() - dwPrev;
			dwGet += dwDiff;
			if(err < UIO_RCV_BUFFER_SIZE || ss != SEC_E_OK)
			{
				bWSA = true;
				break;
			}
		}
		else if(err == -1)
		{
			err = ::WSAGetLastError();
			if(err == WSAEWOULDBLOCK)
			{
				bWSA = true;
			}
			else if(err != 0)
			{
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
			}
			break;
		}
		else
		{
			if(!m_bClosing)
			{
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, 0));
			}
			break;
		}
		if(m_rcvQueue.GetSize() > m_ulStartBlocking && m_ulSvsID != sidStartup && QueryRequestsInQueue() > 1 )
		{
			break;
		}
		if(m_ulSvsID == sidStartup && m_rcvQueue.GetSize() > 50*1460)
			return;
	}

	do
	{
		if(!bWSA)
		{
			break;
		}
		memset(&m_RcvIOContext, 0, sizeof(m_RcvIOContext));
		dwFlags = 0;
		err = ::WSARecv(m_hSocket, &m_RcvIOContext.m_RcvWSABuf, 1, &m_RcvIOContext.m_dwTransfered, &dwFlags, &m_RcvIOContext, NULL);
		if(err == -1)
		{
			err = ::WSAGetLastError();
			switch(err)
			{
			case WSA_IO_PENDING:
				m_RcvIOContext.m_dwTransfered = NO_DATA_TRANSFERED;
				break;
			default:
				if(err != 0)
				{
					m_nRtn = -1;
					UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
				}
				break;
			}
			break;
		}
	}while(false);

	if(dwGet > 0)
	{
		m_llBytesIn += dwGet;
		m_dwTimeTrackRcv = ::GetTickCount();
		m_rcvQueue.SetHeadPosition();	
		CheckCancel();
	}
}

void CUClient::DebugCheck()
{
	if(!m_bRegistered && /*!m_bLocal &&*/(g_ulCallCount%PROMPT_NUM) == (PROMPT_NUM/2) && m_ulSvsID != sidStartup && (m_dwTimeTrackSnd%20000)<4000) 
	{
		::MessageBox(NULL, REG_MESSAGE, _T("SocketPro"), MB_OK);
		::Sleep(200);
	}
}

void CUClient::IOPortRecv()
{
	DWORD	dwFlags;
	int		err;
	BYTE	*pBuffer;
	bool    bWSA = false;

	if(m_RcvIOContext.m_dwTransfered == NO_DATA_TRANSFERED)
		return;

	if(m_rcvQueue.GetSize() > m_ulStartBlocking && m_ulSvsID != sidStartup && QueryRequestsInQueue()>1)
		return;

	g_tempQueue.SetSize(0);
	if(g_tempQueue.GetMaxSize() < UIO_RCV_BUFFER_SIZE)
	{
		g_tempQueue.ReallocBuffer(UIO_RCV_BUFFER_SIZE);
	}

	pBuffer = (BYTE*)g_tempQueue.GetBuffer();
	m_nRtn = 0;
	DWORD dwGet = 0;
	while(true)
	{
		err = ::recv(m_hSocket, (char*)pBuffer, UIO_RCV_BUFFER_SIZE, 0);
		if(err > 0)
		{
			if(m_pSSL != NULL)
			{
				if(!m_pSSL->IsSSLConnected())
				{
					m_tempQueue.SetSize(0);
					m_pSSL->m_hSocket = m_hSocket;
					err = m_pSSL->DoHandshake(pBuffer, err, m_tempQueue);
					if(err > 0)
					{
						err = ::send(m_hSocket, (char*)m_tempQueue.GetBuffer(), m_tempQueue.GetSize(), 0); 
						m_tempQueue.SetSize(0);
					}
					err = 0;
					bWSA = true;
					break;
				}
				else
				{
					if(m_pSSL->GetOut().GetSize() > 0)
						IOPortSend();
					err = m_pSSL->Decrypt(pBuffer, err, m_rcvQueue);
				}
			}
			else
			{
				m_rcvQueue.Push(pBuffer, err);
			}
			dwGet += err;
			m_llBytesIn += err;
			if(err < UIO_RCV_BUFFER_SIZE)
			{
				bWSA = true;
				break;
			}
		}
		else if(err == 0)
		{
			DWORD dwError = ::GetLastError();
			if(!m_bClosing)
			{
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, 0));
			}
			break;
		}
		else if(err == -1)
		{
			err = ::WSAGetLastError();
			if(err == WSAEWOULDBLOCK)
			{
				bWSA = true;
			}
			else if(err != 0)
			{
				ATLTRACE("Error code  = %d\n", err);
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
			}
			break;
		}
		if(m_rcvQueue.GetSize() > m_ulStartBlocking && m_ulSvsID != sidStartup && QueryRequestsInQueue() > 1)
		{
			break;
		}

		if(m_ulSvsID == sidStartup && m_rcvQueue.GetSize() > 50*1460)
			return;
	}

	do
	{
		memset(&m_RcvIOContext, 0, sizeof(m_RcvIOContext));
		if(!bWSA)
		{
			break;
		}
		dwFlags = 0;
		m_RcvIOContext.m_dwTransfered = (NO_DATA_TRANSFERED - 1);
		err = ::WSARecv(m_hSocket, &m_RcvIOContext.m_RcvWSABuf, 1, &m_RcvIOContext.m_dwTransfered, &dwFlags, &m_RcvIOContext, NULL);
		if(err == -1)
		{
			err = ::WSAGetLastError();
			switch(err)
			{
			case WSA_IO_PENDING:
				m_RcvIOContext.m_dwTransfered = NO_DATA_TRANSFERED;
				break;
			default:
				if(err != 0)
				{
					m_nRtn = -1;
					ATLTRACE("Error code  = %d\n", err);
					UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
				}
				break;
			}
			break;
		}
	}
	while(false);

	if(dwGet > 0)
	{
		m_dwTimeTrackRcv = ::GetTickCount();
		m_rcvQueue.SetHeadPosition();	
		CheckCancel();
	}
}

void CUClient::Recv()
{
	int err;
	bool bCheck = false;
//	CAutoLock AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	unsigned long ulBatch = g_tempQueue.GetMaxSize();
	if(ulBatch>40*1460)
		ulBatch = 40*1460;
	void	*pBuffer = (void*)g_tempQueue.GetBuffer();
	m_nRtn = 0;
	do
	{
		if(m_rcvQueue.GetSize() > m_ulStartBlocking && m_ulSvsID != sidStartup && QueryRequestsInQueue() > 1 )
			break;
		if(m_ulSvsID == sidStartup && m_rcvQueue.GetSize() > 50*1460)
			return;
		if(g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
		{
			ULONG ulStart = m_rcvQueue.GetSize();
			err = m_pSspiServer->GetData(m_hSocket, m_rcvQueue, ulBatch);
			ulStart = m_rcvQueue.GetSize() - ulStart;
			if(err != SEC_E_OK)
			{
				m_nRtn = -1;
				err = ::WSAGetLastError();
				if(err != seWouldBlock)
				{
					UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
				}
				err = 0;
			}
			else
			{
				err = ulStart;
				if(err)
				{
					m_llBytesIn += err;
					m_dwTimeTrackRcv = ::GetTickCount();
					bCheck = true;
				}
			}
		}
		else
		{
			err = ::recv(m_hSocket, (char*)pBuffer, ulBatch, 0); 
			if(err == -1)
			{
				err = ::WSAGetLastError();
				if(err == seWouldBlock || err == seNoBufs)
				{
				}
				else
				{
					m_nRtn = -1;
					UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, err));
				}
				err = 0;
				break;
			}
			else
			{
				if(err)
				{
					if(m_pSSL != NULL)
					{
						if(!m_pSSL->IsSSLConnected())
						{
							m_tempQueue.SetSize(0);
							m_pSSL->m_hSocket = m_hSocket;
							err = m_pSSL->DoHandshake(pBuffer, err, m_tempQueue);
							if(err > 0)
							{
								err = ::send(m_hSocket, (char*)m_tempQueue.GetBuffer(), m_tempQueue.GetSize(), 0); 
								m_tempQueue.SetSize(0);
							}
							err = 0;
							break;
						}
						else
						{
							if(m_pSSL->GetOut().GetSize() > 0)
								Send();
							err = m_pSSL->Decrypt(pBuffer, err, m_rcvQueue);
							if(err == 0)
								break;
						}
					}
					else
					{
						m_rcvQueue.Push((BYTE*)pBuffer, err);
					}
					m_llBytesIn += err;
					m_dwTimeTrackRcv = ::GetTickCount();
					bCheck = true;
				}
			}
		}
	}while(err>0);
	m_rcvQueue.SetHeadPosition();	
	if(bCheck)
		CheckCancel();
}

unsigned long CUClient::GetTotalMemory()
{
	unsigned long ulTotal = GetRcvBufferSize();
	ulTotal += GetSndBufferSize();
	ulTotal += m_batchQueue.GetMaxSize();
	ulTotal += m_MySpecificBytes.GetMaxSize();
	ulTotal += sizeof(CUClient);
	return ulTotal;
}

void CUClient::ShrinkMemory()
{
	unsigned long ul;
	unsigned long ulSize;
	unsigned long ulMaxSize;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	ul = 2048;
	ulMaxSize = m_rcvQueue.GetMaxSize();
	if(ulMaxSize > ul)
	{
		ulSize = m_rcvQueue.GetSize();
		ulSize = (ulSize > ul) ? ulSize : ul;
		m_rcvQueue.ReallocBuffer(ulSize);
	}
	//if(g_pSocketSvr->m_bUseMessagePump)
	{
		ulMaxSize = m_sndQueue.GetMaxSize();
		if(ulMaxSize > ul)
		{
			ulSize = m_sndQueue.GetSize();
			ulSize = (ulSize > ul) ? ulSize : ul;
			m_sndQueue.ReallocBuffer(ulSize);
		}
	}
	ulMaxSize = m_batchQueue.GetMaxSize();
	if(ulMaxSize > ul)
	{
		ulSize = m_batchQueue.GetSize();
		ulSize = (ulSize > ul) ? ulSize : ul;
		m_batchQueue.ReallocBuffer(ulSize);
	}
	ulMaxSize = m_MySpecificBytes.GetMaxSize();
	if(ulMaxSize > ul)
	{
		ulSize = m_MySpecificBytes.GetSize();
		ulSize = (ulSize > ul) ? ulSize : ul;
		m_MySpecificBytes.ReallocBuffer(ulSize);
	}
}

bool CUClient::IOCtl(long *plArgment, long lCommand)
{
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	u_long	ulArg = 0;
	unsigned long nArgument = 0;
	if(m_pSSL && lCommand == iocRead)
	{
		nArgument=g_pStartup->SSL_pending(m_pSSL->GetSSL());
	}
	else if(m_pSspiServer && (m_pSspiServer->m_hContext.dwLower != 0 || m_pSspiServer->m_hContext.dwUpper != 0))
	{
		nArgument = m_pSspiServer->m_UQueueRecv.GetSize();
	}
	int err = ::ioctlsocket(m_hSocket, lCommand, &ulArg);
	if(plArgment)
	{
		*plArgment = ulArg + nArgument;
	}
	if(err == -1)
	{
		m_nRtn = ::WSAGetLastError();
	}
	else
	{
		m_nRtn = uecOK;
	}
	return (m_nRtn == uecOK);
}

bool CUClient::IsRegistered()
{
	return m_bRegistered;
}

void CUClient::CloseSocket()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_pSspiServer)
	{
		m_pSspiServer->Close(m_hSocket);
	}
	if(m_pSSL)
	{
		g_pStartup->SSL_set_info_callback(m_pSSL->GetSSL(), NULL);
//		g_pStartup->SSL_shutdown(m_pSSL->GetSSL());
		delete m_pSSL;
		m_pSSL=NULL;
	}
	
	if(m_pBlowFish)
	{
		delete m_pBlowFish;
		m_pBlowFish = NULL;
	}

	CSktBase::CloseSocket();
}

bool CUClient::SetSSL()
{
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	int nRtn;
	if(m_pSSL)
	{
		delete m_pSSL;
		m_pSSL = NULL;
	}
	m_pSSL = new CMyOpenSSL(g_pStartup->m_pCtx, false); 
	if(g_pSocketSvr->m_pCert != NULL && g_pSocketSvr->m_pkey != NULL)
	{
		nRtn = g_pStartup->SSL_use_certificate(m_pSSL->GetSSL(), g_pSocketSvr->m_pCert);
		nRtn = g_pStartup->SSL_use_PrivateKey(m_pSSL->GetSSL(), g_pSocketSvr->m_pkey);
//		nRtn = g_pStartup->SSL_CTX_check_private_key(g_pStartup->m_pCtx);
	}
	g_pStartup->SSL_set_read_ahead(m_pSSL->GetSSL(), 1);
	g_pStartup->SSL_set_info_callback(m_pSSL->GetSSL(), SSLCallback);
	return true;
}

bool CUClient::GetSockAddr(unsigned int &nSocketPort, LPSTR& strIPAddress)
{
	nSocketPort = 0;
	strIPAddress = NULL;
	SOCKADDR_IN sockAddr;
	int nSockAddrLen = sizeof(sockAddr);
	if(CUListener::m_suAddr.GetSize())
		m_nRtn = CUListener::GetSockName(m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	else
		m_nRtn = ::getsockname(m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	if (m_nRtn == -1)
	{
		return false;
	}
	else
	{
		nSocketPort = ::ntohs(sockAddr.sin_port);
		strIPAddress = ::inet_ntoa(sockAddr.sin_addr);
	}
	return true;
}

bool CUClient::GetPeerName(unsigned int &nPeerPort, LPSTR& strPeerName)
{
	nPeerPort = 0;
	strPeerName = NULL;
	SOCKADDR_IN sockAddr;
	int nSockAddrLen = sizeof(sockAddr);
	if(CUListener::m_suAddr.GetSize())
		m_nRtn = CUListener::GetPeerName(m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	else
		m_nRtn = ::getpeername(m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	if (m_nRtn == -1)
	{
		return false;
	}
	else
	{
		nPeerPort = ::ntohs(sockAddr.sin_port);
		strPeerName = ::inet_ntoa(sockAddr.sin_addr);
	}
	return true;
}

bool CUClient::GetInterfaceAttributes(unsigned long& ulMTU, unsigned long& ulMaxSpeed, unsigned long& ulType, unsigned long &ulMask)
{
	DWORD dwRtn;
	DWORD ulSize;
	PMIB_IFTABLE		pIfT;
	PMIB_IPADDRTABLE	pIAddrT;
	SOCKADDR_IN			sockAddr;
	ulMTU = 0;
	ulMaxSpeed = 0;
	ulType = 0;
	ulMask = 0;

	CScopeUQueue su0, su1;
	int err;
	int nSockAddrLen = sizeof(sockAddr);
	if(CUListener::m_suAddr.GetSize())
		err = CUListener::GetSockName(m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	else
		err = ::getsockname(m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	if (err == -1)
	{
		m_nRtn = err;
		return false;
	}

	DWORD dwSize = su0->GetMaxSize();
	pIfT = (MIB_IFTABLE*)su0->GetBuffer(); //(MIB_IFTABLE*)::malloc(sizeof(MIB_IFTABLE));
	if (::GetIfTable(pIfT, &dwSize, 0) == ERROR_INSUFFICIENT_BUFFER) {
		su0->ReallocBuffer(dwSize + 1024);
		pIfT = (MIB_IFTABLE *)su0->GetBuffer();
	}
	dwRtn = GetIfTable(pIfT, &dwSize, 0);
	pIAddrT = (PMIB_IPADDRTABLE)su1->GetBuffer(); //(PMIB_IPADDRTABLE)::malloc(sizeof(MIB_IPADDRTABLE));
	dwSize = su1->GetMaxSize();
	if (::GetIpAddrTable(pIAddrT, &dwSize, 0) == ERROR_INSUFFICIENT_BUFFER) {
		su1->ReallocBuffer(dwSize + 1024);
		pIAddrT = pIAddrT = (PMIB_IPADDRTABLE)su1->GetBuffer();
	}
	dwRtn = ::GetIpAddrTable(pIAddrT, &dwSize, 0);
	for(ulSize = 0; ulSize<pIAddrT->dwNumEntries; ulSize++)
	{
		if(sockAddr.sin_addr.S_un.S_addr == pIAddrT->table[ulSize].dwAddr)
		{
			ulMTU = pIfT->table[ulSize].dwMtu;
			ulMaxSpeed = pIfT->table[ulSize].dwSpeed;
			ulType = pIfT->table[ulSize].dwType;
			ulMask = pIAddrT->table[ulSize].dwMask;
			break;
		}
	}
	//::free(pIAddrT);
	//::free(pIfT);
	return true;
}

bool CUClient::GetSockOpt(int nOptName, int *pnOptVal, int nLevel)
{
	int nLen = sizeof(int);
	m_nRtn = ::getsockopt(m_hSocket, nLevel, nOptName, (char*)pnOptVal, &nLen);
	if(m_nRtn == SOCKET_ERROR)
		return false;
	return true;
}

bool CUClient::SetSockOpt(int nOptName, int nOptVal, int nLevel)
{
	m_nRtn = ::setsockopt(m_hSocket, nLevel, nOptName, (char*)&nOptVal, sizeof(int));
	if(m_nRtn == SOCKET_ERROR)
		return false;
	return true;
}

void CUClient::Register(BYTE *pbLock, BYTE *pbKey)
{
	if(!m_bRegistered)
	{
		long plPrivateKeys[2];
		BYTE strOutLock[9]={0};
		plPrivateKeys[0] = SKEY1;
		plPrivateKeys[1] = (SKEY2 + 1);
		CBlowFish	BlowFish((unsigned char*)plPrivateKeys, sizeof(plPrivateKeys));
		
/*		{
			BYTE pbData[8] = {8, 7, 6, 5, 5, 6, 7, 8};
			BlowFish.Encrypt(pbData, strOutLock, 8);
		}*/

		BlowFish.Decrypt(pbLock, strOutLock, 8);
		if(memcmp(strOutLock, pbKey, 8)==0)
			m_bRegistered = true;
	}
}

bool CUClient::IsBatching()
{
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	return m_bBatching;
}

unsigned long CUClient::GetRecvBuffer(unsigned char *pBuffer, unsigned long ulBufferSize)
{
	unsigned long ulGet = 0;
	if(pBuffer && ulBufferSize)
	{
//		CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
		if(ulBufferSize>m_StreamHeader.m_ulLen)
			ulBufferSize = m_StreamHeader.m_ulLen;
		if(ulBufferSize == 0 || pBuffer==NULL)
			return 0;
		ATLASSERT(ulBufferSize <= m_rcvQueue.GetSize());
		if(m_StreamHeader.m_nRequestID == idSwitchTo)
		{
			BYTE *pHead = (BYTE*)m_rcvQueue.GetBuffer();
			ulGet = m_rcvQueue.Pop((BYTE*)pBuffer, ulBufferSize);
			::memset(pHead, 0, ulBufferSize);
		}
		else
		{
			ulGet = m_rcvQueue.Pop((BYTE*)pBuffer, ulBufferSize);
		}
		ATLASSERT(ulGet == ulBufferSize);
		m_StreamHeader.m_ulLen -= ulGet; 
		if(g_pSocketSvr->GetMainThreadID() == ::GetCurrentThreadId())
		{
			if(m_StreamHeader.m_ulLen==0)
			{
				ATLASSERT(m_StreamHeader.m_bRatio == 0);
				ATLASSERT(m_StreamHeader.m_bTreat == 0);
				ATLASSERT(m_StreamHeader.m_nRequestID);
				m_StreamHeader.m_nRequestID = 0;
			}
		}
	}
	return ulGet;
}

void CUClient::ResetBytesIn(unsigned long ulStart, unsigned long *pulHigh)
{
	if(pulHigh)
	{
		m_llBytesIn = *pulHigh;
		m_llBytesIn = (m_llBytesIn << 32);
	}
	m_llBytesIn += ulStart;
}

void CUClient::ResetBytesOut(unsigned long ulStart, unsigned long *pulHigh)
{
	if(pulHigh)
	{
		m_llBytesOut = *pulHigh;
		m_llBytesOut = (m_llBytesOut << 32);
	}
	m_llBytesOut += ulStart;
}

unsigned long CUClient::GetSndBytesInQueue()
{
	ULONG ulSize = m_sndQueue.GetSize();
	if(m_pSspiServer)
	{
		ulSize += m_pSspiServer->GetDataInBuffer();
	}

	if(m_pSSL)
	{
		ulSize += m_pSSL->GetOut().GetSize();
	}
	return ulSize;
}

unsigned long CUClient::GetRcvBytesInQueue()
{
	return m_rcvQueue.GetSize();
}

unsigned long	CUClient::GetBytesIn(unsigned long *pulHigh)
{
	if(pulHigh)
		*pulHigh = (unsigned long)(m_llBytesIn >> 32);
	return (unsigned long)m_llBytesIn;
}

void CUClient::OnContinueProcessing(unsigned short usRequestID)
{
	OnRequestProcessed(usRequestID);
}

void CUClient::OnBaseRequestCame(unsigned short usRequestID)
{
	if(m_OnBaseRequestCame)
	{
		ULONG ulCount = RemoveLock();
		m_OnBaseRequestCame(m_hSocket, usRequestID);
		Relock(ulCount);
	}
}

const unsigned char* CUClient::GetMySpecificBytes(unsigned long& ulLen)
{
	ulLen = m_MySpecificBytes.GetSize();
	if(ulLen)
		return m_MySpecificBytes.GetBuffer();
	return NULL;
}

unsigned long	CUClient::GetBytesOut(unsigned long *pulHigh)
{
	if(pulHigh)
		*pulHigh = (unsigned long)(m_llBytesOut >> 32);
	return (unsigned long)m_llBytesOut;
}

unsigned short CUClient::GetCurrentRequestId()
{
	return m_StreamHeader.m_nRequestID;
}

unsigned long CUClient::GetCurrentRequestLen()
{
	return m_StreamHeader.m_ulLen;
}

unsigned long CUClient::GetSvsID()
{
	return m_ulSvsID;
}


void CUClient::ZeroTrack()
{
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	m_sndQueue.CleanTrack();
	m_rcvQueue.CleanTrack();
	m_batchQueue.CleanTrack();
	g_chatQueue.CleanTrack();
	g_tempQueue.CleanTrack();
	g_tempQueueSnd.CleanTrack();
}


bool CUClient::startBatching()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_HttpReqAttribute.m_HttpRequest != hrUnknown) return false;
	if(m_bBatching)
	{
		m_bBatching = false;
		if(m_batchQueue.GetSize() > 5*1460)
		{
			ATLASSERT(m_batchQueue.GetSize()>= sizeof(CStreamHeader));
			if(m_bZip && m_batchQueue.GetSize() > (unsigned long)((m_ZipLevel == zlBestSpeed) ? 260 : 16))
				sendReturnData(idBatchZipped, m_batchQueue.GetSize(), m_batchQueue.GetBuffer());
			else
			{
				m_sndQueue.Push(m_batchQueue.GetBuffer(), m_batchQueue.GetSize());
				Send();
			}
			m_batchQueue.SetSize(0);
		}
	}
	m_bBatching = true;
	return true;
}

bool CUClient::commitBatching()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_HttpReqAttribute.m_HttpRequest != hrUnknown) return false;
	if(!m_bBatching)
		return false;
	m_bBatching = false;
	if(m_batchQueue.GetSize())
	{
		ATLASSERT(m_batchQueue.GetSize()>=sizeof(CStreamHeader));
		if(m_bZip && m_batchQueue.GetSize() > (unsigned long)((m_ZipLevel == zlBestSpeed) ? 260 : 16))
			sendReturnData(idBatchZipped, m_batchQueue.GetSize(), m_batchQueue.GetBuffer());
		else
		{
			if(m_EncryptionMethod == BlowFish && m_pBlowFish != NULL)
			{
				sendReturnData(idEncrypted, m_batchQueue.GetSize(), m_batchQueue.GetBuffer());
			}
			else
			{
				m_sndQueue.Push(m_batchQueue.GetBuffer(), m_batchQueue.GetSize());
				Send();
			}
		}
		m_batchQueue.SetSize(0);
	}
	m_StreamHeader.m_nRequestID = 0;
	return true;
}

unsigned long CUClient::PeekRcvMemory(unsigned char *pBuffer, unsigned long ulBufferSize)
{
	if(pBuffer==NULL || ulBufferSize==0)
		return 0;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(ulBufferSize > m_rcvQueue.GetSize())
		ulBufferSize = m_rcvQueue.GetSize();
	if(ulBufferSize)
		memcpy(pBuffer, m_rcvQueue.GetBuffer(), ulBufferSize);
	return ulBufferSize;
}

bool CUClient::abortBatching()
{
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_HttpReqAttribute.m_HttpRequest != hrUnknown) return false;
	m_batchQueue.Empty();
	m_bBatching = false;
	return true;
}

void CUClient::FakeSwitchToHttp(unsigned long ulSvsID)
{
	m_ClientInfo.m_ulSvsID = ulSvsID;
	m_ClientInfo.m_ulParam2 = 1; //1 web, 2, Unix, 4, other
	m_ClientInfo.m_usUSockMinor = 3;
}

void CUClient::SetHTTPResponseCode(unsigned int nHTTPResponseCode)
{
	if(m_HttpReqAttribute.m_HttpRequest == hrUnknown)
		return;
	m_HttpReqAttribute.m_nResponseCode = nHTTPResponseCode;
}

void CUClient::RemoveHTTPResponseHeader(const char *strUTF8Header)
{
	char *strHead = (char*)m_batchQueue.GetBuffer();
	char *str = ::StrStrI(strHead, strUTF8Header);
	if(str != NULL && memcmp(str + strlen(strUTF8Header), ": ", 2) == 0)
	{
		unsigned long pos = str - strHead;
		char *strEnd = ::strstr(str, "\r\n");
		if(strEnd)
			m_batchQueue.Pop(2 + (strEnd - str), pos);
		else
			m_batchQueue.Pop((unsigned long)strlen(str), pos);
		m_batchQueue.SetHeadPosition();
		char cEnd = 0;
		m_batchQueue.Push(&cEnd, 1);
		m_batchQueue.SetSize(m_batchQueue.GetSize() - 1);
	}
}

char* CUClient::GetBoundary(unsigned long &ulLen)
{
	ulLen = 0;
	char *strB = NULL;
	bool bQ = false;
	do
	{
		char *strHead = ::StrStrI((char*)m_batchQueue.GetBuffer(), "Content-Type: multipart/");
		if(strHead == NULL)
			break;
		strHead += 24;
		
		strHead = ::strstr(strHead, "boundary=");
		if(strHead == NULL)
			break;
		strHead += 9;

		bQ = (*strHead == '"');
		char *strEnd;
		if(bQ)
		{
			strHead += 1;
			strEnd = ::strstr(strHead, "\"");
		}
		else
		{
			strEnd = ::strstr(strHead, ";");
			if(strEnd == NULL)
				strEnd = ::strstr(strHead, "\r\n");
		}
		if(!strEnd)
			break;
		strB = strHead;
		ulLen = strEnd - strHead;
	}while(false);
	return strB;
}

bool CUClient::SetHTTPResponseHeader(const char *strUTF8Header, const char *strUTF8Value)
{
	if(m_HttpReqAttribute.m_HttpRequest == hrUnknown || !strUTF8Header || strlen(strUTF8Header) == 0)
		return false;
	
	if(::strstr(strUTF8Header, ":") != NULL)
		return false;

	if(	_stricmp(strUTF8Header, "Date") == 0 ||
		_stricmp(strUTF8Header, "Server") == 0 /*||
		_stricmp(strUTF8Header, "Content-Length") == 0*/)
		return false;

	RemoveHTTPResponseHeader(strUTF8Header);

	m_batchQueue.Push(strUTF8Header);
	m_batchQueue.Push(": ");
	m_batchQueue.Push(strUTF8Value);
	m_batchQueue.Push("\r\n");
	
	unsigned long ulLen;
	if(GetBoundary(ulLen) != NULL && ulLen > 0)
		sendReturnData(idGet, 0, NULL);
	return true;
}

bool CUClient::HandleHeader()
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_StreamHeader.m_nRequestID == 0 && m_rcvQueue.GetSize()>=sizeof(m_StreamHeader))
	{
		if(m_rcvQueue.GetSize() > 17 && (m_ulSvsID == sidStartup || (m_ulSvsID == sidHTTP && m_HttpReqAttribute.m_bHeaderSent)))
		{
			char *str = (char*)m_rcvQueue.GetBuffer();
			if(memcmp(str, "GET ", 4) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrGet;
			}
			else if(memcmp(str, "POST ", 5) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrPost;
			}
			else if(memcmp(str, "PUT ", 4) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrPut;
			}
			else if(memcmp(str, "DELETE ", 7) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrDelete;
			}
			else if(memcmp(str, "HEAD ", 5) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrHead;
			}
			else if(memcmp(str, "OPTIONS ", 8) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrOptions;
			}
			else if(memcmp(str, "TRACE ", 6) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrTrace;
			}
			else if(memcmp(str, "CONNECT ", 8) == 0)
			{
				m_HttpReqAttribute.m_HttpRequest = hrConnect;
			}
		
			if(m_HttpReqAttribute.m_HttpRequest != hrUnknown)
			{
				if(::strstr(str, "\r\n\r\n") == NULL)
					return false;
				char *strHTTP = ::strstr(str, " HTTP/");
				if(!strHTTP)
				{
					m_HttpReqAttribute.m_bResponseChunked = false;
					m_HttpReqAttribute.m_nResponseCode = 501;
					m_HttpReqAttribute.m_bKeepAlive = false;
					m_HttpReqAttribute.m_nKeepAlive = 0;
					sendReturnData(idGet, 0, NULL);
					m_bProcessingSlowRequest = true;
					PostClose(m_hSocket, ERROR_BAD_HTTP_REQUEST);
					return false;
				}
				m_HttpReqAttribute.m_dHttpVersion = atof(strHTTP + 6);
				if(m_HttpReqAttribute.m_dHttpVersion < 1.0 || m_HttpReqAttribute.m_dHttpVersion > 1.2)
				{
					m_HttpReqAttribute.m_bResponseChunked = false;
					m_HttpReqAttribute.m_nResponseCode = 406;
					m_HttpReqAttribute.m_bKeepAlive = false;
					m_HttpReqAttribute.m_nKeepAlive = 0;
					sendReturnData(idGet, 0, NULL);
					m_bProcessingSlowRequest = true;
					PostClose(m_hSocket, ERROR_BAD_HTTP_REQUEST);
					return false;
				}

				m_HttpReqAttribute.m_nKeepAlive = 0;

				if(m_HttpReqAttribute.m_dHttpVersion >= 1.1)
					m_HttpReqAttribute.m_bKeepAlive = true;
				else
					m_HttpReqAttribute.m_bKeepAlive = false;

				char *strConnection = ::StrStrI(strHTTP, "Connection: ");
				if(strConnection)
				{
					char *strEnd = ::strstr(strConnection, "\r\n");
					strConnection += 12; //"Connection: "
					char *strClose = ::strstr(strConnection, "close");
					if(strClose && strClose < strEnd)
						m_HttpReqAttribute.m_bKeepAlive = false;
				}
				char *strKA = ::StrStrI(strHTTP, "Keep-Alive: ");
				if(strKA)
				{
					char *strEnd = ::strstr(strKA, "\r\n");
					strKA += 12; //"Keep-Alive: "
					m_HttpReqAttribute.m_nKeepAlive = atoi(strKA);
				}

				m_HttpReqAttribute.m_bRequestChunked = false;
				char *strTE = ::StrStrI(strHTTP, "Transfer-Encoding: ");
				if(strTE)
				{
					char *strEnd = ::strstr(strTE, "\r\n");
					char *strChunk = ::strstr(strTE, "chunked");
					if(strChunk && strChunk < strEnd)
						m_HttpReqAttribute.m_bRequestChunked = true;
				}

				m_bZip = false;
				if(m_EncryptionMethod == BlowFish)
					m_EncryptionMethod = NoEncryption;

				m_HttpReqAttribute.m_bHeaderSent = false;
				switch(m_HttpReqAttribute.m_HttpRequest)
				{
				case hrPost:
				case hrGet:
				case hrHead:
				case hrTrace:
				case hrOptions:
				case hrDelete:
				case hrPut:
				case hrConnect:
					m_HttpReqAttribute.m_nResponseLength = 0;
					m_HttpReqAttribute.m_nSeeked = 0;
					m_HttpReqAttribute.m_nResponseCode = 200;
					m_StreamHeader.m_bRatio = 0;
					m_StreamHeader.m_bTreat = 0;
					if(m_ulSvsID == sidStartup)
					{
						m_StreamHeader.m_nRequestID = idSwitchTo;
						m_StreamHeader.m_ulLen = 0;
					}
					if(m_HttpReqAttribute.m_bRequestChunked)
					{
						m_HttpReqAttribute.m_bResponseChunked = false;
						m_HttpReqAttribute.m_nResponseCode = 501;
						m_HttpReqAttribute.m_bKeepAlive = false;
						m_HttpReqAttribute.m_nKeepAlive = 0;
						sendReturnData(idGet, 0, NULL);
						m_bProcessingSlowRequest = true;
						PostClose(m_hSocket, ERROR_BAD_HTTP_REQUEST);
						return false;
					}
					else
					{
						ProcessHTTPRequest();
						return true;
					}
					break;
				default:
					break;
				}
			}
		}

		m_rcvQueue.Pop(&m_StreamHeader);
	
		if(m_bSameEndian && (m_StreamHeader.m_nRequestID == idReservedOne))
		{
			m_bSameEndian = false;
		}
		if(!m_bSameEndian)
		{
			m_StreamHeader.m_nRequestID = ::htons(m_StreamHeader.m_nRequestID);
			m_StreamHeader.m_ulLen = ::htonl(m_StreamHeader.m_ulLen);
		}
		if(GetSvsID() == sidStartup)
		{
			if(m_StreamHeader.m_ulLen > 2*1460)
			{
				OnClose(uecUnexpected);
				g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
				return false;
			}
		}
		if(m_StreamHeader.m_nRequestID == 0)
		{
			OnClose(uecUnexpected);
			g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
			return false;
		}
		
		if(g_pSocketSvr->m_EncryptionMethod == BlowFish && !m_bVerify 
			&& m_StreamHeader.m_nRequestID != idEncrypted && GetSvsID() != sidStartup && 
			m_StreamHeader.m_nRequestID != idVerifySalt && m_StreamHeader.m_ulLen > 14600 )
		{
			OnClose(ERROR_VERIFY_SALT);
			g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
			return false;
		}

		if(m_StreamHeader.m_ulLen > m_rcvQueue.GetMaxSize())
		{
/*			if(m_StreamHeader.m_ulLen > 100*1024)
			{
				TCHAR str[512] = {0};
				::_stprintf(str, _T("Header Length = %d!"), m_StreamHeader.m_ulLen);
				::MessageBox(NULL, str, _T("USocketPro Debug"), MB_OK);
			}*/
//			ATLASSERT(m_StreamHeader.m_ulLen < 20*1024);

			if(m_HttpReqAttribute.m_qRMult.GetSize() > 0 && m_HttpReqAttribute.m_bAutoPartition)
			{
				if(m_rcvQueue.GetMaxSize() < m_HttpReqAttribute.m_nMaxMessageSize + 1460*100)
					m_rcvQueue.ReallocBuffer(m_HttpReqAttribute.m_nMaxMessageSize + 1460*100);
			}
			else
			{
				m_rcvQueue.ReallocBuffer(m_StreamHeader.m_ulLen + 1460);
				ATLTRACE("Recv Queue Size Changed = %d\n", m_rcvQueue.GetMaxSize());
			}
		}
		return true;
	}
	return true;
}

bool CUClient::HandleEncryption()
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_StreamHeader.m_nRequestID == idEncrypted)
	{
		unsigned long ulLen;
		unsigned long ulP;
		if(m_bKeyLen <= 1 || m_bKeyLen>56 || m_pBlowFish == NULL)
		{
			OnClose(uecUnexpected);
			g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
			return false;
		}
		ulLen = m_StreamHeader.m_ulLen;
		unsigned long ulPos = 0;
/*		if(!m_pBlowFish)
		{
			m_pBlowFish= new CBlowFish(m_strKey, m_bKeyLen);
		}*/
		ATLASSERT((ulLen%8)==0);
		m_pBlowFish->Decrypt((BYTE*)m_rcvQueue.GetBuffer(), ulLen);
		while(ulPos<(ulLen-7))
		{
			CStreamHeader *pHeader = (CStreamHeader *)(m_rcvQueue.GetBuffer() + ulPos);
			if((pHeader->m_bTreat & 0x7A) != 0)
			{
				OnClose(uecFailedInDecrypt);
				g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
				return false;
			}
			if((pHeader->m_bTreat & odZipped) == 0 && pHeader->m_bTreat != 0)
			{
				OnClose(uecFailedInDecrypt);
				g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
				return false;
			}
			ulPos += (sizeof(CStreamHeader) + pHeader->m_ulLen);
		}
		ulP = ulLen - ulPos;
		if(ulP >= 8)
		{
			OnClose(uecFailedInDecrypt);
			g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
			return false;
		}
		m_rcvQueue.Pop(ulP, ulPos);
		if(m_rcvQueue.GetSize()<sizeof(CStreamHeader) || 
			m_rcvQueue.GetSize()<((CStreamHeader*)m_rcvQueue.GetBuffer())->m_ulLen)
		{
			ATLASSERT(FALSE);
		}
		m_rcvQueue.Pop(&m_StreamHeader);
		if(!m_bSameEndian)
		{
			m_StreamHeader.m_nRequestID = ::htons(m_StreamHeader.m_nRequestID);
			m_StreamHeader.m_ulLen = ::htonl(m_StreamHeader.m_ulLen);
		}
	}
	return true;
}

bool CUClient::HandleUnzip()
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if((m_StreamHeader.m_bTreat & odZipped) == odZipped || (m_StreamHeader.m_bTreat & odFastZip) == odFastZip)
	{
		g_tempQueue.SetSize(0);
		tagZipLevel	zl;
		if((m_StreamHeader.m_bTreat & odFastZip) == odFastZip && (m_StreamHeader.m_bTreat & odZipped) == odZipped)
		{
			zl = zlBestSpeed;
		}
		else if((m_StreamHeader.m_bTreat & odFastZip))
		{
			zl = zlBestCompression;
		}
		else
		{
			zl = zlDefault;
		}
		unsigned short nRatio = (m_StreamHeader.m_bTreat & 0x3F) * 256 + m_StreamHeader.m_bRatio;
		unsigned long  ulLenZ = (ULONG)(nRatio * m_StreamHeader.m_ulLen * 1.1 + 15);
		if(GetSvsID() == sidStartup)
		{
			if(ulLenZ>2*1460)
			{
				OnClose(uecUnexpected);
				g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
				return false;
			}
		}
		if(ulLenZ>g_tempQueue.GetMaxSize())
		{
			g_tempQueue.ReallocBuffer(ulLenZ);
			g_pSocketSvr->m_dwTick = ::GetTickCount();
		}
		g_pStartup->m_UZip.m_ZipLevel = zl;
		if(!g_pStartup->m_UZip.Decompress((void*)m_rcvQueue.GetBuffer(), m_StreamHeader.m_ulLen, (BYTE*)g_tempQueue.GetBuffer(), ulLenZ))
		{
/*			char strMessage[256] = {0};
			sprintf(strMessage, "%s, ulLen = %d, m_StreamHeader.m_ulLen = %d, m_rcvQueue.GetSize() = %d", zError(err), ulLenZ, m_StreamHeader.m_ulLen, m_rcvQueue.GetSize());
			::MessageBox(NULL, strMessage, "Error in unzipping", MB_OK);*/
			OnClose(uecFailedInUnzip);
			g_pSocketSvr->m_aPool.Add((CUClientThreaded*)this);
			return false;
		}
		g_tempQueue.SetSize(ulLenZ);
		m_rcvQueue.Pop(m_StreamHeader.m_ulLen);
		m_rcvQueue.Insert(g_tempQueue.GetBuffer(), ulLenZ);
		if(g_tempQueue.GetMaxSize() > 14600)
			g_pSocketSvr->m_dwTick = ::GetTickCount();
		g_tempQueue.SetSize(0);
		if(m_StreamHeader.m_nRequestID == idBatchZipped)
		{
			ATLASSERT(ulLenZ >= sizeof(m_StreamHeader));
			m_rcvQueue.Pop(&m_StreamHeader);
			if(!m_bSameEndian)
			{
				m_StreamHeader.m_nRequestID = ::htons(m_StreamHeader.m_nRequestID);
				m_StreamHeader.m_ulLen = ::htonl(m_StreamHeader.m_ulLen);
			}
			ATLASSERT(m_rcvQueue.GetSize()>=m_StreamHeader.m_ulLen);
			ATLASSERT(m_StreamHeader.m_bRatio == 0);
			ATLASSERT(m_StreamHeader.m_bTreat == 0);
			CheckCancel();
			if(m_StreamHeader.m_ulLen > m_rcvQueue.GetSize())
			{
				ATLASSERT(FALSE);
			}
		}
		else
		{
			m_StreamHeader.m_bRatio = 0;
			m_StreamHeader.m_bTreat = 0;
			m_StreamHeader.m_ulLen = ulLenZ;
		}
	}
	return true;
}

void CUClient::HandleRequest()
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	unsigned short usRID = m_StreamHeader.m_nRequestID;
	switch (usRID)
	{
	case idSwitchTo:
		{
			if(m_StreamHeader.m_ulLen >= (sizeof(CSwitchInfo)+2*sizeof(unsigned short)))
				OnRequestArrive(usRID, m_StreamHeader.m_ulLen);
		}
		break;
	case idCleanTrack:
		{
			ZeroTrack();
			OnBaseRequestCame(usRID);
			sendReturnData(idCleanTrack, 0, NULL);
		}
		break;
	case idSendMySpecificBytes:
		{
			m_MySpecificBytes.SetSize(0);
			if(m_StreamHeader.m_ulLen)
			{
				if(m_StreamHeader.m_ulLen > m_MySpecificBytes.GetMaxSize())
				{
					m_MySpecificBytes.ReallocBuffer(m_StreamHeader.m_ulLen);
				}
				m_rcvQueue.Pop(m_MySpecificBytes.GetBuffer(), m_StreamHeader.m_ulLen);
				m_MySpecificBytes.SetSize(m_StreamHeader.m_ulLen);
				m_StreamHeader.m_ulLen = 0;
				m_StreamHeader.m_nRequestID = 0;
			}
			OnBaseRequestCame(usRID);
			sendReturnData(idSendMySpecificBytes, 0, NULL);
		}
		break;
	case idGetSockOptAtSvr:
		{
			long	lOptName;
			long	lLevel;
			int		nOptVal;
			HRESULT hr;
			ATLASSERT(m_StreamHeader.m_ulLen == 2*sizeof(long));
			m_StreamHeader.m_ulLen -= m_rcvQueue.Pop(&lOptName);
			m_StreamHeader.m_ulLen -= m_rcvQueue.Pop(&lLevel);
			if(!m_bSameEndian)
			{
				lOptName = ::htonl(lOptName);
				lLevel = ::htonl(lLevel);
			}
			if(GetSockOpt(lOptName, &nOptVal, lLevel))
			{
				hr = uecOK;
				lOptName = nOptVal;
//				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				g_tempQueue.SetSize(0);
				g_tempQueue.Push(&hr);
				g_tempQueue.Push(&lOptName);
				OnBaseRequestCame(usRID);
				sendReturnData(usRID, g_tempQueue.GetSize(), g_tempQueue.GetBuffer());
			}
			else
			{
				HRESULT hr = GetLastError();
				OnBaseRequestCame(usRID);
				sendReturnData(usRID, sizeof(HRESULT), (BYTE*)&hr);
			}
		}
		break;
	case idSetSockOptAtSvr:
		{
			long lOptName;
			long lOptValue;
			long lLevel;
			HRESULT hr;
			ATLASSERT(m_StreamHeader.m_ulLen == 3*sizeof(long));
			m_StreamHeader.m_ulLen -= m_rcvQueue.Pop(&lOptName);
			m_StreamHeader.m_ulLen -= m_rcvQueue.Pop(&lOptValue);
			m_StreamHeader.m_ulLen -= m_rcvQueue.Pop(&lLevel);
			if(!m_bSameEndian)
			{
				lOptName = ::htonl(lOptName);
				lOptValue = ::htonl(lOptValue);
				lLevel = ::htonl(lLevel);
			}
			if(SetSockOpt(lOptName, lOptValue, lLevel))
			{
				hr = uecOK;
			}
			else
			{
				hr = GetLastError();
			}
			OnBaseRequestCame(usRID);
			sendReturnData(usRID, sizeof(hr), (BYTE*)&hr);
		}
		break;
	case idSendingTooFast:
		{
			m_bSendingTooFast = true;
			OnBaseRequestCame(usRID);
			ATLTRACE("Sending too fast!\n");
		}
		break;
	case idDoEcho:
		{
			OnBaseRequestCame(usRID);
			sendReturnData(usRID, 0, NULL);
		}
		break;
	case idTurnOnZipAtSvr:
		{
			ATLASSERT(m_StreamHeader.m_ulLen == sizeof(m_bZip));
			m_StreamHeader.m_ulLen -= m_rcvQueue.Pop(&m_bZip);
			sendReturnData(usRID, sizeof(m_bZip), (BYTE*)&m_bZip);
		}
		OnBaseRequestCame(usRID);
		break;
	case idSetZipLevelAtSvr:
		{
			int nZipLevel;
			ATLASSERT(m_StreamHeader.m_ulLen == sizeof(nZipLevel));	
			m_StreamHeader.m_ulLen -= m_rcvQueue.Pop(&nZipLevel);
			sendReturnData(usRID, sizeof(nZipLevel), (BYTE*)&nZipLevel);
			m_ZipLevel = (tagZipLevel)nZipLevel;
		}
		OnBaseRequestCame(usRID);
		break;
	case idCancel:
		{
//			ATLASSERT(FALSE);
		}
		break;
	case idStartBatching:
		{
			ATLASSERT(m_StreamHeader.m_ulLen==0);
//			ATLASSERT(!m_bBatching);
			if(m_bBatching)
				commitBatching();
			m_bBatching = true;
			m_StreamHeader.m_nRequestID = 0;
			OnBaseRequestCame(usRID);
		}
		break;
	case idCommitBatching:
		{
			ATLASSERT(m_StreamHeader.m_ulLen==0);
			m_bBatching = false;
			if(m_batchQueue.GetSize())
			{
				ATLASSERT(m_batchQueue.GetSize()>=sizeof(CStreamHeader));
				if(m_bZip && m_batchQueue.GetSize() > (unsigned long)((m_ZipLevel == zlBestSpeed) ? 260 : 16))
					sendReturnData(idBatchZipped, m_batchQueue.GetSize(), m_batchQueue.GetBuffer());
				else
				{
					if(m_EncryptionMethod == BlowFish && m_pBlowFish != NULL)
					{
						sendReturnData(idEncrypted, m_batchQueue.GetSize(), m_batchQueue.GetBuffer());
					}
					else
					{
						m_sndQueue.Push(m_batchQueue.GetBuffer(), m_batchQueue.GetSize());
						Send();
					}
				}
				m_batchQueue.SetSize(0);
			}
			m_StreamHeader.m_nRequestID = 0;
		}
		OnBaseRequestCame(usRID);
		break;
	case idShrinkMemoryAtSvr:
		{
			ATLASSERT(m_StreamHeader.m_ulLen==0);
			ShrinkMemory();
			OnBaseRequestCame(usRID);
			sendReturnData(usRID, 0, NULL);
		}
		break;
	case idStartJob:
	case idEndJob:
		{
//			OnBaseRequestCame(usRID);
			sendReturnData(usRID, 0, NULL);
		}
//		break; //still treat it as regular requests
	default:
		{
			OnRequestArrive(usRID, m_StreamHeader.m_ulLen);
		}
		break;
	}
}

void CUClient::HandleTooFast()
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(QueryRequestsInQueue()>256)
	{
		ATLASSERT(FALSE);
		CStreamHeader	StreamHeader;
		StreamHeader.m_bRatio = 0;
		StreamHeader.m_bTreat = 0;
		StreamHeader.m_ulLen = 0;
		StreamHeader.m_nRequestID = idSendingTooFast;
		m_sndQueue.Push(&StreamHeader);
		Send();
	}
}

void CUListener::RemoveAllDlls()
{
	CAutoLock AutoLock(&m_csLock);
	while(m_aLibrary.GetSize())
	{
		RemoveADll(m_aLibrary[0]);
	}	
}

bool CUClientThreaded::DoSSPI()
{
	bool bOk = false;
	do
	{
		wchar_t *strUID;
		unsigned long ulLen;
		if(m_strPassword == NULL)
			break;
		ulLen = ::wcslen(m_strPassword);
		if(ulLen == 0)
			break;

		CComBSTR bstrDomain(L"");
		if(m_strUID == NULL)
			break;
		ulLen = ::wcslen(m_strUID);
		if(ulLen == 0)
			break;
		wchar_t *pSlash = ::wcschr(m_strUID, L'\\');
		if(pSlash == NULL)
		{
			strUID = m_strUID;
		}
		else
		{
			strUID = (pSlash + 1);
			CComBSTR bstr(((unsigned long)pSlash-(unsigned long)m_strUID)/sizeof(WCHAR), m_strUID);
			bstrDomain = bstr;
		}
		if(g_pSocketSvr->m_SSPILogon.m_bNT)
		{
			bOk = g_pSocketSvr->m_SSPILogon.Logon(bstrDomain.m_str, strUID, m_strPassword);
		}
		else
		{
			USES_CONVERSION;
			bOk = g_pSocketSvr->m_SSPILogon.Logon(OLE2A(bstrDomain.m_str), OLE2A(strUID), OLE2A(m_strPassword));
		}
	}while(false);

	return bOk;
}

void CUListener::CleanMutex()
{
	if(m_h0 != NULL)
	{
		::CloseHandle(m_h0);
		m_h0 = NULL;
	}
	
	if(m_h1 != NULL)
	{
		::CloseHandle(m_h1);
		m_h1 = NULL;
	}
}



