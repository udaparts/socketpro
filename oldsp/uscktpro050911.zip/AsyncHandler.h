#ifndef __U_ASYNC_HANDLER_H__
#define __U_ASYNC_HANDLER_H__

#include "sprowrap.h"
using namespace SocketProAdapter;
using namespace SocketProAdapter::ClientSide;

class CPeerJob : public CScopeUQueue
{
public:
	CPeerJob()
	{
		m_hSocketPeer = 0;
	}
	
public:
	unsigned int m_hSocketPeer;
};

class CAsyncHandler : public CAsyncServiceHandler
{
public:
	CAsyncHandler(CClientSocket *pClientSocket = UNULL_PTR, IAsyncResultsHandler *pIAsyncResultsHandler = UNULL_PTR);
	virtual ~CAsyncHandler(void);

	unsigned int GetPeer();
	void  SetPeer(unsigned int hSocketPeer);

protected:
	virtual void OnResultReturned(unsigned short usRequestID, CUQueue &UQueue);

public:
	CPeerJob		m_PeerJob;
};

#endif
