#include "stdafx.h"
#include <atlbase.h>
#include "ChatRoom.h"

CChatGroup::CChatGroup()
{
	m_nID=0;
}

CChatGroup::CChatGroup(const CChatGroup& ChatGroup)
{
	ULONG n;
	m_Listeners.RemoveAll();
	ULONG nCount=ChatGroup.m_Listeners.GetSize();
	for(n=0; n<nCount; n++)
	{
		m_Listeners.Add(ChatGroup.m_Listeners[n]);
	}
	m_bstrDescription=ChatGroup.m_bstrDescription;
	m_nID=ChatGroup.m_nID;
}

CChatGroup& CChatGroup::operator=(const CChatGroup& ChatGroup)
{
	ULONG n;
	m_Listeners.RemoveAll();
	ULONG nCount=ChatGroup.m_Listeners.GetSize();
	for(n=0; n<nCount; n++)
	{
		m_Listeners.Add(ChatGroup.m_Listeners[n]);
	}
	m_bstrDescription=ChatGroup.m_bstrDescription;
	m_nID=ChatGroup.m_nID;
	return *this;
}

bool CChatGroup::operator==(const CChatGroup& ChatGroup)
{
	ULONG n;
	ULONG nCount=m_Listeners.GetSize();
	if(m_bstrDescription!=ChatGroup.m_bstrDescription)
		return false;
	if(m_nID!=ChatGroup.m_nID)
		return false;
	if(m_Listeners.GetSize()!=ChatGroup.m_Listeners.GetSize())
		return false;
	for(n=0; n<nCount; n++)
	{
		if(m_Listeners[n]!=ChatGroup.m_Listeners[n])
			return false;
	}
	return true;
}

bool CChatGroup::operator!=(const CChatGroup& ChatGroup)
{
	return (*this==ChatGroup) ? false : true;
}