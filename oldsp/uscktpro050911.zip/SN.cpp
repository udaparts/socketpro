// SN.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Wbemidl.h>

bool SetSocketProConfig(BSTR bstrSN, BSTR *bstrFileName, BSTR *pbstrXML)
{
	bool bSuc = false;
	do
	{
		HRESULT hr;
		TCHAR strFullFileName[1025] = {0};
		CComPtr<IXMLDOMDocument> pIXMLDOMDocument;
		hr = pIXMLDOMDocument.CoCreateInstance(__uuidof(DOMDocument));
		if(FAILED(hr))
			break;
		VARIANT_BOOL vbSuc = VARIANT_FALSE;
		::GetModuleFileName(NULL, strFullFileName, sizeof(strFullFileName)/sizeof(TCHAR) - 1);
		TCHAR *strSlash = _tcsrchr(strFullFileName, _T('\\'));

#if _MSC_VER >= 1400
		CComBSTR bstrPath((int)(strSlash - strFullFileName + 1), strFullFileName);
#else
		CComBSTR bstrPath((int)(strSlash - strFullFileName + 2), strFullFileName);
#endif
		TCHAR *strDot = _tcsrchr(strFullFileName, _T('.'));
		strSlash++;
		unsigned long nLen = (unsigned long)::_tcslen(strSlash);
		if(strDot != NULL)
			nLen -= (unsigned long)::_tcslen(strDot);
#if _MSC_VER >= 1400
		CComBSTR bstrName(nLen, strSlash);
#else
		CComBSTR bstrName(nLen + 1, strSlash);
#endif
		bstrPath += bstrName;
		*bstrFileName = ::SysAllocString(bstrName);
		bstrPath += L"_sp.xml";
		CComVariant vtXMLFile(bstrPath);
		hr = pIXMLDOMDocument->load(vtXMLFile, &vbSuc);
		if(FAILED(hr) || !vbSuc)
		{
			CComBSTR strConfig	(	L"<?xml version=\"1.0\" ?>\n"
									L"<SocketProRegistration>\n"
										L"<SmartDevice>0</SmartDevice>\n"
										L"<JavaScript>0</JavaScript>\n"
										L"<Java>0</Java>\n"
										L"<Unix>0</Unix>\n"
										L"<PLG>0</PLG>\n"
										L"<MachineID>"
								);
			strConfig += bstrSN;
			strConfig +=				L"</MachineID>\n" 
										L"<Other>0</Other>\n"
										L"<Key>PutRegistrationKeyHere</Key>\n"
									L"</SocketProRegistration>";

			hr = pIXMLDOMDocument->loadXML(strConfig, &vbSuc);
			if(FAILED(hr) || !vbSuc)
				break;
			hr = pIXMLDOMDocument->save(vtXMLFile);
			if(FAILED(hr))
				break;
		}
		hr = pIXMLDOMDocument->load(vtXMLFile, &vbSuc);
		if(FAILED(hr) || !vbSuc)
			break;
		hr = pIXMLDOMDocument->get_xml(pbstrXML);
		if(FAILED(hr) || !vbSuc)
			break;
		bSuc = true;
	}while(0);
	return bSuc;
}

bool GetMotherBoadSerialNumber(CComBSTR &bstrSN)
{
	HRESULT hr;
	bool bSuc = false;
	
	do
	{
		CComPtr<IWbemLocator> pIWbemLocator;
		hr = pIWbemLocator.CoCreateInstance(__uuidof(WbemLocator));
		if(FAILED(hr))
			break;
		CComPtr<IWbemServices> pIWbemServices;
		hr = pIWbemLocator->ConnectServer(
			CComBSTR(L"ROOT\\CIMV2"), // Object path of WMI namespace
			 NULL,                    // User name. NULL = current user
			 NULL,                    // User password. NULL = current
			 0,                       // Locale. NULL indicates current
			 NULL,                    // Security flags.
			 0,                       // Authority (e.g. Kerberos)
			 0,                       // Context object 
			 &pIWbemServices          // pointer to IWbemServices proxy
			 );
	    
		if (FAILED(hr))
			break;
		hr = CoSetProxyBlanket(
		   pIWbemServices,                        // Indicates the proxy to set
		   RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
		   RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
		   NULL,                        // Server principal name 
		   RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
		   RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
		   NULL,                        // client identity
		   EOAC_NONE                    // proxy capabilities 
		);
		if (FAILED(hr))
			break;
		CComPtr<IEnumWbemClassObject> pIEnumWbemClassObject;
		hr = pIWbemServices->ExecQuery(
			CComBSTR(L"WQL"), 
			CComBSTR(L"SELECT * FROM Win32_BaseBoard"),
			WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
			NULL,
			&pIEnumWbemClassObject);
		if (FAILED(hr))
			break;
		CComPtr<IWbemClassObject> pIWbemClassObject;
		if(pIEnumWbemClassObject != NULL)
		{
			ULONG uReturn = 0;
			hr = pIEnumWbemClassObject->Next(WBEM_INFINITE, 1, &pIWbemClassObject, &uReturn);
			if(uReturn && pIWbemClassObject != NULL)
			{
				CComVariant vtProp;
				hr = pIWbemClassObject->Get(L"SerialNumber", 0, &vtProp, 0, 0);
				bstrSN = vtProp.bstrVal;
				bSuc = true;
			}
		}
	}while(0);
	
	SYSTEM_INFO si;
	GetSystemInfo(&si);

	TCHAR str[128] = {0};
	_stprintf(str, _T("%d%d%d%d%d"), si.dwProcessorType|123, si.wProcessorLevel|5, si.dwNumberOfProcessors|24, 
		si.wProcessorRevision, si.dwActiveProcessorMask|22);
	bstrSN += str;

	return bSuc;
}

/*
int main(int argc, char* argv[])
{
	USES_CONVERSION;
	CComBSTR bstrSN;
	CComBSTR bstrXML;
	::CoInitialize(NULL);
	bool bSuc = GetMotherBoadSerialNumber(bstrSN);
	bSuc = SetSocketProConfig(bstrSN, &bstrXML);
	CoUninitialize();
    return 0;
}*/
