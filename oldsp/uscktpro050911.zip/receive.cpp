#include "stdafx.h"
#include "ULSocket.h"
#include "Startup.h"
#include "context.h"
#include "UThread.h"
#include "ChatRoom.h"

extern CUQueue	g_cancelQueue;
extern CUQueue	g_tempQueue;
extern CUQueue	g_tempQueueSnd;

extern CSimpleMap<SOCKET, CUClient*> g_mapUClient;

