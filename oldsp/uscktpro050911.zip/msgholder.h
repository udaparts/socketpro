// MsgHolder.h: interface for the CMsgHolder class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MSGHOLDER_H__4E8E9BB9_621B_40FE_9460_3ADB4FA50271__INCLUDED_)
#define AFX_MSGHOLDER_H__4E8E9BB9_621B_40FE_9460_3ADB4FA50271__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "uqueue.h"
#include "sprowrap.h"

class CMsgHolder  
{
public:
	CMsgHolder(BSTR bstrSender, unsigned long ipAddr, int nPort, unsigned long ulSvsID);
	virtual ~CMsgHolder();
	CMsgHolder(const CMsgHolder&);
	CMsgHolder& operator=(const CMsgHolder&);
	
public:
	LONG AddRef();
	LONG Release();
	void PushMessage(const char *strMethodName, const VARIANT &vtMessage);
	CUQueue* GetUQueue();

private:
	void Push(BSTR bstr);
	void Push(const VARIANT &vtMessage);
	void Push(const SYSTEMTIME &st);

public:
	CScopeUQueue	m_qGroup;

private:
	CScopeUQueue	m_UQueue;
	LONG			m_lRef;
	CComBSTR		m_bstrSender;
	unsigned long	m_ipAddr;
	unsigned long	m_ulSvsID;
	int				m_nPort;
};

class CWebChatContext
{
public:
	CWebChatContext(const GUID &guid, LPSTR ipAddr, DWORD dwLeaseTime = 60000);
	virtual ~CWebChatContext();
	
	CWebChatContext(const CWebChatContext& wsc);

public:
	CWebChatContext& operator=(const CWebChatContext& wsc);
	void AddMsg(CMsgHolder *pMsgHolder);
	int GetCountMessages();
	bool CanDie();
	CComBSTR& GetHTTPPushSessionId();
	CComBSTR& GetIpAddr();
	void SendTimeoutMessage();
	void SendShutdownMessage();
	unsigned long GetLeaseTime(){return m_dwLastSentTime;}

public:
	unsigned int	m_hSocket; //associated
	CComVariant		m_vtGroups;
	CComBSTR		m_bstrUserId;
	CComBSTR		m_bstrJSCallback;
	unsigned long	m_ulTimeout;
	unsigned long	m_ulWhy;

private:
	void Init(const CWebChatContext& wsc);
	void RemoveAll();
	void SendMsgs(CUQueue &UQueue); 
	void Push(BSTR bstr, CUQueue &UQueue);

private:
	CComBSTR					m_bstrGuid;
	CComBSTR					m_ipAddr;
	DWORD						m_dwLastSentTime;
	CSimpleArray<CMsgHolder*>	m_aMsg;
	DWORD						m_dwLeaseTime;
};

#endif // !defined(AFX_MSGHOLDER_H__4E8E9BB9_621B_40FE_9460_3ADB4FA50271__INCLUDED_)
