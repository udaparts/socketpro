#ifndef __USOCKET_SERVER_H__STDAFX__
#define __USOCKET_SERVER_H__STDAFX__

#ifndef _SECURE_ATL
#define _SECURE_ATL 1
#endif

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#endif


// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef WINVER				// Allow use of features specific to Windows XP or later.
#define WINVER 0x0501		// Change this to the appropriate value to target other versions of Windows.
#endif

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

#ifndef _WIN32_WINDOWS		// Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0410 // Change this to the appropriate value to target Windows Me or later.
#endif

#ifndef _WIN32_IE			// Allow use of features specific to IE 6.0 or later.
#define _WIN32_IE 0x0600	// Change this to the appropriate value to target other versions of IE.
#endif

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit


#define _WIN32_DCOM

#define PROMPT_NUM	60

#define	SKEY1	0x98767890
#define	SKEY2	0x12355321
#define MLPARAM	11111111

#include <winsock2.h>
#include <atlbase.h>
#include <tlhelp32.h>

extern unsigned long g_ulCallCount;

BOOL UPostMessage(
  HWND hWnd,      // handle of destination window
  UINT Msg,       // message to post
  WPARAM wParam,  // first message parameter
  LPARAM lParam   // second message parameter
);

#include "sockutil.h"

#include "streamhead.h"

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

//#include "umemoryzip.h"
#include "zlib.h"

#include <iphlpapi.h>

#include "uqueue.h"
#include "usocket.h"

using namespace SocketProAdapter;

extern long		g_lAdapter;
extern short	g_sAdapter;

void CreateUDASocketProReg();
bool CheckValid();
bool OpenLock();
extern bool g_bRegistered;
bool IsRegistered();
int EnumApp(LPCTSTR strModuleName);

ULONG RemoveLock();
void Relock(ULONG ulCount);

#define ALLCOUNT0	_T("S_PU_0")
#define ALLCOUNT1	_T("S_PU_1")

#define USE_MESSAGE_PUMP_WORKERTHREAD

#define REG_MESSAGE	_T("The SocketPro server is NOT registerred.\nPlease contact UDAParts at support@udaparts.com for a proper key to unlock the server.")

extern bool	g_bMachine;
extern ULONG g_ulPopCount;

bool SetSocketProConfig(BSTR bstrSN, BSTR *bstrFileName, BSTR *pbstrXML);
bool GetMotherBoadSerialNumber(CComBSTR &bstrSN);

#include "uscktpro.h"

class CSvsContextEx : public CSvsContext
{
public:
	bool	m_bRandom;
};

#endif