#include "stdafx.h"

#include "uscktpro.h"
#include "ulsocket.h"
#include "chatroom.h"
#include "startup.h"
#include "MsgHolder.h"

extern CStartup	*g_pStartup;
extern CSimpleMap<SOCKET, CUClient*> g_mapUClient;
extern CSimpleMap<DWORD, CUThread*>	g_mapThread;

bool WINAPI StartSocketProServer(unsigned int uiPort, unsigned int uiMaxBacklog)
{
	if(g_pSocketSvr == NULL)
		return NULL;
	if(!g_pSocketSvr->Create(uiPort))
		return false;
	if(!g_pSocketSvr->Listen(uiMaxBacklog))
		return false;
	return true;
}

void WINAPI StopSocketProServer()
{
	if(g_pSocketSvr)
	{
//		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		g_pSocketSvr->CloseSocket();
		g_pSocketSvr->RemoveAllDlls();
	}
}

unsigned int WINAPI GetCountOfClients()
{
	if(g_pSocketSvr == NULL)
		return 0;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->GetClientCount();
}

unsigned int WINAPI GetClient(unsigned int uiIndex)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->GetClient(uiIndex);
	if(pClient)
		return pClient->m_hSocket;
	return INVALID_SOCKET;
}

unsigned int WINAPI FindClient(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->m_hSocket;
	return INVALID_SOCKET;
}

HWND WINAPI GetWin()
{
	if(g_pSocketSvr == NULL)
		return NULL;
	return g_pSocketSvr->GetWin();
}

unsigned long WINAPI GetMainThreadID()
{
	if(!g_pSocketSvr)
		return 0;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->GetMainThreadID();
}

int WINAPI GetLastSocketError()
{
	return ::WSAGetLastError();
}

FARPROC GetOpenSSLProcAddress(const wchar_t *strOpenSSLFuncName)
{
	USES_CONVERSION;
	if(!strOpenSSLFuncName)
		return NULL;
	return CSktBase::GetProcAddress(OLE2T(strOpenSSLFuncName));
}

void WINAPI SetDefaultEncryptionMethod(tagEncryptionMethod EncryptionMethod)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(g_pSocketSvr->m_hSocket != 0 && g_pSocketSvr->m_hSocket != INVALID_SOCKET)
	{
		return;
	}
/*	if((!g_pSocketSvr->m_bUseMessagePump) && (EncryptionMethod == TLSv1 || EncryptionMethod == SSL23))
		return;*/
	g_pSocketSvr->m_EncryptionMethod = EncryptionMethod;
}

void WINAPI SetDefaultZip(bool bZip)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_bZip = bZip;
}

tagEncryptionMethod WINAPI GetDefaultEncryptionMethod()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_EncryptionMethod;
}

bool WINAPI GetDefaultZip()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_bZip;
}

void WINAPI SetGroupsNotifiedWhenEntering(unsigned long ulGroupsNotifiedWhenEntering)
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
//	g_pSocketSvr->m_ulGroupsNotifiedWhenEntering = ulGroupsNotifiedWhenEntering;
}

void WINAPI SetGroupsNotifiedWhenExiting(unsigned long ulGroupsNotifiedWhenExiting)
{
//	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
//	g_pSocketSvr->m_ulGroupsNotifiedWhenExiting = ulGroupsNotifiedWhenExiting;
}

unsigned long WINAPI GetGroupsNotifiedWhenEntering()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulGroupsNotifiedWhenEntering;
}

unsigned long WINAPI GetGroupsNotifiedWhenExiting()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulGroupsNotifiedWhenExiting;
}

void WINAPI SetMaxThreadIdleTimeBeforeSuicide(unsigned long ulMaxThreadIdleTimeBeforeSuicide)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_ulMaxThreadIdleTimeBeforeSuicide = ulMaxThreadIdleTimeBeforeSuicide;
}

void WINAPI SetMaxConnectionsPerClient(unsigned long ulMaxConnectionsPerClient)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_ulMaxConnectionsPerClient = ulMaxConnectionsPerClient;
}

unsigned long WINAPI GetMaxThreadIdleTimeBeforeSuicide()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulMaxThreadIdleTimeBeforeSuicide;
}

unsigned long WINAPI GetMaxConnectionsPerClient()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulMaxConnectionsPerClient;
}

void WINAPI SetTimerElapse(unsigned long ulTimerElapse)
{
	if(ulTimerElapse > 10000)
	{
		ulTimerElapse = 10000;
	}
	if(ulTimerElapse < 100)
	{
		ulTimerElapse = 100;
	}
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_ulTimerElapse = ulTimerElapse;
}

void WINAPI SetSMInterval(unsigned long ulSMInterval)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_ulSMInterval = ulSMInterval;
}

void WINAPI SetPingInterval(unsigned long ulPingInterval)
{
	if(ulPingInterval > (0x0000FFFF * 1000))
	{
		ulPingInterval = (0x0000FFFF * 1000);
	}
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_ulPingInterval = ulPingInterval;
}

unsigned long WINAPI GetTimerElapse()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulTimerElapse;
}

unsigned long WINAPI GetSMInterval()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulSMInterval;
}

unsigned long WINAPI GetPingInterval()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulPingInterval;
}

void WINAPI SetRecycleGlobalMemoryInterval(unsigned long ulRecycleGlobalMemoryInterval)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_ulRecycleGlobalMemoryInterval = ulRecycleGlobalMemoryInterval;
}

void WINAPI SetCertFile(const wchar_t *strCertFile)
{
	USES_CONVERSION;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(strCertFile)
		::strcpy(g_pSocketSvr->m_strCertFile, OLE2A(strCertFile));
}

void WINAPI SetPrivateKeyFile(const wchar_t *strPrivateKeyFile)
{
	USES_CONVERSION;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(strPrivateKeyFile)
		::strcpy(g_pSocketSvr->m_strPrivateKeyFile, OLE2A(strPrivateKeyFile));
}

unsigned long WINAPI GetRecycleGlobalMemoryInterval()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_ulRecycleGlobalMemoryInterval;
}

unsigned long WINAPI GetAChatGroup(unsigned long ulGroupID, wchar_t *strDescription, unsigned long ulChars)
{
	int n;
	if(strDescription == NULL || ulChars == 0)
		return 0;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CSimpleArray<CChatGroup> *pChat = g_pSocketSvr->m_pChat;
	int nCount = pChat->GetSize();
	for(n=0; n<nCount; n++)
	{
		if((*pChat)[n].m_nID == ulGroupID)
		{
			unsigned long ulLen = (*pChat)[n].m_bstrDescription.Length();
			if(ulChars>ulLen)
				ulChars = ulLen;
			memcpy(strDescription, (*pChat)[n].m_bstrDescription.m_str, ulChars*sizeof(WCHAR));
			return ulChars;
		}
	}
	return 0;
}

bool WINAPI AddAChatGroup(unsigned long ulGroupID, const wchar_t *strDescription)
{
	return g_pSocketSvr->CreateAChatGroup(ulGroupID, strDescription);
}

unsigned long WINAPI GetJoinedGroup(unsigned int hSocket)
{
	return g_pSocketSvr->GetJoinedGroup(hSocket);
}

unsigned long WINAPI GetJoinedGroupIds(unsigned int hSocket, unsigned long *pGroupId, unsigned long ulGroupCount)
{
	if(pGroupId == NULL || ulGroupCount == 0)
		return 0;
	CSimpleArray<CChatGroup*> Groups;
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		g_pSocketSvr->GetJoinedGroup(hSocket, Groups);
	}
	unsigned n = 0;
	unsigned long nSize = Groups.GetSize();
	for(n=0; n<nSize && n<ulGroupCount; n++)
	{
		pGroupId[n] = Groups[n]->m_nID;
	}
	return n;
}


const VARIANT* WINAPI GetHTTPJoinedGroups(unsigned int hSocket, const wchar_t *strChatSession)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		LPSTR strPeer = NULL;
		unsigned int nPort;
		pClient->GetPeerName(nPort, strPeer);
		CWebChatContext *p = g_pSocketSvr->Seek(strChatSession, strPeer);
		if(p != NULL)
			return &p->m_vtGroups;
	}
	return NULL;
}

void WINAPI SetOnChatRequestComing(POnChatRequestComing pOnChatRequestComing)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnChatRequestComing = pOnChatRequestComing;
}

void WINAPI SetOnChatRequestCame(POnChatRequestCame pOnChatRequestCame)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnChatRequestCame = pOnChatRequestCame;
}

void WINAPI SetOnSSLEvent(POnSSLEvent pOnSSLEvent)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnSSLEvent = pOnSSLEvent;
}

void WINAPI SetOnWinMessage(POnWinMessage pOnWinMessage)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnWinMessage = pOnWinMessage;
}

void WINAPI SetOnAccept(POnAccept pOnAccept)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnAccept = pOnAccept;
}

void WINAPI ResetBytesIn(unsigned int hSocket, unsigned long ulStart, unsigned long *pulHigh)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		pClient->ResetBytesIn(ulStart, pulHigh);
}

void WINAPI ResetBytesOut(unsigned int hSocket, unsigned long ulStart, unsigned long *pulHigh)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		pClient->ResetBytesOut(ulStart, pulHigh);
}

unsigned long WINAPI GetBytesIn(unsigned int hSocket, unsigned long *pulHigh)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetBytesIn(pulHigh);
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetBytesOut(unsigned int hSocket, unsigned long *pulHigh)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetBytesOut(pulHigh);
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetCurrentRequestLen(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetCurrentRequestLen();
	return SOCKET_NOT_FOUND;
}

unsigned short WINAPI GetCurrentRequestID(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetCurrentRequestId();
	return 0;
}

unsigned long WINAPI GetLastSndTime(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetLastSndTime();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetLastRcvTime(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetLastRcvTime();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetSndBufferSize(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetSndBufferSize();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetRcvBufferSize(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetRcvBufferSize();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetSndBytesInQueue(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetSndBytesInQueue();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetRcvBytesInQueue(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetRcvBytesInQueue();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetSvsID(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetSvsID();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetTotalMemory(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->GetTotalMemory();
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI QueryRequestsInQueue(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->QueryRequestsInQueue();
	return SOCKET_NOT_FOUND;
}

bool WINAPI IsBatching(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		return pClient->IsBatching();
	return false;
}

bool WINAPI GetInterfaceAttributes(unsigned int hSocket, unsigned long *pulMTU, unsigned long *pulMaxSpeed, unsigned long *pulType, unsigned long *pulMask)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		unsigned long ulMTU;
		unsigned long ulMaxSpeed;
		unsigned long ulType; 
		unsigned long ulMask;
		bool bSuc = pClient->GetInterfaceAttributes(ulMTU, ulMaxSpeed, ulType, ulMask);
		if(pulMTU)
			*pulMTU = ulMTU;
		if(pulMaxSpeed)
			*pulMaxSpeed = ulMaxSpeed;
		if(pulType)
			*pulType = ulType;
		if(pulMask)
			*pulMask = ulMask;
		return bSuc;
	}
	return false;
}

void WINAPI ShrinkMemory(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		pClient->ShrinkMemory();
}

unsigned long WINAPI GetCountOfMySpecificBytes(unsigned int hSocket)
{
	unsigned long ulLen = SOCKET_NOT_FOUND;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
		pClient->GetMySpecificBytes(ulLen);
	return ulLen;
}

unsigned long WINAPI GetMySpecificBytes(unsigned int hSocket, unsigned char* pBuffer, unsigned long ulLen)
{
	unsigned long ulGet = SOCKET_NOT_FOUND;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		ulGet =  GetCountOfMySpecificBytes(hSocket);
		if(ulGet < ulLen)
			ulLen = ulGet;
		memcpy(pBuffer, pClient->GetMySpecificBytes(ulLen), ulGet);
	}
	return ulGet;
}

bool WINAPI AddSvsContext(unsigned long ulSvsID, CSvsContext SvsContext)
{
	return g_pSocketSvr->AddSvsContext(ulSvsID, SvsContext);
}

bool WINAPI AddSlowRequest(unsigned long ulSvsID, unsigned short usRequestID)
{
	return g_pSocketSvr->AddSlowRequest(ulSvsID, usRequestID);
}

void WINAPI SetReturnRandom(unsigned long ulSvs, bool bRandom)
{
	int nIndex = g_pSocketSvr->m_mapSvs.FindKey(ulSvs);
	if(nIndex != -1)
	{
		CSvsContextEx &ex = g_pSocketSvr->m_mapSvs.GetValueAt(nIndex);
		ex.m_bRandom = bRandom;
	}
}

bool WINAPI GetReturnRandom(unsigned long ulSvs)
{
	int nIndex = g_pSocketSvr->m_mapSvs.FindKey(ulSvs);
	if(nIndex != -1)
	{
		CSvsContextEx &ex = g_pSocketSvr->m_mapSvs.GetValueAt(nIndex);
		return ex.m_bRandom;
	}
	return false;
}

void WINAPI DropRequestResult(unsigned int hSocket, unsigned short usRequestId)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		pClient->sendReturnData(idDropRequestResult, sizeof(usRequestId), (BYTE*)&usRequestId);
	}
}

void* WINAPI GetSSL(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		if(g_pSocketSvr->m_EncryptionMethod == MSTLSv1 || g_pSocketSvr->m_EncryptionMethod == MSSSL)
			return &(pClient->m_pSspiServer->m_hContext);
		return pClient->m_pSSL;
	}
	return NULL;
}

bool WINAPI SetBlowFish(unsigned int hSocket, unsigned char bKeyLen, unsigned char *strKey)
{
	//Starting from 4.8.2.4, the below commented out, but it is returned on 4.8.2.6

	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient != NULL && pClient->m_pBlowFish)
	{
		delete pClient->m_pBlowFish;
		pClient->m_pBlowFish = NULL;
	}
	if(pClient && bKeyLen <= 56 && bKeyLen > 1)
	{
		pClient->m_pBlowFish = new CBF(strKey, bKeyLen);
		pClient->m_bKeyLen = bKeyLen;
		return true;
	}
	return false;
}

void WINAPI Register(unsigned int hSocket, unsigned char *pbLock, unsigned char *pbKey)
{
	return;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient && pbLock != NULL && pbKey != NULL)
	{
		pClient->Register(pbLock, pbKey);
	}
}

bool WINAPI Enter(unsigned int hSocket, unsigned long ulGroup)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient && pClient->m_HttpReqAttribute.m_HttpRequest == hrUnknown)
	{
		return ((CUClientThreaded*)pClient)->Enter(ulGroup);
	}
	return false;
}

bool WINAPI Exit(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient && pClient->m_HttpReqAttribute.m_HttpRequest == hrUnknown)
	{
		return ((CUClientThreaded*)pClient)->Exit();
	}
	return true;
}

bool WINAPI RemoveASvsContext(unsigned long ulSvsID)
{
	bool bMsg;
	MSG msg;
	DWORD dwLastError;
	UINT nCount;
	UINT n;
	if(g_pSocketSvr == NULL)
		return false;
	bMsg = GetUseWindowMessagePump();
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(!::IsWindow(g_pSocketSvr->GetWin()))
		return false;
vv:	nCount = g_mapUClient.GetSize();
	for(n=0; n<nCount; n++)
	{
		if(g_mapUClient.GetValueAt(n)->m_ulSvsID == ulSvsID)
		{
			if(!::PostClose(g_mapUClient.GetValueAt(n)->m_hSocket, 0))
			{
				dwLastError = ::GetLastError();
			}
			if(!bMsg)
			{

			}
			else
			{
				while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
				{
					::TranslateMessage(&msg);
					::DispatchMessage(&msg);
				}
				goto vv;
			}	
		}
	}
//	g_pSocketSvr->m_mapSvsSlowRequest.Remove(ulSvsID);
	return g_pSocketSvr->m_mapSvs.Remove(ulSvsID) ? true : false;
}

HINSTANCE WINAPI AddADll(const wchar_t *strLibFile, int nParam)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->AddADll(strLibFile, nParam);
}

bool WINAPI RemoveADll(const wchar_t *strLibFile)
{
	if(g_pSocketSvr == NULL)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->RemoveADll(strLibFile);
}

bool WINAPI PostClose(unsigned int hSocket, unsigned short usError)
{
	if(g_pSocketSvr != NULL)
		return UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, hSocket, WSAMAKESELECTREPLY(FD_CLOSE, usError)) ? true : false;
	return false;
}

bool WINAPI SetEncryptionMethod(unsigned int hSocket, tagEncryptionMethod EncryptionMethod)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient && g_pSocketSvr->m_hSocket != 0 && 
		g_pSocketSvr->m_hSocket != INVALID_SOCKET && 
		(EncryptionMethod == BlowFish || EncryptionMethod == NoEncryption) &&
		g_pSocketSvr->m_EncryptionMethod == BlowFish)
	{
		if(pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown && EncryptionMethod == BlowFish) 
			return false;
		pClient->m_EncryptionMethod = EncryptionMethod;
		return true;
	}
	return false;
}

bool WINAPI SetZip(unsigned int hSocket, bool bZip)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		if(pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown) return false;
		pClient->m_bZip = bZip;
		return true;
	}
	return false;
}

tagEncryptionMethod WINAPI GetEncryptionMethod(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return pClient->m_EncryptionMethod;
	}
	return NoEncryption;	
}

bool WINAPI GetZip(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return pClient->m_bZip;
	}
	return false;
}

unsigned long WINAPI GetUID(unsigned int hSocket, wchar_t* strUID, unsigned long ulBufferLen)
{
	if(strUID == NULL || ulBufferLen == 0)
		return 0;
	memset(strUID, 0, ulBufferLen*sizeof(WCHAR));
	unsigned long ulCount = 0;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		if(strUID && ulBufferLen && pClient->m_strUID)
		{
			unsigned long ulLen = ::wcslen(pClient->m_strUID);
			if(ulBufferLen > ulLen)
				ulBufferLen = ulLen;
			memcpy(strUID, pClient->m_strUID, ulBufferLen*sizeof(WCHAR));
			ulCount = ulBufferLen;
		}
	}
	return ulCount;	
}

unsigned long WINAPI GetPassword(unsigned int hSocket, wchar_t *strPassword, unsigned long ulBufferLen)
{
	if(strPassword == NULL || ulBufferLen == 0)
		return 0;
	memset(strPassword, 0, ulBufferLen*sizeof(WCHAR));
	unsigned long ulCount = 0;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		if(strPassword && ulBufferLen && pClient->m_strPassword)
		{
			unsigned long ulLen = ::wcslen(pClient->m_strPassword);
			if(ulBufferLen > ulLen)
				ulBufferLen = ulLen;
			memcpy(strPassword, pClient->m_strPassword, ulBufferLen*sizeof(WCHAR)); 
			ulCount = ulBufferLen;
		}
	}
	return ulCount;	
}

unsigned long WINAPI GetTimeOut(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return pClient->m_ulTimeOut;
	}
	return SOCKET_NOT_FOUND;
}

bool WINAPI SetTimeOut(unsigned int hSocket, unsigned long ulTimeOut)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		pClient->m_ulTimeOut = ulTimeOut;
		return true;
	}
	return false;
}

bool WINAPI GetClientInfo(unsigned int hSocket, CSwitchInfo *pClientInfo)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		if(pClientInfo)
			*pClientInfo = pClient->m_ClientInfo;
		return true;
	}
	return false;
}

unsigned long WINAPI GetRequestIDsInQueue(unsigned int hSocket, unsigned short *pusRequestID, unsigned long ulSize)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return pClient->GetReqIDsInQueue(pusRequestID, ulSize);
	}
	return 0;
}

bool WINAPI GetServerInfo(unsigned int hSocket, CSwitchInfo *pServerInfo)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		if(pServerInfo)
			*pServerInfo = pClient->m_ServerInfo;
		return true;
	}
	return false;
}

bool WINAPI IsSameEndian(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return pClient->m_bSameEndian;
	}
	return true;
}

bool WINAPI SetServerInfo(unsigned int hSocket, CSwitchInfo *pServerInfo)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient && pClient->GetSvsID() != sidStartup)
	{
		if(pServerInfo)
		{
			pClient->m_ServerInfo = *pServerInfo;
			pClient->m_ServerInfo.m_usUSockMajor = 0; // ????
			pClient->m_ServerInfo.m_usUSockMinor = 7; 
			pClient->m_ServerInfo.m_ulParam1 = g_pStartup->m_ulOS;  // ???
			pClient->m_ServerInfo.m_ulParam2 = g_pSocketSvr->m_ulPingInterval/1000;  // ???
			pClient->m_ServerInfo.m_ulParam2 += g_pSocketSvr->m_am*0x00010000;
		}
		return true;
	}
	return false;
}

CSvsContext WINAPI GetSvsContext(unsigned long ulSvsID)
{
	CSvsContext SvsContext;
	memset(&SvsContext, 0, sizeof(SvsContext));
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	int nIndex = g_pSocketSvr->m_mapSvs.FindKey(ulSvsID);
	if(nIndex != -1)
	{
		SvsContext = g_pSocketSvr->m_mapSvs.GetValueAt(nIndex);
	}
	return SvsContext;
}

bool WINAPI ReplaceSvsContext(unsigned long ulSvsID, CSvsContext SvsContext)
{
	if(g_pSocketSvr == NULL)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(g_pSocketSvr->m_hSocket != 0 && g_pSocketSvr->m_hSocket != INVALID_SOCKET)
		return false;
	CSvsContextEx ex;
	memcpy(&ex, &SvsContext, sizeof(SvsContext));
	ex.m_bRandom = false;
	return (g_pSocketSvr->m_mapSvs.SetAt(ulSvsID, ex) ? true : false);
}

bool WINAPI RemoveSlowRequest(unsigned long ulSvsID, unsigned short usRequestID)
{
	if(g_pSocketSvr == NULL)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	int nIndex = g_pSocketSvr->m_mapSvsSlowRequest.FindKey(ulSvsID);
	if(nIndex == -1)
		return false;
	CRequestArray &aSlowRequest = g_pSocketSvr->m_mapSvsSlowRequest.GetValueAt(nIndex);
	return (aSlowRequest.Remove(usRequestID) ? true : false);
}

unsigned long WINAPI GetCountOfServices()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_mapSvs.GetSize();
}

unsigned long WINAPI GetServiceID(unsigned long ulIndex)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(ulIndex >= (ULONG)g_pSocketSvr->m_mapSvs.GetSize())
		return 0;
	return g_pSocketSvr->m_mapSvs.GetKeyAt(ulIndex);
}

unsigned short WINAPI GetCountOfSlowRequests(unsigned long ulSvsID)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	int nIndex = g_pSocketSvr->m_mapSvsSlowRequest.FindKey(ulSvsID);
	if(nIndex == -1)
		return 0;
	CRequestArray &aSlowRequest = g_pSocketSvr->m_mapSvsSlowRequest.GetValueAt(nIndex);
	return aSlowRequest.GetSize();
}

void WINAPI RemoveAllSlowRequests(unsigned long ulSvsID)
{
	if(g_pSocketSvr == NULL)
		return;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	int nIndex = g_pSocketSvr->m_mapSvsSlowRequest.FindKey(ulSvsID);
	if(nIndex == -1)
		return;
	CRequestArray &aSlowRequest = g_pSocketSvr->m_mapSvsSlowRequest.GetValueAt(nIndex);
	aSlowRequest.RemoveAll();
}

unsigned short WINAPI GetSlowRequest(unsigned long ulSvsID, unsigned short usIndex)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	int nIndex = g_pSocketSvr->m_mapSvsSlowRequest.FindKey(ulSvsID);
	if(nIndex == -1)
		return 0;
	CRequestArray &aSlowRequest = g_pSocketSvr->m_mapSvsSlowRequest.GetValueAt(nIndex);
	if(usIndex >= aSlowRequest.GetSize())
		return 0;
	return aSlowRequest[usIndex];
}

bool WINAPI SpeakToEx(unsigned int hSocket, const unsigned char *pMessage, unsigned long ulLen, unsigned int hSocketTarget)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	CUClient* pTarget = g_pSocketSvr->FindClient(hSocketTarget);
	if(pClient && pTarget)
	{
		return ((CUClientThreaded*)pClient)->SpeakToEx(pMessage, ulLen, (CUClientThreaded*)pTarget);
	}
	return false;
}

bool WINAPI XSpeakEx(unsigned int hSocket, const unsigned char *pMessage, unsigned long ulLen, unsigned long ulGroupCount, const unsigned long *pGroups)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return ((CUClientThreaded*)pClient)->XSpeakEx(pMessage, ulLen, ulGroupCount, pGroups);
	}
	return false;
}

bool WINAPI SpeakEx(unsigned int hSocket, const unsigned char *pMessage, unsigned long ulLen, unsigned long ulGroups)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return ((CUClientThreaded*)pClient)->SpeakEx(pMessage, ulLen, ulGroups);
	}
	return false;
}

bool WINAPI SendUserMessage(unsigned int hSocket, const wchar_t *strUserID, const VARIANT *pvtMsg)
{
	if(!pvtMsg)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return ((CUClientThreaded*)pClient)->SendUserMessage(strUserID, *pvtMsg);
	}
	return false;
}

bool WINAPI SendUserMessageEx(unsigned int hSocket, const wchar_t *strUserID, const unsigned char *pMessage, unsigned long ulLen)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return ((CUClientThreaded*)pClient)->SendUserMessageEx(strUserID, pMessage, ulLen);
	}
	return false;
}

bool WINAPI SpeakTo(unsigned int hSocket, const VARIANT *pvtMsg, unsigned int hSocketTarget)
{
	if(!pvtMsg)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	CUClient* pTarget = g_pSocketSvr->FindClient(hSocketTarget);
	if(pClient && pTarget)
	{
		return ((CUClientThreaded*)pClient)->SpeakTo(*pvtMsg, (CUClientThreaded*)pTarget);
	}
	return false;
}

bool WINAPI XSpeak(unsigned int hSocket, const VARIANT *pvtMsg, const VARIANT *pvtGroups)
{
	if(!pvtMsg || !pvtGroups)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		return ((CUClientThreaded*)pClient)->XSpeak(*pvtMsg, *pvtGroups);
	}
	return false;
}

bool WINAPI XEnter(unsigned int hSocket, const VARIANT *pvtGroups)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient && pClient->m_HttpReqAttribute.m_HttpRequest == hrUnknown)
	{
		return ((CUClientThreaded*)pClient)->XEnter(pvtGroups);
	}
	return false;
}

bool WINAPI Speak(unsigned int hSocket, const VARIANT *pvtMsg, unsigned long ulGroups)
{
	if(!pvtMsg)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		((CUClientThreaded*)pClient)->Speak(*pvtMsg, ulGroups);
	}
	return false;
}

void WINAPI SetOnSwitchTo(POnSwitchTo pOnSwitchTo)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnSwitchTo = pOnSwitchTo;
}

void WINAPI SetOnIsPermitted(POnIsPermitted pOnIsPermitted)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(g_pSocketSvr->m_hSocket != 0 && g_pSocketSvr->m_hSocket != INVALID_SOCKET)
	{
		return;
	}
	g_pSocketSvr->m_OnIsPermitted = pOnIsPermitted;
}

void WINAPI SetOnClose(POnClose pOnClose)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnClose = pOnClose;
}

void WINAPI SetOnSend(POnSend pOnSend)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_OnSend = pOnSend;
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved)  
{
    switch(fdwReason) 
    { 
    case DLL_PROCESS_ATTACH:
		{
			ATLTRACE("DLL_PROCESS_ATTACH called, usktpror.dll\n");
		}
        break;
    case DLL_THREAD_ATTACH:
		{
			ATLTRACE("DLL_THREAD_ATTACH called, usktpror.dll\n");
		}
        break;
    case DLL_THREAD_DETACH:
		{
			ATLTRACE("DLL_THREAD_DETACH called, usktpror.dll\n");
		}
        break;
    case DLL_PROCESS_DETACH:
		{
			ATLTRACE("DLL_PROCESS_DETACH called, usktpror.dll\n");
		}
        break;
	default:
		ATLASSERT(FALSE);
		break;
    }
    return TRUE;  
}

unsigned short WINAPI GetCurrentRequestId(SOCKET hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient *pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient)
		return pUClient->GetCurrentRequestId();
//	ATLASSERT(FALSE);
	return 0;
}

bool IsRegistered()
{
	return g_bRegistered;
}

bool WINAPI AbortBatching(unsigned int hSocket)
{
	CUClient *pUClient;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient)
	{
		return pUClient->abortBatching();
	}
	return true;
}

void WINAPI SetPfxFile(const wchar_t *strPfxFile, const wchar_t *strPassword)
{
	if(g_pSocketSvr == NULL)
		return;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_strPfxFile = strPfxFile;
	g_pSocketSvr->m_strPassword = strPassword;
}

void WINAPI UseMSCert(bool bMachine, bool bRoot, const wchar_t *strCertSubject)
{
	if(g_pSocketSvr == NULL)
		return;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	g_pSocketSvr->m_bstrSubject = strCertSubject;
	g_pSocketSvr->m_bMachine = bMachine;
	g_pSocketSvr->m_bRoot = bRoot;
}

unsigned long WINAPI GetCountOfLibraries()
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_aLibrary.GetSize();
}

HINSTANCE WINAPI GetADll(unsigned long ulIndex)
{
	if(ulIndex >= GetCountOfLibraries())
		return NULL;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->m_aLibrary[ulIndex];
}

bool WINAPI RemoveADllByHandle(HINSTANCE hInstance)
{
	if(g_pSocketSvr == NULL)
		return false;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	return g_pSocketSvr->RemoveADll(hInstance);
}

bool WINAPI ContinueProcessing(unsigned int hSocket, unsigned short usRequestID)
{
	if(::GetCurrentThreadId() == g_pSocketSvr->GetMainThreadID())
		return false;
	unsigned long ulIndex = 0;
	{
		CUClient *pUClient;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		pUClient = g_mapUClient.Lookup(hSocket);
		if(!pUClient)
		{
			return false;
		}
	}
	while(!UPostMessage(g_pSocketSvr->GetWin(), WM_CONTINUE_PROCESSING, hSocket, usRequestID))
	{
		ulIndex++;
		if(ulIndex>10)
			return false;
		::Sleep(1);
	}
	return true;	
}

unsigned long WINAPI RetrieveBuffer(unsigned int hSocket, unsigned long ulLen, unsigned char* pBuffer, bool bPeek)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient *pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient)
	{
		if(bPeek)
			return pUClient->PeekRcvMemory(pBuffer, ulLen);
		return pUClient->GetRecvBuffer(pBuffer, ulLen);
	}
	return SOCKET_NOT_FOUND;
}

unsigned long WINAPI GetAssociatedThreadID(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient *pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient && pUClient->m_pUThread)
	{
		return 	pUClient->m_pUThread->GetThreadId();
	}
	return GetMainThreadID();
}

unsigned int WINAPI GetAssociatedSocket()
{
	DWORD dwThreadID = ::GetCurrentThreadId();
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	if(g_pSocketSvr->GetMainThreadID() == dwThreadID)
		return 0;
	int nIndex = g_mapThread.FindKey(dwThreadID);
	if(nIndex != -1)
	{
		CUThread* pUThread = g_mapThread.GetValueAt(nIndex);
		if(pUThread && pUThread->m_pUClient)
		{
			return pUThread->m_pUClient->m_hSocket;
		}
	}
	return 0;	
}

unsigned long WINAPI GetBytesBatched(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient *pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient)
	{
		return pUClient->m_batchQueue.GetSize();
	}
	return 0;
}

/*
bool WINAPI IsBlocked(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient *pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient)
	{
		return pUClient->m_bProcessingSlowRequest;
	}
	return false;
}

void WINAPI BlockIt(unsigned int hSocket, bool bBlockIt)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient *pUClient = g_mapUClient.Lookup(hSocket);
	if(pUClient)
	{
		pUClient->m_bProcessingSlowRequest = bBlockIt;
		if(g_pSocketSvr->GetMainThreadID() != ::GetCurrentThreadId())
			::PostThreadMessage(g_pSocketSvr->GetMainThreadID(), WM_SOCKET_SVR_NOTIFY, hSocket, FD_READ);
	}
}*/

unsigned int WINAPI GetListeningSocket()
{
	if(g_pSocketSvr)
	{
		return g_pSocketSvr->m_hSocket;
	}
	return INVALID_SOCKET;
}

unsigned long WINAPI XGetCountOfChatGroups()
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return g_pSocketSvr->m_pChat->GetSize();
	}
	return 0;
}

unsigned char WINAPI GetCountOfChatGroups()
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return g_pSocketSvr->m_pChat->GetSize();
	}
	return 0;
}

unsigned long WINAPI XGetGroupID(unsigned long ulIndex)
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(ulIndex >= (unsigned long)g_pSocketSvr->m_pChat->GetSize())
			return 0;
		return (*(g_pSocketSvr->m_pChat))[ulIndex].m_nID;
	}
	return 0;
}

unsigned long WINAPI GetGroupID(unsigned char bIndex)
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(bIndex >= g_pSocketSvr->m_pChat->GetSize())
			return 0;
		return (*(g_pSocketSvr->m_pChat))[bIndex].m_nID;
	}
	return 0;
}

bool WINAPI GetHTTPChatContext(const wchar_t *strChatId, wchar_t **pstrUserID, wchar_t **pstrIpAddr, unsigned long *pLeaseTime, VARIANT *pvtGroups, unsigned long *pTimeout, unsigned long *pCountOfMessages)
{
	if(g_pSocketSvr)
	{
		int ulIndex;
		CComBSTR bstrChatId = strChatId;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		int ulCount = g_pSocketSvr->m_aChatContext.GetSize();
		for (ulIndex = 0; ulIndex<ulCount; ulIndex++)
		{
			CWebChatContext *p = g_pSocketSvr->m_aChatContext[ulIndex];
			if(bstrChatId == p->GetHTTPPushSessionId())
			{
				if(pLeaseTime)
					*pLeaseTime = p->GetLeaseTime();
				if(pvtGroups)
				{
					VariantClear(pvtGroups);
					VariantCopy(pvtGroups, &p->m_vtGroups);
				}
				if(pTimeout)
					*pTimeout = p->m_ulTimeout;
				if(pCountOfMessages)
					*pCountOfMessages = (unsigned long)(p->GetCountMessages());
				if(pstrUserID)
					*pstrUserID = p->m_bstrUserId.m_str;
				if(pstrIpAddr)
					*pstrIpAddr = p->GetIpAddr().m_str;
				return true;
			}
		}
	}
	return false;
}


const wchar_t* WINAPI GetHTTPChatId(unsigned long ulGroupID, unsigned long ulIndex)
{
	if(g_pSocketSvr)
	{
		int ulIndex;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		int ulCount = g_pSocketSvr->m_aChatContext.GetSize();
		for (ulIndex = 0; ulIndex<ulCount; ulIndex++)
		{
			CWebChatContext *p = g_pSocketSvr->m_aChatContext[ulIndex];
			VARIANT &vtGroups = p->m_vtGroups;
			if(vtGroups.vt == (VT_ARRAY|VT_INT)||vtGroups.vt == (VT_ARRAY|VT_UINT)||vtGroups.vt == (VT_ARRAY|VT_I4)||vtGroups.vt == (VT_ARRAY|VT_UI4))
			{
				unsigned long *pGroups;
				unsigned j, jSize = vtGroups.parray->rgsabound->cElements;
				::SafeArrayAccessData(vtGroups.parray, (void**)&pGroups);
				for(j=0; j<jSize; j++)
				{
					if(pGroups[j] == ulGroupID)
					{
						::SafeArrayUnaccessData(vtGroups.parray);
						return p->GetHTTPPushSessionId().m_str;
					}
				}
				::SafeArrayUnaccessData(vtGroups.parray);
			}
		}
	}
	return NULL;
}

unsigned long WINAPI GetCountOfHTTPChatters(unsigned long ulGroupID)
{
	unsigned long ulChatters = 0;
	if(g_pSocketSvr)
	{
		int ulIndex;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		int ulCount = g_pSocketSvr->m_aChatContext.GetSize();
		for (ulIndex = 0; ulIndex<ulCount; ulIndex++)
		{
			CWebChatContext *p = g_pSocketSvr->m_aChatContext[ulIndex];
			VARIANT &vtGroups = p->m_vtGroups;
			if(vtGroups.vt == (VT_ARRAY|VT_INT)||vtGroups.vt == (VT_ARRAY|VT_UINT)||vtGroups.vt == (VT_ARRAY|VT_I4)||vtGroups.vt == (VT_ARRAY|VT_UI4))
			{
				unsigned long *pGroups;
				unsigned j, jSize = vtGroups.parray->rgsabound->cElements;
				::SafeArrayAccessData(vtGroups.parray, (void**)&pGroups);
				for(j=0; j<jSize; j++)
				{
					if(pGroups[j] == ulGroupID)
					{
						++ulChatters;
						break;
					}
				}
				::SafeArrayUnaccessData(vtGroups.parray);
			}
		}
	}
	return ulChatters;
}

unsigned long WINAPI GetCountOfChatters(unsigned long ulGroupID)
{
	unsigned long ulChatters = 0;
	if(g_pSocketSvr)
	{
		int ulIndex;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		int ulCount = ((CSimpleArray<CChatGroup>*)(g_pSocketSvr->m_pChat))->GetSize();
		for (ulIndex = 0; ulIndex<ulCount; ulIndex++)
		{
			if((*(g_pSocketSvr->m_pChat))[ulIndex].m_nID == ulGroupID)
			{
				ulChatters = (*(g_pSocketSvr->m_pChat))[ulIndex].m_Listeners.GetSize();
				break;
			}
		}
	}
	return ulChatters;
}

unsigned int WINAPI GetChatterSocket(unsigned long ulGroupID, unsigned long ulIndex)
{
	if(g_pSocketSvr)
	{
		ULONG ul;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		ULONG ulCount = ((CSimpleArray<CChatGroup>*)(g_pSocketSvr->m_pChat))->GetSize();
		for (ul=0; ul<ulCount; ul++)
		{
			if((*((CSimpleArray<CChatGroup>*)(g_pSocketSvr->m_pChat)))[ul].m_nID == ulGroupID)
			{
				ULONG ulChatters = (*((CSimpleArray<CChatGroup>*)(g_pSocketSvr->m_pChat)))[ul].m_Listeners.GetSize();
				if(ulIndex >= ulChatters)
					return INVALID_SOCKET;
				return (*((CSimpleArray<CChatGroup>*)(g_pSocketSvr->m_pChat)))[ul].m_Listeners[ulIndex];
			}
				
		}
		return INVALID_SOCKET;
	}
	return INVALID_SOCKET;
}

bool WINAPI GetSockAddr(unsigned int hSocket, unsigned int *pnSockPort, wchar_t *strIPAddrBuffer, unsigned short usChars)
{
	int nRtn;
	unsigned int nPeerPort = 0;
	LPSTR strPeerName = NULL;
	SOCKADDR_IN sockAddr;
	int nSockAddrLen = sizeof(sockAddr);
	if(CUListener::m_suAddr.GetSize())
		nRtn = CUListener::GetSockName(hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	else
		nRtn = ::getsockname(hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	if(nRtn == -1)
	{
		return false;
	}
	else
	{
		nPeerPort = ::ntohs(sockAddr.sin_port);
		strPeerName = ::inet_ntoa(sockAddr.sin_addr);
		if(pnSockPort)
			*pnSockPort = nPeerPort;
		if(strIPAddrBuffer && usChars)
		{
			USES_CONVERSION;
			memset(strIPAddrBuffer, 0, usChars*sizeof(WCHAR));
			unsigned long ulLen = ::strlen(strPeerName);
			if(ulLen > (usChars - 1))
			{
				ulLen = (usChars-1);
			}
			::wcsncpy(strIPAddrBuffer, A2OLE(strPeerName), ulLen);
		}
	}
	return true;
}

bool WINAPI GetPeerName(unsigned int hSocket, unsigned int *pnPeerPort, wchar_t *strPeerAddr, unsigned short usChars)
{
	int nRtn;
	unsigned int nPeerPort = 0;
	LPSTR strPeerName = NULL;
	SOCKADDR_IN sockAddr;
	int nSockAddrLen = sizeof(sockAddr);
	if(CUListener::m_suAddr.GetSize())
		nRtn = CUListener::GetPeerName(hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	else
		nRtn = ::getpeername(hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
	if(nRtn == -1)
	{
		return false;
	}
	else
	{
		nPeerPort = ::ntohs(sockAddr.sin_port);
		strPeerName = ::inet_ntoa(sockAddr.sin_addr);
		if(pnPeerPort)
			*pnPeerPort = nPeerPort;
		if(strPeerAddr && usChars)
		{
			USES_CONVERSION;
			memset(strPeerAddr, 0, usChars*sizeof(WCHAR));
			unsigned long ulLen = (unsigned long)::strlen(strPeerName);
			if((unsigned short)ulLen > (usChars-1))
			{
				ulLen = (usChars-1);
			}
			::wcsncpy(strPeerAddr, A2OLE(strPeerName), ulLen);
		}
	}
	return true;
}

bool WINAPI GetLocalName(wchar_t *strLocalName, unsigned short usChars)
{
	if(strLocalName == NULL || usChars == 0)
		return true;
	memset(strLocalName, 0, usChars*sizeof(WCHAR));
	if(strLocalName && usChars)
	{
		bool bSuc = true;
		char strName[1024];
		memset(strName, 0, 1024);
		int nRtn=::gethostname(strName, 1024);
		if(nRtn == -1)
			bSuc = false;
		else
		{
			USES_CONVERSION;
			memset(strLocalName, 0, usChars*sizeof(WCHAR));
			unsigned long ulLen = (unsigned long)::strlen(strName);
			if((unsigned short)ulLen > (usChars-1))
			{
				ulLen = (usChars-1);
			}
			::wcsncpy(strLocalName, A2OLE(strName), ulLen);
		}
		return bSuc;
	}
	return true;
}

void WINAPI SetCleanPoolInterval(unsigned long ulCleanPoolInterval)
{
	if(ulCleanPoolInterval < 1000)
	{
		ulCleanPoolInterval = 1000;
	}
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(ulCleanPoolInterval < 2*g_pSocketSvr->m_ulTimerElapse)
		{
			ulCleanPoolInterval = 2*g_pSocketSvr->m_ulTimerElapse;
		}
		g_pSocketSvr->m_ulCleanPoolInterval = ulCleanPoolInterval;
	}
}

unsigned long WINAPI GetCleanPoolInterval()
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return g_pSocketSvr->m_ulCleanPoolInterval;
	}
	return 0;
}

unsigned long WINAPI GetSwitchTime()
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return g_pSocketSvr->m_ulMinSwitchTime;
	}
	return 0;
}

void WINAPI SetSwitchTime(unsigned long ulSwitchTime)
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(ulSwitchTime < 1000)
			ulSwitchTime = 1000;
		g_pSocketSvr->m_ulMinSwitchTime = ulSwitchTime;
	}
}

unsigned long WINAPI GetAuthenticationMethod()
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return (unsigned long)g_pSocketSvr->m_am;
	}
	return amOwn;
}

void WINAPI SetAuthenticationMethod(unsigned long ulAuthMethod)
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(ulAuthMethod > (unsigned long)g_pSocketSvr->m_am)
		{
			g_pSocketSvr->m_am = (tagAuthenticationMethod)ulAuthMethod;
			if(g_pSocketSvr->m_am > amIntegrated)
			{
				g_pSocketSvr->m_am = amIntegrated;
			}
		}
	}
}

void WINAPI SetSharedAM(bool bShared)
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(g_pSocketSvr->m_hSocket != 0 && g_pSocketSvr->m_hSocket != INVALID_SOCKET && !g_pSocketSvr->m_bSharedAM)
		{
			return;
		}
		g_pSocketSvr->m_bSharedAM = bShared;
	}
}

bool WINAPI GetSharedAM()
{
	if(g_pSocketSvr)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return g_pSocketSvr->m_bSharedAM;
	}
	return false;
}

void WINAPI CleanTrack(unsigned int hSocket)
{
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient)
	{
		pClient->ZeroTrack();
		pClient->sendReturnData(idCleanTrack, 0, NULL);
		if(::GetCurrentThreadId() == g_pSocketSvr->GetMainThreadID())
		{
			pClient->OnBaseRequestCame(idCleanTrack);
		}
		else
		{
			pClient->m_bCleanFromSvr = true;
		}
	}
}

bool WINAPI SetUseWindowMessagePump(bool bUseMessagePump)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		if(g_pSocketSvr->m_hSocket != 0 && g_pSocketSvr->m_hSocket != INVALID_SOCKET)
			return false;
		if((!bUseMessagePump) && (g_pSocketSvr->m_EncryptionMethod == TLSv1 || g_pSocketSvr->m_EncryptionMethod == SSL23))
		{
			return false;
		}
		if(bUseMessagePump)
		{
			g_pSocketSvr->m_bUseMessagePump = true;
			return true;
		}
		if(g_pStartup->CreateIoCompletionPort != NULL)
		{
			g_pSocketSvr->m_bUseMessagePump = bUseMessagePump;
			return true;
		}
	}
	return false;
}

bool WINAPI GetUseWindowMessagePump()
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return g_pSocketSvr->m_bUseMessagePump;
	}
	return false;
}

bool WINAPI StartIOPump()
{
	if(GetUseWindowMessagePump())
		return false;
	if(g_pSocketSvr != NULL)
	{
		//no locking here
		return g_pSocketSvr->StartIOPump();
	}
	return false;
}

bool WINAPI PostQuitPump(unsigned long ulThreadID)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		g_pSocketSvr->CleanWebChat();
		if(g_pSocketSvr->m_bUseMessagePump)
			return ::PostThreadMessage(ulThreadID, WM_QUIT, 0, 0) ? true : false;
		return UPostMessage(g_pSocketSvr->GetWin(), WM_QUIT, 0, 0) ? true : false;
	}
	return true;
}

void WINAPI DropCurrentSlowRequest(unsigned int hSocket)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			pClient->m_bDropSlow = true;
		}
	}
}

bool WINAPI IsClosing(unsigned int hSocket)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			return pClient->m_bClosing;
		}
	}
	return true;
}

bool WINAPI SetPassword(unsigned int hSocket, const wchar_t *strPassword)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_EncryptionMethod == BlowFish && !pClient->m_bVerify && strPassword != NULL)
		{
			size_t nLen = ::wcslen(strPassword);
			if(nLen > 0 && nLen < 256)
			{
				pClient->m_strPassword = (WCHAR*)::realloc(pClient->m_strPassword, (nLen + 1)*sizeof(WCHAR));
				::wcscpy(pClient->m_strPassword, strPassword);
				pClient->m_strPassword[nLen] = 0;
				return true;
			}
		}
	}
	return false;
}

void WINAPI SetZipLevel(unsigned int hSocket, tagZipLevel zl)
{
	if(g_pSocketSvr != NULL)
	{
		if(zl == zlBestCompression)
			zl = zlDefault;
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			if(pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown) return;
			pClient->m_ZipLevel = zl;
			if(pClient->m_ClientInfo.m_usUSockMinor < 2)
			{
				pClient->m_ZipLevel = zlDefault;
			}
		}
	}
}

tagZipLevel WINAPI GetZipLevel(unsigned int hSocket)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			return pClient->m_ZipLevel;
		}
	}
	return zlDefault;
}

void WINAPI SetHTTPServerPush(bool bEnableHTTPServerPush)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		g_pSocketSvr->m_bHTTPServerPush = bEnableHTTPServerPush;
		if(!bEnableHTTPServerPush)
		{
			g_pSocketSvr->CleanWebChat();
		}	
	}
}

bool WINAPI GetHTTPServerPush()
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		return g_pSocketSvr->m_bHTTPServerPush;
	}
	return false;
}

bool WINAPI	SetUserID(unsigned int hSocket, const wchar_t *strUserID)
{
	if(strUserID == NULL)
		return false;
	size_t len = wcslen(strUserID);
	if(len > 255)
		return false;
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			pClient->m_strUID = (WCHAR*)::realloc(pClient->m_strUID, (len + 1)*sizeof(WCHAR));
			memcpy(pClient->m_strUID, strUserID, (len + 1)*sizeof(WCHAR));
		}
	}
	return true;
}

void WINAPI SetHTTPResponseCode(unsigned int hSocket, unsigned int nHTTPResponseCode)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			pClient->SetHTTPResponseCode(nHTTPResponseCode);
		}
	}
}

void WINAPI SetHTTPMaxMessageSize(unsigned int hSocket, unsigned int nNewMax)
{
	if(nNewMax < 8*1024)
		nNewMax = 8*1024;
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			pClient->m_HttpReqAttribute.m_nMaxMessageSize = nNewMax;
		}
	}
}

unsigned int WINAPI GetHTTPMaxMessageSize(unsigned int hSocket)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			return pClient->m_HttpReqAttribute.m_nMaxMessageSize;
		}
	}
	return 0;
}

void WINAPI SetHTTPAutoPartition(unsigned int hSocket, bool bAutoPartition)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown)
		{
			pClient->m_HttpReqAttribute.m_bAutoPartition = bAutoPartition;
		}
	}
}

bool WINAPI GetHTTPAutoPartition(unsigned int hSocket)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown)
		{
			return pClient->m_HttpReqAttribute.m_bAutoPartition;
		}
	}
	return false;
}

const wchar_t* WINAPI XHTTPEnter(unsigned int hSocket, const VARIANT *pvtGroups, unsigned long dwLeaseTime, const wchar_t *strIpAddr)
{
	if(pvtGroups == NULL)
		return NULL;
	if(g_pSocketSvr == NULL)
		return NULL;
	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
	if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown && g_pSocketSvr->m_bHTTPServerPush)
	{
		if(pvtGroups->vt == (VT_ARRAY|VT_I4) || pvtGroups->vt == (VT_ARRAY|VT_UI4) || pvtGroups->vt == (VT_ARRAY|VT_INT) || pvtGroups->vt == (VT_ARRAY|VT_UINT))
		{
/*			unsigned long *p;
			unsigned long n;
			int j, jSize;
			CSimpleArray<unsigned long> Groups;
			unsigned long nSize = pvtGroups->parray->rgsabound->cElements;
			::SafeArrayAccessData(pvtGroups->parray, (void**)&p);
			for(n=0; n<nSize; n++)
			{
				jSize = g_pSocketSvr->m_pChat->GetSize();
				for(j=0; j<jSize; j++)
				{
					CChatGroup &cg = (*(g_pSocketSvr->m_pChat))[n];
					if(cg.m_nID == p[n])
					{
						Groups.Add(p[n]);
						break;
					}
				}
			}
			::SafeArrayUnaccessData(pvtGroups->parray);
			if(Groups.GetSize() == 0)
				return NULL;
			CComVariant vtGroups;
			vtGroups.vt = (VT_ARRAY|VT_UI4);
			nSize = (unsigned long)Groups.GetSize();
			SAFEARRAYBOUND sab[1] = {nSize, 0};
			vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
			::SafeArrayAccessData(vtGroups.parray, (void**)&p);
			memcpy(p, Groups.GetData(), nSize*sizeof(unsigned long));
			::SafeArrayUnaccessData(vtGroups.parray);*/
			const wchar_t *strChatId = ((CUClientThreaded*)pClient)->HTTPEnter(*pvtGroups, dwLeaseTime, strIpAddr);
			return strChatId;
		}
	}
	return NULL;
}

const wchar_t* WINAPI HTTPEnter(unsigned int hSocket, unsigned long ulGroups, unsigned long dwLeaseTime, const wchar_t *strIpAddr)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown && g_pSocketSvr->m_bHTTPServerPush)
		{
			int n = 0;
			void *p;
			unsigned long ulGroupCount = 0;
			unsigned long pGroup[32] = {0};
			unsigned long ulGroup = 1;
			while(n<32)
			{
				if((ulGroup & ulGroups) == ulGroup)
				{
					pGroup[ulGroupCount] = ulGroup;
					ulGroupCount++;
/*					int j, jSize;
					jSize = g_pSocketSvr->m_pChat->GetSize();
					for(j=0; j<jSize; j++)
					{
						CChatGroup &cg = (*(g_pSocketSvr->m_pChat))[n];
						if(cg.m_nID == ulGroup)
						{
							pGroup[ulGroupCount] = ulGroup;
							ulGroupCount++;
							break;
						}
					}*/
				}
				n++;
				ulGroup <<= 1;
			}
			CComVariant vtGroups;
			if(ulGroupCount)
			{
				SAFEARRAYBOUND sab[1] = {ulGroupCount, 0};
				vtGroups.vt = (VT_ARRAY|VT_UI4);
				vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
				::SafeArrayAccessData(vtGroups.parray, &p);
				::memcpy(p, pGroup, ulGroupCount*sizeof(ulGroup));
				::SafeArrayUnaccessData(vtGroups.parray);
			}
			const wchar_t *strChatId = ((CUClientThreaded*)pClient)->HTTPEnter(vtGroups, dwLeaseTime, strIpAddr);
			return strChatId;
		}
	}
	return NULL;
}

bool WINAPI HTTPExit(unsigned int hSocket, const wchar_t* strPushSessionId)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown)
		{
			return ((CUClientThreaded*)pClient)->HTTPExit(strPushSessionId);
		}
	}
	return false;
}

bool WINAPI HTTPSendUserMessage(unsigned int hSocket, const wchar_t* strPushSessionId, const wchar_t* strUserID, const VARIANT *pvtMsg)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown && pvtMsg != NULL && g_pSocketSvr->m_bHTTPServerPush)
		{
			return ((CUClientThreaded*)pClient)->HTTPSendUserMessage(strPushSessionId, strUserID, *pvtMsg);
		}
	}
	return false;
}

bool WINAPI XHTTPSpeak(unsigned int hSocket, const wchar_t* strPushSessionId, const VARIANT *pvtMsg, const VARIANT *pvtGroup)
{
	if(pvtGroup == NULL)
		return false;
	if(!(pvtGroup->vt == (VT_ARRAY|VT_I4) || pvtGroup->vt == (VT_ARRAY|VT_UI4) || pvtGroup->vt == (VT_ARRAY|VT_INT) || pvtGroup->vt == (VT_ARRAY|VT_UINT)))
		return false;
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown && pvtMsg != NULL && g_pSocketSvr->m_bHTTPServerPush)
		{
			return ((CUClientThreaded*)pClient)->HTTPSpeak(strPushSessionId, *pvtMsg, *pvtGroup);
		}
	}
	return false;
}

bool WINAPI HTTPSpeak(unsigned int hSocket, const wchar_t* strPushSessionId, const VARIANT *pvtMsg, unsigned long ulGroups)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown && pvtMsg != NULL && ulGroups != 0 && g_pSocketSvr->m_bHTTPServerPush)
		{
			int n = 0;
			void *p;
			unsigned long ulGroupCount = 0;
			unsigned long pGroup[32] = {0};
			unsigned long ulGroup = 1;
			while(n<32)
			{
				if((ulGroup & ulGroups) == ulGroup)
				{
					int j, jSize;
					jSize = g_pSocketSvr->m_pChat->GetSize();
					for(j=0; j<jSize; j++)
					{
						CChatGroup &cg = (*(g_pSocketSvr->m_pChat))[n];
						if(cg.m_nID == ulGroup)
						{
							pGroup[ulGroupCount] = ulGroup;
							ulGroupCount++;
							break;
						}
					}
				}
				n++;
				ulGroup <<= 1;
			}
			SAFEARRAYBOUND sab[1] = {ulGroupCount, 0};
			CComVariant vtGroups;
			vtGroups.vt = (VT_ARRAY|VT_UI4);
			vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
			::SafeArrayAccessData(vtGroups.parray, &p);
			::memcpy(p, pGroup, ulGroupCount*sizeof(ulGroup));
			::SafeArrayUnaccessData(vtGroups.parray);
			return ((CUClientThreaded*)pClient)->HTTPSpeak(strPushSessionId, *pvtMsg, vtGroups);
		}
	}
	return false;
}

bool WINAPI HTTPSubscribe(unsigned int hSocket, const wchar_t* strPushSessionId, unsigned long ulTimeout, const wchar_t *strCrossSiteJSCallback)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL && pClient->m_HttpReqAttribute.m_HttpRequest != hrUnknown && g_pSocketSvr->m_bHTTPServerPush)
		{
			return ((CUClientThreaded*)pClient)->HTTPSubscribe(strPushSessionId, ulTimeout, strCrossSiteJSCallback);
		}
	}
	return false;
}
