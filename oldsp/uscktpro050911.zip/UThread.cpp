// UThread.cpp: implementation of the CUThread class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <objbase.h>
#include "UThread.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
HANDLE							g_hThreadEvent;
CSimpleMap<DWORD, CUThread*>	g_mapThread;

extern CUListener	*g_pSocketSvr;

CThreadPool		*g_pThreadPool;
unsigned short WINAPI GetCurrentRequestId(SOCKET hSocket);

bool WINAPI IsCanceled()
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	DWORD dwThreadID = ::GetCurrentThreadId();
	CUThread *pUThread = g_mapThread.Lookup(dwThreadID);
	if(pUThread != NULL)
	{
		return pUThread->m_UMsgQueue.CheckCancel();
	}
	return false;
/*	MSG	msg;
	return ::PeekMessage(&msg, NULL, WM_CANCEL_REQUEST, WM_CANCEL_REQUEST, PM_REMOVE) ? true : false;*/
}

void CALLBACK UThreadTimerProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	MSG msg;
	ATLASSERT(idEvent == ::GetCurrentThreadId());
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
//	ATLTRACE(" <--*--> Thread timer called <--*-->\n");
	CUThread *pUThread = g_mapThread.Lookup(idEvent);
	memset(&msg, 0, sizeof(msg));
	msg.message = WM_QUIT;
	if(!pUThread)  
	{
		pUThread->m_UMsgQueue.PushMsg(msg);
		::SetEvent(pUThread->m_hWaitEvent);
	}
	else if (pUThread->GetTA() == taApartment)
	{
		if(pUThread->m_bSuicidable)
		{
			if(pUThread->IsOnIdle() && dwTime-pUThread->GetRequestProcessedTime()>pUThread->GetMaxIdleTime())
			{
				pUThread->m_UMsgQueue.PushMsg(msg);
				::SetEvent(pUThread->m_hWaitEvent);
			}
		}
	}
	else
	{
		if(pUThread->m_bSuicidable)
		{
			if(pUThread->IsOnIdle() && dwTime-pUThread->GetRequestProcessedTime()>pUThread->GetMaxIdleTime())
			{
				pUThread->m_UMsgQueue.PushMsg(msg);
				::SetEvent(pUThread->m_hWaitEvent);
			}
		}
	}
}

DWORD WINAPI CUThread::UThreadProc(LPVOID lpParameter)
{
	MSG	msg;
	DWORD dwEvent;
	int nSize;
	BOOL bSuc = TRUE;
	CUThread *pUThread = (CUThread*)lpParameter;
	HANDLE hEvent = pUThread->m_hWaitEvent;
	enumThreadApartment TA = pUThread->m_TA;
	PSLOW_PROCESS SlowProcess = pUThread->m_SlowProcess;
	PTHREAD_DYING ThreadDying = pUThread->m_ThreadDying;
	PPRETRANSLATEMESSAGE	PreTranslateMessage = pUThread->m_PreTranslateMessage;
	PTHREAD_STARTED	ThreadStarted = pUThread->m_ThreadStarted;
	DWORD dwCurrentThreadID = ::GetCurrentThreadId();

#ifdef USE_MESSAGE_PUMP_WORKERTHREAD
	::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE);
#endif

	::SetEvent(g_hThreadEvent);
	if(TA == taApartment)
	{
		((CUThread*)lpParameter)->m_bSuicidable = false;
		::CoInitialize(NULL);
	}
	else if(TA == taFree)
	{
		::CoInitializeEx(NULL, COINIT_MULTITHREADED);
	}
	else
	{
	}
	if(ThreadStarted)
		ThreadStarted();
	DWORD	dwRtn = 0;
#ifdef USE_MESSAGE_PUMP_WORKERTHREAD
	UINT	nTimer = ::SetTimer(NULL, ::GetCurrentThreadId(), 1000, NULL);
#endif
	try
	{
		do
		{
#ifdef USE_MESSAGE_PUMP_WORKERTHREAD
			dwEvent = ::MsgWaitForMultipleObjects(1, &hEvent, FALSE, 1000, QS_ALLEVENTS);
#else
			dwEvent = ::WaitForSingleObject(hEvent, 1000);
#endif
			switch(dwEvent)
			{
			case WAIT_TIMEOUT:
			{
				memset(&msg, 0, sizeof(msg));
				msg.time = ::GetTickCount();
				msg.message = WM_TIMER;
				UThreadTimerProc(msg.hwnd, msg.message, dwCurrentThreadID, msg.time);
			}
				break;
#ifdef USE_MESSAGE_PUMP_WORKERTHREAD
			case 1:
			{
				while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
				{
					if(PreTranslateMessage)
					{
						if(PreTranslateMessage(&msg))
						{
							continue;
						}
					}
					if(msg.message == WM_TIMER)
					{
						UThreadTimerProc(msg.hwnd, msg.message, dwCurrentThreadID, msg.time);
					}
					if(msg.message == WM_QUIT)
					{
						::PostQuitMessage(0);
						break;
					}
					::TranslateMessage(&msg);
					::DispatchMessage(&msg);
				}
			}
				break;
#endif
			case WAIT_OBJECT_0:
			{
				{
					CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
					nSize = pUThread->m_UMsgQueue.GetCount();
				}
				while(nSize > 0)
				{
					{
						CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
						if(pUThread->m_UMsgQueue.GetSize() == 0)
							continue;
						pUThread->m_UMsgQueue.PopMsg(msg);
					}

					if(PreTranslateMessage)
					{
						if(PreTranslateMessage(&msg))
						{
							continue;
						}
					}
				
					switch(msg.message)
					{
					case WM_CANCEL_REQUEST:
						ATLTRACE("Thread has a cancel message.\n");
						{
							CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
							CUThread *pUThread = g_mapThread.Lookup(dwCurrentThreadID);
							if(pUThread)
							{
								pUThread->m_dwRequestProcessedTime = ::GetTickCount();
							}
						}
						break;
					case WM_SET_PRETRANS_FUNC:
						PreTranslateMessage = (PPRETRANSLATEMESSAGE)msg.wParam;
						{
							CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
							CUThread *pUThread = g_mapThread.Lookup(dwCurrentThreadID);
							if(pUThread)
							{
								pUThread->m_dwRequestProcessedTime = ::GetTickCount();
							}
						}
						break;
					case WM_SET_PROCESSING_FUNC:
						SlowProcess = (PSLOW_PROCESS)msg.wParam;
						ThreadDying = (PTHREAD_DYING)msg.lParam;
						{
							CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
							CUThread *pUThread = g_mapThread.Lookup(dwCurrentThreadID);
							if(pUThread)
							{
								pUThread->m_dwRequestProcessedTime = ::GetTickCount();
							}
						}
						break;
					case WM_ASK_FOR_PROCESSING:
						{
							unsigned short usRequestID = GetCurrentRequestId(msg.lParam);
							SOCKET hSocket = msg.lParam;
							try
							{
								{
									CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
									CUThread *pUThread = g_mapThread.Lookup(dwCurrentThreadID);
									if(pUThread)
									{
										pUThread->m_bIsOnIdle = false;
									}
								}
								if(SlowProcess)
								{
									if(usRequestID)
									{
										dwRtn = SlowProcess(usRequestID, msg.wParam, hSocket);
									}
								}
								{
									CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
									CUThread *pUThread = g_mapThread.Lookup(dwCurrentThreadID);
									if(pUThread)
									{
										if(pUThread->m_pUClient != NULL)
										{
											if(pUThread->m_pUClient == g_pSocketSvr->FindClient(hSocket) && TA != taApartment)
											{
												pUThread->m_pUClient->m_pUThread = NULL;
												pUThread->m_pUClient = NULL;
											}
										}
										pUThread->m_bIsOnIdle = true;
										pUThread->m_dwRequestProcessedTime = ::GetTickCount();
									}
								}
								while(!UPostMessage(g_pSocketSvr->GetWin(), WM_REQUEST_PROCESSED, msg.lParam, usRequestID))
								{
									::Sleep(1);
								}
							}
							catch(...)
							{
		//						::MessageBox(NULL, "Exception happens in OnSlowRequest", "Exception", MB_OK);
								WCHAR strError[256] = {0};
								DWORD dwError = ::GetLastError();
								CUQueue	tempQueue;
								HRESULT hr = ERROR_UEXCEPTION_CAUGHT;
								{
									CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
									CUClient   *pUClient = g_pSocketSvr->FindClient(hSocket);
									if(pUClient)
									{
										ULONG ulLen = pUClient->GetCurrentRequestLen();
										if(ulLen>tempQueue.GetMaxSize())
											tempQueue.ReallocBuffer(ulLen);
										if(ulLen)
										{
											pUClient->GetRecvBuffer((BYTE*)tempQueue.GetBuffer(), ulLen);
											tempQueue.SetSize(0);
										}
									}
								}
								tempQueue.Push(&hr);
								::swprintf(strError, L"Exception is caught, and error code = %d.", dwError);
								tempQueue.Push(strError);
								::SendReturnData(hSocket, usRequestID, tempQueue.GetSize(), tempQueue.GetBuffer());	
								{
									CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
									CUThread *pUThread = g_mapThread.Lookup(dwCurrentThreadID);
									
									if(pUThread)
									{
										pUThread->m_bIsOnIdle = true;
										if(pUThread->m_pUClient != NULL)
										{
											if(pUThread->m_pUClient == g_pSocketSvr->FindClient(hSocket) && TA != taApartment)
											{
												pUThread->m_pUClient->m_pUThread = NULL;
												pUThread->m_pUClient = NULL;
											}
										}
										pUThread->m_dwRequestProcessedTime = ::GetTickCount();
									}
								}
								while(!UPostMessage(g_pSocketSvr->GetWin(), WM_REQUEST_PROCESSED, msg.lParam, usRequestID))
								{
									::Sleep(1);
								}
							}
						}
						break;
					case WM_QUIT:
						::PostQuitMessage(0);
						break;
					default:
						ATLASSERT(FALSE);
						break;
					}
					{
						CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
						nSize = pUThread->m_UMsgQueue.GetCount();
					}
				}
			}
				break;
			case WM_QUIT:
				break;
			default:
				break;
			}
			if(msg.message == WM_QUIT)
				break;
		}while(true);
	}
	catch(...)
	{
		dwRtn = ::GetLastError();
		ATLTRACE("Thread catches an exception with %d.\n", dwRtn);
	}
#ifdef USE_MESSAGE_PUMP_WORKERTHREAD
	bSuc = ::KillTimer(NULL, nTimer/*::GetCurrentThreadId()*/);
#endif
	ATLASSERT(bSuc);
	try
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		CUThread *pUThread = g_mapThread.Lookup(dwCurrentThreadID);
		if(pUThread)
			pUThread->m_bIsOnIdle = true;
	}
	catch(...)
	{
		dwRtn = ::GetLastError();
		ATLTRACE("Thread catches an exception with %d.\n", dwRtn);
	}
	if(ThreadDying)
		ThreadDying();
	if(TA == taApartment || TA == taFree)
	{
		::CoUninitialize();
	}
	try
	{
		if(g_pSocketSvr)
		{
			while(!UPostMessage(g_pSocketSvr->GetWin(), WM_WORKER_THREAD_DYING, dwCurrentThreadID, dwRtn))
			{
				::Sleep(1);
			}
		}
	}
	catch(...)
	{
	}
	return dwRtn;
}


CUThread::CUThread()
{
	m_hThread = NULL;
	m_dwThreadId = 0;
	m_bSuicidable = true;
	m_dwMaxIdleTime = DEFAULT_MAX_IDLE_TIME;
	m_dwRequestProcessedTime = 0;
	m_bIsOnIdle = true;
	m_ThreadStarted = NULL;
	m_PreTranslateMessage = NULL;
	m_SlowProcess = NULL;
	m_ThreadDying = NULL;
	m_TA = taNone;
	m_pUClient = NULL;
	m_ulSvsID = 0;
	m_hSocket = INVALID_SOCKET;
	m_OnThreadCreated = NULL;
	m_hWaitEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
	ATLASSERT(m_hWaitEvent != NULL);
}

CUThread::~CUThread()
{
	KillThread();
	if(m_hThread)
	{
		::CloseHandle(m_hThread);
	}
	if(m_hWaitEvent != NULL)
	{
		::CloseHandle(m_hWaitEvent);
	}
}

DWORD CUThread::GetThreadId()
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	return m_dwThreadId;
}

DWORD CUThread::KillThread(DWORD dwWaitTime)
{
	if(m_hThread == NULL)
	{
		ATLASSERT(m_dwThreadId==0);
		return WAIT_OBJECT_0;
	}
	DWORD dwObject = WAIT_OBJECT_0;
	{
		unsigned long ul = 0;
//		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
kt:		if(m_hThread && (dwObject=::WaitForSingleObject(m_hThread, 0)) != WAIT_OBJECT_0)
		{
			ATLASSERT(m_dwThreadId);
			while(!PostThreadMessage(WM_QUIT, 0, 0))
			{
				ul++;
				::Sleep(1);
				if(ul>5)
					break;
				goto kt;
			}
			dwObject = ::WaitForSingleObject(m_hThread, dwWaitTime);
			if(dwObject != WAIT_TIMEOUT)
			{
				::CloseHandle(m_hThread);
				m_hThread = NULL;
				m_dwThreadId = 0;
			}
		}
	}
	return dwObject;
}

enumThreadApartment CUThread::GetTA()
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	return m_TA;
}

bool CUThread::CreateThread(DWORD dwCreationFlags, DWORD dwStackSize)
{
	m_dwRequestProcessedTime = ::GetTickCount();
	ATLASSERT(m_dwThreadId == 0 && m_hThread == NULL);
	::ResetEvent(g_hThreadEvent);
	m_hThread = ::CreateThread(NULL, dwStackSize, UThreadProc, this, dwCreationFlags, &m_dwThreadId);
	if(!m_hThread)
		return false;
	if(m_OnThreadCreated)
	{
		ULONG ulCount = RemoveLock();
		m_OnThreadCreated(m_ulSvsID, m_dwThreadId, m_hSocket);
		Relock(ulCount);
	}
	ATLASSERT(m_dwThreadId);
	::WaitForSingleObject(g_hThreadEvent, INFINITE);
	return true;
}

HANDLE CUThread::GetThread() const
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	return m_hThread;
}

bool CUThread::AskForProcessing(unsigned long ulBufferLen, DWORD dwUsedBy)
{
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		if(!m_hThread || !m_dwThreadId || ::WaitForSingleObject(m_hThread, 0) != WAIT_TIMEOUT)
			return false;
		m_bIsOnIdle = false;
	}
	while(!PostThreadMessage(WM_ASK_FOR_PROCESSING, ulBufferLen, dwUsedBy))
	{
		::Sleep(1);
	}
	
	return true;
}

DWORD CUThread::GetRequestProcessedTime()
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	return m_dwRequestProcessedTime;
}

bool CUThread::IsOnIdle()
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	return m_bIsOnIdle;
}

BOOL CUThread::PostThreadMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	MSG msg;
	msg.hwnd = NULL;
	msg.message = uMsg;
	msg.wParam = wParam;
	msg.lParam = lParam;
	msg.time = ::GetTickCount();
	msg.pt.x = 0;
	msg.pt.y = 0;
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		m_UMsgQueue.PushMsg(msg);
	}
	return ::SetEvent(m_hWaitEvent);
}

bool CUThread::ResetSlowProcess()
{
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		if(!m_hThread || !m_dwThreadId || ::WaitForSingleObject(m_hThread, 0) != WAIT_TIMEOUT)
			return false;
	}
	while(!PostThreadMessage(WM_SET_PROCESSING_FUNC, (WPARAM)m_SlowProcess, (LPARAM)m_ThreadDying))
	{
		ATLASSERT(FALSE);
		::Sleep(1);
	}
	return true;
}

void CUThread::SetMaxIdleTime(DWORD dwMaxIdleTime)
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	if(dwMaxIdleTime<MIN_IDLE_TIME)
		dwMaxIdleTime = MIN_IDLE_TIME;
	m_dwMaxIdleTime = dwMaxIdleTime;
}

DWORD CUThread::GetMaxIdleTime()
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	return m_dwMaxIdleTime;
}

CThreadPool::CThreadPool()
{
	m_ulSvsID = 0;
	m_hSocket = INVALID_SOCKET;
	m_OnThreadCreated = NULL;
	g_mapThread.RemoveAll();
	g_hThreadEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);
}

CThreadPool::~CThreadPool()
{
	DestroyAllThread();
	::CloseHandle(g_hThreadEvent);
	g_mapThread.RemoveAll();
}

void CThreadPool::OnThreadDead(DWORD dwThreadId, DWORD dwRtn)
{
	CUThread *pUThread;
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	pUThread = g_mapThread.Lookup(dwThreadId);
	if(pUThread)
	{
		int nIndex = g_mapThread.FindVal(pUThread);
		ATLASSERT(nIndex!=-1);
		g_mapThread.m_aKey[nIndex] = 0;
		pUThread->m_bIsOnIdle = true;
		pUThread->m_TA = taNone;
		pUThread->m_dwMaxIdleTime = DEFAULT_MAX_IDLE_TIME;
		pUThread->m_ThreadStarted = NULL;
		pUThread->m_PreTranslateMessage = NULL;
		pUThread->m_SlowProcess = NULL;
		pUThread->m_ThreadDying = NULL;
		pUThread->m_bSuicidable = true;
		pUThread->m_dwRequestProcessedTime = 0;
		pUThread->m_dwThreadId = 0;
		pUThread->m_pUClient = NULL;
		if(pUThread->m_hThread)
		{
			::CloseHandle(pUThread->m_hThread);
			pUThread->m_hThread = NULL;
		}
	}
}

CUThread* CThreadPool::GetAThread(enumThreadApartment TA, PSLOW_PROCESS SlowProcess, PPRETRANSLATEMESSAGE PreTranslateMessage, PTHREAD_DYING ThreadDying, PTHREAD_STARTED ThreadStarted, bool bSuicidable, unsigned long ulMaxIdleTime)
{
	bool b;
	unsigned long ul;
	unsigned long ulCount;
	CUThread *pUThread = NULL;
	DWORD	dwNow = ::GetTickCount();
	if(ulMaxIdleTime < MIN_IDLE_TIME)
		ulMaxIdleTime = MIN_IDLE_TIME;
	do
	{
		if(TA != taApartment)
		{
			ulCount = g_mapThread.GetSize();
			for(ul=0; ul<ulCount; ul++)
			{
				pUThread = g_mapThread.GetValueAt(ul);
				ATLASSERT(pUThread);
				if(!pUThread->IsDead() && pUThread->GetThread() && pUThread->GetTA()==TA && pUThread->m_bIsOnIdle && dwNow-pUThread->GetRequestProcessedTime()<pUThread->GetMaxIdleTime()*3/4)
				{
					pUThread->m_dwRequestProcessedTime = dwNow;
					pUThread->m_bSuicidable = bSuicidable;
					pUThread->m_dwMaxIdleTime = ulMaxIdleTime;
					if(SlowProcess != pUThread->m_SlowProcess || ThreadDying != pUThread->m_ThreadDying)
					{
						pUThread->m_ThreadDying = ThreadDying;
						pUThread->m_SlowProcess = SlowProcess;
						b = pUThread->ResetSlowProcess();
						ATLASSERT(b);
					}
					
					if(pUThread->m_PreTranslateMessage != PreTranslateMessage)
					{
						pUThread->m_PreTranslateMessage = PreTranslateMessage;
						b = pUThread->ResetPreTransFunc();
						ATLASSERT(b);
					}
					return pUThread;
				}
			}
		}
		
		{
			DWORD dwThreadId = 0;
			ulCount = g_mapThread.GetSize();
			for(ul=0; ul<ulCount; ul++)
			{
				pUThread = g_mapThread.GetValueAt(ul);
				ATLASSERT(pUThread);
				if(pUThread->IsDead())
				{
					if(pUThread->m_hThread)
					{
						::CloseHandle(pUThread->m_hThread);
						pUThread->m_hThread = NULL;
						dwThreadId = pUThread->GetThreadId();
						pUThread->m_dwThreadId = 0;
					}
					pUThread->m_dwRequestProcessedTime = dwNow;
					pUThread->m_dwMaxIdleTime = ulMaxIdleTime;
					pUThread->m_bIsOnIdle = true;
					pUThread->m_ThreadStarted = ThreadStarted;
					pUThread->m_PreTranslateMessage = PreTranslateMessage;
					pUThread->m_SlowProcess = SlowProcess;
					pUThread->m_ThreadDying = ThreadDying;
					pUThread->m_TA = TA;
					if(TA==taApartment)
						pUThread->m_bSuicidable = false;
					else
						pUThread->m_bSuicidable = bSuicidable;
					pUThread->m_hSocket = m_hSocket;
					pUThread->m_OnThreadCreated = m_OnThreadCreated;
					pUThread->m_ulSvsID = m_ulSvsID;
					b = pUThread->CreateThread();
					g_mapThread.m_aKey[ul] = pUThread->GetThreadId();
					ATLASSERT(b);
					return pUThread;
				}
			}
		}
	}while(false);
	pUThread = new CUThread;
	pUThread->m_ThreadStarted = ThreadStarted;
	pUThread->m_PreTranslateMessage = PreTranslateMessage;
	pUThread->m_SlowProcess = SlowProcess;
	pUThread->m_ThreadDying = ThreadDying;
	pUThread->m_TA = TA;
	if(TA==taApartment)
		pUThread->m_bSuicidable = false;
	else
		pUThread->m_bSuicidable = bSuicidable;
	pUThread->m_dwMaxIdleTime = ulMaxIdleTime;
	pUThread->m_hSocket = m_hSocket;
	pUThread->m_OnThreadCreated = m_OnThreadCreated;
	pUThread->m_ulSvsID = m_ulSvsID;
	b = pUThread->CreateThread();
	ATLASSERT(b);
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		g_mapThread.Add(pUThread->GetThreadId(), pUThread);
	}
	return pUThread;
}

void CThreadPool::DestroyAllThread()
{
	unsigned long ul;
	DWORD dwThreadId;
	unsigned long ulCount = g_mapThread.GetSize();
	for(ul=0; ul<ulCount; ul++)
	{
		CUThread *pUThread = g_mapThread.GetValueAt(ul);
		dwThreadId= pUThread->GetThreadId();
		if(pUThread->KillThread(0)==WAIT_OBJECT_0)
		{
			CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
			if(g_mapThread.Remove(dwThreadId))
			{
				delete pUThread;
				ulCount--;
				ul--;
			}
		}
	}

	int nIndex = 0;

	while(g_mapThread.GetSize())
	{
		ulCount = g_mapThread.GetSize();
		for(ul=0; ul<ulCount; ul++)
		{
			CUThread *pUThread = g_mapThread.GetValueAt(ul);
			dwThreadId= pUThread->GetThreadId();
			ATLASSERT(pUThread && dwThreadId && pUThread->GetThread());
			DWORD dwRtn = ::WaitForSingleObject(pUThread->GetThread(), 0);
			if(dwRtn != WAIT_TIMEOUT)
			{
				CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
				pUThread = g_mapThread.GetValueAt(ul);
				if(pUThread)
				{
					try
					{
						if(g_mapThread.Remove(dwThreadId))
						{
							delete pUThread;
							ulCount--;
							ul--;
						}
					}
					catch(...)
					{
						ATLASSERT(FALSE);
						g_mapThread.Remove(dwThreadId);
						ulCount--;
						ul--;
					}
				}
			}
		}
		::Sleep(1);

		nIndex++;

		if(nIndex == 500)
			break;
//		break;
	}
	
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		g_mapThread.RemoveAll();
	}
	
//	ATLASSERT(g_mapThread.GetSize()==0);
}

bool CUThread::Cancel()
{
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		if(!m_hThread || !m_dwThreadId || ::WaitForSingleObject(m_hThread, 0) != WAIT_TIMEOUT)
			return false;
	}

	while(!PostThreadMessage(WM_CANCEL_REQUEST, 0, 0))
	{
		ATLASSERT(FALSE);
		::Sleep(1);
	}
	return true;
}

bool CUThread::IsDead()
{
//	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	if(!m_hThread)
	{
		ATLASSERT(!m_dwThreadId);
		return true;
	}
	DWORD dwState=::WaitForSingleObject(m_hThread, 0);
	return (dwState == WAIT_OBJECT_0);
}

bool CUThread::ResetPreTransFunc()
{
	{
		CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
		if(!m_hThread || !m_dwThreadId || ::WaitForSingleObject(m_hThread, 0) != WAIT_TIMEOUT)
			return false;
	}
	while(!PostThreadMessage(WM_SET_PRETRANS_FUNC, (WPARAM)m_PreTranslateMessage, 0))
	{
		ATLASSERT(FALSE);
		::Sleep(1);
	}
	return true;
}

void CThreadPool::EnableThreadSuicidable(DWORD dwThreadID, bool bSuicidable)
{
	CAutoLock	AutoLockGlobal(g_pSocketSvr->GetCriticalSection());
	CUThread *pUThread = g_mapThread.Lookup(dwThreadID);
	if(pUThread)
	{
		pUThread->m_bSuicidable = bSuicidable;
		pUThread->m_dwRequestProcessedTime = ::GetTickCount();
	}
}

DWORD CUThread::SuspendThread()
{
	return ::SuspendThread(m_hThread);
}

DWORD CUThread::ResumeThread()
{
	return ::ResumeThread(m_hThread);
}

int CUThread::GetThreadPriority()
{
	return ::GetThreadPriority(m_hThread);
}

bool CUThread::SetThreadPriority(int nPriority)
{
	return (::SetThreadPriority(m_hThread, nPriority) ? true : false);
}


