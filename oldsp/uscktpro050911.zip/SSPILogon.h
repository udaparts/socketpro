#ifndef __UDAPARTS_SSPI_LOGON_H___
#define __UDAPARTS_SSPI_LOGON_H___

#ifndef SEC_TCHAR
	#if defined(UNICODE) || defined(_UNICODE)
		#define SEC_TCHAR	SEC_WCHAR
	#else
		#define SEC_TCHAR	SEC_CHAR
	#endif
#endif

#ifndef SECURITY_WIN32
	#define SECURITY_WIN32
#endif

#include <windows.h>
#include <sspi.h>

class CSSPILogon
{
public:
	CSSPILogon(void);
	~CSSPILogon(void);

public:
	bool Logon(LPCWSTR strDomain, LPCWSTR strUserID, LPCWSTR strPassword);
	bool Logon(LPCSTR strDomain, LPCSTR strUserID, LPCSTR strPassword);

private:
	void LoadSecurityDll();
	void UnloadSecurityDll();

	typedef struct _AUTH_SEQ {
		BOOL fInitialized;
		BOOL fHaveCredHandle;
		BOOL fHaveCtxtHandle;
		CredHandle hcred;
		struct _SecHandle hctxt;
	} AUTH_SEQ, *PAUTH_SEQ;

	bool GenClientContextW(PAUTH_SEQ pAS, PSEC_WINNT_AUTH_IDENTITY_W pAuthIdentity, PVOID pIn, DWORD cbIn, PVOID pOut, PDWORD pcbOut, PBOOL pfDone);
	bool GenClientContextA(PAUTH_SEQ pAS, PSEC_WINNT_AUTH_IDENTITY_A pAuthIdentity, PVOID pIn, DWORD cbIn, PVOID pOut, PDWORD pcbOut, PBOOL pfDone);
	bool GenServerContext(PAUTH_SEQ pAS, PVOID pIn, DWORD cbIn, PVOID pOut, PDWORD pcbOut, PBOOL pfDone);

public:
	bool	m_bNT;
	bool	m_bNTLM;

private:
	ACCEPT_SECURITY_CONTEXT_FN       AcceptSecurityContext;
	COMPLETE_AUTH_TOKEN_FN           CompleteAuthToken;
	DELETE_SECURITY_CONTEXT_FN       DeleteSecurityContext;
	FREE_CONTEXT_BUFFER_FN           FreeContextBuffer;
	FREE_CREDENTIALS_HANDLE_FN       FreeCredentialsHandle;

	ACQUIRE_CREDENTIALS_HANDLE_FN_W    AcquireCredentialsHandleW;
	ACQUIRE_CREDENTIALS_HANDLE_FN_A    AcquireCredentialsHandleA;
	INITIALIZE_SECURITY_CONTEXT_FN_W   InitializeSecurityContextW;
	INITIALIZE_SECURITY_CONTEXT_FN_A   InitializeSecurityContextA;
	QUERY_SECURITY_PACKAGE_INFO_FN_W   QuerySecurityPackageInfoW;
	QUERY_SECURITY_PACKAGE_INFO_FN_A   QuerySecurityPackageInfoA;

	HMODULE			m_hModule;
	DWORD			m_cbMaxToken;
	OSVERSIONINFO	m_VerInfo;
	PVOID			m_pClientBuf;
	PVOID			m_pServerBuf;
};

#endif
