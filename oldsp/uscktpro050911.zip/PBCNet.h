#ifndef __PARALLEL_LOAD_BLANCE_CLUSTER_H__
#define __PARALLEL_LOAD_BLANCE_CLUSTER_H__

#include "AsyncHandler.h"
class CGridNet : public CSocketPoolEx<CAsyncHandler>
{
public:
	CGridNet(void);
	virtual ~CGridNet(void);

public:
	void RemoveJobs(unsigned int hSocketPeer);

protected:
	virtual void OnFailover(CAsyncHandler *pHandler);
	virtual void OnResultReturned(CAsyncHandler *pHandler, unsigned short usRequestId);
	virtual bool OnExecuteJob(CAsyncHandler *pHandler);

private:
	void CleanJobs();

private:
	CSimpleArray<CPeerJob*> m_aJob;
};


#endif
