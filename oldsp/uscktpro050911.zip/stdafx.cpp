#include "stdafx.h"

#include <iphlpapi.h>
#include "BlowfishGA.h"

bool	g_bRegistered;
long	g_lAdapter;
short	g_sAdapter;

#include "ULSocket.h"
#include "Startup.h"
extern CUListener	*g_pSocketSvr;
extern CStartup		*g_pStartup;
bool	g_bMachine = false;
unsigned long g_ulCallCount = 0;

ULONG GetOS()
{
	ULONG ulOs;
	BYTE bMajor, bMinor, bBuildNumber, bPlatform;
	OSVERSIONINFO	OsInfo;
	memset(&OsInfo, 0, sizeof(OSVERSIONINFO));
	OsInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	::GetVersionEx(&OsInfo);
	bMajor = (BYTE)OsInfo.dwMajorVersion;
	bMinor = (BYTE)OsInfo.dwMinorVersion;
	bBuildNumber = (BYTE)OsInfo.dwBuildNumber;
	bPlatform = (BYTE)OsInfo.dwPlatformId;
	ulOs = bPlatform*(0x1000000L) + bMajor*(0x10000L) + bMinor*(0x100L) + bBuildNumber;
	return ulOs;
}

void Char2Hex(const unsigned char ch, char* szHex)
{
	unsigned char byte[2];
	byte[0] = ch/16;
	byte[1] = ch%16;
	for(int i=0; i<2; i++)
	{
		if(byte[i] >= 0 && byte[i] <= 9)
			szHex[i] = '0' + byte[i];
		else
			szHex[i] = 'A' + byte[i] - 10;
	}
	szHex[2] = 0;
}

//Function to convert string of length 2 to unsigned char
void Hex2Char(const char* szHex, unsigned char& rch)
{
	rch = 0;
	for(int i=0; i<2; i++)
	{
		if(*(szHex + i) >='0' && *(szHex + i) <= '9')
			rch = (rch << 4) + (*(szHex + i) - '0');
		else if(*(szHex + i) >='A' && *(szHex + i) <= 'F')
			rch = (rch << 4) + (*(szHex + i) - 'A' + 10);
		else
			break;
	}
}    

//Function to convert string of unsigned chars to string of chars
void CharStr2HexStr(const unsigned char* pucCharStr, char* pszHexStr, int iSize)
{
	int i;
	char szHex[3];
	pszHexStr[0] = 0;
	for(i=0; i<iSize; i++)
	{
		Char2Hex(pucCharStr[i], szHex);
		strcat(pszHexStr, szHex);
	}
}

//Function to convert string of chars to string of unsigned chars
void HexStr2CharStr(const char* pszHexStr, unsigned char* pucCharStr, int iSize)
{
	int i;
	unsigned char ch;
	for(i=0; i<iSize; i++)
	{
		Hex2Char(pszHexStr+2*i, ch);
		pucCharStr[i] = ch;
	}
}

char*	FindUDASocketProKey(const char* strAdapter, char* &strLock)
{
	ATLASSERT(strAdapter);
	BYTE		pData[6]={0};
	strLock=NULL;
	static char strKey[25]={0};
	static char strLocker[25]={0};
	HINSTANCE	hInstance;
	DWORD		dwRtn;
	TCHAR		*strFirst = NULL;
	TCHAR		*strLast = NULL;
	TCHAR		cFirst = _T('\\');
	TCHAR		cLast = _T('.');
	TCHAR		strModuleFileName[513] = {0};
	TCHAR		strInterfaces[256] = {0};
	ULONG		ulCount=0;
	CRegKey	RegKey;
	CRegKey	SubKey;
	if(RegKey.Open(g_bMachine ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER, _T("Software"))!=S_OK)
		return strKey;

	if(RegKey.Open(RegKey.m_hKey, "UDAParts")!=S_OK)
		return strKey;

	if(RegKey.Open(RegKey.m_hKey, "SocketPro")!=S_OK)
		return strKey;
	
	hInstance=::GetModuleHandle(NULL);
	dwRtn=sizeof(strModuleFileName)/sizeof(TCHAR) - 1;
	dwRtn = ::GetModuleFileName(hInstance, strModuleFileName, dwRtn);
	strFirst = ::_tcsrchr(strModuleFileName, cFirst);
	strFirst++;

	int nApp = EnumApp(strFirst);

	strLast = ::_tcsrchr(strFirst, cLast);

	::_tcsncat_s(strInterfaces, strFirst, strLast-strFirst);
	::_tcsupr(strInterfaces);
	::_tcsupr(strLast);

	if(nApp > 1)
	{
		TCHAR strCount[10] = {0};
		::_itot_s(nApp-1, strCount, 10);
		::_tcscat_s(strInterfaces, strCount);
	}

	if(::_tcscmp(strLast, _T(".EXE")) != 0)
	{
		::_tcscat_s(strInterfaces,  strLast);
	}

	if(RegKey.Open(RegKey.m_hKey, strInterfaces)!=S_OK)
		return strKey;

	if(RegKey.Open(RegKey.m_hKey, strAdapter)!=S_OK)
		return strKey;
	{
		DWORD	dwCount=sizeof(strLocker);
		RegKey.QueryValue(strLocker, "Lock", &dwCount);
		dwCount=sizeof(strKey);
		RegKey.QueryValue(strKey, "Key", &dwCount);
		strLock=strLocker;
	}
	return strKey;
}

void CreateUDASocketProReg()
{
	DWORD		dwIndex;
	DWORD		dwRtn;
	HINSTANCE	hInstance;
	unsigned short  nData=0;
	TCHAR		*strFirst = NULL;
	TCHAR		*strLast = NULL;
	TCHAR		cFirst = _T('\\');
	TCHAR		cLast = _T('.');
	TCHAR		strModuleFileName[513]={0};
	TCHAR		strInterfaces[256]={0};
	BYTE		pData[6]={0};
	ULONG		ulCount=0;
	int			n;
	MIB_IFROW	mibIfRow;
	MIB_IFTABLE	*pMibIfTable=NULL;
	CRegKey	RegKey;
	if(RegKey.Open(g_bMachine ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER, _T("Software"))!=S_OK)
		RegKey.Create(g_bMachine ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER, _T("Software"));

	if(RegKey.Open(RegKey.m_hKey, _T("UDAParts"))!=S_OK)
		RegKey.Create(RegKey.m_hKey, _T("UDAParts"));

	if(RegKey.Open(RegKey.m_hKey, _T("SocketPro"))!=S_OK)
		RegKey.Create(RegKey.m_hKey, _T("SocketPro"));
	
	hInstance=::GetModuleHandle(NULL);
	dwRtn=sizeof(strModuleFileName)/sizeof(TCHAR) - 1;
	dwRtn = ::GetModuleFileName(hInstance, strModuleFileName, dwRtn);
	strFirst = ::_tcsrchr(strModuleFileName, cFirst);
	strFirst++;
	
	int nApp = EnumApp(strFirst);
	
	strLast = ::_tcsrchr(strFirst, cLast);
	strncat(strInterfaces, strFirst, strLast-strFirst);
	::_tcsupr(strLast);
	::_tcsupr(strInterfaces);
	
	if(nApp > 1)
	{
		TCHAR strCount[10] = {0};
		::_itot(nApp-1, strCount, 10);
		::_tcscat(strInterfaces, strCount);
	}

	if(::_tcscmp(strLast, _T(".EXE")) != 0)
	{
		::_tcscat(strInterfaces,  strLast);
	}

	if(RegKey.Open(RegKey.m_hKey, strInterfaces)!=S_OK)
		RegKey.Create(RegKey.m_hKey, strInterfaces);

//	strFirst = strrchr(strInterfaces, '_');
//	strFirst++;
	strFirst = strInterfaces;
	dwRtn=1;
	while(*strFirst)
	{
		nData= (*strFirst)*dwRtn;
		dwRtn++;
		strFirst++;
	}

	dwRtn=GetNumberOfInterfaces(&ulCount);
	dwRtn=10*1024*ulCount;
	pMibIfTable=(MIB_IFTABLE*)(new BYTE[dwRtn]);
	memset(pMibIfTable, 0, dwRtn);
	GetIfTable(pMibIfTable, &dwRtn, TRUE);
	for(dwIndex=0; dwIndex<ulCount; dwIndex++)
	{
//		memset(&mibIfRow, 0, sizeof(mibIfRow));
//		mibIfRow.dwIndex=dwIndex+1;
//		dwRtn = GetIfEntry(&mibIfRow);
		mibIfRow=pMibIfTable->table[dwIndex];
		if(/*mibIfRow.dwPhysAddrLen &&*/ mibIfRow.dwDescrLen && /*memcmp(mibIfRow.bPhysAddr, pData, 6)!=0 &&*/ mibIfRow.dwType!=23 /*&& mibIfRow.dwType!=24*/)
		{
			TCHAR   strHexValue[17]={0};
			CRegKey	SubKey;
			nApp = 1;
			for(n=0; n<nApp; n++)
			{
				BYTE bIndex = (BYTE)n;
				if(n > 255)
					bIndex = 255;
				memcpy(mibIfRow.bPhysAddr+6, &nData, sizeof(nData));
				mibIfRow.bPhysAddr[0] = bIndex;
				CharStr2HexStr(mibIfRow.bPhysAddr, strHexValue, 8);
				DWORD	dwCount=0;
				g_lAdapter=*((long*)(mibIfRow.bPhysAddr));
				g_sAdapter=*((short*)(mibIfRow.bPhysAddr+sizeof(long)));
				if(SubKey.Open(RegKey.m_hKey, (LPCTSTR)(mibIfRow.bDescr))!=S_OK)
				{
					
					SubKey.SetValue(RegKey.m_hKey, (LPCTSTR)(mibIfRow.bDescr), strHexValue, _T("Lock"));
					SubKey.SetValue(RegKey.m_hKey, (LPCTSTR)(mibIfRow.bDescr), _T(""), _T("Key"));
				}
				else
				{
					if(ERROR_SUCCESS!=SubKey.SetValue(RegKey.m_hKey, (LPCTSTR)(mibIfRow.bDescr), strHexValue, _T("Lock")))
					{
						if(pMibIfTable)
							delete []pMibIfTable;
						exit(0);
					}
				}
			}
		}
	}
	if(pMibIfTable)
		delete []pMibIfTable;
}

bool OpenLock()
{
	DWORD		dwIndex;
	DWORD		dwRtn;
	LPTSTR		strLock=NULL;
	LPTSTR		strKey={0};
	ULONG		ulCount=0;
	BYTE		pData[6]={0};
	MIB_IFROW	mibIfRow;
	MIB_IFTABLE	*pMibIfTable=NULL;
	bool bOpened=false;
	dwRtn=GetNumberOfInterfaces(&ulCount);
	dwRtn=10*1024*ulCount;
	pMibIfTable=(MIB_IFTABLE*)(new BYTE[dwRtn]);
	memset(pMibIfTable, 0, dwRtn);
	GetIfTable(pMibIfTable, &dwRtn, TRUE);
	for(dwIndex=0; dwIndex<ulCount; dwIndex++)
	{
//		memset(&mibIfRow, 0, sizeof(mibIfRow));
//		mibIfRow.dwIndex=dwIndex+1;
//		dwRtn = GetIfEntry(&mibIfRow);
		mibIfRow=pMibIfTable->table[dwIndex];
		if(/*mibIfRow.dwPhysAddrLen && */mibIfRow.dwDescrLen /*&& memcmp(mibIfRow.bPhysAddr, pData, 6)!=0*/)
		{
			strKey=FindUDASocketProKey((LPCTSTR)mibIfRow.bDescr, strLock);
			if(strKey && strLock && strlen(strKey)==16 && strlen(strLock)==16)
			{
				long plPrivateKeys[2];
				BYTE strOutLock[9]={0};
				BYTE strKeyIn[9]={0};
				plPrivateKeys[0]=SKEY1;
				plPrivateKeys[1]=SKEY2;
				HexStr2CharStr(strKey, (unsigned char*)strKeyIn, 8);
				CBlowFish	BlowFish((unsigned char*)plPrivateKeys, sizeof(plPrivateKeys));
				BlowFish.Decrypt((unsigned char*)strKeyIn, strOutLock, 8);
				if(memcmp(strOutLock, mibIfRow.bPhysAddr, 6)==0)
					bOpened=true;
			}	
		}
		if(bOpened)
			break;
	}
	if(pMibIfTable)
		delete []pMibIfTable;
	return bOpened;
}

bool CheckValid()
{
	USES_CONVERSION;
	DWORD   dwCount;
	LPTSTR	strKeyName;
	ULONG	lNowTime;
	SYSTEMTIME	SysTime;
	TCHAR	strValue[256]={0};
	TCHAR	strKey[7] = {_T('P'), _T('r'), _T('o'), _T('g'), _T('I'), _T('D'), 0};
	TCHAR	strTime[5] = {_T('d'), _T('%'), _T('d'), _T('d'), 0};
	CLSID clsidTimeKey = {0x81039CFD,0x2DBC,0xA2D5,{0x2A,0x63,0xB1,0x30,0x75,0xA0,0x24,0xA2}};
	clsidTimeKey.Data1=(g_lAdapter|clsidTimeKey.Data1);
	clsidTimeKey.Data2=(g_sAdapter|clsidTimeKey.Data2);
	clsidTimeKey.Data3=(g_sAdapter|clsidTimeKey.Data3);
	BYTE pByte[4];
	::memcpy(pByte, &g_lAdapter, 4);
	::memcpy(pByte, &g_sAdapter, 2);
	clsidTimeKey.Data4[0] = (clsidTimeKey.Data4[0] & pByte[0]);
	clsidTimeKey.Data4[2] = (clsidTimeKey.Data4[2] | pByte[1]);
	clsidTimeKey.Data4[4] = (clsidTimeKey.Data4[4] & pByte[2]);
	clsidTimeKey.Data4[6] = (clsidTimeKey.Data4[6] | pByte[3]);
	clsidTimeKey.Data4[1] = (clsidTimeKey.Data4[1] & pByte[3]);
	clsidTimeKey.Data4[3] = (clsidTimeKey.Data4[3] | pByte[2]);
	clsidTimeKey.Data4[5] = (clsidTimeKey.Data4[5] & pByte[1]);
	clsidTimeKey.Data4[7] = (clsidTimeKey.Data4[7] | pByte[0]);

	CComBSTR	bstrSubKey(clsidTimeKey);
	CRegKey	RegKey;
	::GetSystemTime(&SysTime);
	lNowTime=SysTime.wYear*365+SysTime.wMonth*31+SysTime.wDay;
	if(RegKey.Open(HKEY_CLASSES_ROOT, _T("CLSID"))!=S_OK)
		return false;
	strKeyName=OLE2T(bstrSubKey);
	if(RegKey.Open(RegKey.m_hKey, strKeyName)!=S_OK)
	{
		if(RegKey.Create(RegKey.m_hKey, strKeyName) != S_OK)
			return false;
		_stprintf(strValue, strTime /*_T("d%dd")*/, lNowTime);
		RegKey.SetKeyValue(strKey/*_T("ProgID")*/, strValue);
		return true;
	}
	RegKey.Open(RegKey.m_hKey, strKey/*_T("ProgID")*/);
	dwCount=sizeof(strValue);
	RegKey.QueryValue(strValue, NULL, &dwCount);
	dwCount=atoi(strValue+1);
	if(abs(lNowTime-dwCount)<31)
		return true;
	return false;
}

BOOL UPostMessage(
  HWND hWnd,      // handle of destination window
  UINT Msg,       // message to post
  WPARAM wParam,  // first message parameter
  LPARAM lParam   // second message parameter
)
{
/*	short nEvent = WSAGETSELECTEVENT(lParam);
	if(nEvent == FD_CLOSE)
	{
		int n;
		n = 0;
	}*/
	if(g_pSocketSvr != NULL)
	{
		if(g_pSocketSvr->m_bUseMessagePump)
		{
			return ::PostMessage(hWnd, Msg, wParam, lParam);
		}
		else
		{
			MSG msg;
			msg.wParam = wParam;
			msg.message = Msg;
			msg.hwnd = hWnd;
			msg.lParam = lParam;
			msg.time = ::GetTickCount();
			msg.pt.x = 0;
			msg.pt.y = 0;
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				g_pSocketSvr->m_UMsgQueue.PushMsg(msg);
			}
			if(g_pStartup->PostQueuedCompletionStatus(g_pSocketSvr->m_hCompletionPort, 0, (DWORD)g_pSocketSvr, &g_pSocketSvr->m_IOPortContext))
			{
				return true;
			}
		}
	}
	ATLASSERT(FALSE);
	return FALSE;
}

