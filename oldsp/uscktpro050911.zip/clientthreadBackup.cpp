#include "stdafx.h"
#include "ULSocket.h"
#include <winsock2.h>

#include "context.h"
#include "SHA1.h"
#include "ChatRoom.h"

extern CThreadPool	*g_pThreadPool;
extern CUQueue	g_chatQueue;
extern CUQueue	g_upQueue;

CUClientThreaded::CUClientThreaded()
{
	memset(&m_SockThreadContext, 0, sizeof(m_SockThreadContext));
	m_OnFastRequestArrive = NULL;
	m_OnRequestProcessed = NULL;
	m_OnClose = NULL;
	m_OnSwitchTo = NULL;
}

CUClientThreaded::~CUClientThreaded()
{

}

void CUClientThreaded::OnContinueProcessing(unsigned short usRequestID)
{
	OnRequestArrive(usRequestID, LEN_NOT_AVAILABLE);
}

void CUClientThreaded::OnRequestArrive(unsigned short usRequestID, unsigned long ulLen)
{
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	switch (usRequestID)
	{
	case idSwitchTo:
		{
			SvsSwitch(ulLen);
			//if(m_ClientInfo.m_usUSockMinor > 2 && m_HttpReqAttribute.m_HttpRequest == hrUnknown)
			//	m_bRegistered = true; //already notified messagebox at client side
		}
		break;
	case idXEnter:
	case idEnter:
	case idExit:
	case idGetAllGroups:
	case idGetAllListeners:
	case idSpeak:
	case idXSpeak:
	case idSpeakTo:
	case idSpeakEx:
	case idXSpeakEx:
	case idSpeakToEx:
	case idGetAllClients:
	case idSendUserMessage:
	case idSendUserMessageEx:
		{
//			CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
			if(GetSvsID() == sidStartup)
			{
				HRESULT lResult = uecUnexpected; 
				m_bProcessingSlowRequest = true;
				sendReturnData(usRequestID, sizeof(lResult), (unsigned char*)&lResult); 
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, ERROR_UNOT_SWITCHED_YET));
				return;
			}
			else
			{
				g_pSocketSvr->OnChatRequestArrive(m_hSocket, usRequestID, ulLen);
				OnBaseRequestCame(usRequestID);
			}
		}
		break;
	default:
		if(GetSvsID() == sidStartup)
		{
//			CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
			m_bProcessingSlowRequest = true;
			HRESULT lResult = uecUnexpected; 
			sendReturnData(usRequestID, sizeof(lResult), (unsigned char*)&lResult); 
			UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, ERROR_UNOT_SWITCHED_YET));
			return;	
		}

		g_ulCallCount++;

/*		if(g_ulPopCount > 50 && !m_bRegistered)
		{
			return;
		}*/
		if(IsSlowRequest(usRequestID))
		{
			CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
			m_bDropSlow = false;
			if(usRequestID != idStartJob && usRequestID != idEndJob)
			{
				OnBaseRequestCame(usRequestID);
			}
			if(!m_bDropSlow)
			{
				if(m_SockThreadContext.m_enumTA == taApartment)
				{
					if(m_pUThread)
					{
						ATLASSERT(m_pUThread->m_pUClient == this);
					}
					else
					{
						g_pThreadPool->m_hSocket = m_hSocket;
						g_pThreadPool->m_ulSvsID = m_ulSvsID;
						g_pThreadPool->m_OnThreadCreated = m_OnThreadCreated;
						m_pUThread = g_pThreadPool->GetAThread(m_SockThreadContext.m_enumTA,
							m_SockThreadContext.m_SlowProcess, m_SockThreadContext.m_PreTranslateMessage,
							m_SockThreadContext.m_ThreadDying, m_SockThreadContext.m_ThreadStarted, false, g_pSocketSvr->m_ulMaxThreadIdleTimeBeforeSuicide);
					}
				}
				else
				{
					g_pThreadPool->m_hSocket = m_hSocket;
					g_pThreadPool->m_ulSvsID = m_ulSvsID;
					g_pThreadPool->m_OnThreadCreated = m_OnThreadCreated;
					m_pUThread = g_pThreadPool->GetAThread(m_SockThreadContext.m_enumTA,
						m_SockThreadContext.m_SlowProcess, m_SockThreadContext.m_PreTranslateMessage,
						m_SockThreadContext.m_ThreadDying, m_SockThreadContext.m_ThreadStarted, true, g_pSocketSvr->m_ulMaxThreadIdleTimeBeforeSuicide);
				}
				m_StreamHeader.m_nRequestID = usRequestID;
				m_pUThread->m_pUClient = this;
				m_bProcessingSlowRequest = true;
				m_pUThread->AskForProcessing(GetCurrentRequestLen(), m_hSocket);
			}
		}
		else
		{
//			CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
			OnFastRequestArrive(usRequestID, ulLen);
			DebugCheck();
		}
		break;
	}
}

void CUClientThreaded::OnRequestProcessed(unsigned short usRequestID)
{
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_OnRequestProcessed)
	{
		ULONG ulCount = RemoveLock();
		m_OnRequestProcessed(m_hSocket, usRequestID);
		Relock(ulCount);
	}
	if(IsSlowRequest(usRequestID))
	{
		if(m_SockThreadContext.m_enumTA == taApartment)
		{
		}
		else
		{
			m_pUThread = NULL;
		}
	}
	CUClient::OnRequestProcessed(usRequestID);
}

void CUClientThreaded::RetrieveClientSwitchInfo(unsigned long ulLen)
{
	if(m_HttpReqAttribute.m_HttpRequest != hrUnknown && !m_HttpReqAttribute.m_bHeaderSent)
	{
		FakeSwitchToHttp();
		if(!g_pSocketSvr->m_RegInfo.m_bWeb)
			m_bRegistered = false;
		return;
	}
	CUQueue	&qTemp = g_upQueue;
	unsigned short usLen = 0;
	
	qTemp.SetSize(0);
	if(ulLen > qTemp.GetMaxSize())
		qTemp.ReallocBuffer(ulLen);
	
	GetRecvBuffer((BYTE*)qTemp.GetBuffer(), ulLen);
	qTemp.SetSize(ulLen);
	qTemp.Pop(&m_ClientInfo);

	if(!m_bLocal && m_bRegistered)
	{
		if((m_ClientInfo.m_ulParam2 & 1) != 0)
		{
			if(!g_pSocketSvr->m_RegInfo.m_bWeb)
				m_bRegistered = false;
		}

		if((m_ClientInfo.m_ulParam2 & 2) != 0)
		{
			if(!g_pSocketSvr->m_RegInfo.m_bUnix)
				m_bRegistered = false;
		}

		if((m_ClientInfo.m_ulParam2 & 4) != 0)
		{
			if(!g_pSocketSvr->m_RegInfo.m_bOther)
				m_bRegistered = false;
		}

		if((m_ClientInfo.m_ulParam1 >> 24) == 3) //VER_PLATFORM_WIN32_CE
		{
			if(!g_pSocketSvr->m_RegInfo.m_bSmartDevice)
				m_bRegistered = false;
		}
	}
	

	if(!m_bSameEndian)
	{
/*		m_ClientInfo.m_ulSvsID = ::htonl(m_ClientInfo.m_ulSvsID);
		m_ClientInfo.m_ulParam1 = ::htonl(m_ClientInfo.m_ulParam1);
		m_ClientInfo.m_ulParam2 = ::htonl(m_ClientInfo.m_ulParam1);
		m_ClientInfo.m_ulParam3 = ::htonl(m_ClientInfo.m_ulParam1);
		m_ClientInfo.m_ulParam4 = ::htonl(m_ClientInfo.m_ulParam1);
		m_ClientInfo.m_ulParam5 = ::htonl(m_ClientInfo.m_ulParam1);
		m_ClientInfo.m_usVerMajor = ::htons(m_ClientInfo.m_usVerMajor);
		m_ClientInfo.m_usVerMinor = ::htons(m_ClientInfo.m_usVerMinor);
		m_ClientInfo.m_usUSockMajor = ::htons(m_ClientInfo.m_usUSockMajor);
		m_ClientInfo.m_usUSockMinor = ::htons(m_ClientInfo.m_usUSockMinor);*/
	}
	
	qTemp.Pop(&usLen);
	if(!m_bSameEndian)
	{
		usLen = ::htons(usLen);
	}
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(usLen)
	{
		m_strUID = (WCHAR*)::realloc(m_strUID, usLen+sizeof(WCHAR));	
		qTemp.Pop((BYTE*)m_strUID, usLen);
		m_strUID[usLen/sizeof(WCHAR)] = 0;
	}
	else
	{
		if(m_strUID)
		{
			::free(m_strUID);
			m_strUID = NULL;
		}
	}
	qTemp.Pop(&usLen);
	if(!m_bSameEndian)
	{
		usLen = ::htons(usLen);
	}
	if(usLen)
	{
		m_strPassword = (WCHAR*)::realloc(m_strPassword, usLen+sizeof(WCHAR));
		qTemp.Pop((BYTE*)m_strPassword, usLen);
		m_strPassword[usLen/sizeof(WCHAR)] = 0;
	}
	else
	{
		CleanPassword();
	}
	if(ulLen > 0)
	{
		memset((BYTE*)qTemp.GetBuffer(), 0, ulLen);
	}
}

bool CUClientThreaded::IsPermitted(unsigned long ulSvsID)
{
	ULONG ulCount = RemoveLock();
	if(g_pSocketSvr->m_bSharedAM && m_ulSvsID != sidStartup && ulSvsID != 0 && m_ulSvsID != sidHTTP)
	{
		CleanPassword();
		if(g_pSocketSvr->m_OnIsPermitted != NULL)
		{
			g_pSocketSvr->m_OnIsPermitted(m_hSocket, ulSvsID);
		
		}
		if(m_OnIsPermitted)
		{
			m_OnIsPermitted(m_hSocket, ulSvsID);
		}
		Relock(ulCount);
		return true;
	}
	bool bOk = false;
	switch(g_pSocketSvr->m_am)
	{
	case amOwn:
		if(g_pSocketSvr->m_EncryptionMethod == BlowFish && !m_bVerify)
		{
			::CoCreateGuid(&m_guid);
		}
		if(g_pSocketSvr->m_OnIsPermitted != NULL)
		{
			bOk = g_pSocketSvr->m_OnIsPermitted(m_hSocket, ulSvsID);
		}
		if(g_pSocketSvr->m_EncryptionMethod == BlowFish && bOk)
		{
			if(!m_bVerify)
			{
				bOk = false;
				do
				{
					if(m_strPassword == NULL || ::wcslen(m_strPassword) == 0)
						break;
					if(m_pBlowFish != NULL)
					{
						delete m_pBlowFish;
						m_pBlowFish = NULL;
					}
					m_Sha1.HashPassword2(m_strPassword, m_guid);
					BYTE strKey[20];
					m_Sha1.GetHash((UINT_8*)strKey);
					m_pBlowFish = new CBF(strKey, 20);
					::memset(strKey, 0, sizeof(strKey));
					m_bKeyLen = 20;
					m_Sha1.HashPassword(m_strPassword, m_guid);
					bOk = true;
				}while(false);
			}
			else
			{
				bOk = true;
			}
		}
		CleanPassword();
		if(m_OnIsPermitted)
		{
			m_OnIsPermitted(m_hSocket, ulSvsID);
		}
		break;
	case amIntegrated:
		if(m_HttpReqAttribute.m_HttpRequest != hrUnknown)
		{
			if(g_pSocketSvr->m_OnIsPermitted != NULL)
			{
				bOk = g_pSocketSvr->m_OnIsPermitted(m_hSocket, ulSvsID);
			}
			if(m_OnIsPermitted)
			{
				m_OnIsPermitted(m_hSocket, ulSvsID);
			}
		}
		else
		{
			if(g_pSocketSvr->m_EncryptionMethod != BlowFish)
			{
				bOk = DoSSPI();
			}
			else
			{
				bOk = false;
			}
			CleanPassword();
			if(g_pSocketSvr->m_OnIsPermitted != NULL)
			{
				g_pSocketSvr->m_OnIsPermitted(m_hSocket, ulSvsID);
			}
			if(m_OnIsPermitted)
			{
				m_OnIsPermitted(m_hSocket, ulSvsID);
			}
		}
		break;
	case amMixed:
		if(g_pSocketSvr->m_EncryptionMethod != BlowFish)
		{
			if(m_HttpReqAttribute.m_HttpRequest != hrUnknown)
			{
				if(g_pSocketSvr->m_OnIsPermitted != NULL)
				{
					bOk = g_pSocketSvr->m_OnIsPermitted(m_hSocket, ulSvsID);
				}
			}
			else
			{
				if(g_pSocketSvr->m_OnIsPermitted != NULL)
				{
					bOk = g_pSocketSvr->m_OnIsPermitted(m_hSocket, ulSvsID);
				}
				if(!bOk)
				{
					bOk = DoSSPI();
				}
			}
		}
		else
		{
			bOk = false;
		}
		CleanPassword();
		if(m_OnIsPermitted)
		{
			m_OnIsPermitted(m_hSocket, ulSvsID);
		}
		break;
	default:
		break;
	}
	Relock(ulCount);
	return bOk;
}

bool CUClientThreaded::XSpeak(const VARIANT &vtMsg, const VARIANT &vtGroups)
{
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	if(!(vtGroups.vt == (VT_ARRAY|VT_INT)||vtGroups.vt == (VT_ARRAY|VT_UINT)||vtGroups.vt == (VT_ARRAY|VT_I4)||vtGroups.vt == (VT_ARRAY|VT_UI4)))
		return false;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	g_chatQueue.SetSize(0);
	g_chatQueue.PushVT(vtGroups);
	g_chatQueue.PushVT(vtMsg);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idXSpeak;
	OnRequestArrive(idXSpeak, m_StreamHeader.m_ulLen);
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::Speak(const VARIANT &vtMsg, unsigned long ulGroups)
{
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	g_chatQueue.SetSize(0);
	g_chatQueue.Push(&ulGroups);
	g_chatQueue.PushVT(vtMsg);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idSpeak;
	OnRequestArrive(idSpeak, g_chatQueue.GetSize());
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::SpeakToEx(const BYTE *pMessage, unsigned long ulLen, CUClientThreaded *pUClientThreaded)
{
	unsigned int	unPort;
	unsigned long	ulAddr;
	LPSTR			strPeer;
	ULONG			ulPrev;
	unsigned short	usRequestIDPrev;
	if(pMessage == NULL)
		ulLen = 0;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(!pUClientThreaded || pUClientThreaded->m_hSocket == INVALID_SOCKET || pUClientThreaded != g_pSocketSvr->FindClient(pUClientThreaded->m_hSocket))
		return false;
	g_chatQueue.SetSize(0);
	pUClientThreaded->GetPeerName(unPort, strPeer);
	ulAddr = ::inet_addr(strPeer);
	g_chatQueue.Push(&ulAddr);
	if(!m_bSameEndian)
	{
		unPort = ::htonl(unPort);
	}
	g_chatQueue.Push(&unPort);
	g_chatQueue.Push(pMessage, ulLen);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idSpeakToEx;
	OnRequestArrive(idSpeakToEx, g_chatQueue.GetSize());
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::XSpeakEx(const BYTE *pMessage, unsigned long ulLen, unsigned long ulGroupCount, const unsigned long *pGroups)
{
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	if(pMessage == NULL)
		ulLen = 0;
	if(pGroups == NULL || ulGroupCount == 0)
		return false;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	g_chatQueue.SetSize(0);
	g_chatQueue.Push(&ulLen);
	g_chatQueue.Push(pMessage, ulLen);
	g_chatQueue.Push((const unsigned char*)pGroups, ulGroupCount*sizeof(unsigned long));
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idXSpeakEx;
	OnRequestArrive(idXSpeakEx, m_StreamHeader.m_ulLen);
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::SpeakEx(const BYTE *pMessage, unsigned long ulLen, unsigned long ulGroups)
{
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	if(pMessage == NULL)
		ulLen = 0;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	g_chatQueue.SetSize(0);
	if(!m_bSameEndian)
	{
		ulGroups = ::htonl(ulGroups);
	}
	g_chatQueue.Push(&ulGroups);
	g_chatQueue.Push(pMessage, ulLen);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idSpeakEx;
	OnRequestArrive(idSpeakEx, g_chatQueue.GetSize());
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::SendUserMessageEx(LPCWSTR strUserID, const BYTE *pMessage, unsigned long ulLen)
{
	if(strUserID == NULL || wcslen(strUserID) == 0)
		return false;
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	g_chatQueue.SetSize(0);
	g_chatQueue << strUserID;
	g_chatQueue.Push(pMessage, ulLen);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idSendUserMessageEx;
	OnRequestArrive(idSendUserMessageEx, g_chatQueue.GetSize());
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::SendUserMessage(LPCWSTR strUserID, const VARIANT& vtMsg)
{
	if(strUserID == NULL || wcslen(strUserID) == 0)
		return false;
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	g_chatQueue.SetSize(0);
	g_chatQueue << strUserID;
	g_chatQueue.PushVT(vtMsg);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idSendUserMessage;
	OnRequestArrive(idSendUserMessage, g_chatQueue.GetSize());
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::SpeakTo(const VARIANT& vtMsg, CUClientThreaded *pUClientThreaded)
{
	unsigned int	unPort;
	unsigned long	ulAddr;
	LPSTR			strPeer;
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(!pUClientThreaded || pUClientThreaded->m_hSocket == INVALID_SOCKET || pUClientThreaded != g_pSocketSvr->FindClient(pUClientThreaded->m_hSocket))
		return false;
	g_chatQueue.SetSize(0);
	pUClientThreaded->GetPeerName(unPort, strPeer);
	ulAddr = ::inet_addr(strPeer);
	g_chatQueue.Push(&ulAddr);
	g_chatQueue.Push(&unPort);
	g_chatQueue.PushVT(vtMsg);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idSpeakTo;
	OnRequestArrive(idSpeakTo, g_chatQueue.GetSize());
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

void CUClientThreaded::OnFastRequestArrive(unsigned short usRequestID, unsigned long ulLen)
{
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	if(m_OnFastRequestArrive)
	{
		ULONG ulCount = RemoveLock();
		m_OnFastRequestArrive(m_hSocket, usRequestID, ulLen);
		Relock(ulCount);
	}
}

bool CUClientThreaded::Exit()
{
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = 0;
	m_StreamHeader.m_nRequestID = idExit;
	OnRequestArrive(idExit, 0);
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::XEnter(const VARIANT *pvtGroups)
{
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	if(pvtGroups == NULL)
		return false;
	if(!(pvtGroups->vt == (VT_ARRAY|VT_INT) || pvtGroups->vt == (VT_ARRAY|VT_UINT) || pvtGroups->vt == (VT_ARRAY|VT_I4) || pvtGroups->vt == (VT_ARRAY|VT_UI4)))
		return false;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	g_chatQueue.SetSize(0);
	g_chatQueue.PushVT(*pvtGroups);
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(g_chatQueue.GetBuffer(), g_chatQueue.GetSize());
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = g_chatQueue.GetSize();
	m_StreamHeader.m_nRequestID = idXEnter;
	OnRequestArrive(idXEnter, m_StreamHeader.m_ulLen);
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

bool CUClientThreaded::Enter(unsigned long ulGroup)
{
	ULONG ulPrev;
	unsigned short usRequestIDPrev;
	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	m_dwTimeTrackRcv = ::GetTickCount();
	m_rcvQueue.Insert(&ulGroup);
	ulPrev = m_StreamHeader.m_ulLen;
	usRequestIDPrev = m_StreamHeader.m_nRequestID;
	m_StreamHeader.m_ulLen = sizeof(ulGroup);
	m_StreamHeader.m_nRequestID = idEnter;
	OnRequestArrive(idEnter, sizeof(ulGroup));
	m_StreamHeader.m_ulLen = ulPrev;
	m_StreamHeader.m_nRequestID = usRequestIDPrev;
	return true;
}

LPCWSTR CUClientThreaded::HTTPEnter(VARIANT vtGroups, DWORD dwLeaseTime, const wchar_t *strIpAddr)
{
	USES_CONVERSION;
	GUID guid;
	CoCreateGuid(&guid);
	unsigned int nPeerPort = 0;
	LPSTR strPeerName = NULL;
	in_addr in;
	if(strIpAddr != NULL && ::wcslen(strIpAddr) > 0 && ::wcslen(strIpAddr) < 64)
	{
		unsigned long ulAddr = inet_addr(OLE2A(strIpAddr));
		if(ulAddr != INADDR_NONE)
		{
			in.S_un.S_addr = ulAddr;
			strPeerName = ::inet_ntoa(in);
		}
	}
	if(strPeerName == NULL)
		GetPeerName(nPeerPort, strPeerName);
	if(dwLeaseTime < g_pSocketSvr->m_ulTimerElapse*4)
		dwLeaseTime = g_pSocketSvr->m_ulTimerElapse*4;
	CWebChatContext *p = new CWebChatContext(guid, strPeerName, dwLeaseTime);
	p->m_bstrUserId = m_strUID;
	p->m_vtGroups = vtGroups;
	m_pHttpChatContext = p;
	XEnter(&vtGroups);
	CScopeUQueue sq;
	g_pSocketSvr->Merge(vtGroups, *sq);
	p->m_vtGroups.Clear();
	unsigned long ulSize = sq->GetSize()/sizeof(unsigned long);
	if(ulSize)
	{
		void *pData;
		SAFEARRAYBOUND sab[1] = {ulSize, 0};
		p->m_vtGroups.vt = (VT_ARRAY|VT_UI4);
		p->m_vtGroups.parray = ::SafeArrayCreate(VT_UI4, 1, sab);
		::SafeArrayAccessData(p->m_vtGroups.parray, &pData);
		::memcpy(pData, sq->GetBuffer(), sq->GetSize());
		::SafeArrayUnaccessData(p->m_vtGroups.parray);
	}
	g_pSocketSvr->HTTPEnter(p);
	return p->GetHTTPPushSessionId().m_str;
}

bool CUClientThreaded::HTTPExit(LPCWSTR strPushSessionId)
{
	unsigned int nPeerPort;
	LPSTR strPeerName = NULL;
	GetPeerName(nPeerPort, strPeerName);
	CComBSTR bstrUserId;
	CComVariant vtGroups;
	g_pSocketSvr->HTTPExit(strPushSessionId, strPeerName, bstrUserId, vtGroups);
	if(vtGroups.vt == (VT_ARRAY|VT_UI4) || vtGroups.vt == (VT_ARRAY|VT_I4) || vtGroups.vt == (VT_ARRAY|VT_UINT) || vtGroups.vt == (VT_ARRAY|VT_INT))
	{
		ULONG	n, j;
		ULONG	nCount, jSize;
		ULONG	*pGroups;
		CSimpleArray<CChatGroup> *pChat = g_pSocketSvr->m_pChat;
		nCount=pChat->GetSize();
		jSize = vtGroups.parray->rgsabound->cElements;	
		::SafeArrayAccessData(vtGroups.parray, (void**)&pGroups);
		for(j=0; j<jSize; j++)
		{
			for(n=0; n<nCount; n++)
			{
				DWORD	dwGroup=(*pChat)[n].m_nID;
				if(pGroups[j] == dwGroup)
				{
					if(m_HttpReqAttribute.m_HttpRequest != hrUnknown)
						(*pChat)[n].m_Listeners.Add(m_hSocket);
				}
			}
		}
		::SafeArrayUnaccessData(vtGroups.parray);
		CComBSTR bstr = m_strUID;
		::SetUserID(m_hSocket, bstrUserId.m_str);
		Exit();
		::SetUserID(m_hSocket, bstr.m_str);
		return true;
	}
	return false;
}

bool CUClientThreaded::HTTPSendUserMessage(LPCWSTR strPushSessionId, LPCWSTR strUserID, const VARIANT& vtMsg)
{
	unsigned int nPeerPort;
	LPSTR strPeerName = NULL;
	GetPeerName(nPeerPort, strPeerName);
	
	if(g_pSocketSvr->HTTPSendUserMessage(strPushSessionId, strPeerName, strUserID, vtMsg))
	{
		CComBSTR bstr(m_strUID);
		m_HttpReqAttribute.m_ulChatGroups = 0;
		CWebChatContext *pSource = g_pSocketSvr->Seek(strPushSessionId, strPeerName);
		if(pSource)
		{
/*
			m_HttpReqAttribute.m_ulChatGroups = pSource->m_ulGroups; 
*/
			::SetUserID(m_hSocket, pSource->m_bstrUserId.m_str);
		}
		else
		{
			::SetUserID(m_hSocket, L"");
		}
		SendUserMessage(strUserID, vtMsg);
		::SetUserID(m_hSocket, bstr.m_str);
		return true;
	}
	return false;
}

bool CUClientThreaded::HTTPSpeak(LPCWSTR strPushSessionId, const VARIANT& vtMsg, const VARIANT &vtGroups)
{
	unsigned int nPeerPort;
	LPSTR strPeerName = NULL;
	GetPeerName(nPeerPort, strPeerName);
	if(g_pSocketSvr->HTTPSpeak(strPushSessionId, strPeerName, vtMsg, vtGroups))
	{
		CComBSTR bstr(m_strUID);
		m_HttpReqAttribute.m_ulChatGroups = 0;
		CWebChatContext *pSource = g_pSocketSvr->Seek(strPushSessionId, strPeerName);
		::SetUserID(m_hSocket, pSource->m_bstrUserId.m_str);
		XSpeak(vtMsg, vtGroups);
		::SetUserID(m_hSocket, bstr.m_str);
		return true;
	}
	return false;
}

bool CUClientThreaded::HTTPSubscribe(const wchar_t* strPushSessionId, unsigned long ulTimeout, const wchar_t *strCrossSiteJSCallback)
{
	unsigned int nPeerPort;
	LPSTR strPeerName = NULL;
	GetPeerName(nPeerPort, strPeerName);
	CWebChatContext *pWCC = g_pSocketSvr->HTTPSubscribe(strPushSessionId, strPeerName);
	if(pWCC == NULL)
		return false;
	
	if(ulTimeout > pWCC->GetLeaseTime())
		ulTimeout =  pWCC->GetLeaseTime();

	if(ulTimeout && ulTimeout < g_pSocketSvr->m_ulTimerElapse)
		ulTimeout = g_pSocketSvr->m_ulTimerElapse;
	
	pWCC->m_ulTimeout = ulTimeout;
	pWCC->m_hSocket = m_hSocket;
	pWCC->m_bstrJSCallback = strCrossSiteJSCallback;
	if(pWCC->GetCountMessages() || ulTimeout == 0)
		pWCC->AddMsg(NULL);
	return true;
}

bool CUClientThreaded::IsSlowRequest(unsigned short usRequestID)
{
	unsigned long ulSvsID = GetSvsID();
//	CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
	int nIndex = g_pSocketSvr->m_mapSvsSlowRequest.FindKey(ulSvsID);
	if(nIndex == -1)
		return false;
	CRequestArray &aSlowRequest = g_pSocketSvr->m_mapSvsSlowRequest.GetValueAt(nIndex);
	return (aSlowRequest.Find(usRequestID) != -1);
}

//native SOCKET messages
void CUClientThreaded::OnClose(int nError)
{
	if(m_hSocket != INVALID_SOCKET)
	{
		CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());

		if(GetSvsID() == sidHTTP)
			g_pSocketSvr->ShutdownHTTP(m_hSocket);

		m_dwTimeTrackRcv = ::GetTickCount();
		if(g_pSocketSvr->GetJoinedGroup(m_hSocket))
		{
			g_pSocketSvr->OnChatRequestArrive(m_hSocket, idExit, 0);
			OnBaseRequestCame(idExit);
		}
		ULONG ulCount = RemoveLock();
		if(m_OnClose)
		{
			m_OnClose(m_hSocket, nError);
		}
		if(g_pSocketSvr->m_OnClose)
		{
			g_pSocketSvr->m_OnClose(m_hSocket, nError);
		}
		Relock(ulCount);
	}
	{
		CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
		if(m_SockThreadContext.m_enumTA == taApartment)
		{
			if(m_pUThread)
			{
				m_pUThread->KillThread(0);
			}
		}
	}
	{
		SOCKADDR_IN sockAddr;
		int nSockAddrLen = sizeof(sockAddr);
		int rtn = ::getpeername(m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
		CAutoLock	AutoLock(g_pSocketSvr->GetCriticalSection());
		if(rtn == 0)
		{
			unsigned long addr = sockAddr.sin_addr.S_un.S_addr;
			int index = CUListener::m_mapAddrCount.FindKey(addr);
			if(index != -1)
			{
				unsigned long &ulCount = CUListener::m_mapAddrCount.GetValueAt(index);
				ATLASSERT(ulCount > 0);
				ulCount--;
			}
			else
			{
				ATLASSERT(false);
			}
		}
		else
		{
			ATLASSERT(false);
		}
		CUClient::OnClose(nError);
	}
}


