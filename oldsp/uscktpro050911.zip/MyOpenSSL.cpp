// MyOpenSSL.cpp: implementation of the CMyOpenSSL class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MyOpenSSL.h"
#include "Startup.h"
#include "ulsocket.h"

extern CStartup	*g_pStartup;
extern CUListener	*g_pSocketSvr;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyOpenSSL::CMyOpenSSL(SSL_CTX *pContext, bool bClient)
{
	m_hSocket = 0;
	m_pSSL = g_pStartup->SSL_new(pContext);
    m_pBioIn = g_pStartup->BIO_new(g_pStartup->BIO_s_mem());
	m_pBioOut = g_pStartup->BIO_new(g_pStartup->BIO_s_mem());
	g_pStartup->SSL_set_bio(m_pSSL, m_pBioIn, m_pBioOut);
	if(bClient)
	{
		g_pStartup->SSL_set_connect_state(m_pSSL);
	}
	else
	{
		g_pStartup->SSL_set_accept_state(m_pSSL);	
	}
	m_bClient = bClient;
}

CMyOpenSSL::~CMyOpenSSL()
{
	g_pStartup->SSL_free(m_pSSL);
}

bool CMyOpenSSL::IsSSLConnected()
{

	return (g_pStartup->SSL_state(m_pSSL) & SSL_ST_OK) ? true : false;
}

int CMyOpenSSL::GetSSLState()
{
	return g_pStartup->SSL_state(m_pSSL);
}

BIO* CMyOpenSSL::GetBioIn()
{
	return g_pStartup->SSL_get_rbio(m_pSSL);
}

int CMyOpenSSL::Shutdown(CUQueue &qOut)
{
	int res = 0;
	g_pStartup->SSL_shutdown(m_pSSL);
	if(g_pStartup->BIO_ctrl_pending(m_pBioOut))
	{
		qOut.SetHeadPosition();
		if(qOut.GetMaxSize() - qOut.GetSize() < STATIC_BUFFER_SIZE/4)
		{
			qOut.ReallocBuffer(qOut.GetMaxSize() + STATIC_BUFFER_SIZE/4);
		}
		res = g_pStartup->BIO_read(m_pBioOut, (unsigned char*)qOut.GetBuffer() + qOut.GetSize(), qOut.GetMaxSize() - qOut.GetSize());
		if(res > 0)
		{
			qOut.SetSize(qOut.GetSize() + res);
		}
	}
	return res;
}

int CMyOpenSSL::DoHandshake(const void *pBuffer, unsigned int nLen, CUQueue &qOut)
{
	int res;
	int nState = GetSSLState();
	if( nState & SSL_ST_BEFORE)
	{
		if(m_bClient)
			res = g_pStartup->SSL_connect(m_pSSL);
		else
			res = g_pStartup->SSL_accept(m_pSSL);
		if(res < 0)
		{
			const char *strError = g_pStartup->SSL_state_string_long(m_pSSL);
			ATLTRACE(strError);
			ATLTRACE("\n");
			res = g_pStartup->SSL_get_error(m_pSSL, res);
			if(res == SSL_ERROR_WANT_READ || res == SSL_ERROR_WANT_WRITE)
			{
				unsigned char pBuffer[4096];
				int res = g_pStartup->BIO_read(m_pBioOut, pBuffer, sizeof(pBuffer));
				if(res > 0)
				{
					qOut.Push(pBuffer, (unsigned long)res);
					return res;
				}
				else
				{
					ATLASSERT(FALSE);
				}
			}
			else
			{
				ATLASSERT(FALSE);
			}
		}
		else
		{
			ATLASSERT(FALSE);
		}
	}
	else if(nState & SSL_ST_INIT)
	{
		res = g_pStartup->BIO_write(m_pBioIn, pBuffer, nLen);
		if(m_bClient)
			res = g_pStartup->SSL_connect(m_pSSL);
		else
			res = g_pStartup->SSL_accept(m_pSSL);
		if(res < 0)
		{
			const char *strError = g_pStartup->SSL_state_string_long(m_pSSL);
			ATLTRACE(strError);
			ATLTRACE("\n");
			res = g_pStartup->SSL_get_error(m_pSSL, res);
			if(res == SSL_ERROR_WANT_READ || res == SSL_ERROR_WANT_WRITE)
			{
				unsigned char pBuffer[8*1460];
				res = g_pStartup->BIO_read(m_pBioOut, pBuffer, sizeof(pBuffer));
				if(res > 0)
				{
					qOut.Push(pBuffer, (unsigned long)res);
					return res;
				}
			}
			else
			{
				UPostMessage(g_pSocketSvr->GetWin(), WM_SOCKET_SVR_NOTIFY, m_hSocket, WSAMAKESELECTREPLY(FD_CLOSE, seSSLError));
//				ATLASSERT(FALSE);
			}
		}
		else if(res == 1)
		{
			ATLASSERT(IsSSLConnected());
			if(!m_bClient)
			{
				unsigned char pBuffer[8*1460];
				res = g_pStartup->BIO_read(m_pBioOut, pBuffer, sizeof(pBuffer));
				if(res > 0)
				{
					qOut.Push(pBuffer, (unsigned long)res);
					return res;
				}
			}
		}
		else
		{
			ATLASSERT(FALSE);
		}
	}
	else 
	{
		ATLASSERT(FALSE);
	}
	return 0;
}

int CMyOpenSSL::Encrypt(const void *pBuffer, unsigned int nSize)
{
	int nLen = 0;
	int res = g_pStartup->SSL_write(m_pSSL, pBuffer, nSize);
	while(g_pStartup->BIO_ctrl_pending(m_pBioOut) || res > 0)
	{
		m_qOut.SetHeadPosition();
		if(m_qOut.GetMaxSize() - m_qOut.GetSize() < STATIC_BUFFER_SIZE)
		{
			m_qOut.ReallocBuffer(m_qOut.GetMaxSize() + STATIC_BUFFER_SIZE);
		}
		res = g_pStartup->BIO_read(m_pBioOut, (unsigned char*)m_qOut.GetBuffer() + m_qOut.GetSize(), m_qOut.GetMaxSize() - m_qOut.GetSize());
		if(res > 0)
		{
			m_qOut.SetSize(m_qOut.GetSize() + res);
			nLen += res;
		}
		else
		{
			break;
		}
		res = 0;
	}
	return nLen;
}

CUQueue& CMyOpenSSL::GetOut()
{
	return m_qOut;
}

int CMyOpenSSL::Decrypt(const void *pBuffer, unsigned int nSize, CUQueue &qOut)
{
	int nLen = 0;
	int res = g_pStartup->BIO_write(m_pBioIn, pBuffer, nSize);
	while(g_pStartup->BIO_ctrl_pending(m_pBioIn))
	{
		qOut.SetHeadPosition();
		if(qOut.GetMaxSize() - qOut.GetSize() < STATIC_BUFFER_SIZE)
		{
			qOut.ReallocBuffer(qOut.GetMaxSize() + STATIC_BUFFER_SIZE);
		}
		res = g_pStartup->SSL_read(m_pSSL, (unsigned char*)qOut.GetBuffer() + qOut.GetSize(), qOut.GetMaxSize() - qOut.GetSize());
		if(res > 0)
		{
			qOut.SetSize(qOut.GetSize() + res);
			nLen += res;
		}
		else
		{
			break;
		}
		res = 0;
	}
	return nLen;	
}