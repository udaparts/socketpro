#ifndef	__USOCKET_SERVER_CONTEXT_H__
#define __USOCKET_SERVER_CONTEXT_H__

#include "uqueue.h"
#include "UThread.h"
#include "BlowfishGA.h"

#define	RCV_BATCH_SIZE		(6*1460)
#define SND_BATCH_SIZE		RCV_BATCH_SIZE

extern CThreadPool		*g_pThreadPool;
extern CUQueue			g_tempQueue;
extern CUQueue			g_tempQueueSnd;

struct CReqPos
{
	CStreamHeader	m_StreamHeader;
	unsigned long	m_ulPos;
};

#pragma pack(push,1)
struct CRtnNormal
{
	HRESULT		m_hr;
	CSwitchInfo m_SwitchInfo;
};
#pragma pack(pop)

#endif