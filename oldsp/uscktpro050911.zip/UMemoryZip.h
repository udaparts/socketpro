
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0280 */
/* at Sat Jan 17 12:05:54 2004
 */
/* Compiler settings for E:\uskt\UMemoryZip\UMemoryZip.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __UMemoryZip_h__
#define __UMemoryZip_h__

/* Forward Declarations */ 

#ifndef __IUZip_FWD_DEFINED__
#define __IUZip_FWD_DEFINED__
typedef interface IUZip IUZip;
#endif 	/* __IUZip_FWD_DEFINED__ */


#ifndef __UZip_FWD_DEFINED__
#define __UZip_FWD_DEFINED__

#ifdef __cplusplus
typedef class UZip UZip;
#else
typedef struct UZip UZip;
#endif /* __cplusplus */

#endif 	/* __UZip_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IUZip_INTERFACE_DEFINED__
#define __IUZip_INTERFACE_DEFINED__

/* interface IUZip */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IUZip;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D032E20C-D30F-45B8-8ADE-CB828E393DC1")
    IUZip : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Zip( 
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pSource[  ],
            /* [out][in] */ unsigned long __RPC_FAR *pulSize,
            /* [size_is][in] */ BYTE __RPC_FAR pDest[  ]) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Unzip( 
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pSource[  ],
            /* [out][in] */ unsigned long __RPC_FAR *pulSize,
            /* [size_is][in] */ BYTE __RPC_FAR pDest[  ]) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUZipVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUZip __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUZip __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUZip __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Zip )( 
            IUZip __RPC_FAR * This,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pSource[  ],
            /* [out][in] */ unsigned long __RPC_FAR *pulSize,
            /* [size_is][in] */ BYTE __RPC_FAR pDest[  ]);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Unzip )( 
            IUZip __RPC_FAR * This,
            /* [in] */ unsigned long ulLen,
            /* [size_is][in] */ BYTE __RPC_FAR pSource[  ],
            /* [out][in] */ unsigned long __RPC_FAR *pulSize,
            /* [size_is][in] */ BYTE __RPC_FAR pDest[  ]);
        
        END_INTERFACE
    } IUZipVtbl;

    interface IUZip
    {
        CONST_VTBL struct IUZipVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUZip_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUZip_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUZip_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUZip_Zip(This,ulLen,pSource,pulSize,pDest)	\
    (This)->lpVtbl -> Zip(This,ulLen,pSource,pulSize,pDest)

#define IUZip_Unzip(This,ulLen,pSource,pulSize,pDest)	\
    (This)->lpVtbl -> Unzip(This,ulLen,pSource,pulSize,pDest)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUZip_Zip_Proxy( 
    IUZip __RPC_FAR * This,
    /* [in] */ unsigned long ulLen,
    /* [size_is][in] */ BYTE __RPC_FAR pSource[  ],
    /* [out][in] */ unsigned long __RPC_FAR *pulSize,
    /* [size_is][in] */ BYTE __RPC_FAR pDest[  ]);


void __RPC_STUB IUZip_Zip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IUZip_Unzip_Proxy( 
    IUZip __RPC_FAR * This,
    /* [in] */ unsigned long ulLen,
    /* [size_is][in] */ BYTE __RPC_FAR pSource[  ],
    /* [out][in] */ unsigned long __RPC_FAR *pulSize,
    /* [size_is][in] */ BYTE __RPC_FAR pDest[  ]);


void __RPC_STUB IUZip_Unzip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUZip_INTERFACE_DEFINED__ */



#ifndef __UMEMORYZIPLib_LIBRARY_DEFINED__
#define __UMEMORYZIPLib_LIBRARY_DEFINED__

/* library UMEMORYZIPLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_UMEMORYZIPLib;

EXTERN_C const CLSID CLSID_UZip;

#ifdef __cplusplus

class DECLSPEC_UUID("CCAB78F0-F0CC-4ED5-8339-8E1224350268")
UZip;
#endif
#endif /* __UMEMORYZIPLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


