// MsgHolder.cpp: implementation of the CMsgHolder class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "uscktpro.h"
#include "MsgHolder.h"
#include "ULSocket.h"
#include "AsyncHandler.h"

extern CSimpleMap<SOCKET, CUClient*> g_mapUClient;

bool WINAPI SetHTTPResponseHeader(unsigned int hSocket, const char *strUTF8Header, const char *strUTF8HeaderValue)
{
	if(g_pSocketSvr != NULL)
	{
		CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
		CUClient* pClient = g_pSocketSvr->FindClient(hSocket);
		if(pClient != NULL)
		{
			return pClient->SetHTTPResponseHeader(strUTF8Header, strUTF8HeaderValue);
		}
	}
	return false;
}

unsigned long WINAPI SendReturnData(unsigned int hSocket, unsigned short usRequestId, unsigned long ulLen, const unsigned char* pBuffer)
{
	CUClient *pUClient;
	ULONG	ulMaxSpeed;
	bool	bZip;
	DWORD dwThreadID = ::GetCurrentThreadId();
	DWORD dwMainThreadID = GetMainThreadID();
	if(dwThreadID != dwMainThreadID)
	{
		do
		{
			if(IsCanceled())
			{
				ATLTRACE("Request Canceled!\n");
				return REQUEST_CANCELED;
			}
			{
				CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
				pUClient = g_mapUClient.Lookup(hSocket);
				if(!pUClient || pUClient->m_bClosing)
					return SOCKET_NOT_FOUND;

				if(pUClient->m_ulSpeed == 0)
				{
					unsigned long ulMTU;
					unsigned long ulType;
					unsigned long ulMask;
					pUClient->GetInterfaceAttributes(ulMTU, pUClient->m_ulSpeed, ulType, ulMask);
					if(pUClient->m_ulSpeed > 100000000)
						pUClient->m_ulSpeed = 100000000;
				}
				ulMaxSpeed = pUClient->m_ulSpeed;
	
				bZip = pUClient->m_bZip;
				if(pUClient->IsBatching())
					break;
				if(pUClient->GetSndBytesInQueue() < ((bZip ? 10000 : 100000) + ulMaxSpeed/(bZip ? 10000 : 1000)))
				{
					break;
				}
				else
				{
					pUClient->Send();
				}
			}
			::Sleep(5);
		}while(true);
	}

	CAutoLock AutoLock(g_pSocketSvr->GetCriticalSection());
	pUClient = g_mapUClient.Lookup(hSocket);
	if(!pUClient || pUClient->m_bClosing)
		return SOCKET_NOT_FOUND;
	return pUClient->sendReturnData(usRequestId, ulLen, pBuffer);
}

void CAsyncHandler::OnResultReturned(unsigned short usRequestID, CUQueue &UQueue)
{
	{
		CAutoLock al(&g_cs.m_sec);
		if(m_PeerJob.m_hSocketPeer == 0)
			return;
	}

	SendReturnData(m_PeerJob.m_hSocketPeer, usRequestID, UQueue.GetSize(), UQueue.GetBuffer());
	UQueue.SetSize(0);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMsgHolder::CMsgHolder(BSTR bstrSender, unsigned long ipAddr, int nPort, unsigned long ulSvsID)
{
	m_lRef = 0;
	m_bstrSender = bstrSender;
	m_ipAddr = ipAddr;
	m_ulSvsID = ulSvsID;
	m_nPort = nPort;
}

CMsgHolder::~CMsgHolder()
{

}

LONG CMsgHolder::AddRef()
{
	return ::InterlockedIncrement(&m_lRef);
}

LONG CMsgHolder::Release()
{
	LONG lRef = ::InterlockedDecrement(&m_lRef);
	if(lRef == 0)
	{
		delete this;
	}
	return lRef;
}

CUQueue* CMsgHolder::GetUQueue()
{
	return &(*m_UQueue);
}

void CMsgHolder::Push(const SYSTEMTIME &st)
{
	char str[64] = {0};
	::sprintf(str, "%d-%02d-%02dT%02d:%02d:%02dZ", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
	m_UQueue->Push(str);
}

void CMsgHolder::Push(BSTR bstr)
{
	ATLASSERT(bstr != NULL);
	int nBytes = ::WideCharToMultiByte(CP_UTF8, 0, bstr, -1, NULL, 0, NULL, NULL);
	CScopeUQueue su;
	if((unsigned long)nBytes > su->GetMaxSize())
	{
		su->ReallocBuffer((unsigned long)nBytes);
	}
	int nGet = ::WideCharToMultiByte(CP_UTF8, 0, bstr, -1, (LPSTR)su->GetBuffer(), nBytes, NULL, NULL);
	ATLASSERT(nGet == nBytes);
	m_UQueue->Push(su->GetBuffer(), nBytes - 1);
}

void CMsgHolder::Push(const VARIANT &vtMessage)
{
	__int64 lData = 0;
	if((vtMessage.vt & VT_ARRAY) == VT_ARRAY)
	{
		void *pBuffer;
		VARTYPE vt =  vtMessage.vt - VT_ARRAY;
		unsigned long n;
		unsigned long nCount = vtMessage.parray->rgsabound[0].cElements;
		m_UQueue->Push("[");
		::SafeArrayAccessData(vtMessage.parray, &pBuffer);
		for(n=0; n<nCount; n++)
		{
			if(n)
				m_UQueue->Push(",");
			switch(vt)
			{
			case VT_NULL:
			case VT_EMPTY:
				m_UQueue->Push("null");
				break;
			case VT_CY:
				{
					CComVariant vtCY(((CY*)pBuffer)[n]);
					Push(vtCY);
				}
				break;
			case VT_DECIMAL:
				{
					CComVariant vtDecimal;
					vtDecimal.vt = vt;
					vtDecimal.decVal = ((DECIMAL*)pBuffer)[n];
					Push(vtDecimal);
				}
				break;
			case VT_BOOL:
				{
					VARIANT_BOOL vtBool = ((VARIANT_BOOL*)pBuffer)[n];
					if(vtBool == VARIANT_FALSE)
						m_UQueue->Push("false");
					else
						m_UQueue->Push("true");	
				}		
				break;
			case VT_BSTR:
				{
					BSTR bstr = ((BSTR*)pBuffer)[n];
					if(bstr == NULL)
						m_UQueue->Push("null");
					else
					{
						m_UQueue->Push("\"");
						Push(bstr);
						m_UQueue->Push("\"");
					}
				}
				break;
			case VT_UI8:
				{
					char str[64] = {0};
					_ui64toa(((unsigned __int64*)pBuffer)[n], str, 10);
					m_UQueue->Push(str);
				}
				break;
			case VT_R4:
				{
					char str[64] = {0};
					::sprintf(str, "%f", ((float*)pBuffer)[n]);
					m_UQueue->Push(str);
				}
				break;
			case VT_R8:
				{
					char str[64] = {0};
					::sprintf(str, "%f", ((double*)pBuffer)[n]);
					m_UQueue->Push(str);
				}
				break;
			case VT_I1:
			case VT_UI1:
			case VT_I2:
			case VT_UI2:
			case VT_I4:
			case VT_UI4:
			case VT_INT:
			case VT_UINT:
			case VT_I8:
				switch(vt)
				{
				case VT_I1:
					lData = ((char*)pBuffer)[n];
					break;
				case VT_UI1:
					lData = ((unsigned char*)pBuffer)[n];
					break;
				case VT_I2:
					lData = ((short*)pBuffer)[n];
					break;
				case VT_UI2:
					lData = ((unsigned short*)pBuffer)[n];
					break;
				case VT_I4:
					lData = ((long*)pBuffer)[n];
					break;
				case VT_UI4:
					lData = ((unsigned long*)pBuffer)[n];
					break;
				case VT_INT:
					lData = ((int*)pBuffer)[n];
					break;
				case VT_UINT:
					lData = ((unsigned int*)pBuffer)[n];
					break;
				case VT_I8:
					lData = ((__int64*)pBuffer)[n];
					break;
				default:
					ATLASSERT(FALSE);
					break;
				}
				{
					char str[64] = {0};
					_i64toa(lData, str, 10);
					m_UQueue->Push(str);
				}
				break;
			case VT_DATE:
				{
					SYSTEMTIME st;
					::VariantTimeToSystemTime(((DATE*)pBuffer)[n], &st);
					m_UQueue->Push("\"");
					Push(st);
					m_UQueue->Push("\"");
				}
				break;
			case VT_FILETIME:
				{
					SYSTEMTIME st;
					::FileTimeToSystemTime((FILETIME*)pBuffer + n, &st);
					m_UQueue->Push("\"");
					Push(st);
					m_UQueue->Push("\"");
				}
				break;
			case VT_VARIANT:
				Push(((VARIANT*)pBuffer)[n]);
				break;
			default:
				ATLASSERT(false); //not implemented
				m_UQueue->Push("null");
				break;
			}
		}
		::SafeArrayUnaccessData(vtMessage.parray);
		m_UQueue->Push("]");
	}
	else
	{
		switch(vtMessage.vt)
		{
		case VT_NULL:
		case VT_EMPTY:
			m_UQueue->Push("null");
			break;
		case VT_I1:
		case VT_UI1:
		case VT_I2:
		case VT_UI2:
		case VT_I4:
		case VT_UI4:
		case VT_INT:
		case VT_UINT:
		case VT_I8:
			switch(vtMessage.vt)
			{
			case VT_I1:
				lData = vtMessage.cVal;
				break;
			case VT_UI1:
				lData = vtMessage.bVal; 
				break;
			case VT_I2:
				lData = vtMessage.iVal; 
				break;
			case VT_UI2:
				lData = vtMessage.uiVal; 
				break;
			case VT_I4:
				lData = vtMessage.lVal; 
				break;
			case VT_UI4:
				lData = vtMessage.ulVal; 
				break;
			case VT_INT:
				lData = vtMessage.intVal; 
				break;
			case VT_UINT:
				lData = vtMessage.uintVal; 
				break;
			case VT_I8:
				lData = vtMessage.llVal; 
				break;
			default:
				ATLASSERT(FALSE);
				break;
			}
			{
				char str[64] = {0};
				_i64toa(lData, str, 10);
				m_UQueue->Push(str);
			}
			break;
		case VT_UI8:
			{
				char str[64] = {0};
				_ui64toa(vtMessage.ullVal, str, 10);
				m_UQueue->Push(str);
			}
			break;
		case VT_R4:
			{
				char str[64] = {0};
				::sprintf(str, "%f", vtMessage.fltVal);
				m_UQueue->Push(str);
			}
			break;
		case VT_R8:
			{
				char str[64] = {0};
				::sprintf(str, "%f", vtMessage.dblVal);
				m_UQueue->Push(str);
			}
			break;
		case VT_CY:
		case VT_DECIMAL:
			{
				USES_CONVERSION;
				CComVariant vtStr;
				::VariantChangeType(&vtStr, (VARIANT*)&vtMessage, VARIANT_NOVALUEPROP, VT_BSTR);
				m_UQueue->Push(OLE2A(vtStr.bstrVal));
			}
			break;
		case VT_BOOL:
			if(vtMessage.boolVal == VARIANT_FALSE)
				m_UQueue->Push("false");
			else
				m_UQueue->Push("true");		
			break;
		case VT_BSTR:
			if(vtMessage.bstrVal == NULL)
				m_UQueue->Push("null");
			else
			{
				m_UQueue->Push("\"");
				Push(vtMessage.bstrVal);
				m_UQueue->Push("\"");
			}
			break;
		case VT_DATE:
			{
				SYSTEMTIME st;
				::VariantTimeToSystemTime(vtMessage.date, &st);
				m_UQueue->Push("\"");
				Push(st);
				m_UQueue->Push("\"");
			}
			break;
		case VT_FILETIME:
			{
				SYSTEMTIME st;
				::FileTimeToSystemTime((FILETIME*)&vtMessage.llVal, &st);
				m_UQueue->Push("\"");
				Push(st);
				m_UQueue->Push("\"");
			}
			break;
		default:
			ATLASSERT(false); //not implemented
			m_UQueue->Push("null");
			break;
		}
	}
}

void CMsgHolder::PushMessage(const char *strMethodName, const VARIANT &vtMessage)
{
	int n;

	m_UQueue->Push("{");

	//sender user id
	m_UQueue->Push("\"sender\":");
	if(m_bstrSender.m_str == NULL)
		m_UQueue->Push("null");	
	else
	{
		m_UQueue->Push("\"");
		Push(m_bstrSender);
		m_UQueue->Push("\"");
	}
	
	//service id
	m_UQueue->Push(",");
	m_UQueue->Push("\"serviceId\":");
	char str[64] = {0};
	::_ui64toa(m_ulSvsID, str, 10);
	m_UQueue->Push(str);
	
	//ip address
	m_UQueue->Push(",");
	m_UQueue->Push("\"ip\":\"");
	BYTE *pIp = (BYTE*)&m_ipAddr;
	for(n=0; n<4; ++n)
	{
		if(n > 0)
			m_UQueue->Push(".");
		BYTE b = pIp[n];
		{
			char strB[16] = {0};
			_itoa(b, strB, 10);
			m_UQueue->Push(strB);
		}
	}
	m_UQueue->Push("\"");

	//port
	m_UQueue->Push(",");
	m_UQueue->Push("\"port\":");
	memset(str, 0, sizeof(str));
	_itoa(m_nPort, str, 10);
	m_UQueue->Push(str);

	//Groups
	m_UQueue->Push(",");
	m_UQueue->Push("\"groups\":[");

	int nSize = m_qGroup->GetSize()/sizeof(unsigned long);
	int *pData = (int*)m_qGroup->GetBuffer();
	for(n=0; n<nSize; n++)
	{
		if(n)m_UQueue->Push(",");
		memset(str, 0, sizeof(str));
		_itoa(pData[n], str, 10);
		m_UQueue->Push(str);
	}
	m_UQueue->Push("],");
	m_UQueue->Push("\"method\":\"");
	m_UQueue->Push(strMethodName);
	m_UQueue->Push("\"");

	//message
	m_UQueue->Push(",");
	m_UQueue->Push("\"msg\":");
	Push(vtMessage);

	m_UQueue->Push(",");
	m_UQueue->Push("\"dt\":");

	SYSTEMTIME st;
	::GetSystemTime(&st);
	m_UQueue->Push("\"");
	Push(st);
	m_UQueue->Push("\"}");
//	m_UQueue->Push("}");
}

CWebChatContext::CWebChatContext(const GUID &guid, LPSTR ipAddr, DWORD dwLeaseTime) : m_bstrGuid(guid)
{
	m_ipAddr = ipAddr;
	m_dwLastSentTime = ::GetTickCount();
	m_dwLeaseTime = dwLeaseTime;
	m_hSocket = 0;
	m_ulTimeout = 0;
	m_ulWhy = 0;
}

CWebChatContext::~CWebChatContext()
{
	ATLTRACE("*** CWebChatContext destroyed ***\n");
	RemoveAll();
}

void CWebChatContext::Init(const CWebChatContext& wsc)
{
	CAutoLock AutoLock(&g_cs.m_sec);
	m_bstrGuid = wsc.m_bstrGuid;
	m_ipAddr = wsc.m_ipAddr;
	m_dwLastSentTime = wsc.m_dwLastSentTime;
	m_dwLeaseTime = wsc.m_dwLeaseTime;
}

/*
CWebChatContext::CWebChatContext(const CWebChatContext& wsc)
{
	Init(wsc);
}

CWebChatContext& CWebChatContext::operator=(const CWebChatContext& wsc)
{
	Init(wsc);
	return *this;
}*/

int CWebChatContext::GetCountMessages()
{
	CAutoLock AutoLock(&g_cs.m_sec);
	return m_aMsg.GetSize();
}

bool CWebChatContext::CanDie()
{
	DWORD dwNow = ::GetTickCount();
	CAutoLock AutoLock(&g_cs.m_sec);
	if(m_hSocket != 0)
		return false;
	return ((dwNow - m_dwLastSentTime) > m_dwLeaseTime);
}

void CWebChatContext:: SendTimeoutMessage()
{
	DWORD dwNow = ::GetTickCount();
	CAutoLock AutoLock(&g_cs.m_sec);
	if(m_hSocket == 0)
		return;
	if((dwNow - m_dwLastSentTime) > m_ulTimeout)
	{
		m_ulWhy = 1;
		AddMsg(NULL);
	}
}

void CWebChatContext:: SendShutdownMessage()
{
	CAutoLock AutoLock(&g_cs.m_sec);
	if(m_hSocket == 0)
		return;
	m_ulWhy = 2;
	AddMsg(NULL);
}

void CWebChatContext::RemoveAll()
{
	int n;
	CAutoLock AutoLock(&g_cs.m_sec);
	for(n=0; n<m_aMsg.GetSize(); n++)
	{
		CMsgHolder *p = m_aMsg[n];
		p->Release();
	}
	m_aMsg.RemoveAll();
}

void CWebChatContext::SendMsgs(CUQueue &UQueue)
{
	int n;
	USES_CONVERSION;
	CAutoLock AutoLock(&g_cs.m_sec);
	if(m_ulWhy != 2)
		m_ulWhy = 1;
	if(m_bstrJSCallback.Length())
		Push(m_bstrJSCallback.m_str, UQueue);
	UQueue.Push("{\"messages\":[");
	
	for(n=0; n<m_aMsg.GetSize(); n++)
	{
		if(n)
			UQueue.Push(",");
		CMsgHolder *p = m_aMsg[n];
		UQueue.Push((p->GetUQueue())->GetBuffer(), (p->GetUQueue())->GetSize());
		m_ulWhy = 0;
	}
	UQueue.Push("]");
	
	UQueue.Push(",\"type\":");
	char str[10] = {0};
	_itoa(m_ulWhy, str, 10);
	UQueue.Push(str);

	UQueue.Push(",\"chatId\":\"");
	UQueue.Push(OLE2A(m_bstrGuid.m_str));
	UQueue.Push("\"}");
	if(m_bstrJSCallback.Length())
		UQueue.Push(");");
	m_dwLastSentTime = ::GetTickCount();
	RemoveAll();

	ATLTRACE("### Web Message Sent to %s @ %s ###\n", OLE2A(m_bstrUserId.m_str), OLE2A(m_ipAddr.m_str));
}

CComBSTR& CWebChatContext::GetHTTPPushSessionId()
{
	return m_bstrGuid;
}

CComBSTR& CWebChatContext::GetIpAddr()
{
	return m_ipAddr;
}


void CWebChatContext::Push(BSTR bstr, CUQueue &UQueue)
{
	ATLASSERT(bstr != NULL);
	int nBytes = ::WideCharToMultiByte(CP_UTF8, 0, bstr, -1, NULL, 0, NULL, NULL);
	CScopeUQueue su;
	if((unsigned long)nBytes > su->GetMaxSize())
	{
		su->ReallocBuffer((unsigned long)nBytes);
	}
	int nGet = ::WideCharToMultiByte(CP_UTF8, 0, bstr, -1, (LPSTR)su->GetBuffer(), nBytes, NULL, NULL);
	ATLASSERT(nGet == nBytes);
	UQueue.Push(su->GetBuffer(), nBytes - 1);
}

void CWebChatContext::AddMsg(CMsgHolder *pMsgHolder)
{
	if(pMsgHolder != NULL)
	{
		LONG lRef = pMsgHolder->AddRef();
		CAutoLock AutoLock(&g_cs.m_sec);
		m_aMsg.Add(pMsgHolder);
	}

	if(m_hSocket != 0)
	{
		CScopeUQueue su;
		SendMsgs(*su);
		bool bSuc = ::SetHTTPResponseHeader(m_hSocket, "Content-Type", "application/json; charset=utf-8");
		bSuc = ::SetHTTPResponseHeader(m_hSocket, "Cache-Control", "no-cache");
		unsigned long lRet = SendReturnData(m_hSocket, idGet, su->GetSize(), su->GetBuffer());
		m_hSocket = 0;
	}
}
