#include "PBCNet.h"

CGridNet::CGridNet(void)
{

}

CGridNet::~CGridNet(void)
{
	CleanJobs();
}

void CGridNet::OnFailover(CAsyncHandler *pHandler)
{

}

void CGridNet::OnResultReturned(CAsyncHandler *pHandler, unsigned short usRequestId)
{

}

bool CGridNet::OnExecuteJob(CAsyncHandler *pHandler)
{
	unsigned long ulLen;
	unsigned short usRequestId;
	bool bSuc = false;
	bool bBatching = false;

	CAutoLock al(&g_cs.m_sec);
	if(m_aJob.GetSize() == 0)
		return false;
	CPeerJob *p = m_aJob[0];
	m_aJob.RemoveAt(0);
	CScopeUQueue &su = (*p);
	CUQueue &UQueue = *su;
	while(UQueue.GetSize() >= (sizeof(unsigned short) + sizeof(unsigned long)))
	{
		UQueue >> usRequestId;
		UQueue >> ulLen;
		
		if(usRequestId == idStartBatching)
		{
			pHandler->GetAttachedClientSocket()->BeginBatching();			
			continue;
		}
		else if(usRequestId == idCommitBatching)
		{
			pHandler->GetAttachedClientSocket()->Commit(true);
			continue;
		}
		bSuc = true;
		pHandler->SendRequest(usRequestId, UQueue.GetBuffer(), ulLen);
		if(ulLen > 0)
			UQueue.Pop(ulLen);
	}
	ATLASSERT(UQueue.GetSize() == 0);
	delete p;
	return bSuc;
}

void CGridNet::RemoveJobs(unsigned int hSocketPeer)
{
	int n;
	CAutoLock al(&g_cs.m_sec);
	int nSize = m_aJob.GetSize();
	for(n=nSize-1; n>=0; n--)
	{
		CPeerJob *p = m_aJob[n];
		if(p->m_hSocketPeer = hSocketPeer)
		{
			m_aJob.RemoveAt(n);
			delete p;
		}
	}
}

void CGridNet::CleanJobs()
{
	int n;
	CAutoLock al(&g_cs.m_sec);
	int nSize = m_aJob.GetSize();
	for(n=0; n<nSize; n++)
	{
		CPeerJob *p = m_aJob[n];
		delete p;
	}
	m_aJob.RemoveAll();
}
