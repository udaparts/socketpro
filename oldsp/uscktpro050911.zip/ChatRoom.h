#ifndef	__CHAT__ROOM_H___
#define __CHAT__ROOM_H___

class CChatGroup
{
public:
	CChatGroup();
	CChatGroup(const CChatGroup& ChatGroup);
	
	CChatGroup& operator=(const CChatGroup& ChatGroup);

	bool operator==(const CChatGroup& ChatGroup);
	bool operator!=(const CChatGroup& ChatGroup);

public:
	CSimpleArray<SOCKET> m_Listeners;
	DWORD		m_nID;
	CComBSTR	m_bstrDescription;
};

#endif