#ifndef __4_USOCKETCP_H_
#define __4_USOCKETCP_H_

#include "USocketImp.h"

template <class T>
class CProxy_IUSocketEvent : public IConnectionPointImpl<T, &DIID__IUSocketEvent, CComDynamicUnkArray>
{
//	CComPtr<_IUSocketEvent> m_pIUSocketEvent;
	//Warning this class may be recreated by the wizard.
public:
	HRESULT Fire_OnDataAvailable(LONG hSocket, LONG lBytes, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[3];
		CComVariant pvars[3];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[2] = hSocket;
				pvars[1] = lBytes;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 3, 0 };
				pDispatch->Invoke(0x1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnOtherMessage(LONG nMsg, LONG wParam, LONG lParam)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[3];
		CComVariant pvars[3];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[2] = nMsg;
				pvars[1] = wParam;
				pvars[0] = lParam;
				DISPPARAMS disp = { pvars, NULL, 3, 0 };
				pDispatch->Invoke(0x2, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSocketClosed(LONG hSocket, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[2];
		CComVariant pvars[2];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x3, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSocketConnected(LONG hSocket, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[2];
		CComVariant pvars[2];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
//			HRESULT hr;
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
/*			if(m_pIUSocketEvent.p == NULL)
			{
				hr = sp->QueryInterface(&m_pIUSocketEvent);
			}
			hr = m_pIUSocketEvent->OnSocketConnected(hSocket, lError);*/
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x4, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnConnecting(LONG hSocket, LONG hWnd)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[2];
		CComVariant pvars[2];
		int nConnections = m_vec.GetSize();
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = hWnd;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x5, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSendingData(LONG hSocket, LONG lError, LONG lSent)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[3];
		CComVariant pvars[3];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[2] = hSocket;
				pvars[1] = lError;
				pvars[0] = lSent;
				DISPPARAMS disp = { pvars, NULL, 3, 0 };
				pDispatch->Invoke(0x6, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnGetHostByAddr(LONG hHandle, BSTR bstrHostName, BSTR bstrHostAlias, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[4];
		CComVariant pvars[4];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[3] = hHandle;
				pvars[2] = bstrHostName;
				pvars[1] = bstrHostAlias;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				pDispatch->Invoke(0x7, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnGetHostByName(LONG hHandle, BSTR bstrHostName, BSTR bstrAlias, BSTR bstrIPAddr, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[5];
		CComVariant pvars[5];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[4] = hHandle;
				pvars[3] = bstrHostName;
				pvars[2] = bstrAlias;
				pvars[1] = bstrIPAddr;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 5, 0 };
				pDispatch->Invoke(0x8, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	}

	HRESULT Fire_OnClosing(LONG hSocket, LONG hWnd)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[2];
		CComVariant pvars[2];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = hWnd;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x9, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnRequestProcessed(SHORT nRequestID, LONG lLen, LONG lLenInBuffer, SHORT bFlag)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[4];
		CComVariant pvars[4];
		int nConnections = m_vec.GetSize();
		
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[3] = nRequestID;
				pvars[2] = (long)pT->m_USAttr.m_curRcvStreamHeader.m_ulLen;
				pvars[1] = (long)((unsigned long)lLenInBuffer - ((unsigned long)lLen - pT->m_USAttr.m_curRcvStreamHeader.m_ulLen));
//				pvars[2] = lLen;
//				pvars[1] = lLenInBuffer;
				pvars[0] = bFlag;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				pDispatch->Invoke(0xa, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	}
};

#endif