// UCert.h: interface for the CUCert class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UCERT_H__7AA49544_AEA4_4DE6_B521_7D1682E8C037__INCLUDED_)
#define AFX_UCERT_H__7AA49544_AEA4_4DE6_B521_7D1682E8C037__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "sprowrap.h"
using namespace SocketProAdapter;
using namespace SocketProAdapter::ClientSide;

class ATL_NO_VTABLE CUCert  :
	public CComObjectRootEx<CComMultiThreadModel>,
	public ISupportErrorInfo,
	public IDispatchImpl<IUCert, &IID_IUCert, &LIBID_USOCKETLib>
{
public:
	CUCert();
	virtual ~CUCert();

	BEGIN_COM_MAP(CUCert)
		COM_INTERFACE_ENTRY(IUCert)
		COM_INTERFACE_ENTRY(IDispatch)
		COM_INTERFACE_ENTRY(ISupportErrorInfo)
	END_COM_MAP()

public:
	STDMETHOD(AddCertificateToStore)(/*[in, defaultvalue(0)]*/VARIANT_BOOL bRoot);
//	ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	STDMETHOD(get_SessionInfo)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(Verify)(long *plErrorCode, /*[out, retval]*/BSTR *pbstrErrorMsg);
	STDMETHOD(get_VerifyLocation)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_VerifyLocation)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_CertPem)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_SubjectUID)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_IssuerUID)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_PublicKey)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_Algorithm)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_SerialNumber)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(CompareDomain)(/*[out]*/BSTR *pbstrDomain, BSTR *pbstrHost, /*[out, retval]*/VARIANT_BOOL *pbMatchable);
	STDMETHOD(get_SigAlg)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_NotAfter)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_NotBefore)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Validity)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(get_Subject)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Issuer)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Version)(/*[out, retval]*/ VARIANT *pVal);

	SSL				*m_pSSL;
	CUSocket		*m_pUSocket;



private:
	void GetDomain(unsigned int addr, char *strDomain, char *strHost, bool bNeedDomain);
};

#endif // !defined(AFX_UCERT_H__7AA49544_AEA4_4DE6_B521_7D1682E8C037__INCLUDED_)
