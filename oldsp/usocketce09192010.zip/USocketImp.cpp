// USocketImp.cpp : Implementation of CUSocket
#include "stdafx.h"
#include "USocket.h"
#include "USocketImp.h"
#include "wsastartup.h"
#include "UCert.h"
#include "usinternal_i.c"
#include "SHA1.h"
#include <Exdisp.h>

extern CWSAStartup	*g_pWSAStartup;
#define IF_TABLE_SIZE  (2*1024)

TCHAR *g_strInfoMsg = _T("Thank you for evaluting SocketPro communication framework!");
TCHAR *g_strTitle = _T("SocketPro");
bool g_bRegistered = true;

/////////////////////////////////////////////////////////////////////////////
// CUSocket



void CALLBACK SocketTimerProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	::WSASetLastError(WSAETIMEDOUT);
	while(!::PostMessage(hWnd, msgSocketEvent, idEvent, MAKELONG(FD_CONNECT, WSAETIMEDOUT)))
	{
		::Sleep(1);
	}
}

CUSocket::CUSocket()
{

	m_SBAttr.m_ulRecvTimeout = 30000;
	m_SBAttr.m_ulSendTimeout = 30000;
	m_SBAttr.m_ulConnTimeout = 30000;
	m_SBAttr.m_hSocket = INVALID_SOCKET;
	m_SBAttr.m_pSSL = NULL;
	m_SBAttr.m_hWSAAsync = NULL;
	m_SBAttr.m_nTimer = 0;
	m_SBAttr.m_EncryptionMethod = NoEncryption;
	m_SBAttr.m_bUseBaseSocketOnly = false;
	memset(&m_USAttr, 0, sizeof(m_USAttr));
	m_USAttr.m_ulMemBlockSize = 1024;
	m_USAttr.m_ulZipLimit = 16;

	m_USAttr.m_Client.m_ulSvsID = sidStartup;

	m_MyWindow.m_pUSocket = this;
	m_strHostEntBuffer = new char[MAXGETHOSTSTRUCT+1];

	m_pBlowFish = NULL;
	m_ulSynIndicator = 0;

	memset(&m_RTrace, 0, sizeof(m_RTrace));
	m_ulSndBatch = 10*1460;
	m_ulCancelRequests = 0;
	m_dwBytesIn = 0;
	m_dwBytesInHigh = 0;
	m_dwBytesOut = 0;
	m_dwBytesOutHigh = 0;
	m_bFrozen = false;
	m_usRtnEvents = rfCompleted;
	m_bSendingTooFast = false;
	m_nMaxRtns = 256;
	m_NetworkBandwidth = npUnknown;
	m_bSameEndian = true;
	m_lMTU = 0;
	m_lType = 0;
	m_lSpeed = 0;
	m_dwObjThreadID = ::GetCurrentThreadId();
	m_hSocketEvent = NULL;
	m_USAttr.m_Client.m_ulParam1 = g_pWSAStartup->m_ulOS;
	m_USAttr.m_Client.m_usUSockMinor = 3;
	m_USAttr.m_bZipIsOn = false;
	m_USAttr.m_bStartingJob = false;
	m_usWaitReqID = 0;
	m_ulWaitSvsID = 0;
	m_bCleanRequired = false;
	m_hSEvent = NULL;
	m_pCS = &m_csGeneral.m_sec;
	m_sLastRequestID = 0;
	m_bVerify = false;
	m_zlServer = zlDefault;
	ATLASSERT(sizeof(unsigned int) == 4); 
	m_hNotify = NULL;
	m_bWaiting = false;
	m_pJSSerialization = NULL;
	m_usRequestIdDiscarded = 0;
}

HRESULT CUSocket::FinalConstruct()
{
	m_pBlowFish = NULL;
	{
		CAutoLock AutoLock(&g_pWSAStartup->m_cs.m_sec);
		g_pWSAStartup->m_dwCountSockets++;
	}
	if(g_pWSAStartup->m_dwUsedWithDotNet == 0xFFFFFFFF)
	{
		CRegKey RegKey;
		RegKey.Open(HKEY_CLASSES_ROOT, _T("CLSID\\{AAD83433-CC8D-4F6D-9C62-E224DCA81358}\\UsedWithDotNet"));
		RegKey.QueryValue(g_pWSAStartup->m_dwUsedWithDotNet, NULL);
	}
	return uecOK;
}

void CUSocket::FinalRelease()
{
	{
		CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
		if(m_pJSSerialization != NULL)
		{
			m_pJSSerialization->Release();
			m_pJSSerialization = NULL;
		}
		if(m_pBlowFish)
		{
			delete m_pBlowFish;
			m_pBlowFish = NULL;
		}
		DestroyTimer();
		if(m_SBAttr.m_hSocket!=INVALID_SOCKET)
		{
			::closesocket(m_SBAttr.m_hSocket);
			m_SBAttr.m_hSocket = INVALID_SOCKET;
		}
	}
	if(m_MyWindow.m_hWnd)
	{
//		m_MyWindow.DestroyWindow();
		m_MyWindow.Detach();
	}

	CAutoLock AutoLock(&g_pWSAStartup->m_cs.m_sec);
	g_pWSAStartup->m_dwCountSockets--;
}

CUSocket::~CUSocket()
{
	int nRef = 0;
	if(m_pJSSerialization != NULL)
	{
		nRef = m_pJSSerialization->Release();
	}
	if(m_hNotify != NULL)
		::CloseHandle(m_hNotify);
	if(m_pBlowFish)
		delete m_pBlowFish;
	DestroyTimer();
	if(m_SBAttr.m_hSocket!=INVALID_SOCKET)
	{
		::closesocket(m_SBAttr.m_hSocket);
	}
	if(m_MyWindow.m_hWnd)
	{
		m_MyWindow.DestroyWindow();
		m_MyWindow.Detach();
	}
	if(m_strHostEntBuffer)
	{
		delete []m_strHostEntBuffer;
		m_strHostEntBuffer = NULL;
	}
}

/*
STDMETHODIMP CUSocket::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IUSocket,
		&IID_IUChat,
		&IID_IUFast,
		&IID_ISocketBase
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return uecOK;
	}
	return S_FALSE;
}*/

STDMETHODIMP CUSocket::DoEcho()
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequestEx(idDoEcho, 0, NULL);
}

STDMETHODIMP CUSocket::Connect(BSTR bstrHostAddress, long lHostPort, VARIANT_BOOL bSynConnecting, long lSocketType, long lAddrFormat, long lProtocol, long lLocalPort)
{
	USES_CONVERSION;
	//for CE Only
//	bSynConnecting = VARIANT_TRUE;
	lSocketType = stSTREAM;
	lAddrFormat = afINet;
	lProtocol = spIP;
	lLocalPort = 0;
	CAutoLock LockHere(&m_csGeneral.m_sec);
	m_bIO = false;

	m_mapFunc.RemoveAll();
	if(m_spWebDoc != NULL && m_vtJSObject.vt == VT_DISPATCH)
	{
		UINT n;
		USES_CONVERSION;
		CComQIPtr<IDispatch> pIDispatch(m_vtJSObject.pdispVal);
		UINT nCount = 0;
		CComBSTR bstrName;
		CComPtr<ITypeInfo> pITypeInfo;
		pIDispatch->GetTypeInfoCount(&nCount);
		for(n=0; n<nCount; n++)
		{
			pIDispatch->GetTypeInfo(n, LOCALE_SYSTEM_DEFAULT, &pITypeInfo);
			if(pITypeInfo.p == NULL)
				continue;

			TYPEATTR *pTypeAttr = NULL;
			pITypeInfo->GetTypeAttr(&pTypeAttr);
			if(pTypeAttr == NULL)
				continue;

			WORD w; 

			//QueryInterface, AddRef, Release, GetTypeInfoCount, GetTypeInfo, GetIDsOfNames and Invoke ignored
			for(w=0; w<pTypeAttr->cFuncs; w++)
			{
				FUNCDESC *pFuncDesc = NULL;
				pITypeInfo->GetFuncDesc(w, &pFuncDesc);

				if(pFuncDesc == NULL)
					continue;
				unsigned int nNames;
				bstrName.Empty();
				pITypeInfo->GetNames(pFuncDesc->memid, &bstrName, 1, &nNames);
				
//					ATLTRACE("Method == %s\n", OLE2A(bstrName));
				switch(pFuncDesc->invkind)
				{
				case INVOKE_FUNC:
//					m_aMethodName.Add(bstrName);
					m_mapFunc.Add(bstrName, *pFuncDesc);
					break;
				case INVOKE_PROPERTYGET:
					if(pFuncDesc->cParams == 0)
					{
	//					m_aPropertyName.Add(bstrName);
	//					m_mapPropertyGet.Add(bstrName, *pFuncDesc);
					}
					else //for STDMETHODIMP CAcnts::get_Item(long lIndex, VARIANT *pvtValue)
					{
	//					m_aMethodName.Add(bstrName);
	//					m_mapFunc.Add(bstrName, *pFuncDesc);
					}
					break;
				case INVOKE_PROPERTYPUT:
					if(pFuncDesc->cParams == 1)
					{
	//					m_aPropertyNamePut.Add(bstrName);
	//					m_mapPropertyPut.Add(bstrName, *pFuncDesc);
	//					if(m_mapPropertyGet.FindKey(bstrName) == -1)
	//					{
	//						m_aPropertyName.Add(bstrName);
	//						m_mapPropertyGet.Add(bstrName, *pFuncDesc);
	//					}
					}
					else if(pFuncDesc->cParams == 2)//for STDMETHODIMP CAcnts::put_Item(long lIndex, VARIANT vtValue)
					{
	//					m_aMethodName.Add(bstrName);
	//					m_mapFunc.Add(bstrName, *pFuncDesc);
					}
					else
					{
					}
					break;
				case INVOKE_PROPERTYPUTREF:
					//not supported with NPObject
					ATLASSERT(FALSE);
					break;
				default:
					break;
				}
				if(pFuncDesc != NULL)
				{
					pITypeInfo->ReleaseFuncDesc(pFuncDesc);
				}
			}
			pITypeInfo->ReleaseTypeAttr(pTypeAttr);
			pITypeInfo.Release();
		}
	}

	m_bMSSSLState = 0;
	m_bCleanRequired = false;
	m_usWaitReqID = 0;
	m_ulWaitSvsID = 0;
	m_ulLSend = ::GetTickCount();
	m_dwObjThreadID = ::GetCurrentThreadId();
	m_bDoingHandshake = false;
	m_bstrAddrConn.Empty();
	if(m_MyWindow.m_hWnd != NULL && GetWindowThreadProcessId(m_MyWindow.m_hWnd, NULL) != ::GetCurrentProcessId())
	{
		m_MyWindow.DestroyWindow();
		m_MyWindow.m_hWnd = NULL;

	}
	if(m_MyWindow.m_hWnd == NULL)
	{
		HWND hWnd = m_MyWindow.Create(NULL, CWindow::rcDefault, _T("UDAParts USocket Window"));
		if(NULL == hWnd)
		{
			m_USAttr.m_hr = uecFail;
			return uecFail; 
		}
//		::EnableWindow(hWnd, FALSE);
	}
	m_requestQueue.SetSize(0);
	m_USAttr.m_hr = S_OK;
	SOCKADDR_IN sockAddr;
	if(m_SBAttr.m_hSocket != INVALID_SOCKET && m_SBAttr.m_hSocket != 0)
	{
		Disconnect();
	}
	m_bFirstWrite = false;
	m_nHostPort = lHostPort;
	m_nAddressFormat = lAddrFormat;

	if(bstrHostAddress == NULL || wcslen(bstrHostAddress)==0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return uecUnexpected;
	}
	
	m_SBAttr.m_hSocket = ::socket(lAddrFormat, lSocketType, lProtocol);
	if(m_SBAttr.m_hSocket==ssInvalidSocket)
	{
		m_USAttr.m_hr = ::WSAGetLastError();
		return m_USAttr.m_hr;
	}
	
	m_hSocketEvent = g_pWSAStartup->GetEvent();
	if(m_hSocketEvent == NULL)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	::EnterCriticalSection(&g_pWSAStartup->m_cs.m_sec);
	g_pWSAStartup->m_mapUSocket.Add(m_SBAttr.m_hSocket, this);
	::LeaveCriticalSection(&g_pWSAStartup->m_cs.m_sec);
	m_USAttr.m_hr = SAsyncSelect(m_SBAttr.m_hSocket, (HWND)m_hSocketEvent, msgSocketEvent, FD_CONNECT|FD_READ|FD_CLOSE|FD_WRITE);
	if(m_USAttr.m_hr != 0)
	{
		m_USAttr.m_hr = ::WSAGetLastError();
		return m_USAttr.m_hr;
	}
	
	{
		SOCKADDR_IN sockAddr;
		memset(&sockAddr,0,sizeof(sockAddr));
		sockAddr.sin_family = (short)lAddrFormat;
		sockAddr.sin_addr.s_addr = htonl(INADDR_ANY);
		sockAddr.sin_port = htons((u_short)lLocalPort);
		m_USAttr.m_hr = ::bind(m_SBAttr.m_hSocket, (const SOCKADDR*)&sockAddr, sizeof(sockAddr));
		if(m_USAttr.m_hr != 0)
		{
			m_USAttr.m_hr = ::WSAGetLastError();
			::closesocket(m_SBAttr.m_hSocket);
			m_SBAttr.m_hSocket = INVALID_SOCKET;
			return m_USAttr.m_hr;
		}
	}

	m_bVerify = false;
	Fire_OnConnecting(m_SBAttr.m_hSocket, (long)m_MyWindow.m_hWnd);

	memset(&sockAddr,0,sizeof(sockAddr));
	LPSTR lpszAscii = OLE2A(bstrHostAddress);
	sockAddr.sin_family = (short)lAddrFormat;
	sockAddr.sin_addr.s_addr = inet_addr(lpszAscii);

	if (sockAddr.sin_addr.s_addr == INADDR_NONE)
	{
		const hostent* lphost;
		m_bstrAddrConn = bstrHostAddress;
		if(true)
		{
			lphost = ::gethostbyname(lpszAscii);
		}
		else
		{
			memset(m_strHostEntBuffer, 0, MAXGETHOSTSTRUCT+1);
			if(!m_SBAttr.m_nTimer)
			{
				ATLASSERT(m_MyWindow.m_hWnd);
				ATLASSERT(m_SBAttr.m_hSocket!=INVALID_SOCKET);
				m_SBAttr.m_nTimer = ::SetTimer(m_MyWindow.m_hWnd, m_SBAttr.m_hSocket, m_SBAttr.m_ulConnTimeout, SocketTimerProc);
			}
			if(m_SBAttr.m_hWSAAsync)
			{
				//commet the following out for CE
//				::WSACancelAsyncRequest(m_SBAttr.m_hWSAAsync);
				m_SBAttr.m_hWSAAsync=0;
			}
			ATLASSERT(FALSE);
			//commet the following out for CE
//			m_SBAttr.m_hWSAAsync=::WSAAsyncGetHostByName(m_MyWindow.m_hWnd, msgAsyncGetHostByName, lpszAscii, m_strHostEntBuffer, MAXGETHOSTSTRUCT);
			return S_OK;
		}
		if (lphost != NULL)
			sockAddr.sin_addr.s_addr = ((LPIN_ADDR)lphost->h_addr)->s_addr;
		else
		{
			::WSASetLastError(WSAEINVAL);
			m_USAttr.m_hr = WSAEINVAL;
			return WSAEINVAL;
		}
	}
	sockAddr.sin_port = htons((u_short)lHostPort);
	Connect((SOCKADDR*)&sockAddr, sizeof(sockAddr), (bSynConnecting ? true : false));
/*	if(bSynConnecting && m_USAttr.m_hr == uecOK)
	{
		if(m_SBAttr.m_pSSL == NULL && (m_SBAttr.m_EncryptionMethod == TLSv1 || m_SBAttr.m_EncryptionMethod == SSL23) && SetSSL())
		{
			bool bSuc = DoSSLConnect();
			ATLASSERT(bSuc);
		}
	}*/
	m_ulTimeTrack = ::GetTickCount();
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::Disconnect()
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_bDoingHandshake = false;
	m_USAttr.m_hr = uecOK;
	m_requestQueue.SetSize(0);
	if(m_SBAttr.m_hWSAAsync)
	{
		//commet the following out for CE
//		::WSACancelAsyncRequest(m_SBAttr.m_hWSAAsync);
		m_SBAttr.m_hWSAAsync=0;
	}
	if(m_SBAttr.m_hSocket != INVALID_SOCKET && m_SBAttr.m_hSocket != 0)
	{
		OnClosed(0);
	}
	return uecOK;
}

STDMETHODIMP CUSocket::StartJob()
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly || m_USAttr.m_bStartingJob)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_USAttr.m_bStartingJob = true;
	return SendRequestEx(idStartJob, 0, NULL);
}

STDMETHODIMP CUSocket::EndJob()
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly || !m_USAttr.m_bStartingJob)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_USAttr.m_bStartingJob = false;
	return SendRequestEx(idEndJob, 0, NULL);
}

STDMETHODIMP CUSocket::Shutdown(long lHow)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(m_SBAttr.m_pSSL)
	{
		g_pWSAStartup->SSL_shutdown(m_SBAttr.m_pSSL);  /* send SSL/TLS close_notify */
	}
	if(m_SBAttr.m_hSocket != INVALID_SOCKET)
	{
		::shutdown(m_SBAttr.m_hSocket, lHow);
	}
	m_bDoingHandshake = false;
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::SetSockOpt(long lOptName, long lOptValue, long lLevel)
{
	HRESULT hr = uecOK;
	int intLevel = (unsigned short)lLevel;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	hr = ::setsockopt(m_SBAttr.m_hSocket, intLevel, lOptName, (char*)&lOptValue, sizeof(lOptValue));
	if(hr != uecOK)
		hr = ::WSAGetLastError();
	else
	{
		if(lOptName == soSndBuf)
			m_ulSndBatch = lOptValue;
	}
	m_USAttr.m_hr = hr;
	return hr;
}

STDMETHODIMP CUSocket::GetSockOpt(long lOptName, long lLevel, long *plOptValue)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	HRESULT hr = uecOK;
	if(plOptValue)
	{
		*plOptValue = 0;
		int nLen = sizeof(long);
		int intLevel = (unsigned short)lLevel;
		hr = ::getsockopt(m_SBAttr.m_hSocket, intLevel, lOptName, (char*)plOptValue, &nLen);
		if(hr != uecOK)
			hr = ::WSAGetLastError();
	}
	m_USAttr.m_hr = hr;
	return hr;
}

STDMETHODIMP CUSocket::get_hWnd(long *pVal)
{
	if(pVal)
	{
//		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = (long) m_MyWindow.m_hWnd;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::get_ConnTimeout(long *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_SBAttr.m_ulConnTimeout;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::put_ConnTimeout(long newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_SBAttr.m_ulConnTimeout = newVal;
	return uecOK;
}

STDMETHODIMP CUSocket::get_Socket(long *pVal)
{
	if(pVal)
	{
//		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_SBAttr.m_hSocket;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::Send(VARIANT vtData, long *plSent)
{
	void *pData;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(plSent)
		*plSent = 0;
	if(!m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	
	if(vtData.vt == VT_NULL || vtData.vt == VT_EMPTY)
	{
		return m_USAttr.m_hr;
	}
	
	if(vtData.vt!=(VT_ARRAY|VT_UI1) && vtData.vt != (VT_ARRAY|VT_I1))
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	
	::SafeArrayAccessData(vtData.parray, (void**)&pData);
	m_sndQueue.Push((const unsigned char*)pData, vtData.parray->rgsabound[0].cElements);
	::SafeArrayUnaccessData(vtData.parray);
	if(plSent)
		*plSent = vtData.parray->rgsabound[0].cElements;
	USend();
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::Recv(VARIANT *pvtData)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(pvtData)
	{
		if(!m_SBAttr.m_bUseBaseSocketOnly)
		{
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}
		if(pvtData)
			::VariantClear(pvtData);
		URecv();
		unsigned long lByte = m_rcvQueue.GetSize();
		if(lByte)
		{
			void *pData;
			SAFEARRAYBOUND sab[1] = {lByte, 0};
			pvtData->parray = ::SafeArrayCreate(VT_UI1, 1, sab);
			::SafeArrayAccessData(pvtData->parray, &pData);
			memcpy(pData, m_rcvQueue.GetBuffer(), lByte);
			::SafeArrayUnaccessData(pvtData->parray);
			pvtData->vt = (VT_ARRAY|VT_UI1);
			m_rcvQueue.SetSize(0);
		}
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::IOCtl(long lCommand, long *plArgment)
{
	u_long	ulArg = 0;
	unsigned long nArgument = 0;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_pSSL && lCommand == iocRead)
	{
		nArgument=g_pWSAStartup->SSL_pending(m_SBAttr.m_pSSL);
	}
	int err = ::ioctlsocket(m_SBAttr.m_hSocket, lCommand, &ulArg);
	if(plArgment)
	{
		*plArgment = ulArg + nArgument;
	}
	if(err == -1)
	{
		m_USAttr.m_hr = ::WSAGetLastError();
	}
	else
	{
		m_USAttr.m_hr = uecOK;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::SwitchTo(long lSvsID)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}

	if(m_SBAttr.m_EncryptionMethod == BlowFish && m_bstrPassword.Length() == 0 && !m_bVerify)
	{
		OnClosed(seClientAuthenticationError);
		m_USAttr.m_hr = seClientAuthenticationError;
		return m_USAttr.m_hr;
	}

	unsigned short unLenPassword = m_bstrPassword.Length()*sizeof(WCHAR);
	unsigned short unLenUserID = m_bstrUserID.Length()*sizeof(WCHAR);
	
	m_USAttr.m_Client.m_ulSvsID = lSvsID;
	m_tempQueue.SetSize(0);
	m_tempQueue.Push(&m_USAttr.m_Client);
	m_tempQueue.Push((const unsigned char*)&unLenUserID, 2);
	if(unLenUserID)
	{
		m_tempQueue.Push((BYTE*)(m_bstrUserID.m_str), unLenUserID);
	}
	
	if(m_SBAttr.m_EncryptionMethod == BlowFish)
	{
		bool bPass = false;
		unsigned short usLen = 0;
		m_tempQueue.Push((const unsigned char*)&usLen, 2);
		long lTimeOut = -1;
		VARIANT_BOOL bTimeout = VARIANT_FALSE;
		CComBSTR bstrPassword = m_bstrPassword;
		if(unLenPassword)
		{
			memset(m_bstrPassword.m_str, 0, unLenPassword);
			m_bstrPassword.Empty();
		}
		
		if(!m_bVerify)
		{
			m_SBAttr.m_EncryptionMethod = NoEncryption;
		}
		unLenPassword = 0;
		m_tempQueue.Push((const unsigned char*)&unLenPassword, 2);
		bool bBatch = m_USAttr.m_bBatching;
		m_USAttr.m_bBatching = false;
		m_USAttr.m_hr = SendRequestEx(idSwitchTo, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer()); 
		m_bCleanRequired = false;
		if(!m_bVerify)
		{
			HRESULT hr = WaitAll(lTimeOut, &bTimeout);
			m_SBAttr.m_EncryptionMethod = BlowFish;
		}
		m_USAttr.m_bBatching = false;
		if(m_SBAttr.m_hSocket != 0 && m_SBAttr.m_hSocket != INVALID_SOCKET && !m_bVerify)
		{
			CSHA1 sha1;
			GUID *pGuid = &m_guidSalt;
			BYTE pHash[20];
			sha1.HashPassword(bstrPassword, *pGuid);
			sha1.GetHash((UINT_8*)pHash);				
			bPass = (::memcmp(pHash, m_pHash, 20) == 0);
			if(bPass)
			{
				m_bVerify = true;
				sha1.HashPassword2(bstrPassword, *pGuid);
				sha1.GetHash((UINT_8*)pHash);
				if(m_pBlowFish)
				{
					delete m_pBlowFish;
				}
				m_pBlowFish = new CBF(pHash, 20);
				::memset(pHash, 0, sizeof(pHash));
				SendRequestEx(idVerifySalt, 16, (BYTE*)pGuid);
				ULONG ulSize = m_requestQueue.GetSize();
				ulSize -= sizeof(unsigned short);
				m_requestQueue.SetSize(ulSize);
			}
		
		}
		m_USAttr.m_bBatching = bBatch;
		unLenPassword = bstrPassword.Length()*sizeof(WCHAR);
		if(unLenPassword)
		{
			memset(bstrPassword.m_str, 0, unLenPassword);
		}
		if(!bPass && !m_bVerify)
		{
			OnClosed(seClientAuthenticationError);
		}	
	}
	else
	{
		m_tempQueue.Push((const unsigned char*)&unLenPassword, 2);
		if(unLenPassword)
		{
			m_tempQueue.Push((BYTE*)(m_bstrPassword.m_str), unLenPassword);
			memset(m_bstrPassword.m_str, 0, unLenPassword);
			m_bstrPassword.Empty();
		}
		m_USAttr.m_hr = SendRequestEx(idSwitchTo, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer()); 
		memset((BYTE*)m_tempQueue.GetBuffer(), 0, m_tempQueue.GetSize());
		m_bCleanRequired = true;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::get_UserID(BSTR *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		if(*pVal)
		{
			::SysFreeString(*pVal);
			*pVal = NULL;
		}
		ULONG ulLen = m_bstrUserID.Length(); 
		if(ulLen)
		{
			*pVal = ::SysAllocString(m_bstrUserID.m_str);
		}
	}
	return uecOK;
}

STDMETHODIMP CUSocket::put_UserID(BSTR newVal)
{
//	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(newVal && ::SysStringLen(newVal) > 255)
	{
		m_USAttr.m_hr = uecUnexpected;
		return uecUnexpected;
	}
	m_bstrUserID = newVal;
	return uecOK;
}

STDMETHODIMP CUSocket::get_Password(BSTR *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
	{
		if(*pVal)
		{
			::SysFreeString(*pVal);
			*pVal = NULL;
		}
		ULONG ulLen = m_bstrPassword.Length(); 
		if(ulLen)
		{
			*pVal = ::SysAllocString(m_bstrPassword.m_str);
		}
	}
	return uecOK;
}

STDMETHODIMP CUSocket::put_Password(BSTR newVal)
{
//	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(newVal && ::SysStringLen(newVal) > 255)
	{
		m_USAttr.m_hr = uecUnexpected;
		return uecUnexpected;
	}
	m_bstrPassword = newVal;
	return uecOK;
}

STDMETHODIMP CUSocket::GetPeerName(long *plPeerPort, BSTR *pbstrPeerName)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(plPeerPort || pbstrPeerName)
	{
		SOCKADDR_IN sockAddr;
		memset(&sockAddr, 0, sizeof(sockAddr));
		int nSockAddrLen = sizeof(sockAddr);
		int err = ::getpeername(m_SBAttr.m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
		if (err == -1)
		{
			m_USAttr.m_hr = ::WSAGetLastError();
		}
		else
		{
			USES_CONVERSION;
			if(plPeerPort)
				*plPeerPort = ::ntohs(sockAddr.sin_port);
			if(pbstrPeerName)
			{
				if(*pbstrPeerName)
					::SysFreeString(*pbstrPeerName);
				*pbstrPeerName = A2BSTR(::inet_ntoa(sockAddr.sin_addr));
			}
		}
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetLocalName(BSTR *pbstrLocalName)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(pbstrLocalName)
	{
		USES_CONVERSION;
		char *strName = new char [1024];
		memset(strName, 0, 1024);
		int nRtn=::gethostname(strName, 1024);
		if(nRtn == -1)
			m_USAttr.m_hr = ::WSAGetLastError();
		else
		{
			if(*pbstrLocalName)
			{
				::SysFreeString(*pbstrLocalName);
			}
			*pbstrLocalName = A2BSTR(strName);
		}
		delete []strName;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetHostByName(BSTR bstrHost, VARIANT_BOOL bBlocking, long *phHandle, BSTR *pbstrIPAddr, BSTR *pbstrAlias, BSTR *pbstrHostName)
{
	USES_CONVERSION;
	const HOSTENT *pHostEnt = NULL;
	//for CE Only
	bBlocking = VARIANT_TRUE;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(!bstrHost || ::SysStringLen(bstrHost) == 0)
	{
		m_USAttr.m_hr=uecUnexpected;
		return uecUnexpected;
	}
	if(!pbstrHostName && bBlocking)
	{
		m_USAttr.m_hr=uecUnexpected;
		return uecUnexpected;
	}

	{
		memset(m_strHostEntBuffer, 0, MAXGETHOSTSTRUCT+1);
		SOCKADDR_IN sockAddr;
		memset(&sockAddr,0,sizeof(sockAddr));
		LPSTR lpszAscii = OLE2A(bstrHost);
		sockAddr.sin_addr.s_addr = inet_addr(lpszAscii);
		if (sockAddr.sin_addr.s_addr != INADDR_NONE)
			pHostEnt = NULL;
		else
		{
			if(bBlocking)
			{
				pHostEnt = gethostbyname(OLE2A(bstrHost));
			}
			else
			{
				if(m_SBAttr.m_hWSAAsync)
				{
					//commet the following out for CE
//					::WSACancelAsyncRequest(m_SBAttr.m_hWSAAsync);
					m_SBAttr.m_hWSAAsync = 0;
				}
				if(m_dwObjThreadID == ::GetCurrentThreadId() && m_MyWindow.m_hWnd == NULL)
				{
					HWND hWnd = m_MyWindow.Create(NULL, CWindow::rcDefault, _T("UDAParts USocket Window"));
					if(NULL == hWnd)
					{
						m_USAttr.m_hr = uecFail;
						return uecFail; 
					}
				}
				ATLASSERT(FALSE);
				//comment it out for CE Only
//				m_SBAttr.m_hWSAAsync = ::WSAAsyncGetHostByName(m_MyWindow.m_hWnd, msgWSAGetHostByName, OLE2A(bstrHost), m_strHostEntBuffer, MAXGETHOSTSTRUCT);
				memcpy(m_strHostEntBuffer, &(m_SBAttr.m_hWSAAsync), sizeof(m_SBAttr.m_hWSAAsync));
				pHostEnt = (hostent*)m_strHostEntBuffer;
			}
		}
	}

//	pHostEnt=CAsySocketClient::GetHostByName(OLE2T(bstrHost), (bBlocking==VARIANT_TRUE) ? true : false);
	
	if(!pHostEnt)
	{
		m_USAttr.m_hr = ::WSAGetLastError();
		return m_USAttr.m_hr;
	}
	if(bBlocking==VARIANT_TRUE)
	{
		if(pbstrHostName)
		{
			if(*pbstrHostName)
			{
				::SysFreeString(*pbstrHostName);
				*pbstrHostName = NULL;
			}
			*pbstrHostName=A2BSTR(pHostEnt->h_name);
		}
		if(pbstrAlias && pHostEnt->h_aliases)
		{
			if(*pbstrAlias)
			{
				::SysFreeString(*pbstrAlias);
				*pbstrAlias = NULL;
			}
			*pbstrAlias=A2BSTR(pHostEnt->h_aliases[0]);
		}
		if(pbstrIPAddr && pHostEnt->h_addr_list[0])
		{
			CComBSTR	bstrTemp;
			char		*str;
			in_addr		addr;
			UINT		nIndex=0;
			if(*pbstrIPAddr)
			{
				::SysFreeString(*pbstrIPAddr);
				*pbstrIPAddr = NULL;
			}
			do
			{
				str=pHostEnt->h_addr_list[nIndex];
				if(str)
				{
					memcpy(&addr, str, 4);
					if(bstrTemp.Length())
						bstrTemp +=L";";
					bstrTemp +=A2BSTR(inet_ntoa(addr));
					nIndex++;
				}
				else
					break;
			}while(true);
			*pbstrIPAddr=bstrTemp.m_str;
			bstrTemp.m_str=NULL;
		}
	}
	else
	{
		if(phHandle)
			memcpy(phHandle, m_strHostEntBuffer, sizeof(HANDLE));
	}
	m_USAttr.m_hr = S_OK;
	return m_USAttr.m_hr;	
}

STDMETHODIMP CUSocket::GetHostByAddr(BSTR bstrIPAddr, long lAddrFormat, VARIANT_BOOL bBlocking, long *phHandle, BSTR *pbstrAlias, BSTR *pbstrHostName)
{
	USES_CONVERSION;
	const HOSTENT *pHostEnt = NULL;
	bBlocking = VARIANT_TRUE;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(!bstrIPAddr || ::SysStringLen(bstrIPAddr)==0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
/*	if(!pbstrHostName)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}*/
	{
		SOCKADDR_IN sockAddr;
		memset(&sockAddr,0,sizeof(sockAddr));
		LPSTR lpszAscii = OLE2A(bstrIPAddr);
		sockAddr.sin_family = (short)lAddrFormat;
		sockAddr.sin_addr.s_addr = inet_addr(lpszAscii);
		if (sockAddr.sin_addr.s_addr == INADDR_NONE)
			return NULL;
		if(bBlocking)
		{
			pHostEnt=::gethostbyaddr((LPCSTR)&(sockAddr.sin_addr.s_addr), 4, lAddrFormat);
		}
		else
		{
			if(m_SBAttr.m_hWSAAsync)
			{
				//commet the following out for CE
//				::WSACancelAsyncRequest(m_SBAttr.m_hWSAAsync);
				m_SBAttr.m_hWSAAsync = 0;
			}
			if(m_dwObjThreadID == ::GetCurrentThreadId() && m_MyWindow.m_hWnd == NULL)
			{
				HWND hWnd = m_MyWindow.Create(NULL, CWindow::rcDefault, _T("UDAParts USocket Window"));
				if(NULL == hWnd)
				{
					m_USAttr.m_hr = uecFail;
					return uecFail; 
				}
			}
			ATLASSERT(FALSE);
			//commet the following out for CE
//			m_SBAttr.m_hWSAAsync = ::WSAAsyncGetHostByAddr(m_MyWindow.m_hWnd, msgWSAGetHostByAddr, (LPCSTR)&(sockAddr.sin_addr.s_addr), 4, lAddrFormat, m_strHostEntBuffer, MAXGETHOSTSTRUCT);
			memcpy(m_strHostEntBuffer, &(m_SBAttr.m_hWSAAsync), sizeof(m_SBAttr.m_hWSAAsync));
			pHostEnt = (hostent*)m_strHostEntBuffer;
		}
	}
//	pHostEnt=CAsySocketClient::GetHostByAddr(OLE2T(bstrHostAddr), lType, (bBlocking==VARIANT_TRUE) ? true : false);
	if(!pHostEnt)
	{
		m_USAttr.m_hr = ::WSAGetLastError();
		return m_USAttr.m_hr;
	}
	if(bBlocking==VARIANT_TRUE)
	{
		if(pbstrHostName)
		{
			if(*pbstrHostName)
			{
				::SysFreeString(*pbstrHostName);
				*pbstrHostName = NULL;
			}
			*pbstrHostName=A2BSTR(pHostEnt->h_name);
		}
		if(pbstrAlias && pHostEnt->h_aliases)
		{
			if(*pbstrAlias)
			{
				::SysFreeString(*pbstrAlias);
				*pbstrAlias = NULL;
			}
			*pbstrAlias=A2BSTR(pHostEnt->h_aliases[0]);
		}
	}
	else
	{
		if(phHandle)
			memcpy(phHandle, m_strHostEntBuffer, sizeof(HANDLE));
	}
	m_USAttr.m_hr = S_OK;
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::SetSockOptAtSvr(long lOptName, long lOptValue, long lLevel)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	int intLevel = (unsigned short)lLevel;
	m_tempQueue.Push(&lOptName);
	m_tempQueue.Push(&lOptValue);
	m_tempQueue.Push(&intLevel);
	return SendRequestEx(idSetSockOptAtSvr, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::GetSockOptAtSvr(long lOptName, long lLevel)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	int intLevel = (unsigned short)lLevel;
	m_tempQueue.Push(&lOptName);
	m_tempQueue.Push(&intLevel);
	return SendRequestEx(idGetSockOptAtSvr, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::GetOptValueAtSvr(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_USAttr.m_lOptValue;
	return uecOK;
}

STDMETHODIMP CUSocket::get_EncryptionMethod(short *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
	{
		*pVal = m_SBAttr.m_EncryptionMethod;
	}

	return uecOK;
}

STDMETHODIMP CUSocket::put_EncryptionMethod(short newVal)
{
//	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_SBAttr.m_EncryptionMethod = (tagEncryptionMethod)newVal;
	return uecOK;
}


STDMETHODIMP CUSocket::get_SSLHandle(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
	{
		if(m_SBAttr.m_EncryptionMethod == SSL23 || m_SBAttr.m_EncryptionMethod == TLSv1)
		{
			*pVal = (long)m_SBAttr.m_pSSL;
		}
		else if(m_SBAttr.m_EncryptionMethod == MSSSL || m_SBAttr.m_EncryptionMethod == MSTLSv1)
		{
			*pVal = (long)&m_Sspi.m_hContext;
		}
		else
		{
			*pVal = 0;
		}
	}
	return uecOK;
}

STDMETHODIMP CUSocket::GetProcAddress(BSTR bstrOpenSSLFuncName, long *plProcAddr)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(plProcAddr != NULL)
	{
		*plProcAddr = 0;
		if(bstrOpenSSLFuncName && ::SysStringLen(bstrOpenSSLFuncName) && g_pWSAStartup->SSL_accept)
		{
//			USES_CONVERSION;
			FARPROC	farProc=NULL;
			if(g_pWSAStartup->m_hSSLEay)
			{
				farProc = ::GetProcAddress(g_pWSAStartup->m_hSSLEay, bstrOpenSSLFuncName);
			}
			if(!farProc && g_pWSAStartup->m_hLibeay)
				farProc = ::GetProcAddress(g_pWSAStartup->m_hLibeay, bstrOpenSSLFuncName);
			*plProcAddr = (long)farProc;
		}
		else
		{
			m_USAttr.m_hr = uecUnexpected;
		}
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::get_PeerCertificate(VARIANT *pVal)
{
	if(pVal == NULL)
		return S_OK;
	::VariantClear(pVal);
	
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_pSSL != NULL || m_Sspi.m_hContext.dwLower != 0 || m_Sspi.m_hContext.dwUpper != 0)
	{
		CComObject<CUCert> *pUCert = NULL;
		

		m_USAttr.m_hr =  CComObject<CUCert>::CreateInstance(&pUCert);
		if(FAILED(m_USAttr.m_hr))
		{
			return m_USAttr.m_hr;
		}
		
		pUCert->m_pUSocket = this;
		pUCert->m_pSSL = m_SBAttr.m_pSSL;
	
		
		m_USAttr.m_hr = pUCert->QueryInterface(__uuidof(IUnknown), (void**)&(pVal->punkVal));
		if(!FAILED(m_USAttr.m_hr))
		{
			pVal->vt = VT_UNKNOWN;
		}
		else
		{
			delete pUCert;
		}
		return m_USAttr.m_hr;
		
	}
	m_USAttr.m_hr = S_OK;
	return S_OK;
}

STDMETHODIMP CUSocket::get_Key(VARIANT *pVal)
{
	if(pVal)
	{
		::VariantClear(pVal);
//		CAutoLock AutoLock(&m_csGeneral.m_sec);
//		::VariantCopy(pVal, &m_vtKey);
	}
	return uecOK;
}

STDMETHODIMP CUSocket::put_Key(VARIANT newVal)
{
	//Beginning 4.8.2.4, the following commented out, it is returned on 4.8.2.6
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if((newVal.vt == (VT_ARRAY|VT_UI1)||newVal.vt == (VT_ARRAY|VT_I1)) && newVal.parray->rgsabound[0].cElements>=1 && newVal.parray->rgsabound[0].cElements<=56)
	{
		BYTE	*pBuffer;
		if(m_pBlowFish)
		{
			delete m_pBlowFish;
		}
		::SafeArrayAccessData(newVal.parray, (void**)&pBuffer);
		m_pBlowFish = new CBF(pBuffer, newVal.parray->rgsabound[0].cElements);
		::SafeArrayUnaccessData(newVal.parray);
	}
	else
	{
		if(m_pBlowFish)
		{
			delete m_pBlowFish;
			m_pBlowFish = NULL;
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocket::get_Rtn(long *plRtn)
{
	if(plRtn)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*plRtn = m_USAttr.m_hr;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::SetClientVersion(short nMinor, short nMajor)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_Client.m_usVerMinor = nMinor;
	m_USAttr.m_Client.m_usVerMajor = nMajor;
	return uecOK;
}

STDMETHODIMP CUSocket::Enter(/*[in]*/long lGroup)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequestEx(idEnter, sizeof(lGroup), (BYTE*)&lGroup);
}

STDMETHODIMP CUSocket::Exit()
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequestEx(idExit, 0, NULL);
}

STDMETHODIMP CUSocket::Speak(/*[in]*/VARIANT vtMsg, /*[in, defaultvalue(0xFFFFFFFF)]*/long lGroups)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}

	if(m_pJSSerialization != NULL)
	{
		m_pJSSerialization->m_UQueue.SetSize(0);
		m_pJSSerialization->m_UQueue<<lGroups;
		m_USAttr.m_hr = m_pJSSerialization->save(vtMsg);
		if(FAILED(m_USAttr.m_hr))
			return m_USAttr.m_hr;
		return SendJSRequest(idSpeak);
	}

	m_tempQueue.SetSize(0);
	m_tempQueue.Push(&lGroups);
	m_tempQueue.PushVT(vtMsg);
	return SendRequestEx(idSpeak, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::SpeakTo(/*[in]*/BSTR bstrIPAddr, /*[in]*/long lPort, /*[in]*/VARIANT vtMsg)
{
	USES_CONVERSION;
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly || bstrIPAddr == NULL || ::SysStringLen(bstrIPAddr)==0 || lPort<=0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	unsigned long ulAddr = ::inet_addr(OLE2A(bstrIPAddr));
/*	if(ulAddr == INADDR_NONE)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}*/
	if(m_pJSSerialization != NULL)
	{
		m_pJSSerialization->m_UQueue.SetSize(0);
		m_pJSSerialization->m_UQueue<<ulAddr;
		m_pJSSerialization->m_UQueue<<lPort;
		m_USAttr.m_hr = m_pJSSerialization->save(vtMsg);
		if(FAILED(m_USAttr.m_hr))
			return m_USAttr.m_hr;
		return SendJSRequest(idSpeakTo);
	}
	m_tempQueue.Push(&ulAddr);
	m_tempQueue.Push(&lPort);
	m_tempQueue.PushVT(vtMsg);
	return SendRequestEx(idSpeakTo, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::GetAllGroups()
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequestEx(idGetAllGroups, 0, NULL);
}

STDMETHODIMP CUSocket::GetGroupInfo(/*[in]*/long lIndex, /*[out]*/long *plGroup, /*[out, retval]*/BSTR *pbstrDescription)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_GroupInfos.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(plGroup)
		*plGroup=m_GroupInfos[lIndex].m_dwID;

	if(pbstrDescription && m_GroupInfos[lIndex].m_bstrDescription.m_str)
		*pbstrDescription=::SysAllocString(m_GroupInfos[lIndex].m_bstrDescription.m_str);

	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetAllListeners(/*[in, defaultvalue(0xFFFFFFFF)]*/long lGroups)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequestEx(idGetAllListeners, sizeof(lGroups), (BYTE*)&lGroups);
}

STDMETHODIMP CUSocket::GetInfo(/*[in]*/long lIndex, /*[out]*/long *plGroup, /*[out]*/BSTR *pbstrUID, long *plSvsID, /*[out]*/long *plPort, /*[out, retval]*/BSTR *pbstrIPAddress)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_Listeners.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(plSvsID)
		*plSvsID = m_Listeners[lIndex].m_ulSvsID;
	if(plGroup)
		*plGroup = m_Listeners[lIndex].m_dwID;
	if(pbstrUID)
		*pbstrUID = OLE2BSTR(m_Listeners[lIndex].m_strUID);
	if(plPort)
		*plPort = m_Listeners[lIndex].m_unPort;
	if(pbstrIPAddress)
	{
		in_addr in;
		in.S_un.S_addr=m_Listeners[lIndex].m_ulIPAddr;
		*pbstrIPAddress=A2BSTR(::inet_ntoa(in));
	}
	return uecOK;
}

STDMETHODIMP CUSocket::get_Groups(/*[out, retval]*/ long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal=m_GroupInfos.GetSize();
	return uecOK;
}

STDMETHODIMP CUSocket::get_Listeners(/*[out, retval]*/ long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal=m_Listeners.GetSize();
	return uecOK;
}

STDMETHODIMP CUSocket::get_Message(/*[out, retval]*/ VARIANT *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
	{
		if(m_pJSSerialization != NULL)
		{
			m_pJSSerialization->m_UQueue.SetSize(0);
			m_pJSSerialization->m_UQueue.PushVT(m_vtMsg);
			return m_pJSSerialization->load(pVal);
		}
		else
		{
			::VariantClear(pVal);
			::VariantCopy(pVal, &m_vtMsg);
		}
	}
	return uecOK;
}

STDMETHODIMP CUSocket::get_ZipIsOn(VARIANT_BOOL *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_USAttr.m_bZipIsOn ? VARIANT_TRUE : VARIANT_FALSE;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::put_ZipIsOn(VARIANT_BOOL newVal)
{
/*
#if defined(ARM) || defined(_ARM_) || defined(ARMV4)
	newVal = VARIANT_FALSE;
#endif*/

//	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_bZipIsOn = newVal ? true : false;
	return uecOK;
}

STDMETHODIMP CUSocket::TurnOnZipAtSvr(VARIANT_BOOL bZipOn)
{
/*
#if defined(ARM) || defined(_ARM_) || defined(ARMV4)
	bZipOn = VARIANT_FALSE;
#endif*/
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	bool bData = bZipOn ? true : false;
	return SendRequestEx(idTurnOnZipAtSvr, sizeof(bData), (BYTE*)&bData);
}

STDMETHODIMP CUSocket::get_ZipOnAtSvr(VARIANT_BOOL *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_USAttr.m_bZipIsOnSvr ? VARIANT_TRUE : VARIANT_FALSE;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::get_KeyFromSvr(VARIANT *pVal)
{
	if(pVal)
	{
		::VariantClear(pVal);
	}
	return uecOK;
}

STDMETHODIMP CUSocket::StartBatching()
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(!m_USAttr.m_bBatching /*&& !m_USAttr.m_bSyn*/)
	{
		m_USAttr.m_hr = uecOK;
		m_BatchQueue.Pop(m_BatchQueue.GetSize());
		m_USAttr.m_bBatching = true;
	}
	else
	{
		m_USAttr.m_hr = uecUnexpected;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::CommitBatching(VARIANT_BOOL bSvrBatching)
{
	ATLASSERT(::GetCurrentThreadId() == m_dwObjThreadID);
	CAutoLock AutoLockLocal(&(m_csGeneral.m_sec));
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(m_USAttr.m_bBatching)
	{
		m_USAttr.m_hr = uecOK;
		m_USAttr.m_bBatching = false;
		if(m_BatchQueue.GetSize())
		{
			ATLASSERT(m_BatchQueue.GetSize()>=sizeof(CStreamHeader));
			if(bSvrBatching != VARIANT_FALSE)
			{
				CStreamHeader	StreamHeader;
				memset(&StreamHeader, 0, sizeof(CStreamHeader));
				StreamHeader.m_nRequestID = idStartBatching;
				m_tempQueue.SetSize(0);
				m_tempQueue.Push(&StreamHeader);
				m_tempQueue.Push(m_BatchQueue.GetBuffer(), m_BatchQueue.GetSize());
				StreamHeader.m_nRequestID = idCommitBatching;
				m_tempQueue.Push(&StreamHeader);
				m_BatchQueue.SetSize(0);
				m_BatchQueue.Push(m_tempQueue.GetBuffer(), m_tempQueue.GetSize());
				m_tempQueue.SetSize(0);
			}
			if(m_USAttr.m_bZipIsOn && m_BatchQueue.GetSize() > ((m_UZip.m_ZipLevel == zlBestSpeed) ? 260 : 16))
			{ 
				SendRequestEx(idBatchZipped, m_BatchQueue.GetSize(), (BYTE*)m_BatchQueue.GetBuffer());	
			}
			else
			{
				m_tempQueue.SetSize(0);
				memset(&m_RTrace, 0, sizeof(m_RTrace));
				{
					BYTE	*pBuffer = (BYTE*)m_BatchQueue.GetBuffer();
					unsigned long ulPos = 0;
					while(ulPos<m_BatchQueue.GetSize())
					{
						CStreamHeader	*pStreamHeader = (CStreamHeader*)(pBuffer + ulPos);
						ulPos += sizeof(CStreamHeader);
						ulPos += pStreamHeader->m_ulLen;
						m_RTrace.m_ulContained = 1;
						m_RTrace.m_ulRBufferLen = pStreamHeader->m_ulLen;
						m_RTrace.m_usRID = pStreamHeader->m_nRequestID;
						m_tempQueue.Push(&m_RTrace);
						if(pStreamHeader->m_nRequestID != idStartBatching && pStreamHeader->m_nRequestID != idCommitBatching)
						{
							m_requestQueue.Push((const BYTE*)&pStreamHeader->m_nRequestID, sizeof(pStreamHeader->m_nRequestID)); //looks like WCHAR
						}
					}
				}
				if(m_SBAttr.m_EncryptionMethod == BlowFish && m_pBlowFish)
				{
					unsigned long ul = m_BatchQueue.GetSize();
					CStreamHeader	StreamHeader;
					StreamHeader.m_bRatio = 0;
					StreamHeader.m_bTreat = 0;
					StreamHeader.m_nRequestID = idEncrypted;
					if((ul%8))
					{
						BYTE	pData[7] = {0};
						ul = ul + 8 - (ul%8);
						m_BatchQueue.Push(pData, ul-m_BatchQueue.GetSize());
					}
					m_pBlowFish->Encrypt((BYTE*)m_BatchQueue.GetBuffer(), ul);
					StreamHeader.m_ulLen = ul;
					m_RTrace.m_ulContained = m_tempQueue.GetSize()/sizeof(m_RTrace);
					if(bSvrBatching)
					{
						ATLASSERT(m_RTrace.m_ulContained >= 3);
						m_RTrace.m_ulContained -=2;
					}
					m_RTrace.m_ulRBufferLen = ul;
					m_RTrace.m_usRID = idEncrypted;
					m_tempQueue.SetSize(0);
					m_tempQueue.Push(&m_RTrace);
					m_BatchQueue.Insert(&StreamHeader);
				}
				m_sndQueue.Push(m_BatchQueue.GetBuffer(), m_BatchQueue.GetSize());
				m_traceQueue.Push(m_tempQueue.GetBuffer(), m_tempQueue.GetSize());
				USend();
				if(m_USAttr.m_bSyn)
				{
					DoSyn();
					ATLASSERT(m_requestQueue.GetSize()==0);
				}
			}
//			m_BatchQueue.Pop(m_BatchQueue.GetSize());
			m_BatchQueue.SetSize(0);
		}
	}
	else
	{
		m_USAttr.m_hr = uecUnexpected;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::AbortBatching()
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(!m_USAttr.m_bBatching)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_USAttr.m_hr = uecOK;
	m_BatchQueue.Pop(m_BatchQueue.GetSize());
	m_USAttr.m_bBatching = false;
	return m_USAttr.m_hr;
}

/*
STDMETHODIMP CUSocket::Pack(VARIANT vtBuffer)
{
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(m_USAttr.m_bBatching)
	{
		if(vtBuffer.vt == VT_EMPTY || vtBuffer.vt == VT_NULL)
		{
			m_USAttr.m_hr = uecOK;
		}
		else if(vtBuffer.vt == (VT_UI1|VT_ARRAY) || vtBuffer.vt == (VT_I1|VT_ARRAY))
		{
			void *pBuffer;
			unsigned long ulLen = vtBuffer.parray->rgsabound[0].cElements;
			::SafeArrayAccessData(vtBuffer.parray, &pBuffer);
			m_BatchQueue.Push(pBuffer, ulLen);
			::SafeArrayUnaccessData(vtBuffer.parray);
			m_USAttr.m_hr = uecOK;
		}
		else
		{
			m_USAttr.m_hr = uecOK;
			switch(vtBuffer.vt)
			{
			case VT_I1:
				m_BatchQueue.Push(&vtBuffer.cVal, sizeof(vtBuffer.cVal));
				break;
			case VT_UI1:
				m_BatchQueue.Push(&vtBuffer.bVal, sizeof(vtBuffer.bVal));
				break;
			case VT_I2:
				m_BatchQueue.Push(&vtBuffer.iVal, sizeof(vtBuffer.iVal));
				break;
			case VT_UI2:
				m_BatchQueue.Push(&vtBuffer.iVal, sizeof(vtBuffer.uiVal));
				break;
			case VT_I4:
				m_BatchQueue.Push(&vtBuffer.lVal, sizeof(vtBuffer.lVal));
				break;
			case VT_UI4:
				m_BatchQueue.Push(&vtBuffer.ulVal, sizeof(vtBuffer.ulVal));
				break;
			case VT_R4:
				m_BatchQueue.Push(&vtBuffer.fltVal, sizeof(vtBuffer.fltVal));
				break;
			case VT_R8:
				m_BatchQueue.Push(&vtBuffer.dblVal, sizeof(vtBuffer.dblVal));
				break;
			case VT_CY:
				m_BatchQueue.Push(&vtBuffer.cyVal, sizeof(vtBuffer.cyVal));
				break;
			case VT_DATE:
				m_BatchQueue.Push(&vtBuffer.date, sizeof(vtBuffer.date));
				break;
			case VT_BOOL:
				m_BatchQueue.Push(&vtBuffer.boolVal, sizeof(vtBuffer.boolVal));
				break;
			case VT_DECIMAL:
				m_BatchQueue.Push(&vtBuffer.decVal, sizeof(vtBuffer.decVal));
				break;
			case VT_INT:
				m_BatchQueue.Push(&vtBuffer.intVal, sizeof(vtBuffer.intVal));
				break;
			case VT_UINT:
				m_BatchQueue.Push(&vtBuffer.uintVal, sizeof(vtBuffer.uintVal));
				break;
			case VT_BSTR:
				{
					unsigned long ulLen = ::SysStringLen(vtBuffer.bstrVal)*sizeof(WCHAR);
					m_BatchQueue.Push(vtBuffer.bstrVal, ulLen);
				}
				break;
			default:
				if((vtBuffer.vt & VT_ARRAY) == VT_ARRAY)
				{	
					ATLASSERT(vtBuffer.parray->cDims == 1);
					ATLASSERT(vtBuffer.parray->rgsabound[0].lLbound == 0);
					void	*pBuffer = NULL;
					ULONG ulSize = vtBuffer.parray->rgsabound[0].cElements;
					ATLASSERT(ulSize);
					::SafeArrayAccessData(vtBuffer.parray, &pBuffer);
					ATLASSERT(pBuffer);
					switch(vtBuffer.vt)
					{
					case (VT_I2|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(SHORT));
						break;
					case (VT_UI2|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(USHORT));
						break;
					case (VT_I4|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(LONG));
						break;
					case (VT_UI4|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(ULONG));
						break;
					case (VT_R4|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(FLOAT));
						break;
					case (VT_R8|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(DOUBLE));
						break;
					case (VT_CY|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(CY));
						break;
					case (VT_DATE|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(DATE));
						break;
					case (VT_BOOL|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(VARIANT_BOOL));
						break;
					case (VT_DECIMAL|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(DECIMAL));
						break;
					case (VT_INT|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(INT));
						break;
					case (VT_UINT|VT_ARRAY):
						m_BatchQueue.Push(pBuffer, ulSize*sizeof(UINT));
						break;
					default:
						m_USAttr.m_hr = uecUnexpected;
						break;
					}
					::SafeArrayUnaccessData(vtBuffer.parray);
				}
				else
				{
					m_USAttr.m_hr = uecUnexpected;
				}
				break;
			}
		}	
	}
	else
	{
		m_USAttr.m_hr = uecUnexpected;		
	}
	return m_USAttr.m_hr;
}*/

STDMETHODIMP CUSocket::GetRequestsInQueue(VARIANT *pvtRequests)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(pvtRequests)
	{
		::VariantClear(pvtRequests);
		if(m_requestQueue.GetSize())
		{
			void *pBuffer;
			SAFEARRAYBOUND sab[1] = {m_requestQueue.GetSize()/sizeof(unsigned short), 0};
			SAFEARRAY *psa = ::SafeArrayCreate(VT_I2, 1, sab);
			::SafeArrayAccessData(psa, (void**)&pBuffer);
			memcpy(pBuffer, m_requestQueue.GetBuffer(), m_requestQueue.GetSize());
			::SafeArrayUnaccessData(psa);
			pvtRequests->vt = (VT_ARRAY|VT_I2);
			pvtRequests->parray = psa;
		}	
	}
	return uecOK;
}

STDMETHODIMP CUSocket::SendRequest(short nRequestID, VARIANT vtData, VARIANT_BOOL bKeepVTFormat)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET)
	{
		m_USAttr.m_hr = seNotSock;
		return m_USAttr.m_hr;
	}

	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(bKeepVTFormat)
	{
		m_tempQueue.SetSize(0);
		m_tempQueue.PushVT(vtData);
		m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
		return m_USAttr.m_hr;
	}
	if(vtData.vt == (VT_ARRAY|VT_UI1) || vtData.vt == (VT_ARRAY|VT_I1))
	{
		BYTE	*pBuffer;
		unsigned long ulLen = vtData.parray->rgsabound[0].cElements;
		::SafeArrayAccessData(vtData.parray, (void**)&pBuffer);
		m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulLen, pBuffer);
		::SafeArrayUnaccessData(vtData.parray);
	}
	else if(vtData.vt == VT_EMPTY || vtData.vt == VT_NULL)
	{
		m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, 0, NULL);
	}
	else
	{
		switch(vtData.vt)
		{
		case VT_I1:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.cVal), (BYTE*)&vtData.cVal);
			break;
		case VT_UI1:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.bVal), (BYTE*)&vtData.bVal);
			break;
		case VT_I2:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.iVal), (BYTE*)&vtData.iVal);
			break;
		case VT_UI2:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.uiVal), (BYTE*)&vtData.uiVal);
			break;
		case VT_I4:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.lVal), (BYTE*)&vtData.lVal);
			break;
		case VT_UI4:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.ulVal), (BYTE*)&vtData.ulVal);
			break;
		case VT_R4:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.fltVal), (BYTE*)&vtData.fltVal);
			break;
		case VT_R8:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.dblVal), (BYTE*)&vtData.dblVal);
			break;
		case VT_CY:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.cyVal), (BYTE*)&vtData.cyVal);
			break;
		case VT_DATE:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.date), (BYTE*)&vtData.date);
			break;
		case VT_BOOL:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.boolVal), (BYTE*)&vtData.boolVal);
			break;
		case VT_DECIMAL:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.decVal), (BYTE*)&vtData.decVal);
			break;
		case VT_INT:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.intVal), (BYTE*)&vtData.intVal);
			break;
		case VT_UINT:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.uintVal), (BYTE*)&vtData.uintVal);
			break;
		case VT_UI8:
		case VT_I8:
#ifndef _WIN32_WCE
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(vtData.llVal), (BYTE*)&(vtData.llVal));
#else
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(LONGLONG), (BYTE*)&(vtData.lVal));
#endif
			break;
		case VT_FILETIME:
			m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, sizeof(FILETIME), (BYTE*)&(vtData.lVal));
			break;
		case VT_BSTR:
			{
				unsigned long ulLen = ::SysStringLen(vtData.bstrVal)*sizeof(WCHAR);
				m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulLen, (BYTE*)vtData.bstrVal);
			}
			break;
		default:
			if((vtData.vt & VT_ARRAY) == VT_ARRAY)
			{	
				ATLASSERT(vtData.parray->cDims == 1);
				ATLASSERT(vtData.parray->rgsabound[0].lLbound == 0);
				BYTE	*pBuffer = NULL;
				ULONG ulSize = vtData.parray->rgsabound[0].cElements;
				ATLASSERT(ulSize);
				::SafeArrayAccessData(vtData.parray, (void**)&pBuffer);
				ATLASSERT(pBuffer);
				switch(vtData.vt)
				{
				case (VT_I2|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(SHORT), pBuffer);
					break;
				case (VT_UI2|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(USHORT), pBuffer);
					break;
				case (VT_I4|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(LONG), pBuffer);
					break;
				case (VT_UI4|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(ULONG), pBuffer);
					break;
				case (VT_R4|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(FLOAT), pBuffer);
					break;
				case (VT_R8|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(DOUBLE), pBuffer);
					break;
				case (VT_CY|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(CY), pBuffer);
					break;
				case (VT_DATE|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(DATE), pBuffer);
					break;
				case (VT_BOOL|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(VARIANT_BOOL), pBuffer);
					break;
				case (VT_DECIMAL|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(DECIMAL), pBuffer);
					break;
				case (VT_INT|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(INT), pBuffer);
					break;
				case (VT_UINT|VT_ARRAY):
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(UINT), pBuffer);
					break;
				case (VT_I8|VT_ARRAY):
				case (VT_UI8|VT_ARRAY):
#ifndef _WIN32_WCE
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(vtData.llVal), pBuffer);
#else
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(LONGLONG), pBuffer);
#endif
					break;
				case VT_FILETIME:
					m_USAttr.m_hr = SendRequestEx((unsigned short)nRequestID, ulSize*sizeof(FILETIME), pBuffer);
					break;
				default:
					m_USAttr.m_hr = uecUnexpected;
					break;
				}
				::SafeArrayUnaccessData(vtData.parray);
			}
			else
			{
				m_USAttr.m_hr = uecUnexpected;
			}
			break;
		}
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetRtnBuffer(long nLen, VARIANT *pvtData)
{
	if(nLen == 0)
		return uecOK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(nLen && pvtData)
	{
		::VariantClear(pvtData);
		if(m_SBAttr.m_bUseBaseSocketOnly || m_USAttr.m_curRcvStreamHeader.m_nRequestID==0 || (m_USAttr.m_curRcvStreamHeader.m_bTreat & odZipped)!=0 || m_USAttr.m_curRcvStreamHeader.m_nRequestID == idEncrypted)
		{
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}
		unsigned long ulLen = m_USAttr.m_curRcvStreamHeader.m_ulLen;
		if(ulLen > (unsigned long)nLen)
		{
			ulLen = (unsigned long)nLen;
		}
		if(ulLen)
		{
			BYTE	*pBuffer = NULL;
			SAFEARRAYBOUND sab[1] = {ulLen, 0};
			SAFEARRAY *psa = ::SafeArrayCreate(VT_UI1, 1, sab);
			::SafeArrayAccessData(psa, (void**)&pBuffer);
			GetRtnBufferEx(ulLen, pBuffer, (unsigned long*)&nLen);
			if(ulLen != (unsigned long)nLen)
			{
				ulLen = 0;
			}
			::SafeArrayUnaccessData(psa);
			pvtData->vt = (VT_ARRAY|VT_UI1);
			pvtData->parray = psa;
		}
	}
	return m_USAttr.m_hr;
}

/*
STDMETHODIMP CUSocket::PackEx(unsigned long ulLen, BYTE *pBuffer)
{
	m_USAttr.m_hr = uecOK;
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(ulLen && pBuffer)
	{
		if(!m_USAttr.m_bBatching)
		{
			m_USAttr.m_hr = uecUnexpected;	
		}
		else
		{
			m_BatchQueue.Push(pBuffer, ulLen);
		}
	}
	return m_USAttr.m_hr;
}*/

STDMETHODIMP CUSocket::GetRtnBufferEx(unsigned long ulLen, BYTE pBuffer[], unsigned long *plRtnSize)
{
	if(plRtnSize)
		*plRtnSize = 0;
	if(ulLen == 0)
		return uecOK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_USAttr.m_curRcvStreamHeader.m_nRequestID == idEncrypted || m_SBAttr.m_bUseBaseSocketOnly || m_USAttr.m_curRcvStreamHeader.m_nRequestID==0 || (m_USAttr.m_curRcvStreamHeader.m_bTreat & odZipped)!=0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(ulLen && pBuffer && m_USAttr.m_curRcvStreamHeader.m_ulLen)
	{
		if(ulLen > m_USAttr.m_curRcvStreamHeader.m_ulLen)
			ulLen = m_USAttr.m_curRcvStreamHeader.m_ulLen;
		ulLen = m_rcvQueue.Pop(pBuffer, ulLen);
		m_USAttr.m_curRcvStreamHeader.m_ulLen -=ulLen;
		if(plRtnSize)    
			*plRtnSize = ulLen;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::SendRequestEx(unsigned short usRequestID, unsigned long ulLen, BYTE pBuffer[])
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET)
	{
		m_USAttr.m_hr = seNotSock;
		return m_USAttr.m_hr;
	}
	m_USAttr.m_hr = uecOK;
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(usRequestID == idReservedOne || usRequestID == idReservedTwo)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(m_ulSynIndicator && m_USAttr.m_bSyn)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(usRequestID == 0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	CStreamHeader	StreamHeader;
	unsigned long 	ul = 0;
	unsigned long   ulContained = 0;
	StreamHeader.m_nRequestID = usRequestID;
	if(pBuffer == NULL)
		ulLen = 0;
	StreamHeader.m_ulLen = ulLen;
	StreamHeader.m_bRatio = 0;
	StreamHeader.m_bTreat = 0;
	if(m_USAttr.m_bBatching)
	{
		m_BatchQueue.Push(&StreamHeader);
		if(ulLen && pBuffer)
		{
			m_BatchQueue.Push(pBuffer, ulLen);
		}
		m_USAttr.m_hr = uecOK;
	}
	else
	{
		memset(&m_RTrace, 0, sizeof(m_RTrace));
		if(usRequestID != idBatchZipped)
		{
			ulContained = 1;
			m_requestQueue.Push((const BYTE*)&usRequestID, sizeof(usRequestID));
		}
		else
		{
			if(ulLen && pBuffer)
			{
				unsigned long ulPos = 0;
				while(ulPos<ulLen)
				{
					CStreamHeader	*pStreamHeader = (CStreamHeader*)(pBuffer + ulPos);
					ulPos += sizeof(CStreamHeader);
					ulPos += pStreamHeader->m_ulLen;
					if(pStreamHeader->m_nRequestID != idStartBatching && pStreamHeader->m_nRequestID != idCommitBatching)
					{
						ulContained++;
						m_requestQueue.Push((const BYTE*)&pStreamHeader->m_nRequestID, sizeof(pStreamHeader->m_nRequestID)); //looks like WCHAR
					}
				}
			}
		}
		m_tQueue.SetSize(0);
		if(m_USAttr.m_bZipIsOn && ulLen >= ((m_UZip.m_ZipLevel == zlBestSpeed) ? 260 : 16))
		{
			unsigned short usRatio;
			if(m_UZip.m_ZipLevel == zlBestSpeed)
				ul = ulLen + 36008;
			else
				ul = (unsigned long)(1.1*ulLen) + 3000;
			if(ul > m_tQueue.GetMaxSize())
			{
				m_tQueue.ReallocBuffer(ul + 1024);
			}
			if(!m_UZip.Compress(pBuffer, ulLen, (BYTE*)m_tQueue.GetBuffer(), ul))
			{
				m_USAttr.m_hr = uecFailedInZip;
				return m_USAttr.m_hr;      
			}
			m_tQueue.SetSize(ul);
			usRatio = (unsigned short)(ulLen/ul) + 1;
			StreamHeader.m_bTreat = usRatio/256;
			StreamHeader.m_bRatio = (usRatio%256);
			switch(m_UZip.m_ZipLevel)
			{
			case zlBestCompression:
				StreamHeader.m_bTreat = (StreamHeader.m_bTreat|odFastZip);
				break;
			case zlBestSpeed:
				StreamHeader.m_bTreat = (StreamHeader.m_bTreat|odFastZip);
			default:
				StreamHeader.m_bTreat = (StreamHeader.m_bTreat|odZipped);
				break;
			}
			StreamHeader.m_ulLen = ul;
		}

		if(m_SBAttr.m_EncryptionMethod == BlowFish && m_pBlowFish)
		{
			CUQueue	tempQueue;
			tempQueue.Push(&StreamHeader);
			if(m_tQueue.GetSize())
				tempQueue.Push(m_tQueue.GetBuffer(), StreamHeader.m_ulLen);
			else
				tempQueue.Push(pBuffer, ulLen);

			StreamHeader.m_nRequestID = idEncrypted;
			if(tempQueue.GetSize()%8)
			{
				BYTE	pbBytes[7]= {0};
				ul = tempQueue.GetSize() + 8 - (tempQueue.GetSize()%8);
				tempQueue.Push(pbBytes, ul-tempQueue.GetSize());
			}
			else
				ul = tempQueue.GetSize();
			if(tempQueue.GetMaxSize()<ul)
			{
				tempQueue.ReallocBuffer(ul);
			}
			m_pBlowFish->Encrypt((BYTE*)tempQueue.GetBuffer(), ul);
			StreamHeader.m_ulLen = ul;
			StreamHeader.m_bRatio = 0;
			StreamHeader.m_bTreat = 0;
			m_RTrace.m_ulContained = ulContained;
			m_RTrace.m_ulRBufferLen = ul;
			m_RTrace.m_usRID = idEncrypted;
			tempQueue.Insert(&StreamHeader);
			m_sndQueue.Push(tempQueue.GetBuffer(), tempQueue.GetSize());
		}
		else
		{
			m_RTrace.m_ulContained = ulContained;
			m_sndQueue.Push(&StreamHeader);
			m_RTrace.m_usRID = StreamHeader.m_nRequestID;
			if(m_tQueue.GetSize())
			{
				m_RTrace.m_ulRBufferLen = StreamHeader.m_ulLen;
				m_sndQueue.Push(m_tQueue.GetBuffer(), StreamHeader.m_ulLen);
			}
			else
			{
				m_RTrace.m_ulRBufferLen = ulLen;
				m_sndQueue.Push(pBuffer, ulLen);
			}
		}
		m_USAttr.m_hr = uecOK;
		m_traceQueue.Push(&m_RTrace);
		USend();
		if(m_USAttr.m_bSyn)
		{
			DoSyn();
			ATLASSERT(m_requestQueue.GetSize()==0);
		}
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::get_CurrentSvsID(long *plSvsID)
{
	if(plSvsID)
	{
//		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*plSvsID = m_USAttr.m_Client.m_ulSvsID;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::get_UseBaseSocketOnly(VARIANT_BOOL *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_SBAttr.m_bUseBaseSocketOnly ? VARIANT_TRUE : VARIANT_FALSE;
	}
	return uecOK;
}

STDMETHODIMP CUSocket::put_UseBaseSocketOnly(VARIANT_BOOL newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(newVal)
	{
		if(m_requestQueue.GetSize())
		{
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}
	}
	m_SBAttr.m_bUseBaseSocketOnly = newVal ? true : false;
	return uecOK;
}

STDMETHODIMP CUSocket::XEnter(VARIANT vtGroups)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(!(vtGroups.vt == (VT_ARRAY|VT_INT) || vtGroups.vt == (VT_ARRAY|VT_UINT) || vtGroups.vt == (VT_ARRAY|VT_I4) || vtGroups.vt == (VT_ARRAY|VT_UI4)))
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	m_tempQueue.PushVT(vtGroups);
	return SendRequestEx(idXEnter, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::XGetAllListeners(VARIANT vtGroups)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(!(vtGroups.vt == (VT_ARRAY|VT_INT) || vtGroups.vt == (VT_ARRAY|VT_UINT) || vtGroups.vt == (VT_ARRAY|VT_I4) || vtGroups.vt == (VT_ARRAY|VT_UI4)))
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	m_tempQueue.PushVT(vtGroups);
	return SendRequestEx(idGetAllListeners, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::XSpeakEx(unsigned long ulLen, BYTE pMessage[], unsigned long ulGroupCount, unsigned long pGroups[])
{
	if(pGroups == NULL)
		ulGroupCount = 0;
	if(pMessage == NULL)
		ulLen = 0;
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	m_tempQueue << ulLen;
	m_tempQueue.Push(pMessage, ulLen);
	m_tempQueue.Push((const unsigned char*)pGroups, ulGroupCount*sizeof(unsigned long));
	return SendRequestEx(idXSpeakEx, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::XSpeak(VARIANT vtMsg, VARIANT vtGroups)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(!(vtGroups.vt == (VT_ARRAY|VT_INT) || vtGroups.vt == (VT_ARRAY|VT_UINT) || vtGroups.vt == (VT_ARRAY|VT_I4) || vtGroups.vt == (VT_ARRAY|VT_UI4)))
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(m_pJSSerialization != NULL)
	{
		m_pJSSerialization->m_UQueue.SetSize(0);
		m_pJSSerialization->m_UQueue.PushVT(vtGroups);
		m_USAttr.m_hr = m_pJSSerialization->save(vtMsg);
		if(FAILED(m_USAttr.m_hr))
			return m_USAttr.m_hr;
		return SendJSRequest(idXSpeak);
	}
	m_tempQueue.SetSize(0);
	m_tempQueue.PushVT(vtGroups);
	m_tempQueue.PushVT(vtMsg);
	return SendRequestEx(idXSpeak, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}


STDMETHODIMP CUSocket::Cancel(long lRequests)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(lRequests == 0)
		return uecOK;
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if((m_USAttr.m_bBatching || m_USAttr.m_bStartingJob) && (m_USAttr.m_bZipIsOn || m_SBAttr.m_EncryptionMethod == BlowFish))
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	tagEncryptionMethod em = m_SBAttr.m_EncryptionMethod;
	if(em == BlowFish)
	{
		m_SBAttr.m_EncryptionMethod = NoEncryption;
	}
	DWORD dwCancel = (DWORD)lRequests;
	if(m_USAttr.m_bBatching || m_USAttr.m_bStartingJob)
	{
	}
	else
	{
		m_ulCancelRequests = 0;
		dwCancel = CancelImp(lRequests);
	}
	if(dwCancel)
		m_USAttr.m_hr = SendRequestEx(idCancel, sizeof(dwCancel), (BYTE*)&dwCancel);
	if(em == BlowFish)
		m_SBAttr.m_EncryptionMethod = em;
	return m_USAttr.m_hr;
}

void CUSocket::DestroyTimer()
{
	if(m_SBAttr.m_nTimer)
	{
		ATLASSERT(m_MyWindow.m_hWnd);
		ATLASSERT(m_SBAttr.m_hSocket);
		::KillTimer(m_MyWindow.m_hWnd, m_SBAttr.m_hSocket);
		m_SBAttr.m_nTimer = 0;
	}
}

void CUSocket::OnClosed(int nErrorCode)
{
//	int err = 0;
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_bIO && m_hSocketEvent)
	{
		m_bIO = false;
		::SetEvent(m_hSocketEvent);
	}
	m_zlServer = zlDefault;
	m_USAttr.m_Server.m_usUSockMinor = 0;
	m_bVerify = false;
	m_bFirstWrite = false;
	m_bMSSSLState = 0;
 	m_USAttr.m_bZipIsOnSvr = false;
	m_usWaitReqID = 0;
	m_ulWaitSvsID = 0;
	if(m_bDoingHandshake)
	{
		m_USAttr.m_hr = nErrorCode = seSSLError;
		Fire_OnSocketConnected(m_SBAttr.m_hSocket, seSSLError);
	}
	m_USAttr.m_Client.m_ulSvsID = sidStartup;
	memset(&(m_USAttr.m_curRcvStreamHeader), 0, sizeof(m_USAttr.m_curRcvStreamHeader));
	m_USAttr.m_hr = nErrorCode;
	if(m_SBAttr.m_hSocket != INVALID_SOCKET)
	{
		Fire_OnClosing(m_SBAttr.m_hSocket, (long)m_MyWindow.m_hWnd);
	}
	m_bSameEndian = true;
	m_bSendingTooFast = false;
	memset(&m_RTrace, 0, sizeof(m_RTrace));
	m_ulCancelRequests = 0;
	m_requestQueue.SetSize(0);
	m_sndQueue.SetSize(0);
	m_rcvQueue.SetSize(0);
	m_tempQueue.SetSize(0);
	m_BatchQueue.SetSize(0);
	m_traceQueue.SetSize(0);
	m_sndQueue.ReallocBuffer(1024);
	m_rcvQueue.ReallocBuffer(1024);
	m_tempQueue.ReallocBuffer(1024);
	m_BatchQueue.ReallocBuffer(1024);
	m_requestQueue.ReallocBuffer(1024);
	m_traceQueue.ReallocBuffer(1024);
	if(m_SBAttr.m_pSSL)
	{
		g_pWSAStartup->SSL_set_info_callback(m_SBAttr.m_pSSL, NULL);
		g_pWSAStartup->SSL_free(m_SBAttr.m_pSSL);
		m_SBAttr.m_pSSL=NULL;
	}
	m_Sspi.Close(m_SBAttr.m_hSocket);
	m_NetworkBandwidth = npUnknown;
	m_dwBytesIn = 0;
	m_dwBytesInHigh = 0;
	m_dwBytesOut = 0;
	m_dwBytesOutHigh = 0;
	SOCKET hSocket = m_SBAttr.m_hSocket;
	if(m_SBAttr.m_hSocket != INVALID_SOCKET)
	{
//		err = ::WSAGetLastError();
		::closesocket(m_SBAttr.m_hSocket);
		m_SBAttr.m_hSocket = INVALID_SOCKET;
		m_hSocketEvent = NULL;
//		if(!m_bDoingHandshake)
		Fire_OnSocketClosed(hSocket, nErrorCode);
	}
	DestroyTimer();

	if(hSocket != INVALID_SOCKET)
	{
		ULONG ulCount = RemoveLock();
		::EnterCriticalSection(&g_pWSAStartup->m_cs.m_sec);
		g_pWSAStartup->m_mapUSocket.Remove(m_SBAttr.m_hSocket);
		::LeaveCriticalSection(&g_pWSAStartup->m_cs.m_sec);
		Relock(ulCount);
	}
	ATLTRACE("OnClose called, error code = %d, error code2 = %d\n", m_USAttr.m_hr, nErrorCode);
}

bool CUSocket::DoSSLConnect()
{
	ATLASSERT(m_MyWindow.m_hWnd && m_SBAttr.m_pSSL);
	return g_pWSAStartup->SSL_connect(m_SBAttr.m_pSSL) ? true : false;
}

void CUSocket::OnConnected(int nErrorCode)
{
//	CAutoLock AutoLock(&g_pWSAStartup->m_cs.m_sec);
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	m_usRequestIdDiscarded = 0;
	m_USAttr.m_bStartingJob = false;
	if(nErrorCode == 0)
	{
		m_USAttr.m_bZipIsOnSvr = true;
		m_bFirstWrite = true;
	}
	m_ulTimeTrack = ::GetTickCount();
	m_bDoingHandshake = false;
	m_bSendingTooFast = false;
	m_dwBytesIn = 0;
	m_dwBytesInHigh = 0;
	m_dwBytesOut = 0;
	m_dwBytesOutHigh = 0;
	DestroyTimer();
	if(m_SBAttr.m_hWSAAsync)
	{
		//commet the following out for CE
//		WSACancelAsyncRequest(m_SBAttr.m_hWSAAsync);
		m_SBAttr.m_hWSAAsync = 0;
	}
	m_USAttr.m_hr = nErrorCode;
	if(nErrorCode == S_OK)
	{
		m_ulTimeTrack = ::GetTickCount();
//		g_pWSAStartup->m_mapUSocket.Add(m_SBAttr.m_hSocket, this);
		g_pWSAStartup->KillTimer();
		g_pWSAStartup->SetTimer();

		GetInterfaceAttributes(&m_lMTU, &m_lSpeed, &m_lType, NULL, NULL);
		m_NetworkBandwidth = npUnknown;
		if(m_lType == itLoopback)
			m_NetworkBandwidth = npFast;
		else if(m_lType == itPPP || m_lType == itSlip)
			m_NetworkBandwidth = npVerySlow;
/*
#if defined(ARM) || defined(_ARM_) || defined(ARMV4)
		HRESULT hr = SetSockOpt(soSndBuf, 20*1460, slSocket);
		hr = S_OK;
#endif*/

	}
//	m_SBAttr.m_EncryptionMethod = MSTLSv1; ///?????
	memset(&m_USAttr.m_curRcvStreamHeader, 0, sizeof(m_USAttr.m_curRcvStreamHeader));
	if((m_SBAttr.m_EncryptionMethod==TLSv1 || m_SBAttr.m_EncryptionMethod==SSL23) && (nErrorCode == S_OK || nErrorCode == seWouldBlock))
	{
		do
		{
			if(g_pWSAStartup->SSL_accept==NULL)
			{
				if(!g_pWSAStartup->LoadOpenSSL(m_SBAttr.m_EncryptionMethod==SSL23))
				{
					nErrorCode = m_USAttr.m_hr = uecFailedInLoadingSSL;
					Fire_OnSocketConnected(m_SBAttr.m_hSocket, nErrorCode);
					if(nErrorCode != uecOK && m_SBAttr.m_hSocket != 0 && m_SBAttr.m_hSocket != INVALID_SOCKET)
					{
						OnClosed(nErrorCode);
					}
					break;
				}
			}
			if(g_pWSAStartup->m_pCtx==NULL)
			{
				if(!g_pWSAStartup->StartOpenSSL())
				{
					nErrorCode = m_USAttr.m_hr = uecFailedInStartingSSL;
					Fire_OnSocketConnected(m_SBAttr.m_hSocket, nErrorCode);
					if(nErrorCode != uecOK && m_SBAttr.m_hSocket != 0 && m_SBAttr.m_hSocket != INVALID_SOCKET)
					{
						OnClosed(nErrorCode);
					}
					break;
				}
			}
			if(m_SBAttr.m_pSSL == NULL && SetSSL())
			{
				bool bSuc = DoSSLConnect();
				Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgSSLEvent, ssleDoSSLConnect, (long)(g_pWSAStartup->m_pCtx));
				if(bSuc && (m_SBAttr.m_hSocket && m_SBAttr.m_hSocket != INVALID_SOCKET))
				{
					m_USAttr.m_hr = S_OK;
					m_bDoingHandshake = true;
				}	
				else
				{
					m_bDoingHandshake = true;
					m_USAttr.m_hr = seSSLError;
					Fire_OnSocketConnected(m_SBAttr.m_hSocket, seSSLError);
					OnClosed(seSSLError);
				}
			}
		}while(false);
	}
	else if((m_SBAttr.m_EncryptionMethod == MSTLSv1 || m_SBAttr.m_EncryptionMethod == MSSSL) && nErrorCode == S_OK)
	{
		do
		{
			USES_CONVERSION;
			if(!g_pWSAStartup->StartSSPI())
			{
				nErrorCode = m_USAttr.m_hr = uecFailedInLoadingMsSSPI;
				Fire_OnSocketConnected(m_SBAttr.m_hSocket, nErrorCode);
				OnClosed(nErrorCode);
				break;
			}
			
			if(m_Sspi.Open((m_SBAttr.m_EncryptionMethod == MSTLSv1) ? SP_PROT_TLS1 : SP_PROT_SSL3, NULL) != SEC_E_OK)
			{
				nErrorCode = m_USAttr.m_hr = uecFailedInStartingSSL;
				Fire_OnSocketConnected(m_SBAttr.m_hSocket, nErrorCode);
				OnClosed(nErrorCode);
				break;
			}
			Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgSSLEvent, ssleDoSSLConnect, (long)(&m_Sspi.m_hCreds));
			if(m_Sspi.PerformClientHandshake(m_SBAttr.m_hSocket, OLE2T(m_bstrAddrConn)) == SEC_E_OK && (m_SBAttr.m_hSocket && m_SBAttr.m_hSocket != INVALID_SOCKET))
			{
				m_USAttr.m_hr = S_OK;
				m_bDoingHandshake = true;
				Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgSSLEvent, ssleHandshakeStarted, (long)(&m_Sspi.m_hContext));
			}	
			else
			{
				m_USAttr.m_hr = seSSLError;
				m_bDoingHandshake = true;
				Fire_OnSocketConnected(m_SBAttr.m_hSocket, seSSLError);
				OnClosed(seSSLError);
			}
		}while(false);
	}
	else
	{
		m_USAttr.m_hr = nErrorCode;
		Fire_OnSocketConnected(m_SBAttr.m_hSocket, nErrorCode);
		if(nErrorCode != uecOK && m_SBAttr.m_hSocket != 0 && m_SBAttr.m_hSocket != INVALID_SOCKET)
		{
			OnClosed(nErrorCode);
		}
	}
}

void CUSocket::OnWrite(int nErrorCode)
{
	unsigned long ul;
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		if(m_bFirstWrite && m_hSEvent != NULL)
		{
			m_USAttr.m_hr = SAsyncSelect(m_SBAttr.m_hSocket, (HWND)m_hSocketEvent, msgSocketEvent, 0);
			m_USAttr.m_hr = WSAEventSelect(m_SBAttr.m_hSocket, m_hSEvent, FD_READ|FD_CLOSE|FD_WRITE);
			m_bFirstWrite = false;
			{
				CAutoLock AutoLock(&g_pWSAStartup->m_cs.m_sec);
				m_hSocketEvent = NULL;
			}
		}
		m_USAttr.m_hr = nErrorCode;
		ul = m_sndQueue.GetSize() + m_Sspi.GetDataInBuffer();
		if(ul)
		{
			USend();
			ul = m_sndQueue.GetSize() + m_Sspi.GetDataInBuffer();
		}
	}
	Fire_OnSendingData(m_SBAttr.m_hSocket, nErrorCode, ul);
}

void CUSocket::OnRead(int nErrorCode)
{
	long lByte = 0;
	if(m_SBAttr.m_EncryptionMethod == MSTLSv1 || m_SBAttr.m_EncryptionMethod == MSSSL)
	{
		if(m_Sspi.GetSSLState() == ssClientHello || m_Sspi.GetSSLState() == ssHandshaking)
		{
			Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgSSLEvent, ssleHandshakeLoop, 0);
			SECURITY_STATUS sc = m_Sspi.ClientHandshakeLoop(m_SBAttr.m_hSocket);
			if(sc != SEC_E_OK)
			{
				m_USAttr.m_hr = sc;
				Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgSSLEvent, ssleHandshakeExit, sc);
				OnClosed(sc);
				return;
			}
			else if(m_Sspi.GetSSLState() == ssFinished)
			{
				m_bDoingHandshake = false;
				m_bstrLocation = L"";
				Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgSSLEvent, ssleHandshakeDone, (long)m_Sspi.m_pRemoteCertContext);
				Fire_OnSocketConnected(m_SBAttr.m_hSocket, 0);
			}
			else
			{
				if(m_bIO)
				{
					m_bIO = false;
					::SetEvent(m_hSocketEvent);
				}
				return;
			}
		}
	}
	
	IOCtl(iocRead, &lByte);
	if(lByte == 0)
	{
		if(m_bIO)
		{
			m_bIO = false;
			::SetEvent(m_hSocketEvent);
		}
		return;
	}
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	m_USAttr.m_hr = nErrorCode;
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_ulTimeTrack = ::GetTickCount();
		Fire_OnDataAvailable(m_SBAttr.m_hSocket, lByte, nErrorCode);
		IOCtl(iocRead, &lByte);
		if(lByte > 0)
		{
			::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_READ, 0));
		}
	}
	else
	{
		ULONG ulCount = 0;
		if((rfDataComing & m_usRtnEvents) && lByte && nErrorCode == 0)
		{
			Fire_OnDataAvailable(m_SBAttr.m_hSocket, lByte, 0);
		}
		do
		{
			ULONG ulRtns = QueryRtns();
			if(ulRtns <= 1)
			{
				lByte = URecv();
				if(lByte == 0 )
				{
					if(ulRtns && m_rcvQueue.GetSize())
					{
						if(m_USAttr.m_curRcvStreamHeader.m_ulLen > m_rcvQueue.GetSize())
							break;
					}
					else
					{
						break;
					}
				}
				ulCount++;
			}
			if(m_rcvQueue.GetSize()>=sizeof(CStreamHeader))
			{
				HandleNextRtn();
				ulCount = 0;
				m_rcvQueue.SetHeadPosition();
				m_requestQueue.SetHeadPosition();
//				m_ulTimeTrack = ::GetTickCount();
				if(m_usWaitReqID == 0xFFFF && m_ulWaitSvsID == 0)
					break;
				if(m_rcvQueue.GetSize() > sizeof(CStreamHeader))
				{
					MSG msg;
					while(::PeekMessage(&msg, NULL, 1, 0x7FFF, PM_REMOVE))
					{
						if(msg.hwnd == m_MyWindow.m_hWnd && WSAGETSELECTEVENT(msg.lParam) == FD_READ)
							break;
						if(!m_bFrozen || msg.hwnd == m_MyWindow.m_hWnd)
						{
							::TranslateMessage(&msg);
							::DispatchMessage(&msg);
						}
						if(msg.message == WM_PAINT)
							break;
					}
				}
/*				if(m_rcvQueue.GetSize() < sizeof(CStreamHeader))
					break;*/
			}
			else
			{
				if(ulCount > 1)
					break;
			}
		}while(true);
/*		if(m_sndQueue.GetSize())
		{
			USend();
		}*/
	}
	if(m_bIO && m_hSocketEvent)
	{
		m_bIO = false;
		::SetEvent(m_hSocketEvent);
	}
}

void CUSocket::OnOtherMessage(long nMsg, WPARAM wParam, LPARAM lParam)
{
	switch(nMsg)
	{
	case msgAsyncGetHostByName:
		OnWSAAsyncGetHostByName(wParam, WSAGETASYNCERROR(lParam), WSAGETASYNCBUFLEN(lParam));
		break;
	case msgWSAGetHostByName:
		OnWSAGetHostByName(wParam, WSAGETASYNCERROR(lParam), WSAGETASYNCBUFLEN(lParam));
		break;
	case msgWSAGetHostByAddr:
		OnWSAGetHostByAddr(wParam, WSAGETASYNCERROR(lParam), WSAGETASYNCBUFLEN(lParam));
		break;
	default:
		Fire_OnOtherMessage(m_SBAttr.m_hSocket, nMsg, wParam, lParam);
	}
}

unsigned long CUSocket::URecv()
{
	ULONG ulBest = (m_lSpeed/(146*8) + 1460);
	unsigned long ulTotal = 0;
	int err = 0;
	unsigned long ulBatch = m_tQueue.GetMaxSize();
	if(ulBatch >= ulBest)
	{
		ulBatch = ulBest;
	}
	else
	{
		m_tQueue.ReallocBuffer(ulBest);
		ulBatch = ulBest;
	}
	void	*pBuffer = (void*)m_tQueue.GetBuffer();
	m_USAttr.m_hr = uecOK;
	bool bNeedOne = false;
	do
	{
		m_tQueue.SetSize(0);
		if(QueryRtns() > 1 && m_rcvQueue.GetSize() > 14600)
		{
			break;
		}
		if((m_SBAttr.m_EncryptionMethod==TLSv1 || m_SBAttr.m_EncryptionMethod == SSL23) && m_SBAttr.m_pSSL)
		{
			g_pWSAStartup->ERR_clear_error();
			err = g_pWSAStartup->SSL_read(m_SBAttr.m_pSSL, pBuffer, ulBatch);
			if(err<0)
			{
				err=g_pWSAStartup->SSL_get_error(m_SBAttr.m_pSSL, err);
				switch (err)
				{
				case SSL_ERROR_NONE: 
					m_USAttr.m_hr = uecOK;
					break;
				case seSSLWantRead:
					m_USAttr.m_hr = uecOK;
					if(bNeedOne)
					{
						bNeedOne = false;
					}
					else
					{
						bNeedOne = true;
					}
					break;
				case seSSLWantWrite:
					ATLTRACE("SSL Want Write, Recv\n");
					m_USAttr.m_hr = uecOK;
					break;
				case seSSLSysCall:
#ifdef _DEBUG
					{
						char strError[513]={0};
						unsigned long ulError = g_WSAStartup.ERR_get_error();
						g_pWSAStartup->ERR_error_string(ulError, strError);
						ATLTRACE("Error code = %d, %s\n", ulError, strError);
					}
#endif	
					err = ::WSAGetLastError();
					if(g_pWSAStartup->ERR_get_error()==0 && (err == 0 || err == seWouldBlock || err == seNoBufs))
					{
						m_USAttr.m_hr = uecOK;
					}
					else
					{
						m_USAttr.m_hr = err;
						OnClosed(err);
					}
					break;
				case seSSLZeroReturn:
				case seSSLError:
				default :
					{
#ifdef _DEBUG						
						char strError[513]={0};
						unsigned long ulError = g_pWSAStartup->ERR_get_error();
						g_pWSAStartup->ERR_error_string(ulError, strError);
						ATLTRACE("Error code = %d, %s\n", ulError, strError);
#endif	
						m_USAttr.m_hr = seSSLError;
						OnClosed(seSSLError);
					}
					break;
				}
				err = 0;
			}
			else
			{
				if(err)
				{
					m_rcvQueue.Push((BYTE*)pBuffer, err);
					m_dwBytesIn += err;
					if(m_dwBytesIn<err)
						m_dwBytesInHigh += 1;
					ulTotal += err;
					bNeedOne = false;
					m_bChecked = false;
					m_ulTimeTrack = ::GetTickCount();
				}
				else
				{
					bNeedOne = false;
				}
			}
		}
		else if(m_SBAttr.m_EncryptionMethod == MSTLSv1 || m_SBAttr.m_EncryptionMethod == MSSSL)
		{
			ULONG ulStart = m_rcvQueue.GetSize();
			SECURITY_STATUS sc = m_Sspi.GetData(m_SBAttr.m_hSocket, m_rcvQueue, ulBatch);
			if(sc != SEC_E_OK)
			{
			break;
				m_USAttr.m_hr = seSSLWantRead;
				OnClosed(seSSLWantRead);
				err = 0;

				break;
			}
			else
			{
				ulStart =  m_rcvQueue.GetSize() - ulStart;
//				ATLTRACE("Data get = %d\n", ulStart);
				err = ulStart;
				if(ulStart)
				{
					m_dwBytesIn += ulStart;
					if(m_dwBytesIn < ulStart)
						m_dwBytesInHigh += 1;
					ulTotal += ulStart;
					m_bChecked = false;
					m_ulTimeTrack = ::GetTickCount();
				}
			}
		}
		else
		{
			err = ::recv(m_SBAttr.m_hSocket, (char*)pBuffer, ulBatch, 0); 
			if(err == -1)
			{
				err = ::WSAGetLastError();
				if(err == seWouldBlock || err == seNoBufs)
				{

				}
				else
				{
					m_USAttr.m_hr = err;
					if(m_SBAttr.m_hSocket != 0 && m_SBAttr.m_hSocket != INVALID_SOCKET)
					{
						OnClosed(err);
//						::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_CLOSE, (WORD)err));
						break;
					}
				}
				err = 0;
			}
			else
			{
				if(err)
				{
					m_rcvQueue.Push((BYTE*)pBuffer, err);
					m_dwBytesIn += err;
					if(m_dwBytesIn<err)
						m_dwBytesInHigh += 1;
					ulTotal += err;
					m_bChecked = false;
					m_ulTimeTrack = ::GetTickCount();
				}
			}
		}
		if(m_rcvQueue.GetSize()>ulBest && QueryRtns()>1)
		{
			break;
		}
	}while(err>0 || bNeedOne);
	return ulTotal;
}

unsigned long CUSocket::UnZip(void *pBuffer, unsigned long ulSize, const void *pSrc, unsigned long ulLen)
{
	bool bSuc = m_UZip.Decompress((void*)pSrc, ulLen, pBuffer, ulSize);
	if(bSuc)
	{
		return ulSize;
	}
	return 0;
}

void CUSocket::HandleNextRtn()
{
	bool bTooFast = true;
	unsigned ulRepeat = 0;
aa:	if(m_USAttr.m_curRcvStreamHeader.m_nRequestID==0 && m_rcvQueue.GetSize()>=sizeof(m_USAttr.m_curRcvStreamHeader))
	{
//		ATLTRACE("Going to retrieve header\n");
		unsigned long ulLenInBuffer;
		unsigned long ulLen;
		m_USAttr.m_curRcvStreamHeader.m_ulLen = 0;
		m_rcvQueue.Pop(&m_USAttr.m_curRcvStreamHeader);
		if(m_bSameEndian && (m_USAttr.m_curRcvStreamHeader.m_nRequestID == idSwitchTo*256 || m_USAttr.m_curRcvStreamHeader.m_nRequestID == idPublicKeyFromSvr*256))
		{
			m_bSameEndian = false;
		}
		if(!m_bSameEndian)
		{
			m_USAttr.m_curRcvStreamHeader.m_nRequestID = ::htons(m_USAttr.m_curRcvStreamHeader.m_nRequestID);
			m_USAttr.m_curRcvStreamHeader.m_ulLen = ::htonl(m_USAttr.m_curRcvStreamHeader.m_ulLen);
		}
		if(m_rcvQueue.GetMaxSize()<m_USAttr.m_curRcvStreamHeader.m_ulLen)
		{
			m_rcvQueue.ReallocBuffer(m_USAttr.m_curRcvStreamHeader.m_ulLen + 1024);
		}
		ulLen = m_USAttr.m_curRcvStreamHeader.m_ulLen;
		ulLenInBuffer = (ulLen > m_rcvQueue.GetSize()) ? m_rcvQueue.GetSize() : ulLen;
		if((m_usRtnEvents & rfComing))
			Fire_OnRequestProcessed(m_SBAttr.m_hSocket, m_USAttr.m_curRcvStreamHeader.m_nRequestID, /*(m_USAttr.m_curRcvStreamHeader.m_bTreat & odZipped),*/ ulLen, ulLenInBuffer, rfComing);	
		//method header coming
	}
	
	if (m_rcvQueue.GetSize() >= m_USAttr.m_curRcvStreamHeader.m_ulLen && m_USAttr.m_curRcvStreamHeader.m_nRequestID != 0)
	{
		//all data for a request come
		unsigned long ulLenInBuffer;
		unsigned long ulLen;

		ulLen = m_USAttr.m_curRcvStreamHeader.m_ulLen;
		ulLenInBuffer = ulLen;
		m_tQueue.SetSize(0);
		if(m_USAttr.m_curRcvStreamHeader.m_nRequestID == idEncrypted && m_pBlowFish /*&& m_SBAttr.m_EncryptionMethod == BlowFish*/)
		{
			unsigned long ulP;
			unsigned long ulPos = 0;
			ATLASSERT((ulLen%8)==0);
			m_rcvQueue.SetHeadPosition();
			m_pBlowFish->Decrypt((BYTE*)m_rcvQueue.GetBuffer(), ulLen);
			while(ulPos<(ulLen-7))
			{
				CStreamHeader *pHeader = (CStreamHeader *)(m_rcvQueue.GetBuffer() + ulPos);
				ulPos += (sizeof(CStreamHeader) + pHeader->m_ulLen);
			}
			ulP = ulLen - ulPos;
			ATLASSERT(ulP<8);
			m_rcvQueue.Pop(ulP, ulPos);
			m_rcvQueue.Pop(&m_USAttr.m_curRcvStreamHeader);
			if(!m_bSameEndian)
			{
				m_USAttr.m_curRcvStreamHeader.m_nRequestID = ::htons(m_USAttr.m_curRcvStreamHeader.m_nRequestID);
				m_USAttr.m_curRcvStreamHeader.m_ulLen = ::htonl(m_USAttr.m_curRcvStreamHeader.m_ulLen);
			}
			ulLen = m_USAttr.m_curRcvStreamHeader.m_ulLen;
			ulLenInBuffer = ulLen;
			if((m_usRtnEvents & rfDecrypted))
				Fire_OnRequestProcessed(m_SBAttr.m_hSocket, m_USAttr.m_curRcvStreamHeader.m_nRequestID, ulLen, ulLenInBuffer, rfDecrypted);

			//all data for a request decrypted
		}
		if((m_USAttr.m_curRcvStreamHeader.m_bTreat & odZipped) == odZipped || (m_USAttr.m_curRcvStreamHeader.m_bTreat & odFastZip) == odFastZip)
		{
			tagZipLevel	bOrig = m_UZip.m_ZipLevel;
			if((m_USAttr.m_curRcvStreamHeader.m_bTreat & odFastZip) == odFastZip && (m_USAttr.m_curRcvStreamHeader.m_bTreat & odZipped) == odZipped)
			{
				m_UZip.m_ZipLevel = zlBestSpeed;
			}
			else if((m_USAttr.m_curRcvStreamHeader.m_bTreat & odFastZip))
			{
				m_UZip.m_ZipLevel = zlBestCompression;
			}
			else
			{
				m_UZip.m_ZipLevel = zlDefault;
			}
			unsigned short nRatio = (m_USAttr.m_curRcvStreamHeader.m_bTreat & (BYTE)0x3F) * (USHORT)256 + m_USAttr.m_curRcvStreamHeader.m_bRatio;
			unsigned long  ulLenZ = nRatio * m_USAttr.m_curRcvStreamHeader.m_ulLen;
			if(ulLenZ> m_tQueue.GetMaxSize())
			{
				m_tQueue.ReallocBuffer(ulLenZ+1024);
			}
			ATLASSERT(m_rcvQueue.GetSize() >= m_USAttr.m_curRcvStreamHeader.m_ulLen);
			ulLenZ = UnZip((BYTE*)m_tQueue.GetBuffer(), ulLenZ, m_rcvQueue.GetBuffer(), m_USAttr.m_curRcvStreamHeader.m_ulLen);
			m_UZip.m_ZipLevel = bOrig;
			m_rcvQueue.Pop(m_USAttr.m_curRcvStreamHeader.m_ulLen);
			m_rcvQueue.Insert(m_tQueue.GetBuffer(), ulLenZ);
			if((m_usRtnEvents & rfUnzipped))
				Fire_OnRequestProcessed(m_SBAttr.m_hSocket, m_USAttr.m_curRcvStreamHeader.m_nRequestID, /*(m_USAttr.m_curRcvStreamHeader.m_bTreat & odZipped),*/ ulLen, ulLenZ, rfUnzipped);
			if(m_USAttr.m_curRcvStreamHeader.m_nRequestID == idBatchZipped)
			{
				ATLASSERT(ulLenZ >= sizeof(m_USAttr.m_curRcvStreamHeader));
				m_rcvQueue.Pop(&m_USAttr.m_curRcvStreamHeader);
				if(!m_bSameEndian)
				{
					m_USAttr.m_curRcvStreamHeader.m_nRequestID = ::htons(m_USAttr.m_curRcvStreamHeader.m_nRequestID);
					m_USAttr.m_curRcvStreamHeader.m_ulLen = ::htonl(m_USAttr.m_curRcvStreamHeader.m_ulLen);
				}
				ATLASSERT(m_rcvQueue.GetSize()>=m_USAttr.m_curRcvStreamHeader.m_ulLen);
				ATLASSERT(m_USAttr.m_curRcvStreamHeader.m_bRatio == 0);
				ATLASSERT(m_USAttr.m_curRcvStreamHeader.m_bTreat == 0);
				ulLenInBuffer = ulLen = m_USAttr.m_curRcvStreamHeader.m_ulLen;
			}
			else
			{
				m_USAttr.m_curRcvStreamHeader.m_bRatio = 0;
				m_USAttr.m_curRcvStreamHeader.m_bTreat = 0;
				m_USAttr.m_curRcvStreamHeader.m_ulLen = ulLenZ;
				ulLenInBuffer = ulLen = ulLenZ;
			}
			//all data for a request unzipped
		}
		m_tQueue.SetSize(0);
		unsigned short usRID = m_USAttr.m_curRcvStreamHeader.m_nRequestID;
		if(QueryRtns()>m_nMaxRtns && !bTooFast)
		{
			CStreamHeader	StreamHeader;
			StreamHeader.m_bRatio = 0;
			StreamHeader.m_bTreat = 0;
			StreamHeader.m_ulLen = 0;
			StreamHeader.m_nRequestID = idSendingTooFast;
			m_sndQueue.Push(&StreamHeader);
			USend();
			bTooFast = true;
		}
		switch(usRID)
		{
		case idSwitchTo:			//
		case idGetSockOptAtSvr:
		case idSetSockOptAtSvr:
		case idDoEcho:
		case idTurnOnZipAtSvr:
		case idCancel:
		case idShrinkMemoryAtSvr:
		case idEncrypted:
		case idStartBatching:
		case idCommitBatching:
		case idBatchZipped:
		case idEchoFromSvr:
		case idPublicKeyFromSvr:
		case idPing:
		case idEnter:
		case idExit:
		case idGetAllGroups:
		case idGetAllListeners:
		case idGetAllClients:
		case idSpeak:
		case idSpeakTo:
		case idSpeakEx:
		case idSpeakToEx:
		case idSendingTooFast:
		case idSendMySpecificBytes:
		case idCleanTrack:
		case idStartJob:
		case idEndJob:
		case idXEnter:
		case idXSpeak:
		case idXSpeakEx:
		case idSendUserMessage:
		case idSendUserMessageEx:
			ATLASSERT(ulLen == ulLenInBuffer);
			ATLTRACE("RequestID = %d; ulLen = %d\n", usRID, ulLen);
			HandleBaseRequest(usRID, ulLen);
			Fire_OnRequestProcessed(m_SBAttr.m_hSocket, usRID, 0, 0, rfCompleted);
			break;
		case idDropRequestResult:
			HandleBaseRequest(usRID, ulLen);
			usRID = m_usRequestIdDiscarded;
			Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgRequestRemoved, usRID, 0);
			break;
		default:
			ATLTRACE("RequestID = %d; ulLen = %d\n", usRID, ulLen);
			Fire_OnRequestProcessed(m_SBAttr.m_hSocket, usRID, ulLen, ulLenInBuffer, rfCompleted);
			if(m_USAttr.m_curRcvStreamHeader.m_ulLen)
			{
				m_USAttr.m_curRcvStreamHeader.m_ulLen -= m_rcvQueue.Pop(m_USAttr.m_curRcvStreamHeader.m_ulLen);
			}
			break;
		}
		if(m_requestQueue.GetSize() >= sizeof(usRID))
		{
			if((m_USAttr.m_Server.m_usUSockMinor & 0x4000) == 0x4000)
			{
				unsigned int n;
				unsigned short usReqId;
				unsigned long ulPos = 0;
				unsigned int nSize = m_requestQueue.GetSize()/sizeof(unsigned short);
				for(n=0; n<nSize; n++)
				{
					usReqId = *((unsigned short*)m_requestQueue.GetBuffer(ulPos));
					if(usReqId == usRID)
					{
						m_requestQueue.Pop((BYTE*)&usReqId, sizeof(unsigned short), ulPos);
						break;
					}
					ulPos += sizeof(unsigned short);
				}
			}
			else
			{
				if(usRID == *((unsigned short*)m_requestQueue.GetBuffer()))
				{
					m_requestQueue.Pop(sizeof(usRID));
				}
			}
		}

		if(m_requestQueue.GetSize() < sizeof(usRID))
		{
			Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgAllRequestsProcessed, 0, 0);
		}

		if(usRID == m_usWaitReqID)
		{
			if(m_USAttr.m_curRcvStreamHeader.m_nRequestID == m_ulWaitSvsID)
			{
				m_ulWaitSvsID = 0;
				m_usWaitReqID = 0xFFFF;
				if(m_USAttr.m_curRcvStreamHeader.m_ulLen==0)
				{
					m_USAttr.m_curRcvStreamHeader.m_bRatio = 0;
					m_USAttr.m_curRcvStreamHeader.m_bTreat = 0;
					m_USAttr.m_curRcvStreamHeader.m_nRequestID = 0;
				}
				return;
			}
		}
		if(m_USAttr.m_curRcvStreamHeader.m_ulLen==0)
		{
			m_USAttr.m_curRcvStreamHeader.m_bRatio = 0;
			m_USAttr.m_curRcvStreamHeader.m_bTreat = 0;
			m_USAttr.m_curRcvStreamHeader.m_nRequestID = 0;
		}
		
		if(m_rcvQueue.GetSize()>=sizeof(CStreamHeader) && m_USAttr.m_curRcvStreamHeader.m_ulLen==0)
		{
			ulRepeat++;
			if(ulRepeat<512)
			{
				goto aa;
			}
			else
			{
				m_rcvQueue.SetHeadPosition();
			}	
		}
		//all data for a request come, unzipped, and decrypted here
	}
	else
	{
		unsigned long ulLenInBuffer;
		unsigned long ulLen;

		ulLen = m_USAttr.m_curRcvStreamHeader.m_ulLen;
		ulLenInBuffer = m_rcvQueue.GetSize();

//		ATLTRACE("ulLen = %d, ulLenInBuffer = %d, TickCount = %d\n", ulLen, ulLenInBuffer, ::GetTickCount());
		if((m_usRtnEvents & rfReceiving))
			Fire_OnRequestProcessed(m_SBAttr.m_hSocket, m_USAttr.m_curRcvStreamHeader.m_nRequestID, /*(m_USAttr.m_curRcvStreamHeader.m_bTreat & odZipped),*/
		ulLen, ulLenInBuffer, rfReceiving); 
	}
	
}

STDMETHODIMP CUSocket::WaitAll(long lTimeOut, VARIANT_BOOL *pbTimeout)
{
	MSG	msg;
	bool bPump;

	if(lTimeOut == 0)
	{
		if(pbTimeout)
		{
			CAutoLock AutoLock(&m_csGeneral.m_sec);
			ATLASSERT((m_requestQueue.GetSize() % 2) == 0);
			*pbTimeout = m_requestQueue.GetSize() ? VARIANT_TRUE : VARIANT_FALSE;
		}
		return S_OK;
	}

	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		bPump = (m_dwObjThreadID == ::GetCurrentThreadId());
		if(m_SBAttr.m_bUseBaseSocketOnly || m_USAttr.m_bStartingJob || m_USAttr.m_bBatching)
		{
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}
	}

	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		if(m_usWaitReqID != 0 || m_ulWaitSvsID != 0)
		{
			m_ulWaitSvsID = 0;
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}
	}

	if(pbTimeout)
		*pbTimeout = VARIANT_FALSE;
	unsigned long ulStart = ::GetTickCount();
	unsigned long ulNow;
	unsigned long ulTimeout = (DWORD)lTimeOut;
/*	if(bPump && g_pWSAStartup->m_dwUsedWithDotNet > 0)
		::SetFocus(NULL);*/
	do
	{
		if(bPump)
		{
			if(m_sndQueue.GetSize())
				USend();
		}
		else
		{
			CAutoLock AutoLock(&m_csGeneral.m_sec);
			if(m_sndQueue.GetSize())
				USend();
		}
		if(bPump)
		{
			while(::PeekMessage(&msg, 0, 1, 0x7FFF, PM_REMOVE))
			{
//				::GetMessage(&msg, 0, 0, 0);
				if(msg.hwnd == m_MyWindow.m_hWnd && (WSAGETSELECTEVENT(msg.lParam) == FD_READ || WSAGETSELECTEVENT(msg.lParam) == FD_WRITE))
					break;
				if(!m_bFrozen || msg.hwnd == m_MyWindow.m_hWnd)
				{
					::TranslateMessage(&msg);
					::DispatchMessage(&msg);
				}
				if(m_requestQueue.GetSize() == 0)
					break;
				if(msg.message == WM_PAINT)
					break;
			}
		}
		
		if(bPump)
		{
			if(m_SBAttr.m_hSocket == INVALID_SOCKET)
				break;
			if(m_requestQueue.GetSize() == 0)
				break;
		}
		else
		{
			CAutoLock AutoLock(&m_csGeneral.m_sec);
			if(m_SBAttr.m_hSocket == INVALID_SOCKET)
				break;
			if(m_requestQueue.GetSize() == 0)
				break;
		}
		
		if(bPump)
		{
			OnRead(0);
		}
		
		if(bPump)
		{
			if(m_requestQueue.GetSize() == 0)
				break;
		}
		else
		{
			CAutoLock AutoLock(&m_csGeneral.m_sec);
			if(m_requestQueue.GetSize() == 0)
				break;
		}
		
		ulNow = ::GetTickCount();
		if(ulNow>ulStart && (ulNow - ulStart)>=ulTimeout)
		{
			if(pbTimeout)
				*pbTimeout = VARIANT_TRUE;
			break;
		}
		{
			timeval timeout = {0, 50000}; //50 ms
			fd_set fds;
			FD_ZERO(&fds);
			if(bPump)
			{
				FD_SET(m_SBAttr.m_hSocket, &fds);
				int nStatus = ::select(0, &fds, NULL, NULL, &timeout);
				if(nStatus == SOCKET_ERROR)
				{
					::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_CLOSE, (WORD)WSAGetLastError()));
					break;
				}
			}
			else
			{
				if(m_hNotify != NULL)
				{
					m_bWaiting = true;
					::WaitForSingleObject(m_hNotify, 2);
					m_bWaiting = false;
				}
				else
				{
					FD_SET(m_SBAttr.m_hSocket, &fds);
					int nStatus = ::select(0, &fds, NULL, NULL, &timeout);
					if(nStatus == SOCKET_ERROR)
					{
						CAutoLock AutoLock(&m_csGeneral.m_sec);
						::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_CLOSE, (WORD)WSAGetLastError()));
						break;
					}
				}
			}
		}
	}while(true);
	return S_OK;
}

/*
STDMETHODIMP CUSocket::WaitAll(long lTimeOut, VARIANT_BOOL *pbTimeout)
{
	MSG	msg;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	unsigned long ulCount;
	unsigned long ulIndex = 0;
	unsigned long ulNow;
	unsigned long ulTimeout = ::GetTickCount() + lTimeOut;
	::SetFocus(NULL);
	do
	{
		ulCount = 0;
		ulIndex++;
		if(m_sndQueue.GetSize())
			USend();
		while(::PeekMessage(&msg, 0, 1, 0x7FFF, PM_REMOVE))
		{
			if(msg.hwnd == m_MyWindow.m_hWnd && WSAGETSELECTEVENT(msg.lParam) == FD_READ)
				break;
			if(!m_bFrozen || msg.hwnd == m_MyWindow.m_hWnd)
			{
				::TranslateMessage(&msg);
				::DispatchMessage(&msg);
			}
			if(msg.message == 0 || msg.message == WM_PAINT)
				break;
			ulCount++;
//			break;
		}
		if(ulCount || (ulIndex%2))
		{
			if(!m_bFrozen)
			{
				::Sleep(0);
			}
			else
			{
				::Sleep(1);
			}
//			::Sleep(0);
		}
		else
		{
			::Sleep(1);
		}
		ulNow = ::GetTickCount();
		if(m_SBAttr.m_hSocket == INVALID_SOCKET)
			break;
		OnRead(0);
		if(m_requestQueue.GetSize() == 0)
			break;
		if(ulNow>=ulTimeout)
			break;
	}while(true);
	if(pbTimeout)
		*pbTimeout = (ulNow>ulTimeout) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}*/

bool CUSocket::Connect( const SOCKADDR* lpSockAddr, UINT nSockAddrLen, bool bSyn)
{
	int nError = 0;
	bool	bSuccess=true;
	m_USAttr.m_hr = ::connect(m_SBAttr.m_hSocket, lpSockAddr, nSockAddrLen);
	if(m_USAttr.m_hr==-1 && bSyn)	
	{
		DWORD	dwTickCount = ::GetTickCount();
		dwTickCount += m_SBAttr.m_ulConnTimeout;
		nError = ::WSAGetLastError();
		if (nError == WSAEWOULDBLOCK)
		{
			while (!PumpMessages(FD_CONNECT))
			{
				if(::GetTickCount()>=dwTickCount)
				{
					::WSASetLastError(WSAETIMEDOUT);
					m_USAttr.m_hr = WSAETIMEDOUT;
					bSuccess=false;
					nError = WSAETIMEDOUT;
					break;
				}
				::Sleep(1);
			}
		}
		else
			bSuccess=false;
	}
	else if(!m_SBAttr.m_nTimer)
	{
		m_USAttr.m_hr = uecOK;
		m_SBAttr.m_nTimer=::SetTimer(m_MyWindow.m_hWnd, m_SBAttr.m_hSocket, m_SBAttr.m_ulConnTimeout, SocketTimerProc);
	}
/*	if(m_SBAttr.m_EncryptionMethod==TLSv1 || m_SBAttr.m_EncryptionMethod==SSL23)
	{
		::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_CONNECT, nError));
	}*/
	return bSuccess;
}

bool CUSocket::PumpMessages(UINT uStopFlag)
{
	MSG msg;
	while (::PeekMessage(&msg, m_MyWindow.m_hWnd, msgSocketEvent, msgSocketEvent, PM_REMOVE))
	{
		if ((SOCKET)msg.wParam == m_SBAttr.m_hSocket)
		{
			if(WSAGETSELECTEVENT(msg.lParam) == FD_CLOSE)
			{
				::DispatchMessage(&msg);
				return false;
			}
			else if (WSAGETSELECTEVENT(msg.lParam) == uStopFlag)
			{
				if (uStopFlag == FD_CONNECT)
				{
					::DispatchMessage(&msg);
					m_USAttr.m_hr = WSAGETSELECTERROR(msg.lParam);
				}
				return (m_USAttr.m_hr==0);
			}
		}
	}
/*	try
	{
		MSG msg;
		while (::PeekMessage(&msg, m_MyWindow.m_hWnd, msgSocketEvent, 0, 0))
		{
			if ((SOCKET)msg.wParam == m_SBAttr.m_hSocket)
			{
				if(WSAGETSELECTEVENT(msg.lParam) == FD_CLOSE)
				{
					return false;
				}
				else if (WSAGETSELECTEVENT(msg.lParam) == uStopFlag)
				{
					if (uStopFlag == FD_CONNECT)
						m_USAttr.m_hr = WSAGETSELECTERROR(msg.lParam);
					return (m_USAttr.m_hr==0);
				}
			}
		}
	}
	catch(...)
	{
		return false;
	}*/
	return false;
}

void CUSocket::OnWSAAsyncGetHostByName(WPARAM wParam, short nError, short nBufferLen)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	SOCKADDR_IN sockAddr;
	memset(&sockAddr,0,sizeof(sockAddr));
	sockAddr.sin_family = m_nAddressFormat;
	LPHOSTENT lphost=(hostent *)m_strHostEntBuffer;
	m_USAttr.m_hr = nError;
	if(nError==S_OK && wParam == (WPARAM)m_SBAttr.m_hWSAAsync)
	{
		sockAddr.sin_addr.s_addr = ((LPIN_ADDR)lphost->h_addr)->s_addr;
		sockAddr.sin_port = htons((u_short)m_nHostPort);
		Connect((SOCKADDR*)&sockAddr, sizeof(sockAddr), false);
	}
	if(wParam == (WPARAM)m_SBAttr.m_hWSAAsync)
	{
		if(nError != S_OK)
		{
			OnConnected(nError);
		}
		m_SBAttr.m_hWSAAsync = 0;
	}
}

void CUSocket::OnWSAGetHostByName(WPARAM wParam, short nError, short nBufferLen)
{
	USES_CONVERSION;
	char	*str;
	UINT	nIndex = 0;
	long	lError = nError;
	BSTR		bstrIPAddr=NULL;
	BSTR		bstrAlias=NULL;
	CComBSTR	bstrTemp;
	in_addr addr;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = nError;
	if(nError != uecOK)
	{
		Fire_OnGetHostByName(wParam, NULL, NULL, NULL, nError);
		return;
	}
	do
	{
		str=((LPHOSTENT)m_strHostEntBuffer)->h_addr_list[nIndex];
		if(str)
		{
			memcpy(&addr, str, 4);
			if(bstrTemp.Length())
				bstrTemp +=L";";
			bstrTemp +=A2BSTR(inet_ntoa(addr));
			nIndex++;
		}
		else
			break;
	}while(true);
	bstrIPAddr=bstrTemp.m_str;
	bstrTemp.m_str=NULL;
	
	BSTR	bstrHostName=A2BSTR(((LPHOSTENT)m_strHostEntBuffer)->h_name);

	str=((LPHOSTENT)m_strHostEntBuffer)->h_aliases[0];
	if(str)
		bstrAlias =A2BSTR(str);
			
	Fire_OnGetHostByName(wParam, bstrHostName, bstrAlias, bstrIPAddr, lError);
	if(bstrIPAddr)
		::SysFreeString(bstrIPAddr);
	if(bstrHostName)
		::SysFreeString(bstrHostName);
	if(bstrAlias)
		::SysFreeString(bstrAlias);
}

void CUSocket::OnWSAGetHostByAddr(WPARAM wParam, short nError, short nBufferLen)
{
	USES_CONVERSION;
	long lError=nError;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = nError;
	if(nError == S_OK)
	{
		LPHOSTENT	pHost = (LPHOSTENT)m_strHostEntBuffer;
		BSTR	bstrHostName = NULL;
		if(pHost->h_name >= (char*)0x20)
			bstrHostName = A2BSTR(pHost->h_name);
		BSTR	bstrAlias = NULL;
		if(pHost->h_aliases[0])
			bstrAlias = A2BSTR(pHost->h_aliases[0]);
		Fire_OnGetHostByAddr(wParam, bstrHostName, bstrAlias, lError);
		if(bstrHostName)
			::SysFreeString(bstrHostName);
		if(bstrAlias)
			::SysFreeString(bstrAlias);
	}
	else
	{
		Fire_OnGetHostByAddr(wParam, NULL, NULL, lError);
	}
}

bool CUSocket::SetSSL()
{
	if(m_SBAttr.m_pSSL)
	{
//		g_pWSAStartup->SSL_clear(m_pSSL);
		g_pWSAStartup->SSL_free(m_SBAttr.m_pSSL);
		m_SBAttr.m_pSSL = NULL;
	}
	m_SBAttr.m_pSSL = g_pWSAStartup->SSL_new (g_pWSAStartup->m_pCtx); 
	if(m_SBAttr.m_pSSL == NULL)
		return false;
	g_pWSAStartup->SSL_set_connect_state(m_SBAttr.m_pSSL);
	if(!g_pWSAStartup->SSL_set_fd(m_SBAttr.m_pSSL, m_SBAttr.m_hSocket))
	{
		return false;
	}
	g_pWSAStartup->SSL_set_read_ahead(m_SBAttr.m_pSSL, 1);
	g_pWSAStartup->SSL_set_info_callback(m_SBAttr.m_pSSL, SSLCallback);
	return true;
}

void CUSocket::OnSSLEvent(int nWhere, int nRtn)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(nRtn < 0)
	{
		int err = g_pWSAStartup->ERR_get_error();
		if(err == 0 || err == seSSLWantRead || err == seSSLWantWrite)
		{
			nRtn = 1;
		}
		else
		{
			nRtn = -1;
		}
	}
	Fire_OnOtherMessage(m_SBAttr.m_hSocket, msgSSLEvent, nWhere, nRtn);
	if(nWhere == ssleHandshakeDone)
	{
		m_bDoingHandshake = false;
		Fire_OnSocketConnected(m_SBAttr.m_hSocket, 0);
	}
}

void CUSocket::SSLCallback(const SSL *pSSL, int nWhere,int nRtn)
{
	if(pSSL)
	{
		SOCKET hSocket = g_pWSAStartup->SSL_get_fd((SSL *)pSSL);
		CUSocket *pSocket = NULL;
		if(hSocket != INVALID_SOCKET)
		{
			::EnterCriticalSection(&g_pWSAStartup->m_cs.m_sec);
			pSocket = g_pWSAStartup->m_mapUSocket.Lookup(hSocket);
			::LeaveCriticalSection(&g_pWSAStartup->m_cs.m_sec);
		}
		if(pSocket)
		{
			pSocket->OnSSLEvent(nWhere, nRtn);	
		}
	}
}

STDMETHODIMP CUSocket::get_RcvMemory(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_rcvQueue.GetMaxSize();
	return S_OK;
}

STDMETHODIMP CUSocket::get_SndMemory(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_sndQueue.GetMaxSize();
	return S_OK;
}

void CUSocket::DoSyn()
{
	VARIANT_BOOL	bTimeout = VARIANT_FALSE;
	m_ulSynIndicator = 1;
	do
	{
		WaitAll(m_SBAttr.m_ulRecvTimeout, &bTimeout);
		if(bTimeout == VARIANT_TRUE && ::GetTickCount()-m_ulTimeTrack<m_SBAttr.m_ulRecvTimeout)
		{
			bTimeout = VARIANT_FALSE;
		}
		else
		{
			break;
		}
		if(m_SBAttr.m_hSocket == INVALID_SOCKET)
			break;
	}while(bTimeout != VARIANT_TRUE);
	if(bTimeout && m_SBAttr.m_hSocket != INVALID_SOCKET)
	{
		OnClosed(seTimedOut);
	}
	m_ulSynIndicator = 0;
}

STDMETHODIMP CUSocket::get_Syn(VARIANT_BOOL *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_USAttr.m_bSyn ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CUSocket::put_Syn(VARIANT_BOOL newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_USAttr.m_bSyn && m_ulSynIndicator)
	{
		m_USAttr.m_hr = uecUnexpected;
	}
	else
	{
		m_USAttr.m_bSyn = newVal ? true : false;
	}
	return m_USAttr.m_hr;
}

void CUSocket::USend()
{
	int err;
	unsigned long ulBatch;
	unsigned short usRepeat = 0;
//	bool bPump = (m_dwObjThreadID == ::GetCurrentThreadId());
	m_USAttr.m_hr = uecOK;
	while((ulBatch = m_sndQueue.GetSize()) || m_Sspi.GetDataInBuffer() > 0)
	{
		if(m_bSendingTooFast)
		{
			::Sleep(1);
			m_bSendingTooFast = false;
		}
		if(ulBatch > m_ulSndBatch)
		{
			ulBatch = m_ulSndBatch;
		}
		if((m_SBAttr.m_EncryptionMethod==TLSv1 || m_SBAttr.m_EncryptionMethod == SSL23) && m_SBAttr.m_pSSL)
		{
			g_pWSAStartup->ERR_clear_error();
			err = g_pWSAStartup->SSL_write(m_SBAttr.m_pSSL, m_sndQueue.GetBuffer(), ulBatch);
			if(err<0)
			{
				err=g_pWSAStartup->SSL_get_error(m_SBAttr.m_pSSL, err);
				switch (err)
				{
				case SSL_ERROR_NONE: 
				case seSSLWantRead :
				case seSSLWantWrite:
					err = 0;
					break;
				case seSSLSysCall:
#ifdef _DEBUG
					{
						char strError[513]={0};
						unsigned long ulError = g_pWSAStartup->ERR_get_error();
						g_pWSAStartup->ERR_error_string(ulError, strError);
						ATLTRACE("Error code = %d, %s\n", ulError, strError);
					}
#endif	
					err = ::WSAGetLastError();
					if(g_pWSAStartup->ERR_get_error()==0 && (err == 0 || err == seWouldBlock || err == seNoBufs))
					{
						err = 0;
						::Sleep(1);
					}
					else
					{
						m_USAttr.m_hr = err;
						OnClosed(err);
					}
					break;
				case seSSLZeroReturn:
				case seSSLError:
				default :
					{
#ifdef _DEBUG
						char strError[513]={0};
						unsigned long ulError = g_pWSAStartup->ERR_get_error();
						g_pWSAStartup->ERR_error_string(ulError, strError);
						ATLTRACE("Error code = %d, %s\n", ulError, strError);
#endif	
						m_USAttr.m_hr = err;
						OnClosed(err);
					}
					break;
				}
			}
			else
			{
				m_sndQueue.Pop(err);
				m_dwBytesOut += err;
				if(m_dwBytesOut<err)
					m_dwBytesOutHigh += 1;
				m_ulLSend = ::GetTickCount();
				if(m_rcvQueue.GetSize()==0)
					m_ulTimeTrack = m_ulLSend;
				m_bChecked = false;
				usRepeat = 0;
			}
		}
		else if(m_SBAttr.m_EncryptionMethod == MSTLSv1 || m_SBAttr.m_EncryptionMethod == MSSSL)
		{
			ULONG ulMax = m_Sspi.GetMaxSize();
			if(ulBatch > ulMax)
			{
				ulBatch = ulMax;
			}
			err = m_Sspi.SendData(m_SBAttr.m_hSocket, m_sndQueue.GetBuffer(), ulBatch);
			if(err == -1)
			{
				err = ::WSAGetLastError();
				if(err != 0 && err != seWouldBlock)
				{
					m_USAttr.m_hr = err;
					OnClosed(err);
					break;
				}
				else
				{
					break;
				}
			}
			else 
			{
				m_sndQueue.Pop(err);
				m_dwBytesOut += err;
				if(m_dwBytesOut < err)
					m_dwBytesOutHigh += 1;
				m_bChecked = false;
				usRepeat = 0;
				m_ulLSend = ::GetTickCount();
				if(m_rcvQueue.GetSize()==0)
					m_ulTimeTrack = m_ulLSend;
//				ATLTRACE("Send Bytes = %d, Remain = %d\n", ulBatch, m_sndQueue.GetSize());
			}
		}
		else
		{
			err = ::send(m_SBAttr.m_hSocket, (char*)m_sndQueue.GetBuffer(), ulBatch, 0);
			if(err == -1)
			{
				err = ::WSAGetLastError();
				if(err == seWouldBlock || err == seNoBufs)
				{
					::Sleep(1);
				}
				else
				{
					m_USAttr.m_hr = err;
					OnClosed(err);
					break;
				}
			}
			else
			{
				ulBatch = err;
				if(ulBatch)
				{
					m_sndQueue.Pop(ulBatch);
					m_dwBytesOut += ulBatch;
					if(m_dwBytesOut<ulBatch)
						m_dwBytesOutHigh += 1;
					m_bChecked = false;
					usRepeat = 0;
					ATLTRACE("Send Bytes = %d, Remain = %d\n", ulBatch, m_sndQueue.GetSize());
				}
				m_ulLSend = ::GetTickCount();
				if(m_rcvQueue.GetSize()==0)
					m_ulTimeTrack = m_ulLSend;
			}
		}
	}
	if(m_sndQueue.GetHeadPosition() >(m_sndQueue.GetSize()+50000))
		m_sndQueue.SetHeadPosition();
	if(!m_SBAttr.m_bUseBaseSocketOnly)
		SetTraceQueue();
	if(m_bCleanRequired)
	{
		m_sndQueue.SetHeadPosition();
		if(m_sndQueue.GetMaxSize() > m_sndQueue.GetSize())
		{
			::memset((BYTE*)m_sndQueue.GetBuffer(m_sndQueue.GetSize()), 0, m_sndQueue.GetMaxSize() - m_sndQueue.GetSize());
		}

/*		m_tQueue.SetHeadPosition();
		if(m_tQueue.GetMaxSize() > m_tQueue.GetSize())
		{
			::memset((BYTE*)m_tQueue.GetBuffer(m_tQueue.GetSize()), 0, m_tQueue.GetMaxSize() - m_tQueue.GetSize());
		}*/

		m_tQueue.SetSize(0);
		::memset((BYTE*)m_tQueue.GetBuffer(), 0, m_tQueue.GetMaxSize());

		m_BatchQueue.SetHeadPosition();
		if(m_BatchQueue.GetMaxSize() > m_BatchQueue.GetSize())
		{
			::memset((BYTE*)m_BatchQueue.GetBuffer(m_BatchQueue.GetSize()), 0, m_BatchQueue.GetMaxSize() - m_BatchQueue.GetSize());
		}
		m_bCleanRequired = false;
	}
}

STDMETHODIMP CUSocket::GetSockAddr(long *plPort, BSTR *pbstrSockAddr)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(plPort || pbstrSockAddr)
	{
		SOCKADDR_IN sockAddr;
		memset(&sockAddr, 0, sizeof(sockAddr));
		int nSockAddrLen = sizeof(sockAddr);
		int err = ::getsockname(m_SBAttr.m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
		if (err == -1)
		{
			m_USAttr.m_hr = ::WSAGetLastError();
		}
		else
		{
			USES_CONVERSION;
			if(plPort)
				*plPort = ::ntohs(sockAddr.sin_port);
			if(pbstrSockAddr)
			{
				if(*pbstrSockAddr)
				{
					::SysFreeString(*pbstrSockAddr);
				}
				*pbstrSockAddr = A2BSTR(::inet_ntoa(sockAddr.sin_addr));
			}
		}
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetInterfaceAttributes(long *lpMTU, long *plMaxSpeed, long *plIType, BSTR *pbstrMask, BSTR *pbstrDesc)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(lpMTU || plMaxSpeed || plIType || pbstrDesc)
	{
		PMIB_IFTABLE		pIfT;
		PMIB_IPADDRTABLE	pIAddrT;
		SOCKADDR_IN			sockAddr;
		if(lpMTU)
			*lpMTU = 0;
		if(plMaxSpeed)
			*plMaxSpeed = 0;
		if(plIType)
			*plIType = 0;
		{
			memset(&sockAddr, 0, sizeof(sockAddr));
			int nSockAddrLen = sizeof(sockAddr);
			int err = ::getsockname(m_SBAttr.m_hSocket, (SOCKADDR*)&sockAddr, &nSockAddrLen);
			if (err == -1)
			{
				m_USAttr.m_hr = ::WSAGetLastError();
				return m_USAttr.m_hr;
			}
		}

		BYTE pIfTable[IF_TABLE_SIZE] = {0};
		BYTE pIpAddrTable[IF_TABLE_SIZE] = {0};
		memset(pIfTable, 0, IF_TABLE_SIZE);
		memset(pIpAddrTable, 0, IF_TABLE_SIZE);
		
		unsigned long ulSize = IF_TABLE_SIZE; 
		::GetIfTable((PMIB_IFTABLE)pIfTable, &ulSize, TRUE);
		
		pIfT = (PMIB_IFTABLE)pIfTable;

		ulSize = IF_TABLE_SIZE; 
		::GetIpAddrTable((PMIB_IPADDRTABLE)pIpAddrTable, &ulSize, TRUE);
		pIAddrT = (PMIB_IPADDRTABLE)pIpAddrTable;
		
		for(ulSize = 0; ulSize<pIAddrT->dwNumEntries; ulSize++)
		{
			if(sockAddr.sin_addr.S_un.S_addr == pIAddrT->table[ulSize].dwAddr)
			{
				if(lpMTU)
					*lpMTU = pIfT->table[ulSize].dwMtu;
				if(plMaxSpeed)
				{
					*plMaxSpeed = pIfT->table[ulSize].dwSpeed;
/*					if(sockAddr.sin_addr.S_un.S_addr == 0x0100007F)
						*plMaxSpeed = 100000000;*/
				}
				if(plIType)
					*plIType = pIfT->table[ulSize].dwType;
				if(pbstrDesc)
				{
					USES_CONVERSION;
					if(*pbstrDesc)
					{
						::SysFreeString(*pbstrDesc);
						*pbstrDesc = NULL;
					}
					*pbstrDesc = A2BSTR((char*)(pIfT->table[ulSize].bDescr));
				}
				if(pbstrMask)
				{
					USES_CONVERSION;
					if(*pbstrMask)
					{
						::SysFreeString(*pbstrMask);
						*pbstrMask = NULL;
					}
					{
						in_addr in;
						in.S_un.S_addr=pIAddrT->table[ulSize].dwMask;
						*pbstrMask = A2BSTR(::inet_ntoa(in));
					}
				}
				break;
			}
		}
//		delete []pIfTable;
//		delete []pIpAddrTable;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetClientVersion(short *pnMinor, short *pnMajor)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pnMinor)
		*pnMinor = m_USAttr.m_Client.m_usVerMinor;
	if(pnMajor)
		*pnMajor = m_USAttr.m_Client.m_usVerMajor;
	return uecOK;
}

STDMETHODIMP CUSocket::GetServerVersion(short *pnMinor, short *pnMajor)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pnMinor)
		*pnMinor = m_USAttr.m_Server.m_usVerMinor;
	if(pnMajor)
		*pnMajor = m_USAttr.m_Server.m_usVerMajor;
	return uecOK;
}

STDMETHODIMP CUSocket::get_ClientParams(VARIANT *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
	{
		long *lpData;
		if(pVal)
			::VariantClear(pVal);
		SAFEARRAYBOUND sab[1] = {5, 0};
		pVal->parray = ::SafeArrayCreate(VT_I4, 1, sab);
		::SafeArrayAccessData(pVal->parray, (void**)&lpData);
		lpData[0] = m_USAttr.m_Client.m_ulParam1;
		lpData[1] = m_USAttr.m_Client.m_ulParam2;
		lpData[2] = m_USAttr.m_Client.m_ulParam3;
		lpData[3] = m_USAttr.m_Client.m_ulParam4;
		lpData[4] = m_USAttr.m_Client.m_ulParam5;
		::SafeArrayUnaccessData(pVal->parray);
		pVal->vt = (VT_ARRAY|VT_I4);
	}
	return uecOK;
}

STDMETHODIMP CUSocket::put_ClientParams(VARIANT newVal)
{
	if((newVal.vt == (VT_ARRAY|VT_I4)||newVal.vt == (VT_ARRAY|VT_UI4)) && newVal.parray->rgsabound[0].cElements == 3)
	{
		long *plData;
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		::SafeArrayAccessData(newVal.parray, (void**)&plData);
		m_USAttr.m_Client.m_ulParam3 = plData[0];
		m_USAttr.m_Client.m_ulParam4 = plData[1];
		m_USAttr.m_Client.m_ulParam5 = plData[2];
		::SafeArrayUnaccessData(newVal.parray);
	}
	else
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		m_USAttr.m_hr = uecUnexpected;
	}
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::ShrinkMemory()
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	{
		unsigned long ulSize = m_USAttr.m_ulMemBlockSize;
		if((m_rcvQueue.GetSize())<ulSize && m_rcvQueue.GetMaxSize()>ulSize )
		{
			m_rcvQueue.ReallocBuffer(ulSize);
		}
	}
	
	{
		unsigned long ulSize = m_USAttr.m_ulMemBlockSize;
		if(m_sndQueue.GetSize()<ulSize && m_sndQueue.GetMaxSize()>ulSize )
		{
			m_sndQueue.ReallocBuffer(ulSize);
		}
	}

	{
		unsigned long ulSize = m_USAttr.m_ulMemBlockSize;
		if(m_tempQueue.GetSize()<ulSize && m_tempQueue.GetMaxSize()>ulSize )
		{
			m_tempQueue.ReallocBuffer(ulSize);
		}
	}

	{
		unsigned long ulSize = m_USAttr.m_ulMemBlockSize;
		if(m_BatchQueue.GetSize()<ulSize && m_BatchQueue.GetMaxSize()>ulSize )
		{
			m_BatchQueue.ReallocBuffer(ulSize);
		}
	}

	return S_OK;
}

/*

STDMETHODIMP CUSocket::GetClientOSVersion(short *pnMinor, short *pnMajor)
{
	m_USAttr.m_hr = uecOK;
	if(pnMinor)
		*pnMinor = m_USAttr.m_Client.m_nOSMinor;

	if(pnMajor)
		*pnMajor = m_USAttr.m_Client.m_nOSMajor;
	return uecOK;
}

STDMETHODIMP CUSocket::GetSeverOSVersion(short *pnMinor, short *pnMajor)
{
	m_USAttr.m_hr = uecOK;
	if(pnMinor)
		*pnMinor = m_USAttr.m_Server.m_nOSMinor;
	if(pnMajor)
		*pnMajor = m_USAttr.m_Server.m_nOSMajor;
	return uecOK;
}*/

STDMETHODIMP CUSocket::get_ServerParams(VARIANT *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
	{
		long *lpData;
		if(pVal)
			::VariantClear(pVal);
		SAFEARRAYBOUND sab[1] = {5, 0};
		pVal->parray = ::SafeArrayCreate(VT_I4, 1, sab);
		::SafeArrayAccessData(pVal->parray, (void**)&lpData);
		lpData[0] = m_USAttr.m_Server.m_ulParam1;
		lpData[1] = m_USAttr.m_Server.m_ulParam2;
		lpData[2] = m_USAttr.m_Server.m_ulParam3;
		lpData[3] = m_USAttr.m_Server.m_ulParam4;
		lpData[4] = m_USAttr.m_Server.m_ulParam5;
		::SafeArrayUnaccessData(pVal->parray);
		pVal->vt = (VT_ARRAY|VT_I4);
	}
	return uecOK;
}

/*
STDMETHODIMP CUSocket::put_ServerParams(VARIANT newVal)
{
	if((newVal.vt == (VT_ARRAY|VT_UI4)||newVal.vt == (VT_ARRAY|VT_I4)) && newVal.parray->rgsabound[0].cElements == 5)
	{
		long *plData;
		m_USAttr.m_hr = uecOK;
		::SafeArrayAccessData(newVal.parray, (void**)&plData);
		m_USAttr.m_Server.m_ulParam1 = plData[0];
		m_USAttr.m_Server.m_ulParam2 = plData[1];
		m_USAttr.m_Server.m_ulParam3 = plData[2];
		m_USAttr.m_Server.m_ulParam4 = plData[3];
		m_USAttr.m_Server.m_ulParam5 = plData[4];
		::SafeArrayUnaccessData(newVal.parray);
	}
	else
	{
		m_USAttr.m_hr = uecUnexpected;
	}
	return m_USAttr.m_hr;
}*/

STDMETHODIMP CUSocket::get_RecvTimeout(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_SBAttr.m_ulRecvTimeout;
	return S_OK;
}

STDMETHODIMP CUSocket::put_RecvTimeout(long newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_SBAttr.m_ulRecvTimeout = newVal;
	return S_OK;
}

STDMETHODIMP CUSocket::get_SendTimeout(long *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_SBAttr.m_ulSendTimeout;
	}
	return S_OK;
}

STDMETHODIMP CUSocket::put_SendTimeout(long newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_SBAttr.m_ulSendTimeout = newVal;
	return S_OK;
}

void CUSocket::HandleBaseRequest(unsigned short usRID, unsigned long ulLen)
{
	unsigned long ulGet = 0;
	m_tempQueue.SetSize(0);
	if(ulLen>m_tempQueue.GetMaxSize())
		m_tempQueue.ReallocBuffer(ulLen);
	GetRtnBufferEx(ulLen, (BYTE*)m_tempQueue.GetBuffer(), &ulGet);
	if(ulGet != ulLen)
	{
		ATLTRACE("Something wrong!\n");
		Disconnect();
		return;
	}
	m_tempQueue.SetSize(ulGet);
	switch(usRID)
	{
	case idCleanTrack:
		ZeroTrack();
		break;
	case idShrinkMemoryAtSvr:
		break;
	case idSwitchTo:			//
		m_tempQueue.Pop(&m_USAttr.m_hr);
		if(m_USAttr.m_hr && !m_bSameEndian)
		{
			m_USAttr.m_hr = ::htonl(m_USAttr.m_hr);
		}
		if(!FAILED(m_USAttr.m_hr))
		{
			m_tempQueue.Pop(&m_USAttr.m_Server);
			if(!m_bSameEndian)
			{
				m_USAttr.m_Server.m_ulSvsID = ::htonl(m_USAttr.m_Server.m_ulSvsID);
				m_USAttr.m_Server.m_ulParam1 = ::htonl(m_USAttr.m_Server.m_ulParam1);
				m_USAttr.m_Server.m_ulParam2 = ::htonl(m_USAttr.m_Server.m_ulParam1);
				m_USAttr.m_Server.m_ulParam3 = ::htonl(m_USAttr.m_Server.m_ulParam1);
				m_USAttr.m_Server.m_ulParam4 = ::htonl(m_USAttr.m_Server.m_ulParam1);
				m_USAttr.m_Server.m_ulParam5 = ::htonl(m_USAttr.m_Server.m_ulParam1);
				m_USAttr.m_Server.m_usVerMajor = ::htons(m_USAttr.m_Server.m_usVerMajor);
				m_USAttr.m_Server.m_usVerMinor = ::htons(m_USAttr.m_Server.m_usVerMinor);
				m_USAttr.m_Server.m_usUSockMajor = ::htons(m_USAttr.m_Server.m_usUSockMajor);
				m_USAttr.m_Server.m_usUSockMinor = ::htons(m_USAttr.m_Server.m_usUSockMinor);
			}

			if(m_tempQueue.GetSize() >= 36)
			{
			    m_tempQueue >> m_guidSalt;
				m_tempQueue.Pop((BYTE*)m_pHash, sizeof(m_pHash));
			}
		}
		ATLASSERT(m_tempQueue.GetSize()==0);

		if(m_USAttr.m_hr == uecSvrNotRegistered)
		{
			g_bRegistered = false;
/*			if(!g_bRegistered)
			{
				g_bRegistered = true;
				::MessageBox(NULL, g_strInfoMsg, g_strTitle, MB_ICONINFORMATION);
			}*/
			m_USAttr.m_hr = S_OK;
		}

/*		if(m_pJSSerialization != NULL && m_USAttr.m_Server.m_usUSockMinor < 6)
		{
			m_USAttr.m_hr = uecWrongServerVersion;
			OnClosed(m_USAttr.m_hr);
		}*/
		break;
	case idGetSockOptAtSvr:
		m_tempQueue.Pop(&m_USAttr.m_hr);
		if(!FAILED(m_USAttr.m_hr))
		{
			m_tempQueue.Pop(&m_USAttr.m_lOptValue);
			if(!m_bSameEndian)
			{
				m_USAttr.m_lOptValue = ::htonl(m_USAttr.m_lOptValue);
			}
		}
		ATLASSERT(m_tempQueue.GetSize()==0);
		break;
	case idSetSockOptAtSvr:
		m_tempQueue.Pop(&m_USAttr.m_hr);
		ATLASSERT(m_tempQueue.GetSize()==0);
		break;
	case idSendMySpecificBytes:
		m_tempQueue.Pop(&m_USAttr.m_hr);
		break;
	case idStartJob:
		break;
	case idEndJob:
		break;
	case idDropRequestResult:
		m_tempQueue.Pop((BYTE*)&m_usRequestIdDiscarded, sizeof(m_usRequestIdDiscarded));
		break;
	case idDoEcho:
		ATLASSERT(m_tempQueue.GetSize()==0);
		break;
	case idTurnOnZipAtSvr:
		m_tempQueue.Pop(&m_USAttr.m_bZipIsOnSvr);
		ATLASSERT(m_tempQueue.GetSize()==0);
		break;
	case idCancel:
		{
			unsigned long ulCanceled;
			ATLASSERT(m_tempQueue.GetSize() == sizeof(ulCanceled));
			m_tempQueue.Pop(&ulCanceled);
			if(!m_bSameEndian)
			{
				ulCanceled = ::htonl(ulCanceled);
			}
			m_ulCancelRequests += ulCanceled;
			m_requestQueue.Pop(sizeof(unsigned short)*(ulCanceled+1));
		}
		break;
	case idStartBatching:
	case idCommitBatching:
		ATLASSERT(FALSE);
		break;
	case idEncrypted:
	case idBatchZipped:
		break;
	case idSendingTooFast:
		m_bSendingTooFast = true;
		break;
	case idEchoFromSvr:
		ATLASSERT(m_tempQueue.GetSize()==0);
		break;
	case idPublicKeyFromSvr:
		m_vtKeySvr.Clear();
		if(m_tempQueue.GetSize())
		{
			void	*pData;
			SAFEARRAYBOUND	sab[1] = {m_tempQueue.GetSize(), 0};
			m_vtKeySvr.vt = (VT_UI1|VT_ARRAY);
			m_vtKeySvr.parray = ::SafeArrayCreate(VT_UI1, 1, sab);
			::SafeArrayAccessData(m_vtKeySvr.parray, &pData);
			memcpy(pData, m_tempQueue.GetBuffer(), m_tempQueue.GetSize());
			::SafeArrayUnaccessData(m_vtKeySvr.parray);
			m_tempQueue.SetSize(0);
		}
		break;
	case idPing:
		{
			m_requestQueue.SetSize(0);
			ATLASSERT(m_tempQueue.GetSize()==0);
		}
		break;
	case idXEnter:
	case idEnter:
	case idExit:
		{
			unsigned short  usLen;
			CListenerInfo	ListenerInfo;
			m_Listeners.RemoveAll();
			m_tempQueue.Pop(&ListenerInfo.m_ulSvsID);
			m_tempQueue.Pop(&ListenerInfo.m_dwID);
			m_tempQueue.Pop(&ListenerInfo.m_unPort);
			m_tempQueue.Pop(&ListenerInfo.m_ulIPAddr);
			m_tempQueue.Pop(&usLen);
			if(!m_bSameEndian)
			{
				ListenerInfo.m_ulSvsID = ::htonl(ListenerInfo.m_ulSvsID);
				ListenerInfo.m_dwID = ::htonl(ListenerInfo.m_dwID);
				ListenerInfo.m_unPort = ::htons(ListenerInfo.m_unPort);
				usLen = ::htons(usLen);
			}
			if(usLen)
			{
				m_tempQueue.Pop((BYTE*)ListenerInfo.m_strUID, usLen);
			}
			m_Listeners.Add(ListenerInfo);
			ATLASSERT(m_tempQueue.GetSize()==0);
		}
		break;
	case idGetAllGroups:
		{
			m_GroupInfos.RemoveAll();
			CGroupInfo	GroupInfo;
			unsigned long ulLength;
			do
			{
				if(!m_tempQueue.GetSize())
					break;
				m_tempQueue.Pop(&GroupInfo.m_dwID);
				m_tempQueue.Pop(&ulLength);
				if(!m_bSameEndian)
				{
					GroupInfo.m_dwID = ::htonl(GroupInfo.m_dwID);
					ulLength = ::htonl(ulLength);
				}
				ATLASSERT((ulLength%sizeof(WCHAR))==0);
				if(ulLength)
				{
					GroupInfo.m_bstrDescription.Empty();
					GroupInfo.m_bstrDescription.m_str = ::SysAllocStringLen((LPOLESTR)m_tempQueue.GetBuffer(), ulLength/sizeof(WCHAR));
					m_tempQueue.Pop(ulLength);
				}
				m_GroupInfos.Add(GroupInfo);
				
			}while(true);
		}
		break;
	case idGetAllClients:
	case idGetAllListeners:
		{
			m_Listeners.RemoveAll();
			CListenerInfo	Info;
			unsigned short  usLen;
			do
			{
				if(!m_tempQueue.GetSize())
					break;
				m_tempQueue.Pop(&Info.m_ulSvsID);
				m_tempQueue.Pop(&Info.m_dwID);
				m_tempQueue.Pop(&Info.m_unPort);
				m_tempQueue.Pop(&Info.m_ulIPAddr);
				m_tempQueue.Pop(&usLen);
				if(!m_bSameEndian)
				{
					Info.m_ulSvsID = ::htonl(Info.m_ulSvsID);
					Info.m_dwID = ::htonl(Info.m_dwID);
					Info.m_unPort = ::htons(Info.m_unPort);
					usLen = ::htons(usLen);
				}
				if(usLen)
				{
					usLen -= m_tempQueue.Pop((BYTE*)Info.m_strUID, usLen);
					if(usLen)
						m_tempQueue.Pop(usLen);
				}
				m_Listeners.Add(Info);
				memset(&Info, 0, sizeof(Info));
			}while(true);
		}
		break;
	case idXSpeakEx:
	case idSpeakEx:
		{
			m_Listeners.RemoveAll();
			CListenerInfo	Info;
			unsigned short  usLen;
			m_tempQueue.Pop(&Info.m_ulSvsID);
			m_tempQueue.Pop(&Info.m_dwID);
			m_tempQueue.Pop(&Info.m_unPort);
			m_tempQueue.Pop(&Info.m_ulIPAddr);
			m_tempQueue.Pop(&usLen);
			if(!m_bSameEndian)
			{
				Info.m_ulSvsID = ::htonl(Info.m_ulSvsID);
				Info.m_dwID = ::htonl(Info.m_dwID);
				Info.m_unPort = ::htons(Info.m_unPort);
				usLen = ::htons(usLen);
			}
			if(usLen)
			{
				usLen -= m_tempQueue.Pop((BYTE*)Info.m_strUID, usLen);
				if(usLen)
					m_tempQueue.Pop(usLen);
			}
			m_Listeners.Add(Info);
			m_vtMsg.Clear();
			if(m_tempQueue.GetSize())
			{
				BYTE	*pBuffer;
				SAFEARRAYBOUND sab[1] = {m_tempQueue.GetSize(), 0};
				m_vtMsg.vt = (VT_ARRAY|VT_UI1);
				m_vtMsg.parray = ::SafeArrayCreate(VT_UI1, 1, sab);
				::SafeArrayAccessData(m_vtMsg.parray, (void**)&pBuffer);
				m_tempQueue.Pop(pBuffer, sab[0].cElements);
				::SafeArrayUnaccessData(m_vtMsg.parray);

			}
			ATLASSERT(m_tempQueue.GetSize()==0);
		}
		break;
	case idSpeak:
	case idXSpeak:
		{
			m_Listeners.RemoveAll();
			CListenerInfo	Info;
			unsigned short  usLen;
			m_tempQueue.Pop(&Info.m_ulSvsID);
			m_tempQueue.Pop(&Info.m_dwID);
			m_tempQueue.Pop(&Info.m_unPort);
			m_tempQueue.Pop(&Info.m_ulIPAddr);
			m_tempQueue.Pop(&usLen);
			if(usLen)
			{
				usLen -= m_tempQueue.Pop((BYTE*)Info.m_strUID, usLen);
				if(usLen)
					m_tempQueue.Pop(usLen);
			}
			m_Listeners.Add(Info);
			ATLASSERT(m_tempQueue.GetSize()>2);
			m_vtMsg.Clear();
			m_tempQueue.PopVT(m_vtMsg);
			ATLASSERT(m_tempQueue.GetSize()==0);
		}
		break;
	case idSendUserMessageEx:
	case idSpeakToEx:
		{
			m_Listeners.RemoveAll();
			CListenerInfo	Info;
			unsigned short  usLen;
			m_tempQueue.Pop(&Info.m_ulSvsID);
			m_tempQueue.Pop(&Info.m_dwID);
			m_tempQueue.Pop(&Info.m_unPort);
			m_tempQueue.Pop(&Info.m_ulIPAddr);
			m_tempQueue.Pop(&usLen);
			if(!m_bSameEndian)
			{
				Info.m_ulSvsID = ::htonl(Info.m_ulSvsID);
				Info.m_dwID = ::htonl(Info.m_dwID);
				Info.m_unPort = ::htons(Info.m_unPort);
				usLen = ::htons(usLen);
			}
			if(usLen)
			{
				usLen -= m_tempQueue.Pop((BYTE*)Info.m_strUID, usLen);
				if(usLen)
					m_tempQueue.Pop(usLen);
			}
			m_Listeners.Add(Info);
			m_vtMsg.Clear();
			if(m_tempQueue.GetSize())
			{
				BYTE	*pBuffer;
				SAFEARRAYBOUND sab[1] = {m_tempQueue.GetSize(), 0};
				m_vtMsg.vt = (VT_ARRAY|VT_UI1);
				m_vtMsg.parray = ::SafeArrayCreate(VT_UI1, 1, sab);
				::SafeArrayAccessData(m_vtMsg.parray, (void**)&pBuffer);
				m_tempQueue.Pop(pBuffer, sab[0].cElements);
				::SafeArrayUnaccessData(m_vtMsg.parray);
			}
			ATLASSERT(m_tempQueue.GetSize()==0);
		}
		break;
	case idSendUserMessage:
	case idSpeakTo:
		{
			m_Listeners.RemoveAll();
			CListenerInfo	Info;
			unsigned short  usLen;
			m_tempQueue.Pop(&Info.m_ulSvsID);
			m_tempQueue.Pop(&Info.m_dwID);
			m_tempQueue.Pop(&Info.m_unPort);
			m_tempQueue.Pop(&Info.m_ulIPAddr);
			m_tempQueue.Pop(&usLen);
			if(usLen)
			{
				usLen -= m_tempQueue.Pop((BYTE*)Info.m_strUID, usLen);
				if(usLen)
					m_tempQueue.Pop(usLen);
			}
			m_Listeners.Add(Info);
			ATLASSERT(m_tempQueue.GetSize()>2);
			m_vtMsg.Clear();
			m_tempQueue.PopVT(m_vtMsg);
			ATLASSERT(m_tempQueue.GetSize()==0);
		}
		break;
	default:
		ATLASSERT(FALSE);
		break;
	}
}

STDMETHODIMP CUSocket::get_ErrorMsg(BSTR *pbstrErrorMsg)
{
	if(pbstrErrorMsg)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		if(*pbstrErrorMsg)
			::SysFreeString(*pbstrErrorMsg);
		switch (m_USAttr.m_hr)
		{
		case uecOK:
			*pbstrErrorMsg = NULL;
			break;
		case seSSLError:
			*pbstrErrorMsg = ::SysAllocString(L"Error in doing SSL handshake.");
			break;
		case seSSLWantRead:
			*pbstrErrorMsg = ::SysAllocString(L"Error in reading SSL data.");
			break;
		case seSSLWantWrite:
			*pbstrErrorMsg = ::SysAllocString(L"Error in writing SSL data.");
			break;
		case uecUnexpected: 
			*pbstrErrorMsg = ::SysAllocString(L"An unexpected error occurred.");
			break;
		case uecSvsNotAvailable:
			*pbstrErrorMsg = ::SysAllocString(L"Service not available.");
			break;
		case uecAuthenticationFailed:
			*pbstrErrorMsg = ::SysAllocString(L"Authentication to SocketPro server failed.");
			break;
		case uecClientRejected:
			*pbstrErrorMsg = ::SysAllocString(L"Connecting to SocketPro server rejected.");
			break;
		case uecFailedInLoadingSSL:
			*pbstrErrorMsg = ::SysAllocString(L"Error in loading OpenSSL libraries.");
			break;
		case uecFailedInStartingSSL:
			*pbstrErrorMsg = ::SysAllocString(L"Error in starting OpenSSL.");
			break;
		case uecFailedInLoadingMsSSPI:
			*pbstrErrorMsg = ::SysAllocString(L"Error in loading MS security library or certificate store.");
			break;
		case uecNotImplemented:
			*pbstrErrorMsg = ::SysAllocString(L"Not implemented yet.");
			break;
		case uecFail:
			*pbstrErrorMsg = ::SysAllocString(L"Unspecified error.");
			break;
		case uecFailedInZip:
			*pbstrErrorMsg = ::SysAllocString(L"Error in zipping.");
			break;
		case uecFailedInUnzip:
			*pbstrErrorMsg = ::SysAllocString(L"Error in unzipping.");
			break;
		case uecFailedInEncrypt:
			*pbstrErrorMsg = ::SysAllocString(L"Error in encrypting.");
			break;
		case uecFailedInDecrypt:
			*pbstrErrorMsg = ::SysAllocString(L"Error in decrypting.");
			break;
		default:
			{
				if(m_SBAttr.m_EncryptionMethod == MSTLSv1 || m_SBAttr.m_EncryptionMethod == MSSSL)
				{
					CComBSTR bstr = m_Sspi.DisplayWinVerifyTrustError(m_USAttr.m_hr);
					if(bstr.Length() > 0)
					{
						*pbstrErrorMsg = bstr.Copy();
						return S_OK;
					}
				}
				USES_CONVERSION;
				TCHAR	strError[513] = {0};
				::FormatMessage(
					FORMAT_MESSAGE_FROM_SYSTEM,
					NULL,
					m_USAttr.m_hr,
					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
					strError,
					sizeof(strError)/sizeof(TCHAR),
					NULL 
				);
				DWORD dwLen = _tcslen(strError);
				if(dwLen>3)
				{
					*pbstrErrorMsg = ::SysAllocStringLen(T2OLE(strError), dwLen-1);
				}
				else
					*pbstrErrorMsg = NULL;
			}
			break;
		}
	}
	return S_OK;
}

void CUSocket::SetTraceQueue()
{
	CRTrace		*pRTrace;
	unsigned long ulIndex;
	if(m_sndQueue.GetSize() == 0)
	{
		m_traceQueue.SetSize(0);
		return;
	}
	if(m_traceQueue.GetSize() == 0)
		return;

	ATLASSERT((m_traceQueue.GetSize()%sizeof(CRTrace)) == 0);
	
	unsigned long ulRemain = 0;
	unsigned long ulSizeSnd = m_sndQueue.GetSize();
	unsigned long ulCount = m_traceQueue.GetSize()/sizeof(CRTrace);
	
	for(ulIndex = 0; ulIndex<ulCount; ulIndex++)
	{
		pRTrace = (CRTrace*)m_traceQueue.GetBuffer();
		pRTrace += (ulCount-ulIndex-1);
		ulRemain  += (pRTrace->m_ulRBufferLen + sizeof(CStreamHeader));
		if(ulRemain>m_sndQueue.GetSize())
			break;
		else
		{
//			ATLTRACE("Size = %d, Contained = %d\n", pRTrace->m_ulRBufferLen, pRTrace->m_ulContained);
		}
	}
	if(ulCount-ulIndex)
	{
		m_traceQueue.Pop(sizeof(CRTrace)*(ulCount-ulIndex));
	}
//	ATLTRACE("Remain = %d, Snd Buffer = %d\n", m_traceQueue.GetSize()/sizeof(CRTrace), m_sndQueue.GetSize());
}

STDMETHODIMP CUSocket::ShrinkMemoryAtSvr()
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequestEx(idShrinkMemoryAtSvr, 0, NULL);
}

STDMETHODIMP CUSocket::get_RequestsCanceled(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_ulCancelRequests;
	return S_OK;
}

STDMETHODIMP CUSocket::GetClientUSockVersion(short *pnMinor, short *pnMajor)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pnMinor)
		*pnMinor = m_USAttr.m_Client.m_usUSockMinor;
	if(pnMajor)
		*pnMajor = m_USAttr.m_Client.m_usUSockMajor;
	return S_OK;
}

STDMETHODIMP CUSocket::GetServerUSockVersion(short *pnMinor, short *pnMajor)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pnMinor)
		*pnMinor = m_USAttr.m_Server.m_usUSockMinor;
	if(pnMajor)
		*pnMajor = m_USAttr.m_Server.m_usUSockMajor;
	return S_OK;
}

unsigned long CUSocket::CancelImp(unsigned long ulRequests)
{
	DWORD dwCancel = ulRequests;
	DWORD dwRemain = m_traceQueue.GetSize()/sizeof(CRTrace);
	if(dwRemain)
	{
		long lIndex;
		CRTrace *pRTrace;
		DWORD	dwBytes;
		unsigned long ulDelay = 0;
		for(lIndex=dwRemain-1; lIndex>=0; lIndex--)
		{
			pRTrace = (CRTrace*)m_traceQueue.GetBuffer();
			pRTrace += lIndex;
			dwBytes = pRTrace->m_ulRBufferLen + sizeof(CStreamHeader);
			if(pRTrace->m_usRID == idStartBatching)
			{
				ulDelay = 0;
				ATLASSERT(m_traceQueue.GetSize() >= 2*sizeof(CRTrace));
				m_traceQueue.Pop(2*sizeof(CRTrace), m_traceQueue.GetSize()-2*sizeof(CRTrace));
				m_sndQueue.Pop(2*sizeof(CStreamHeader), m_sndQueue.GetSize()-2*sizeof(CStreamHeader));	
			}
			else if (pRTrace->m_usRID == idCommitBatching)
			{
				ulDelay = sizeof(CStreamHeader);
			}
			else
			{
				if(dwCancel>=pRTrace->m_ulContained)
				{
					ATLASSERT(m_sndQueue.GetSize() >= (dwBytes+ulDelay));
					ATLASSERT(m_requestQueue.GetSize() >= pRTrace->m_ulContained*sizeof(unsigned short));
					m_ulCancelRequests += pRTrace->m_ulContained;
					m_sndQueue.Pop(dwBytes, m_sndQueue.GetSize()-(dwBytes+ulDelay));
					m_requestQueue.Pop(pRTrace->m_ulContained*sizeof(unsigned short), m_requestQueue.GetSize()-pRTrace->m_ulContained*sizeof(unsigned short));
					ATLTRACE("Requests = %d\n", m_requestQueue.GetSize()/sizeof(unsigned short));
					m_traceQueue.Pop(sizeof(CRTrace), m_traceQueue.GetSize()-(1+(ulDelay? 1 : 0))*sizeof(CRTrace));
					dwCancel -= pRTrace->m_ulContained;
					if(dwCancel==0)
						break;
				}
				else
				{
					unsigned long lIndex;
					unsigned long ulPos;
					BYTE	*pBuffer = NULL;
					ATLASSERT(ulDelay == 0);
					ATLASSERT(m_sndQueue.GetSize() >= dwBytes);
					ATLASSERT(m_sndQueue.GetSize() >= (dwBytes+ulDelay));
					ATLASSERT(m_requestQueue.GetSize() >= pRTrace->m_ulContained*sizeof(unsigned short));
//					dwCancel = 0;
					m_tempQueue.SetSize(0);
					if(dwBytes > m_tempQueue.GetMaxSize())
					{
						m_tempQueue.ReallocBuffer((1+dwBytes/1024)*1024);
					}
					m_sndQueue.Pop((BYTE*)m_tempQueue.GetBuffer(), dwBytes, m_sndQueue.GetSize()-dwBytes);
					m_tempQueue.SetSize(dwBytes);
					CStreamHeader	StreamHeader;
					CStreamHeader	SH;
					m_requestQueue.Pop(pRTrace->m_ulContained*sizeof(unsigned short), m_requestQueue.GetSize()-pRTrace->m_ulContained*sizeof(unsigned short));
					m_traceQueue.Pop(sizeof(CRTrace), m_traceQueue.GetSize()-sizeof(CRTrace));
					ATLASSERT(m_traceQueue.GetSize()==0);
					m_tempQueue.Pop(&StreamHeader);
					ATLASSERT(StreamHeader.m_nRequestID == idBatchZipped || StreamHeader.m_nRequestID == idEncrypted);
					if(StreamHeader.m_nRequestID == idEncrypted && m_pBlowFish)
					{
						unsigned long ulLen;
						unsigned long ulP;
						ulPos = 0;
						ATLASSERT((StreamHeader.m_ulLen%8)==0);
						ATLASSERT(StreamHeader.m_ulLen+sizeof(StreamHeader)==dwBytes);
						ulLen = dwBytes - sizeof(StreamHeader);
						m_pBlowFish->Decrypt((BYTE*)m_tempQueue.GetBuffer(), ulLen);

						while(ulPos<(ulLen-7))
						{
							CStreamHeader *pHeader = (CStreamHeader *)(m_tempQueue.GetBuffer() + ulPos);
							ulPos += (sizeof(CStreamHeader) + pHeader->m_ulLen);
						}
						ulP = ulLen - ulPos;
						ATLASSERT(ulP<8);
						m_tempQueue.Pop(ulP, ulPos);
						m_tempQueue.Pop(&StreamHeader);
					}
					
					if(StreamHeader.m_nRequestID == idBatchZipped)
					{
						tagZipLevel	bOrig = m_UZip.m_ZipLevel;
						if((StreamHeader.m_bTreat & odFastZip) && (StreamHeader.m_bTreat & odZipped) == odZipped)
						{
							m_UZip.m_ZipLevel = zlBestSpeed;
						}
						else if((StreamHeader.m_bTreat & odFastZip))
						{
							m_UZip.m_ZipLevel = zlBestCompression;
						}
						else
						{
							m_UZip.m_ZipLevel = zlDefault;
						}
						unsigned short nRatio = (StreamHeader.m_bTreat & 0x3F) * 256 + StreamHeader.m_bRatio;
						unsigned long	ulLenZ = nRatio * StreamHeader.m_ulLen;
						pBuffer = (BYTE*)::malloc(ulLenZ);
						ulLenZ = UnZip(pBuffer, ulLenZ, m_tempQueue.GetBuffer(), StreamHeader.m_ulLen);
						m_UZip.m_ZipLevel = bOrig;
						m_tempQueue.Pop(StreamHeader.m_ulLen);
						ATLASSERT(m_tempQueue.GetSize()==0);
						m_tempQueue.Insert((const unsigned char*)pBuffer, ulLenZ);
					}
					else
					{
						m_tempQueue.Insert(&StreamHeader);
					}
					ulPos = 0;
					for(lIndex = 0; lIndex<pRTrace->m_ulContained; lIndex++)
					{
						CStreamHeader *pStreamHeader = (CStreamHeader *)(m_tempQueue.GetBuffer() + ulPos);
						if(lIndex < (pRTrace->m_ulContained-dwCancel))
						{
							ulPos += (pStreamHeader->m_ulLen + sizeof(CStreamHeader));
							if(pStreamHeader->m_nRequestID == idStartBatching)
							{
								lIndex--;
							}
						}
						else
						{
							m_tempQueue.Pop(&SH, ulPos);
							ATLASSERT(m_tempQueue.GetSize()>=ulPos+SH.m_ulLen);
							if(SH.m_ulLen)
							{
								m_tempQueue.Pop(SH.m_ulLen, ulPos);
							}
							m_ulCancelRequests++;
						}
					}
					if(StreamHeader.m_nRequestID == idBatchZipped)
					{
						m_tempQueue.SetSize(0);
						SendRequestEx(idBatchZipped, ulPos, pBuffer);
						if(pBuffer)
							::free(pBuffer);
						dwCancel = 0;
					}
					else
					{
						CUQueue	tempQueue;
						bool bSvrBatching = false;
						memset(&m_RTrace, 0, sizeof(m_RTrace));
						BYTE	*pBuffer = (BYTE*)m_tempQueue.GetBuffer();
						unsigned ulLen = m_tempQueue.GetSize();
						if(ulLen && pBuffer)
						{
							unsigned long ulPos = 0;
							while(ulPos<ulLen)
							{
								CStreamHeader	*pStreamHeader = (CStreamHeader*)(pBuffer + ulPos);
								ulPos += sizeof(CStreamHeader);
								ulPos += pStreamHeader->m_ulLen;
								m_RTrace.m_ulContained = 1;
								m_RTrace.m_ulRBufferLen = pStreamHeader->m_ulLen;
								m_RTrace.m_usRID = pStreamHeader->m_nRequestID;
								tempQueue.Push(&m_RTrace);
								if(pStreamHeader->m_nRequestID != idStartBatching && pStreamHeader->m_nRequestID != idCommitBatching)
								{
									m_requestQueue.Push((const BYTE*)&pStreamHeader->m_nRequestID, sizeof(pStreamHeader->m_nRequestID)); //looks like WCHAR
								}
								else
								{
									bSvrBatching = true;
								}
							}
						}
						if(m_SBAttr.m_EncryptionMethod == BlowFish && m_pBlowFish)
						{
							unsigned long ul = m_tempQueue.GetSize();
							CStreamHeader	StreamHeader;
							StreamHeader.m_bRatio = 0;
							StreamHeader.m_bTreat = 0;
							StreamHeader.m_nRequestID = idEncrypted;
							if((ul%8))
							{
								BYTE	pData[7] = {0};
								ul = ul + 8 - (ul%8);
								m_tempQueue.Push(pData, ul-m_tempQueue.GetSize());
							}
							m_pBlowFish->Encrypt((BYTE*)m_tempQueue.GetBuffer(), ul);
							StreamHeader.m_ulLen = ul;
							m_RTrace.m_ulContained = tempQueue.GetSize()/sizeof(m_RTrace);
							if(bSvrBatching)
							{
								ATLASSERT(m_RTrace.m_ulContained >= 3);
								m_RTrace.m_ulContained -=2;
							}
							m_RTrace.m_ulRBufferLen = ul;
							m_RTrace.m_usRID = idEncrypted;
							tempQueue.SetSize(0);
							tempQueue.Push(&m_RTrace);
							m_tempQueue.Insert(&StreamHeader);
						}
						m_sndQueue.Push(m_tempQueue.GetBuffer(), m_tempQueue.GetSize());
						m_traceQueue.Push(tempQueue.GetBuffer(), tempQueue.GetSize());
						USend();
						dwCancel = 0;
					}
					break;
				}
			}
		}
	}
	ATLTRACE("***** dwCancel = %d, Remain = %d, Canceled = %d *****\n", dwCancel, m_traceQueue.GetSize()/sizeof(CRTrace), m_ulCancelRequests);
	return dwCancel;
}

STDMETHODIMP CUSocket::GetBytesSent(long *plHigh, long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = (long)m_dwBytesOut;
	if(plHigh)
		*plHigh = m_dwBytesOutHigh;
	return S_OK;
}

STDMETHODIMP CUSocket::GetBytesReceived(long *plHigh, long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = (long)m_dwBytesIn;
	if(plHigh)
		*plHigh = m_dwBytesInHigh;
	return S_OK;
}

STDMETHODIMP CUSocket::GetAllClients()
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequestEx(idGetAllClients, 0, NULL);
}

STDMETHODIMP CUSocket::get_Frozen(VARIANT_BOOL *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
	{
		*pVal = m_bFrozen ? VARIANT_TRUE : VARIANT_FALSE;
	}
	return S_OK;
}

STDMETHODIMP CUSocket::put_Frozen(VARIANT_BOOL newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_bFrozen = newVal ? true : false;
	return S_OK;
}

STDMETHODIMP CUSocket::get_BytesInSndMemory(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_sndQueue.GetSize();
	return S_OK;
}

STDMETHODIMP CUSocket::get_BytesInRcvMemory(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_rcvQueue.GetSize();
	return S_OK;
}

STDMETHODIMP CUSocket::get_ReturnEvents(short *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_usRtnEvents;
	return S_OK;
}

STDMETHODIMP CUSocket::put_ReturnEvents(short newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if((newVal & rfCompleted) == 0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_usRtnEvents = newVal;
	return S_OK;
}

unsigned long CUSocket::QueryRtns()
{
	if(m_SBAttr.m_bUseBaseSocketOnly)
		return 0;
	unsigned long ulRtns = 0;
	unsigned long ulStartPos = 0;
	if(m_USAttr.m_curRcvStreamHeader.m_nRequestID)
	{
		ulRtns = 1;
		ulStartPos = m_USAttr.m_curRcvStreamHeader.m_ulLen;
	}
	while(ulStartPos+sizeof(CStreamHeader)<=m_rcvQueue.GetSize())
	{
		CStreamHeader	*pStreamHeader = (CStreamHeader	*)m_rcvQueue.GetBuffer(ulStartPos);
		if(pStreamHeader->m_ulLen > m_rcvQueue.GetMaxSize())
		{
			m_rcvQueue.ReallocBuffer(pStreamHeader->m_ulLen + m_rcvQueue.GetBlockSize());
			if(ulRtns == 0)
				ulRtns = 1;
			break;
		}
		ulStartPos +=(pStreamHeader->m_ulLen+sizeof(CStreamHeader));
		ulRtns++;
	}
	return ulRtns;
}

STDMETHODIMP CUSocket::get_MaxRtns(short *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_nMaxRtns;
	return S_OK;
}

STDMETHODIMP CUSocket::put_MaxRtns(short newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(newVal==0)
		m_nMaxRtns = 512;
	else
		m_nMaxRtns = newVal;
	return S_OK;
}

STDMETHODIMP CUSocket::get_RtnsInQueue(long *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		if(m_SBAttr.m_bUseBaseSocketOnly)
			*pVal = 0;
		else
			*pVal = QueryRtns();
	}
	return S_OK;
}

STDMETHODIMP CUSocket::DetectNetPerformance(short *psNetworkBandwidth)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_USAttr.m_hr = uecOK;
	if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(psNetworkBandwidth)
	{
		if(m_NetworkBandwidth == npUnknown)
		{
			ULONG ulLatencey;
			unsigned short usGate;
			if(m_SBAttr.m_bUseBaseSocketOnly)
			{
				m_USAttr.m_hr = uecUnexpected;
				return m_USAttr.m_hr;
			}
			if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET || m_USAttr.m_hr != uecOK)
				return uecOK;

			while(m_sndQueue.GetSize())
			{
				if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET || m_USAttr.m_hr != uecOK)
					return uecOK;
				USend();
				if(m_sndQueue.GetSize())
				{
					::Sleep(1);
				}
				else
				{
					break;
				}
			}
			DoSyn();
			ulLatencey = DetectLatency(4);
			if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET || m_USAttr.m_hr != uecOK)
				return uecOK;
			if(ulLatencey > 65)
			{
				*psNetworkBandwidth = npSlow;
				return m_USAttr.m_hr;
			}
			if(m_SBAttr.m_EncryptionMethod > BlowFish)
				usGate = 35;
			else
				usGate = 25;
			ulLatencey = DetectLatency(70);
			if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET || m_USAttr.m_hr != uecOK)
				return uecOK;
			if(ulLatencey > usGate )
			{
				*psNetworkBandwidth = npMiddle;
				return m_USAttr.m_hr;
			}
			ulLatencey = DetectLatency(600);
			if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET || m_USAttr.m_hr != uecOK)
				return uecOK;
			if(ulLatencey> 55)
			{
				*psNetworkBandwidth = npFast;
				return m_USAttr.m_hr;
			}
			*psNetworkBandwidth = npSuper;
		}
		else
		{
			*psNetworkBandwidth = m_NetworkBandwidth;
		}
	}
	return m_USAttr.m_hr;
}

unsigned long CUSocket::DetectLatency(unsigned long ulCycle)
{
	DWORD dwNow;
	unsigned short usIndex;
	CStreamHeader	StreamHeader;
	StreamHeader.m_bRatio = 0;
	StreamHeader.m_bTreat = 0;
	StreamHeader.m_ulLen = 0;
	StreamHeader.m_nRequestID = idDoEcho;
	DWORD dwPrevTick = ::GetTickCount();
	for(usIndex=0; usIndex<ulCycle; usIndex++)
	{
		m_sndQueue.Push(&StreamHeader);
		USend();
		do
		{
			URecv();
			if(m_SBAttr.m_hSocket == 0 || m_SBAttr.m_hSocket == INVALID_SOCKET || m_USAttr.m_hr != uecOK)
				return 0;
			if(m_rcvQueue.GetSize()>=sizeof(StreamHeader))
			{
				CStreamHeader	tempSH;
				CStreamHeader *pStreamHeader = (CStreamHeader*)m_rcvQueue.GetBuffer();
				tempSH = *pStreamHeader;
				if(!m_bSameEndian)
				{
					tempSH.m_nRequestID = ::htons(tempSH.m_nRequestID);
					ATLASSERT(tempSH.m_ulLen == 0);
				}
				if(tempSH.m_nRequestID == idDoEcho)
				{
					m_rcvQueue.Pop(sizeof(CStreamHeader));
					break;
				}
				else
				{
					HandleNextRtn();
				}
			}
		}while(true);
	}
	dwNow = ::GetTickCount();
	if(dwNow>dwPrevTick)
		return dwNow - dwPrevTick;
	return 0;
}

STDMETHODIMP CUSocket::IgnorePendingRequests(long lRequests, long lStartWith)
{
	DWORD dwRequests = lRequests;
	DWORD dwStartWith = lStartWith;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(dwRequests == 0xFFFFFFFF)
		m_requestQueue.SetSize(0);
	m_requestQueue.Pop(dwRequests*sizeof(unsigned short), dwStartWith*sizeof(unsigned short));
	return S_OK;
}

STDMETHODIMP CUSocket::SendMySpecificBytes(VARIANT vtBytes)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(vtBytes.vt != VT_NULL && vtBytes.vt != VT_EMPTY && vtBytes.vt != (VT_ARRAY|VT_UI1) && vtBytes.vt != (VT_ARRAY|VT_I1))
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	return SendRequest(idSendMySpecificBytes, vtBytes, VARIANT_FALSE);
}

STDMETHODIMP CUSocket::get_IsSameEndian(VARIANT_BOOL *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = (m_bSameEndian ? VARIANT_TRUE : VARIANT_FALSE);
	}
	return S_OK;
}

STDMETHODIMP CUSocket::SpeakEx(unsigned long ulLen, BYTE pMessage[], unsigned long ulGroups)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	m_tempQueue.Push(&ulGroups);
	m_tempQueue.Push(pMessage, ulLen);
	return SendRequestEx(idSpeakEx, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::SpeakToEx(BSTR bstrIPAddr, long lPort, unsigned long ulLen, BYTE pMessage[])
{
	USES_CONVERSION;
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly || bstrIPAddr == NULL || ::SysStringLen(bstrIPAddr)==0 || lPort<=0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	unsigned long ulAddr = ::inet_addr(OLE2A(bstrIPAddr));
/*	if(ulAddr == INADDR_NONE)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}*/
	m_tempQueue.Push(&ulAddr);
	m_tempQueue.Push(&lPort);
	m_tempQueue.Push(pMessage, ulLen);
	return SendRequestEx(idSpeakToEx, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::get_BytesBatched(long *pVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(pVal)
		*pVal = m_BatchQueue.GetSize();
	return S_OK;
}

STDMETHODIMP CUSocket::Wait(short sRequestID, long lTimeout, long lSvsID, VARIANT_BOOL *pbTimeout)
{
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		if(m_usWaitReqID != 0 || m_ulWaitSvsID != 0 || m_SBAttr.m_bUseBaseSocketOnly || m_USAttr.m_bStartingJob || m_USAttr.m_bBatching)
		{
			m_ulWaitSvsID = 0;
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}
	}
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		if(m_usWaitReqID != 0 || m_ulWaitSvsID != 0)
		{
			m_ulWaitSvsID = 0;
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}

		if(lSvsID == 0)
		{
			m_ulWaitSvsID = m_USAttr.m_Client.m_ulSvsID;
		}
		else
		{
			m_ulWaitSvsID = (ULONG)lSvsID;
		}

		if(m_ulWaitSvsID == sidStartup || sRequestID == 0)
		{
			m_ulWaitSvsID = 0;
			m_USAttr.m_hr = uecUnexpected;
			return m_USAttr.m_hr;
		}
		
		m_usWaitReqID = (unsigned short)sRequestID;
	
	}

	{
		MSG	msg;
		bool bPump;
		if(lTimeout == 0)
		{
			if(pbTimeout)
			{
				CAutoLock AutoLock(&m_csGeneral.m_sec);
				ATLASSERT((m_requestQueue.GetSize() % 2) == 0);
				*pbTimeout = (m_requestQueue.GetSize()  && m_usWaitReqID && m_ulWaitSvsID)? VARIANT_TRUE : VARIANT_FALSE;
				m_usWaitReqID = 0;
				m_ulWaitSvsID = 0;
			}
			return S_OK;
		}

		{
			CAutoLock AutoLock(&m_csGeneral.m_sec);
			bPump = (m_dwObjThreadID == ::GetCurrentThreadId());
			if(m_SBAttr.m_bUseBaseSocketOnly)
			{
				m_USAttr.m_hr = uecUnexpected;
				return m_USAttr.m_hr;
			}
		}
		if(pbTimeout)
			*pbTimeout = VARIANT_FALSE;

		unsigned long ulStart = ::GetTickCount();
		unsigned long ulNow;
		unsigned long ulTimeout = (DWORD)lTimeout;
/*		if(bPump && g_pWSAStartup->m_dwUsedWithDotNet > 0)
			::SetFocus(NULL);*/
		do
		{
			if(bPump)
			{
				if(m_sndQueue.GetSize())
					USend();
			}
			else
			{
				CAutoLock AutoLock(&m_csGeneral.m_sec);
				if(m_sndQueue.GetSize())
					USend();
			}
			if(bPump)
			{
				while(::PeekMessage(&msg, 0, 1, 0x7FFF, PM_REMOVE))
				{
	//				::GetMessage(&msg, 0, 0, 0);
					if(msg.hwnd == m_MyWindow.m_hWnd && (WSAGETSELECTEVENT(msg.lParam) == FD_READ || WSAGETSELECTEVENT(msg.lParam) == FD_WRITE))
						break;
					if(!m_bFrozen || msg.hwnd == m_MyWindow.m_hWnd)
					{
						::TranslateMessage(&msg);
						::DispatchMessage(&msg);
					}
					if(m_requestQueue.GetSize() == 0)
						break;
					if(msg.message == WM_PAINT)
						break;
				}
			}
			
			if(bPump)
			{
				if(m_SBAttr.m_hSocket == INVALID_SOCKET)
					break;
				if(m_requestQueue.GetSize() == 0)
					break;
			}
			else
			{
				CAutoLock AutoLock(&m_csGeneral.m_sec);
				if(m_SBAttr.m_hSocket == INVALID_SOCKET)
					break;
				if(m_requestQueue.GetSize() == 0)
					break;
			}
			
			if(bPump)
			{
				OnRead(0);
			}

			{
				CAutoLock AutoLock(&m_csGeneral.m_sec);
				if(m_usWaitReqID == 0xFFFF && m_ulWaitSvsID == 0)
				{
					::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_READ,0));
					break;
				}
			}
			
			if(bPump)
			{
				if(m_requestQueue.GetSize() == 0)
					break;
			}
			else
			{
				CAutoLock AutoLock(&m_csGeneral.m_sec);
				if(m_requestQueue.GetSize() == 0)
					break;
			}
			
			ulNow = ::GetTickCount();
			if(ulNow>ulStart && (ulNow - ulStart)>=ulTimeout)
			{
				if(pbTimeout)
					*pbTimeout = VARIANT_TRUE;
				break;
			}
			{
				timeval timeout = {0, 50000}; //50 ms
				fd_set fds;
				FD_ZERO(&fds);
				if(bPump)
				{
					FD_SET(m_SBAttr.m_hSocket, &fds);
					int nStatus = ::select(0, &fds, NULL, NULL, &timeout);
					if(nStatus == SOCKET_ERROR)
					{
						::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_CLOSE, (WORD)WSAGetLastError()));
						break;
					}
				}
				else
				{
					if(m_hNotify != NULL)
					{
						m_bWaiting = true;
						::WaitForSingleObject(m_hNotify, 2);
						m_bWaiting = false;
					}
					else
					{
						FD_SET(m_SBAttr.m_hSocket, &fds);
						int nStatus = ::select(0, &fds, NULL, NULL, &timeout);
						if(nStatus == SOCKET_ERROR)
						{
							CAutoLock AutoLock(&m_csGeneral.m_sec);
							::PostMessage(m_MyWindow.m_hWnd, msgSocketEvent, m_SBAttr.m_hSocket, MAKELONG(FD_CLOSE, (WORD)WSAGetLastError()));
							break;
						}
					}
				}
			}
		}while(true);

		{
			CAutoLock AutoLock(&m_csGeneral.m_sec);
			m_usWaitReqID = 0;
			m_ulWaitSvsID = 0;
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocket::get_CountOfRequestsInQueue(long *pVal)
{
	if(pVal)
	{
//		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_requestQueue.GetSize()/sizeof(unsigned short);
	}

	return S_OK;
}

STDMETHODIMP CUSocket::get_IsBatching(VARIANT_BOOL *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		*pVal = m_USAttr.m_bBatching ? VARIANT_TRUE : VARIANT_FALSE;
	}

	return S_OK;
}

void CUSocket::ZeroTrack()
{
	m_BatchQueue.CleanTrack();
	m_rcvQueue.CleanTrack();
	m_sndQueue.CleanTrack();
	m_tempQueue.CleanTrack();
	m_tQueue.CleanTrack();
	m_traceQueue.CleanTrack();
	m_requestQueue.CleanTrack();
}


STDMETHODIMP CUSocket::CleanTrack()
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	ZeroTrack();
	if(m_SBAttr.m_bUseBaseSocketOnly)
	{
	}
	else
	{
		m_USAttr.m_hr = SendRequestEx(idCleanTrack, 0, NULL);
	}
	return m_USAttr.m_hr;
}

HRESULT STDMETHODCALLTYPE CUSocket::SetEvent(long hEvent)
{
	m_hSEvent = (HANDLE)hEvent;
	if(hEvent == 0)
	{
		m_MyWindow.m_hWnd = NULL;
	}
	
	if(hEvent == 0 && m_hNotify != NULL)
	{
		::CloseHandle(m_hNotify);
		m_hNotify = NULL;
	}

	if(m_hSEvent != NULL)
	{
		m_hNotify = ::CreateEvent(NULL, FALSE, FALSE, NULL);
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE CUSocket::OnSClosed(long lError)
{
	OnClosed(lError);
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CUSocket::OnSWrite(long lError)
{
	OnWrite(lError);
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CUSocket::OnSRead(long lError)
{
	OnRead(lError);
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CUSocket::IsWaiting()
{
	return m_bWaiting;
}

HRESULT STDMETHODCALLTYPE CUSocket::Notify(long lInfo)
{
	if(m_hNotify != NULL)
	{
		switch (lInfo)
		{
		case FD_READ:
		case FD_WRITE:
		case FD_CLOSE:
			::SetEvent(m_hNotify);
			break;
		default:
			break;
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocket::SendUserMessage(BSTR bstrUserID, VARIANT vtMsg)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly || bstrUserID == NULL || ::SysStringLen(bstrUserID) == 0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(m_pJSSerialization != NULL)
	{
		m_pJSSerialization->m_UQueue.SetSize(0);
		m_pJSSerialization->m_UQueue<<(LPCWSTR)bstrUserID;
		m_USAttr.m_hr = m_pJSSerialization->save(vtMsg);
		if(FAILED(m_USAttr.m_hr))
			return m_USAttr.m_hr;
		return SendJSRequest(idSendUserMessage);
	}
	m_tempQueue.SetSize(0);
	m_tempQueue << (LPCWSTR)bstrUserID;
	m_tempQueue.PushVT(vtMsg);
	return SendRequestEx(idSendUserMessage, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::SendUserMessageEx(BSTR bstrUserID, unsigned long ulLen, BYTE pMessage[])
{
	USES_CONVERSION;
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly || bstrUserID == NULL || ::SysStringLen(bstrUserID)==0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	m_tempQueue.SetSize(0);
	m_tempQueue << (LPCWSTR)bstrUserID;
	m_tempQueue.Push(pMessage, ulLen);
	return SendRequestEx(idSendUserMessageEx, m_tempQueue.GetSize(), (BYTE*)m_tempQueue.GetBuffer());
}

STDMETHODIMP CUSocket::get_LastRequestID(short *pVal)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	
	if(pVal)
	{
		*pVal = m_sLastRequestID;
	}

	return S_OK;
}

STDMETHODIMP CUSocket::get_ZipLevel(tagZipLevel *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
		*pVal = m_UZip.m_ZipLevel;
	}
	return S_OK;
}

STDMETHODIMP CUSocket::put_ZipLevel(tagZipLevel newVal)
{
	if(newVal == zlBestCompression)
		newVal = zlDefault;
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	m_UZip.m_ZipLevel = newVal;
	if(m_USAttr.m_Server.m_usUSockMinor < 2)
	{
		m_UZip.m_ZipLevel = zlDefault;
	}
	return S_OK;
}

STDMETHODIMP CUSocket::SetZipLevelAtSvr(tagZipLevel zipLevel)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_SBAttr.m_bUseBaseSocketOnly || m_USAttr.m_Server.m_usUSockMinor < 2)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	int nZipLevel = zipLevel;
	return SendRequestEx(idSetZipLevelAtSvr, sizeof(zipLevel), (BYTE*)&zipLevel);
}

STDMETHODIMP CUSocket::get_ZipLevelAtSvr(tagZipLevel *pVal)
{
	if(pVal != NULL)
	{
		CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
		*pVal = m_zlServer;
	}

	return S_OK;
}

STDMETHODIMP CUSocket::GetGroupID(/*[in]*/long lIndex, /*[out,retval]*/long *plGroupID)
{
	if(plGroupID == NULL)
		return S_OK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_GroupInfos.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	*plGroupID = m_GroupInfos[lIndex].m_dwID;
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetGroupDescription(/*[in]*/long lIndex, /*[out, retval]*/BSTR *pbstrDescription)
{
	if(pbstrDescription == NULL)
		return S_OK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_GroupInfos.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	if(m_GroupInfos[lIndex].m_bstrDescription.m_str)
		*pbstrDescription = ::SysAllocString(m_GroupInfos[lIndex].m_bstrDescription.m_str);
	else
		*pbstrDescription = NULL;
	return m_USAttr.m_hr;
}

STDMETHODIMP CUSocket::GetInfoGroupIDs(/*[in]*/long lIndex, /*[out,retval]*/long *plGroupIDs)
{
	if(plGroupIDs == NULL)
		return S_OK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_Listeners.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	*plGroupIDs = m_Listeners[lIndex].m_dwID;
	return uecOK;
}

STDMETHODIMP CUSocket::GetInfoUserID(/*[in]*/long lIndex, /*[out,retval]*/BSTR *pbstrUserID)
{
	if(pbstrUserID == NULL)
		return S_OK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_Listeners.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	*pbstrUserID = OLE2BSTR(m_Listeners[lIndex].m_strUID);
	return uecOK;
}

STDMETHODIMP CUSocket::GetInfoServiceID(/*[in]*/long lIndex, /*[out,retval]*/long *plSvsID)
{
	if(plSvsID == NULL)
		return S_OK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_Listeners.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	*plSvsID = m_Listeners[lIndex].m_ulSvsID;
	return uecOK;
}

STDMETHODIMP CUSocket::GetInfoPort(/*[in]*/long lIndex, /*[out,retval]*/long *plPort)
{
	if(plPort == NULL)
		return S_OK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_Listeners.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	*plPort = m_Listeners[lIndex].m_unPort;
	return uecOK;
}

STDMETHODIMP CUSocket::GetInfoIPAddress(/*[in]*/long lIndex, /*[out,retval]*/BSTR *pbstrIPAddress)
{
	if(pbstrIPAddress == NULL)
		return S_OK;
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(lIndex>=m_Listeners.GetSize() || lIndex<0)
	{
		m_USAttr.m_hr = uecUnexpected;
		return m_USAttr.m_hr;
	}
	in_addr in;
	in.S_un.S_addr=m_Listeners[lIndex].m_ulIPAddr;
	*pbstrIPAddress=A2BSTR(::inet_ntoa(in));
	return uecOK;
}

STDMETHODIMP CUSocket::get_JSObject(VARIANT *pVal)
{
	if(pVal != NULL)
	{
		CAutoLock AutoLock(&m_csGeneral.m_sec);
		::VariantCopy(pVal, &m_vtJSObject);
	}
	return S_OK;
}

STDMETHODIMP CUSocket::put_JSObject(VARIANT newVal)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	m_vtJSObject = newVal;
	if(m_spWebDoc != NULL && m_pJSSerialization == NULL)
	{
		m_USAttr.m_Client.m_ulParam2 = 1; //1 web, 2, Unix, 4, other
		m_USAttr.m_hr =  CComObject<CJSSerialization>::CreateInstance(&m_pJSSerialization);
		if(FAILED(m_USAttr.m_hr))
		{
			return m_USAttr.m_hr;
		}
		m_pJSSerialization->AddRef();
		m_spWebDoc->QueryInterface(IID_IHTMLDocument2, (void**)&m_pJSSerialization->m_spWebDoc);
	}
	return S_OK;
}

STDMETHODIMP CUSocket::get_JSUQueue(IJSSerialization **ppVal)
{
	if(ppVal == NULL)
		return S_OK;
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(m_spWebDoc == NULL)
	{
		m_USAttr.m_hr = uecNotImplemented;
		return m_USAttr.m_hr;
	}
	if(m_pJSSerialization == NULL)
	{
		m_USAttr.m_hr =  CComObject<CJSSerialization>::CreateInstance(&m_pJSSerialization);
		if(FAILED(m_USAttr.m_hr))
		{
			return m_USAttr.m_hr;
		}
		m_pJSSerialization->AddRef();
		m_spWebDoc->QueryInterface(IID_IHTMLDocument2, (void**)&m_pJSSerialization->m_spWebDoc);
	}
	m_USAttr.m_hr = m_pJSSerialization->QueryInterface(__uuidof(IJSSerialization), (void**)ppVal);
	return m_USAttr.m_hr;
}


STDMETHODIMP CUSocket::SetSite(IUnknown *pUnkSite)
{
	CAutoLock AutoLockLocal(&m_csGeneral.m_sec);
	if(pUnkSite == NULL)
	{
		if(m_pJSSerialization != NULL)
		{
			m_pJSSerialization->m_spWebDoc.Release();
		}
		m_spWebDoc.Release();
		m_vtJSObject.Clear();
	}
	else if(m_spWebDoc == NULL)
	{
		CComPtr<IWebBrowser>	spBrowser;
		CComPtr<IDispatch>		pDoc;
		do
		{
			GetSite(IID_IWebBrowser, (void**)&spBrowser);
			if(spBrowser == NULL)
				break;
			spBrowser->get_Document(&pDoc);
			if(pDoc == NULL)
				break;
			pDoc->QueryInterface(IID_IHTMLDocument2, (void**)&m_spWebDoc);
			if(m_spWebDoc == NULL)
				break;
			if(m_pJSSerialization == NULL)
			{
				m_USAttr.m_Client.m_ulParam2 = 1; //1 web, 2, Unix, 4, other
				m_USAttr.m_hr =  CComObject<CJSSerialization>::CreateInstance(&m_pJSSerialization);
				if(FAILED(m_USAttr.m_hr))
				{
					return m_USAttr.m_hr;
				}
				m_pJSSerialization->AddRef();
				m_spWebDoc->QueryInterface(IID_IHTMLDocument2, (void**)&m_pJSSerialization->m_spWebDoc);
			}
			
		}while(false);
	}
	return S_OK;
}


STDMETHODIMP CUSocket::SendJSRequest(short sRequestId)
{
	CAutoLock AutoLock(&m_csGeneral.m_sec);
	if(m_spWebDoc == NULL)
	{
		m_USAttr.m_hr = uecUnexpected;
		return uecUnexpected;
	}
	unsigned long ulLen = 0;
	BYTE *pBuffer = NULL;
	if(m_pJSSerialization != NULL)
	{
		pBuffer = (BYTE*)m_pJSSerialization->m_UQueue.GetBuffer();
		ulLen = m_pJSSerialization->m_UQueue.GetSize();
	}
	m_USAttr.m_hr = SendRequestEx(sRequestId, ulLen, pBuffer);
	m_pJSSerialization->m_UQueue.SetSize(0);
	return m_USAttr.m_hr;
}

HRESULT CUSocket::InvokeVariantMethod(const DISPID dispidMethod, WORD wInvokeFlag, VARIANT *pvtArgs, unsigned int argCount, VARIANT* pVarRet)
{
/*	if(m_pIMozilla.p == NULL)
		return E_FAIL;*/
	ATLASSERT(pVarRet != NULL);
	DISPID dispidNamed = DISPID_PROPERTYPUT;
	DISPPARAMS disp;
	disp.cArgs = argCount;
	disp.rgvarg = (VARIANT *)pvtArgs;
	if(wInvokeFlag == INVOKE_PROPERTYPUT)
	{
		disp.rgdispidNamedArgs = &dispidNamed;
		disp.cNamedArgs = 1;
	}
	else
	{
		disp.rgdispidNamedArgs = NULL;
		disp.cNamedArgs = 0;
	}
	if(/*wInvokeFlag == INVOKE_FUNC &&*/argCount > 1)
	{
		disp.rgvarg = pvtArgs;
	}
	unsigned int nError = 0;
	HRESULT hr = m_vtJSObject.pdispVal->Invoke(dispidMethod, IID_NULL, LOCALE_USER_DEFAULT, wInvokeFlag, &disp, pVarRet, NULL, &nError);
	return hr;
}

bool CUSocket::Invoke(CComBSTR &bstrMethodName, VARIANT *pvtArgs, unsigned int argCount, CComVariant &vtResult)
{
	if(m_vtJSObject.vt != VT_DISPATCH)
		return false;
	int nIndex = m_mapFunc.FindKey(bstrMethodName);
	if(nIndex == -1)
		return false;
	FUNCDESC funcDesc = m_mapFunc.GetValueAt(nIndex);
	return (InvokeVariantMethod(funcDesc.memid, funcDesc.invkind, pvtArgs, argCount, &vtResult) == S_OK);
}