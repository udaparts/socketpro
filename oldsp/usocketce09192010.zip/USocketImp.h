// USocketImp.h : Declaration of the CUSocket

#ifndef __USOCKET_H_
#define __USOCKET_H_

#include "resource.h"       // main symbols
#include "USocketCP.h"
#include <atlwin.h>
#include "uqueue.h"
//#include "BlowfishGA.h"
#include "usspiimpl.h"
#include "usinternal.h"
#include "BF.h"
#include "UZip.h"
#include "JSSerialization.h"

using namespace SocketProAdapter;

#pragma pack(push,1)
struct CRTrace
{
	unsigned short	m_usRID;
	unsigned long	m_ulRBufferLen;
	unsigned long	m_ulContained;
};
#pragma pack(pop)

struct CUSocketAttributes
{
	CSwitchInfo		m_Client;
	CSwitchInfo		m_Server;
	bool			m_bZipIsOn;
	bool			m_bZipIsOnSvr;
	unsigned long	m_ulZipLimit;
	unsigned long	m_ulZipLimitSvr;
	bool			m_bSyn;
	bool			m_bStartingJob;
	HRESULT			m_hr;
	bool			m_bBatching;
	unsigned long	m_ulMemBlockSize;
	CStreamHeader	m_curRcvStreamHeader;
	long			m_lOptValue;
};

struct CSocketBaseAttributes
{
	unsigned long		m_ulConnTimeout;
	bool				m_bUseBaseSocketOnly;
	SOCKET				m_hSocket;
	tagEncryptionMethod	m_EncryptionMethod;	
	SSL					*m_pSSL;
	HANDLE				m_hWSAAsync;
	UINT				m_nTimer;
	unsigned long		m_ulRecvTimeout;
	unsigned long		m_ulSendTimeout;
};

class CGroupInfo
{
public:
	CGroupInfo()
	{
		m_dwID=0;
	}
	CGroupInfo(const CGroupInfo& GroupInfo)
	{
		m_dwID=GroupInfo.m_dwID;
		m_bstrDescription = GroupInfo.m_bstrDescription;
	}

public:
	CGroupInfo& operator=(const CGroupInfo& GroupInfo)
	{
		m_dwID=GroupInfo.m_dwID;
		m_bstrDescription = GroupInfo.m_bstrDescription;
		return *this;
	}

public:
	CComBSTR	m_bstrDescription;
	ULONG		m_dwID;
};

class CListenerInfo
{
public:
	CListenerInfo()
	{
		memset(this, 0, sizeof(CListenerInfo));
	}
public:
	unsigned long		m_ulSvsID;
	unsigned long		m_ulIPAddr;
//	char				m_strIPAddr[256];
	WCHAR				m_strUID[256];
	ULONG				m_dwID;
	unsigned int		m_unPort;
};

/////////////////////////////////////////////////////////////////////////////
// CUSocket
class ATL_NO_VTABLE CUSocket : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CUSocket, &CLSID_USocket>,
	public IDispatchImpl<IUSocketScript, &IID_IUSocketScript, &LIBID_USOCKETLib>,
//	public ISupportErrorInfo,
	public IUFast,
	public IUSocketInternal,
	public IConnectionPointContainerImpl<CUSocket>,
	public IObjectWithSiteImpl<CUSocket>,
	public IDispatchImpl<IUChat, &IID_IUChat, &LIBID_USOCKETLib>,
	public IDispatchImpl<IUZip, &IID_IUZip, &LIBID_USOCKETLib>,
	public CProxy_IUSocketEvent< CUSocket >,
	public IObjectSafetyImpl<CUSocket, INTERFACESAFE_FOR_UNTRUSTED_DATA | INTERFACESAFE_FOR_UNTRUSTED_CALLER>
{
public:
	CUSocket();
	virtual ~CUSocket();
	
	class CMyWindow : public CWindowImpl<CMyWindow, CWindow, CFrameWinTraits> 
	{
	public:
		DECLARE_WND_CLASS(_T("USocket"))
		BOOL ProcessWindowMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT& lResult, DWORD dwMsgMapID = 0)
		{
			if(uMsg == msgSocketEvent)
			{
				SOCKET	hSocket = wParam;
				if(hSocket != m_pUSocket->m_SBAttr.m_hSocket)
					return TRUE;
				ATLASSERT(hWnd == m_hWnd);
				int nErrorCode = WSAGETSELECTERROR(lParam);
				switch (WSAGETSELECTEVENT(lParam))
				{
				case FD_CLOSE:
					{
						m_pUSocket->OnClosed(nErrorCode);
					}
					break;
				case FD_CONNECT:
					{
						m_pUSocket->OnConnected(nErrorCode);
					}
					break;
				case FD_WRITE:
					{
						m_pUSocket->OnWrite(nErrorCode);
					}
					break;
				case FD_READ:
					{
						m_pUSocket->OnRead(nErrorCode);
					}
					break;
				default:
					ATLASSERT(FALSE); //shouldn't come here
					break;
				}
			}
			else if(uMsg>=WM_USER)
			{
				if(hWnd != NULL)
				{
					ATLASSERT(hWnd == m_hWnd);
				}
				m_pUSocket->OnOtherMessage(uMsg, wParam, lParam);
			}
			return TRUE;
		}
		CUSocket	*m_pUSocket;
	};

	HRESULT FinalConstruct();
	void FinalRelease();

DECLARE_REGISTRY_RESOURCEID(IDR_USOCKET)

DECLARE_PROTECT_FINAL_CONSTRUCT()

DECLARE_GET_CONTROLLING_UNKNOWN()
DECLARE_NOT_AGGREGATABLE(CUSocket)

BEGIN_COM_MAP(CUSocket)
	COM_INTERFACE_ENTRY(IUSocket)
	COM_INTERFACE_ENTRY(ISocketBase)
	COM_INTERFACE_ENTRY(IUChat)
	COM_INTERFACE_ENTRY(IUFast)
	COM_INTERFACE_ENTRY(IUZip)
	COM_INTERFACE_ENTRY(IUSocketInternal)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY_IID(IID_IObjectSafety, IObjectSafety)
	COM_INTERFACE_ENTRY2(IDispatch, IUSocket)
//	COM_INTERFACE_ENTRY(ISupportErrorInfo)
//	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CUSocket)
CONNECTION_POINT_ENTRY(DIID__IUSocketEvent)
END_CONNECTION_POINT_MAP()


// ISupportsErrorInfo
//	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);
	STDMETHOD(DoEcho) ();

public:
	CUSocketAttributes		m_USAttr;
	CSocketBaseAttributes	m_SBAttr;
	bool					m_bSameEndian;
	HANDLE					m_hSocketEvent;
	bool m_bIO;
//	HANDLE m_hEventFromThread;

//	CComAutoCriticalSection	m_csSend;
//	CComAutoCriticalSection	m_csRecv;
	CComAutoCriticalSection	m_csGeneral;

	DWORD			m_dwBytesIn;
	DWORD			m_dwBytesOut;
	DWORD			m_dwBytesInHigh;
	DWORD			m_dwBytesOutHigh;

	CUQueue			m_rcvQueue;
	CUQueue			m_sndQueue;
	
	CUQueue			m_tempQueue;
	CUQueue			m_BatchQueue;
	CUQueue			m_traceQueue;
	CUQueue			m_tQueue;

	CMyWindow		m_MyWindow;
	bool			m_bChecked;
	char			*m_strHostEntBuffer;
	CComBSTR		m_bstrUserID;
	CComBSTR		m_bstrPassword;
//	CComVariant		m_vtKey;
	CComVariant		m_vtKeySvr;
	CUQueue			m_requestQueue;
	unsigned long	m_ulLSend;
	unsigned long	m_ulTimeTrack;
	unsigned long	m_ulSynIndicator;
	long			m_lMTU;
	long			m_lType;
	long			m_lSpeed;
	bool			m_bDoingHandshake;

	CSimpleArray<CGroupInfo>	m_GroupInfos;
	CSimpleArray<CListenerInfo>	m_Listeners;
	CComVariant					m_vtMsg;
	CRTrace						m_RTrace;
	DWORD						m_ulCancelRequests;
	bool						m_bFrozen;
	unsigned short				m_usRtnEvents;
	bool						m_bSendingTooFast;
	unsigned short				m_nMaxRtns;
	tagNetPerformance			m_NetworkBandwidth;
	DWORD						m_dwObjThreadID;
	ULONG						m_ulWaitSvsID;
	unsigned short				m_usWaitReqID;
	CComBSTR					m_bstrLocation;
	CComBSTR					m_bstrAddrConn;
	bool						m_bCleanRequired;
	CSspiClient					m_Sspi;
	BYTE m_bMSSSLState;
	HANDLE					m_hSEvent;
	bool						m_bFirstWrite;
	unsigned short				m_sLastRequestID;
	BYTE						m_pHash[20];
	bool						m_bVerify;
	GUID						m_guidSalt;
	HANDLE						m_hNotify;
	bool						m_bWaiting;
	CComVariant						m_vtJSObject;
	CComPtr<IHTMLDocument2>			m_spWebDoc;
	CComObject<CJSSerialization>	*m_pJSSerialization;
private:
	UINT			m_nHostPort;
	int				m_nAddressFormat;
	CBF				*m_pBlowFish;
	unsigned long	m_ulSndBatch;
	CUZip			m_UZip;
	tagZipLevel		m_zlServer;
	CSimpleMap<CComBSTR, FUNCDESC>	m_mapFunc;
	unsigned short m_usRequestIdDiscarded;
private:
	unsigned long DetectLatency(unsigned long ulCycle);
	unsigned long QueryRtns();
	unsigned long CancelImp(unsigned long ulRequests);
	void SetTraceQueue();
	void HandleBaseRequest(unsigned short usRID, unsigned long ulLen);
	void USend();
	static void SSLCallback(const SSL *pSSL, int nWhere,int nRtn);
	bool PumpMessages(UINT uStopFlag);
	bool Connect( const SOCKADDR* lpSockAddr, UINT nSockAddrLen, bool bSyn);
	void DestroyTimer();
	bool SetSSL();
	bool DoSSLConnect();
	void DoSyn();
	void HandleNextRtn();
	unsigned long UnZip(void *pBuffer, unsigned long ulSize, const void* pSrc, unsigned long ulLen);
	unsigned long URecv();
	HRESULT InvokeVariantMethod(const DISPID dispidMethod, WORD wInvokeFlag, VARIANT *pvtArgs, unsigned int argCount, VARIANT* pVarRet);
// IUSocket
public:
	bool Invoke(CComBSTR &bstrMethodName, VARIANT *pvtArgs, unsigned int argCount, CComVariant &vtResult);
	STDMETHOD(StartJob)();
	STDMETHOD(EndJob)();	
	STDMETHOD(get_ZipLevelAtSvr)(/*[out, retval]*/ tagZipLevel *pVal);
	STDMETHOD(SetZipLevelAtSvr)(/*[in]*/tagZipLevel zipLevel);
	STDMETHOD(get_ZipLevel)(/*[out, retval]*/ tagZipLevel *pVal);
	STDMETHOD(put_ZipLevel)(/*[in]*/ tagZipLevel newVal);
	STDMETHOD(get_LastRequestID)(/*[out, retval]*/ short *pVal);
	STDMETHOD(SendUserMessageEx)(/*[in]*/BSTR bstrUserID, /*[in]*/unsigned long ulLen, /*[in]*/BYTE pMessage[]);
	STDMETHOD(SendUserMessage)(/*[in]*/BSTR bstrUserID, VARIANT vtMsg);
	virtual HRESULT STDMETHODCALLTYPE SetEvent(long hEvent);
   	virtual HRESULT STDMETHODCALLTYPE OnSClosed(long lError);
    virtual HRESULT STDMETHODCALLTYPE OnSWrite(long lError);
    virtual HRESULT STDMETHODCALLTYPE OnSRead(long lError);
	virtual HRESULT STDMETHODCALLTYPE Notify(long lInfo);
	virtual HRESULT STDMETHODCALLTYPE IsWaiting();
	STDMETHOD(CleanTrack)();
	STDMETHOD(get_IsBatching)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(get_CountOfRequestsInQueue)(/*[out, retval]*/ long *pVal);
	STDMETHOD(Wait)(/*[in]*/short sRequestID, /*[in]*/long lTimeout, /*[in, defaultvalue(0)]*/long lSvsID, /*[out, retval]*/VARIANT_BOOL *pbTimeout);
	STDMETHOD(get_BytesBatched)(/*[out, retval]*/ long *pVal);
	STDMETHOD(SpeakToEx)(/*[in]*/BSTR bstrIPAddr, long lPort, /*[in]*/unsigned long ulLen, /*[in, size_is(ulLen)]*/BYTE pMessage[]);
	STDMETHOD(SpeakEx)(/*[in]*/unsigned long ulLen, /*[in, size_is(ulLen)]*/BYTE pMessage[], /*[in]*/unsigned long ulGroups);
	STDMETHOD(get_IsSameEndian)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(SendMySpecificBytes)(/*[in]*/VARIANT vtBytes);
	STDMETHOD(IgnorePendingRequests)(long lRequests, long lStartWith);
	STDMETHOD(DetectNetPerformance)(short *psNetworkBandwidth);
	STDMETHOD(get_RtnsInQueue)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_MaxRtns)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_MaxRtns)(/*[in]*/ short newVal);
	STDMETHOD(get_ReturnEvents)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_ReturnEvents)(/*[in]*/ short newVal);
	STDMETHOD(get_BytesInRcvMemory)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_BytesInSndMemory)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_Frozen)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_Frozen)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(GetAllClients)();
	STDMETHOD(GetBytesReceived)(long *plHigh, /*[out, retval]*/ long *pVal);
	STDMETHOD(GetBytesSent)(long *plHigh, /*[out, retval]*/ long *pVal);
	STDMETHOD(GetServerUSockVersion)(/*[out]*/short *pnMinor, /*[out,retval]*/short *pnMajor);
	STDMETHOD(GetClientUSockVersion)(/*[out]*/short *pnMinor, /*[out,retval]*/short *pnMajor);
	STDMETHOD(get_RequestsCanceled)(/*[out, retval]*/ long *pVal);
	STDMETHOD(ShrinkMemoryAtSvr)();
	STDMETHOD(get_ErrorMsg)(/*[out, retval]*/BSTR *pbstrErrorMsg);
	STDMETHOD(get_SendTimeout)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_SendTimeout)(/*[in]*/ long newVal);
	STDMETHOD(get_RecvTimeout)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_RecvTimeout)(/*[in]*/ long newVal);
	STDMETHOD(get_ServerParams)(/*[out, retval]*/ VARIANT *pVal);
//	STDMETHOD(put_ServerParams)(/*[in]*/ VARIANT newVal);
//	STDMETHOD(GetSeverOSVersion)(/*[out]*/short *pnMinor, /*[out, retval]*/short *pnMajor);
//	STDMETHOD(GetClientOSVersion)(/*[out]*/short *pnMinor, /*[out,retval]*/short *pnMajor);
	STDMETHOD(ShrinkMemory)();
	STDMETHOD(get_ClientParams)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(put_ClientParams)(/*[in]*/ VARIANT newVal);
	STDMETHOD(GetServerVersion)(/*[out]*/short *pnMinor, /*[out]*/short *pnMajor);
	STDMETHOD(GetClientVersion)(/*[out]*/short *pnMinor, /*[out, retval]*/short *pnMajor);
	STDMETHOD(GetInterfaceAttributes)(/*[out]*/long *lpMTU, /*[out]*/long *plMaxSpeed, long *plIType, BSTR *pbstrMask, /*[out, retval]*/BSTR *pbstrDesc);
	STDMETHOD(GetSockAddr)(/*[out]*/long *plPort, /*[out, retval]*/BSTR *pbstrSockAddr);
	STDMETHOD(get_Syn)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_Syn)(/*[in]*/ VARIANT_BOOL newVal);
	
	STDMETHOD(get_SndMemory)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_RcvMemory)(/*[out, retval]*/ long *pVal);
	
	STDMETHOD(WaitAll)(/*[in]*/long lTimeOut, VARIANT_BOOL *pbTimeout);
	
	void OnOtherMessage(long nMsg, WPARAM wParam, LPARAM lParam);
	void OnRead(int nErrorCode);
	void OnWrite(int nErrorCode);
	void OnConnected(int nErrorCode);
	void OnClosed(int nErrorCode);
	void OnWSAGetHostByName(WPARAM wParam, short nError, short nBufferLen);
	void OnWSAGetHostByAddr(WPARAM wParam, short nError, short nBufferLen);
	void OnWSAAsyncGetHostByName(WPARAM wParam, short nError, short nBufferLen);

	void OnSSLEvent(int nWhere, int nRtn);
	void ZeroTrack();
	STDMETHOD(XEnter)(/*[in]*/VARIANT vtGroups);
	STDMETHOD(XSpeak)(/*[in]*/VARIANT vtMsg, /*[in, defaultvalue(0xFFFFFFFF)]*/VARIANT vtGroups);
	STDMETHOD(XGetAllListeners)(VARIANT vtGroups);
	STDMETHOD(XSpeakEx)(/*[in]*/unsigned long ulLen, /*[in, size_is(ulLen)]*/BYTE pMessage[], /*[in]*/unsigned long ulGroupCount, /*[in, size_is(ulGroupCount)]*/unsigned long pGroups[]);
	STDMETHOD(Cancel)(/*[in, defaultvalue(0)]*/long lRequests);
	STDMETHOD(get_UseBaseSocketOnly)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_UseBaseSocketOnly)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_CurrentSvsID)(/*[out, retval]*/long *plSvsID);
	STDMETHOD(SendRequestEx)(/*[in]*/unsigned short usRequestID, /*[in]*/unsigned long ulLen, /*[in, sizeof(ulLen)]*/BYTE pBuffer[]);
	STDMETHOD(GetRtnBufferEx)(/*[in]*/unsigned long ulLen, /*[out, sizeof(ulLen)]*/BYTE pBuffer[], unsigned long *plRtnSize);
//	STDMETHOD(PackEx)(/*[in]*/unsigned long ulLen, /*[in]*/BYTE *pBuffer);
	STDMETHOD(GetRtnBuffer)(/*[in]*/long nLen, /*[out, retval]*/VARIANT *pvtData);
	STDMETHOD(SendRequest)(/*[in]*/short nRequestID, /*[in]*/VARIANT vtData, VARIANT_BOOL bKeepVTFormat);
	STDMETHOD(GetRequestsInQueue)(/*[out, retval]*/VARIANT *pvtRequests);
//	STDMETHOD(Pack)(/*[in]*/VARIANT vtBuffer);
	STDMETHOD(AbortBatching)();
	STDMETHOD(CommitBatching)(/*[in, defaultvalue(0)]*/VARIANT_BOOL bSvrBatching);
	STDMETHOD(StartBatching)();
	STDMETHOD(get_KeyFromSvr)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_ZipOnAtSvr)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(TurnOnZipAtSvr)(/*[in, defaultvalue(-1)]*/VARIANT_BOOL bZipOn);
	STDMETHOD(get_ZipIsOn)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ZipIsOn)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(Enter)(/*[in]*/long lGroup);
	STDMETHOD(Exit)();
	STDMETHOD(Speak)(/*[in]*/VARIANT vtMsg, /*[in, defaultvalue(0xFFFFFFFF)]*/long lGroups);
	STDMETHOD(SpeakTo)(/*[in]*/BSTR bstrIPAddr, /*[in]*/long lPort, /*[in]*/VARIANT vtMsg);
	STDMETHOD(GetAllGroups)();
	STDMETHOD(GetGroupInfo)(/*[in]*/long lIndex, /*[out]*/long *plGroup, /*[out, retval]*/BSTR *pbstrDescription);
	STDMETHOD(GetAllListeners)(/*[in, defaultvalue(0xFFFFFFFF)]*/long lGroups);
	STDMETHOD(GetInfo)(/*[in]*/long lIndex, /*[out]*/long *plGroup, /*[out]*/BSTR *pbstrUID, long *plSvsID, /*[out]*/long *plPort, /*[out, retval]*/BSTR *pbstrIPAddress);
	STDMETHOD(get_Groups)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_Listeners)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_Message)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(SetClientVersion)(/*[in]*/short nMinor, short nMajor);
	STDMETHOD(get_Rtn)(/*[out, retval]*/long *plRtn);
	STDMETHOD(get_Key)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(put_Key)(/*[in]*/ VARIANT newVal);
	STDMETHOD(get_PeerCertificate)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(GetProcAddress)(/*[in]*/BSTR bstrOpenSSLFuncName, /*[out, retval]*/long *plProcAddr);
	STDMETHOD(get_SSLHandle)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_EncryptionMethod)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_EncryptionMethod)(/*[in]*/ short newVal);
	STDMETHOD(GetOptValueAtSvr)(/*[out, retval]*/ long *pVal);
	STDMETHOD(GetSockOptAtSvr)(/*[in]*/long lOptName, /*[in, optional, defaultvalue(slSocket)]*/long lLevel);
	STDMETHOD(SetSockOptAtSvr)(/*[in]*/long lOptName, /*[in]*/long lOptValue, /*[in, defaultvalue(slSocket)]*/long lLevel);
	STDMETHOD(GetHostByAddr)(/*[in]*/BSTR bstrIPAddr, /*[in, optional, defaultvalue(2)]*/long lAddrFormat, /*[in, optional, defaultvalue(0)]*/VARIANT_BOOL bBlocking, /*[out, optional, defaultvalue(0)]*/long *phHandle, /*[out, optional, defaultvalue(0)]*/BSTR *pbstrAlias, /*[out,retval]*/BSTR *pbstrHostName);
	STDMETHOD(GetHostByName)(/*[in]*/BSTR bstrHost, /*[in, optional, defaultvalue(0)]*/VARIANT_BOOL bBlocking, /*[out, optional, defaultvalue(0)]*/long *phHandle, /*[out, optional, defaultvalue(0)]*/BSTR *pbstrIPAddr, /*[out, optional, defaultvalue(0)]*/BSTR *pbstrAlias, /*[out,retval]*/BSTR *pbstrHostName);
	STDMETHOD(GetLocalName)(/*[out, retval]*/ BSTR *pbstrLocalName);
	STDMETHOD(GetPeerName)(/*[out, optional]*/long *plPeerPort, /*[out, retval]*/BSTR *pbstrPeerName);
	STDMETHOD(get_Password)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Password)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_UserID)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_UserID)(/*[in]*/ BSTR newVal);
	STDMETHOD(SwitchTo)(/*[in]*/long lSvsID);
	STDMETHOD(IOCtl)(/*[in, defaultvalue(0)]*/long lCommand, /*[in, out]*/long *plArgment);
	STDMETHOD(Recv)(/*[out, retval]*/VARIANT *pvtData);
	STDMETHOD(Send)(/*[in]*/VARIANT vtData, long *plSent);
	STDMETHOD(get_Socket)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_ConnTimeout)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_ConnTimeout)(/*[in]*/ long newVal);
	STDMETHOD(get_hWnd)(/*[out, retval]*/ long *pVal);
	STDMETHOD(GetSockOpt)(/*[in]*/long lOptName, /*[in, optional, defaultvalue(0xffff)]*/long lLevel, /*[out, retval]*/long *plOptValue);
	STDMETHOD(SetSockOpt)(/*[in]*/long lOptName, /*[in]*/long lOptValue, /*[in, defaultvalue(slSocket)]*/long lLevel);
	STDMETHOD(Shutdown)(/*[in, defaultvalue(hsSend)]*/long lHow);
	STDMETHOD(Disconnect)();
	STDMETHOD(Connect)(/*[in]*/ BSTR bstrHostAddress, /*[in]*/ long lHostPort, /*[in, optional, defaultvalue(0)]*/VARIANT_BOOL bSynConnecting, /*[in, optional, defaultvalue(stSTREAM)]*/ long lSocketType, /*[in, optional, defaultvalue(afINet)]*/ long lAddrFormat, /*[in, optional, defaultvalue(spIP)]*/ long lProtocol, /*[in, optional, defaultvalue(0)]*/long lLocalPort);
	STDMETHOD(SendJSRequest)(/*[in]*/short sRequestId);
	STDMETHOD(get_JSUQueue)(/*[out, retval]*/ IJSSerialization **ppVal);
	STDMETHOD(get_JSObject)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(put_JSObject)(/*[in]*/ VARIANT newVal);
	STDMETHOD(SetSite)(IUnknown *pUnkSite);
	STDMETHOD(GetGroupID)(/*[in]*/long lIndex, /*[out,retval]*/long *plGroupID);
	STDMETHOD(GetGroupDescription)(/*[in]*/long lIndex, /*[out, retval]*/BSTR *pbstrDescription);
	STDMETHOD(GetInfoGroupIDs)(/*[in]*/long lIndex, /*[out,retval]*/long *plGroupIDs);
	STDMETHOD(GetInfoUserID)(/*[in]*/long lIndex, /*[out,retval]*/BSTR *pbstrUserID);
	STDMETHOD(GetInfoServiceID)(/*[in]*/long lIndex, /*[out,retval]*/long *plSvsID);
	STDMETHOD(GetInfoPort)(/*[in]*/long lIndex, /*[out,retval]*/long *plPort);
	STDMETHOD(GetInfoIPAddress)(/*[in]*/long lIndex, /*[out,retval]*/BSTR *pbstrIPAddress);
};

typedef CSimpleMap<SOCKET, CUSocket*> CUSocketMap;


#endif //__USOCKET_H_
