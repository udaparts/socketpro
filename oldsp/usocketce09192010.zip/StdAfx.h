// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__6DDC1F71_7B06_4DE0_8DEB_A1888AF2DFA2__INCLUDED_)
#define AFX_STDAFX_H__6DDC1F71_7B06_4DE0_8DEB_A1888AF2DFA2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef STRICT
#define STRICT
#endif

#if _WIN32_WCE == 201
#error ATL is not supported for Palm-Size PC
#endif

#define _WIN32_WINNT 0x0400
#define _ATL_FREE_THREADED

#ifndef _ATL_MIN_CRT
#define _ATL_MIN_CRT
#endif  //  !_ATL_MIN_CRT

#ifdef _WIN32_WCE

#define _ATL_NO_MP_HEAP
#endif

//#define _ATL_DEBUG_QI
//#define _ATL_DEBUG_REFCOUNT

/*
#if defined(_WIN32_WCE)    
#undef _WIN32_WINNT        
#endif*/

#if _WIN32_WCE < 0x500 && _MSC_VER > 1220
// only needed for WM2003 builds under VS2005
#pragma comment(lib, "ccrtrtti.lib")
#endif 

#define _ATL_FREE_THREADED

#include <atlbase.h>

#include "USocketModule.h"

//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
extern CComModule _Module;

#include <atlcom.h>
#include <winsock2.h>
#include <atlctl.h>

void CALLBACK UTimerProc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime);

#include "sockutil.h"
#include "streamhead.h"

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#include "zlib.h"

#include "WSAStartup.h"

#include <iphlpapi.h>
void Char2Hex(const unsigned char ch, char* szHex);
void CharStr2HexStr(const unsigned char* pucCharStr, char* pszHexStr, int iSize);
void Hex2Char(const char* szHex, unsigned char& rch);
void HexStr2CharStr(const char* pszHexStr, unsigned char* pucCharStr, int iSize);
int SAsyncSelect(SOCKET s, HWND hWnd, UINT uMsg, ULONG lEvent);
void CancelEvent(SOCKET s, WSAEVENT hEvent);

#include "uqueue.h"

using namespace SocketProAdapter;

#include "usinternal.h"

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__6DDC1F71_7B06_4DE0_8DEB_A1888AF2DFA2__INCLUDED)
