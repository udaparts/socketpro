// WSAStartup.cpp: implementation of the CWSAStartup class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WSAStartup.h"

#include "usspiimpl.h"

CWSAStartup	*g_pWSAStartup = NULL;


ULONG GetOS();
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CWSAStartup::CWSAStartup()
{
	int n;
	m_hSSLEay=NULL;
	m_hLibeay=NULL;
	SSL_library_init = NULL;
	SSLv23_method = NULL;
	SSL_load_error_strings = NULL;
	SSL_CTX_new = NULL;
	SSL_CTX_free = NULL;
	SSL_new = NULL;
	SSL_free = NULL;
	SSL_set_fd = NULL;
	SSL_accept = NULL;
	SSL_get_error = NULL;
	SSL_write = NULL;
	SSL_read = NULL;
	SSL_shutdown = NULL;
	SSL_state = NULL;
	SSL_set_connect_state = NULL;
	SSL_set_accept_state = NULL;
	SSL_CTX_use_certificate_file = NULL;
	SSL_CTX_use_PrivateKey_file = NULL;
	SSL_CTX_check_private_key = NULL;
	SSL_get_peer_certificate = NULL;
	SSL_get_current_cipher = NULL;
	SSL_state_string_long = NULL;
	SSL_do_handshake = NULL;
	SSL_want = NULL;
	SSL_pending = NULL;
	SSL_connect = NULL;
	SSL_peek = NULL;
	TLSv1_method = NULL;
	ERR_clear_error = NULL;
	SSL_clear = NULL;
	CRYPTO_free = NULL;
	CRYPTO_malloc = NULL;
	CRYPTO_set_locking_callback = NULL;
	CRYPTO_num_locks = NULL;
	SSL_set_read_ahead = NULL;
	SSL_set_info_callback = NULL;
	SSL_get_fd = NULL;
	ERR_get_error = NULL;
	ERR_error_string = NULL;
	SSL_CTX_ctrl = NULL;
	m_pCtx = NULL;
	m_pMeth = NULL;

	m_ulOS = GetOS();

	m_dwUsedWithDotNet = 0xFFFFFFFF;
	m_bQuit = false;
	for(n=0; n<MAXIMUM_WAIT_OBJECTS; n++)
	{
		//m_pEvents[n] = ::CreateEvent(NULL, FALSE, FALSE, NULL);
		m_pEvents[n] = WSACreateEvent();
		//::WSAResetEvent(m_pEvents[n]);
	}
	m_hThread = NULL;
}

CWSAStartup::~CWSAStartup()
{
	int n;
	StopSSPI();
//	::Sleep(500);
	for(n=0; n<MAXIMUM_WAIT_OBJECTS; n++)
	{
		if(m_pEvents[n])
		{
			::CloseHandle(m_pEvents[n]);
		}
	}
	KillTimer();
	StopOpenSSL();
	UnloadOpenSSL();
}

bool CWSAStartup::Startup()
{
	m_mapUSocket.RemoveAll();
	m_nVersionRequested = MAKEWORD(2, 2);
	int err = WSAStartup(m_nVersionRequested, &m_wsaData);
	if(err != 0)
		return false;
	if(HIBYTE(m_wsaData.wVersion) !=2 )
		return false;
	m_hThread = ::CreateThread(NULL, 0, UThreadProc, 0, 0, &m_dwThreadID);
	return true;
}

void CWSAStartup::StopSSPI()
{
	CSspiClient::CloseStoreAndUnloadSecurityLibrary();
}

bool CWSAStartup::StartSSPI()
{
	if(CSspiClient::IsLoaded())
		return true;
	return CSspiClient::LoadSecurityLibraryAndOpenStore();
}

void CWSAStartup::Cleanup()
{
	if(m_hThread)
	{
		m_bQuit = true;
		::WaitForSingleObject(m_hThread, 5000);
		::CloseHandle(m_hThread);
		m_hThread = NULL;
	}
	StopSSPI();
	KillTimer();
	m_mapUSocket.RemoveAll();
	int err = WSACleanup();
}

void CWSAStartup::UnloadOpenSSL()
{
	if(m_hSSLEay)
	{
		::FreeLibrary(m_hSSLEay);
		m_hSSLEay=NULL;
	}
	if(m_hLibeay)
	{
		::FreeLibrary(m_hLibeay);
		m_hLibeay=NULL;
	}
	SSL_library_init = NULL;
	SSLv23_method = NULL;
	SSL_load_error_strings = NULL;
	SSL_CTX_new = NULL;
	SSL_CTX_free = NULL;
	SSL_new = NULL;
	SSL_free = NULL;
	SSL_set_fd = NULL;
	SSL_accept = NULL;
	SSL_get_error = NULL;
	SSL_write = NULL;
	SSL_read = NULL;
	SSL_shutdown = NULL;
	SSL_state = NULL;
	SSL_set_connect_state = NULL;
	SSL_set_accept_state = NULL;
	SSL_CTX_use_certificate_file = NULL;
	SSL_CTX_use_PrivateKey_file = NULL;
	SSL_CTX_check_private_key = NULL;
	SSL_get_peer_certificate = NULL;
	SSL_get_current_cipher = NULL;
	SSL_state_string_long = NULL;
	SSL_do_handshake = NULL;
	SSL_want = NULL;
	SSL_pending = NULL;
	SSL_connect = NULL;
	SSL_peek = NULL;
	TLSv1_method = NULL;
	ERR_clear_error = NULL;
	SSL_clear = NULL;
	CRYPTO_free = NULL;
	CRYPTO_malloc = NULL;
	CRYPTO_set_locking_callback = NULL;
	CRYPTO_num_locks = NULL;
	SSL_set_read_ahead = NULL;
	SSL_set_info_callback = NULL;
	SSL_get_fd = NULL;
	ERR_get_error = NULL;
	ERR_error_string = NULL;
	SSL_CTX_ctrl = NULL;

	//CERT
	BIO_free = NULL;
	BIO_ctrl = NULL;
	BIO_new = NULL;
	BIO_s_mem = NULL;
	BIO_free_all = NULL;

	SSL_get_version = NULL;
	SSL_CIPHER_get_version = NULL;
	SSL_CIPHER_get_name = NULL;
	SSL_CTX_load_verify_locations = NULL;
	SSL_get_verify_result = NULL;
	
	X509_get_pubkey = NULL;
	X509_get_issuer_name = NULL;
	X509_NAME_oneline = NULL;	
	X509_get_subject_name = NULL;
	X509_free = NULL;
	X509_cmp_current_time = NULL;
	X509_verify_cert_error_string = NULL;

	OBJ_nid2sn = NULL;
	OBJ_obj2nid = NULL;
	ASN1_TIME_print = NULL;
	EVP_PKEY_free = NULL;
	BN_num_bits = NULL;
	PEM_write_bio_X509 = NULL;
}

bool CWSAStartup::LoadOpenSSL(bool bUseSSL)
{
	m_hSSLEay=::LoadLibrary(L"ssleay32.dll");
	m_hLibeay=::LoadLibrary(L"libeay32.dll");
	if(!m_hSSLEay || !m_hLibeay)
	{
		UnloadOpenSSL();
		return false;
	}

	SSL_get_version =(PSSL_get_version)::GetProcAddress(m_hSSLEay, L"SSL_get_version");
	SSL_CIPHER_get_version =(PSSL_CIPHER_get_version)::GetProcAddress(m_hSSLEay, L"SSL_CIPHER_get_version");
	SSL_CIPHER_get_name =(PSSL_CIPHER_get_name)::GetProcAddress(m_hSSLEay, L"SSL_CIPHER_get_name");
	SSL_CTX_load_verify_locations = (PSSL_CTX_load_verify_locations)::GetProcAddress(m_hSSLEay, L"SSL_CTX_load_verify_locations");
	SSL_get_verify_result = (PSSL_get_verify_result)::GetProcAddress(m_hSSLEay, L"SSL_get_verify_result");

	BIO_free = (PBIO_free)::GetProcAddress(m_hLibeay, L"BIO_free");
	BIO_ctrl = (PBIO_ctrl)::GetProcAddress(m_hLibeay, L"BIO_ctrl");
	BIO_new = (PBIO_new)::GetProcAddress(m_hLibeay, L"BIO_new");
	BIO_s_mem = (PBIO_s_mem)::GetProcAddress(m_hLibeay, L"BIO_s_mem");
	BIO_free_all = (PBIO_free_all)::GetProcAddress(m_hLibeay, L"BIO_free_all");
	
	X509_get_pubkey = (PX509_get_pubkey)::GetProcAddress(m_hLibeay, L"X509_get_pubkey");
	X509_get_issuer_name = (PX509_get_issuer_name)::GetProcAddress(m_hLibeay, L"X509_get_issuer_name");
	X509_NAME_oneline = (PX509_NAME_oneline)::GetProcAddress(m_hLibeay, L"X509_NAME_oneline");
	X509_get_subject_name = (PX509_get_subject_name)::GetProcAddress(m_hLibeay, L"X509_get_subject_name");
	X509_free = (PX509_free)::GetProcAddress(m_hLibeay, L"X509_free");
	X509_cmp_current_time = (PX509_cmp_current_time)::GetProcAddress(m_hLibeay, L"X509_cmp_current_time");
	X509_verify_cert_error_string =(PX509_verify_cert_error_string)::GetProcAddress(m_hLibeay, L"X509_verify_cert_error_string");

	OBJ_nid2sn = (POBJ_nid2sn)::GetProcAddress(m_hLibeay, L"OBJ_nid2sn");
	OBJ_obj2nid = (POBJ_obj2nid)::GetProcAddress(m_hLibeay, L"OBJ_obj2nid");
	ASN1_TIME_print = (PASN1_TIME_print)::GetProcAddress(m_hLibeay, L"ASN1_TIME_print");
	EVP_PKEY_free = (PEVP_PKEY_free)::GetProcAddress(m_hLibeay, L"EVP_PKEY_free");
	BN_num_bits = (PBN_num_bits)::GetProcAddress(m_hLibeay, L"BN_num_bits");
	PEM_write_bio_X509 = (PPEM_write_bio_X509)::GetProcAddress(m_hLibeay, L"PEM_write_bio_X509");

	if(SSL_get_version == NULL || SSL_CIPHER_get_version == NULL || SSL_CIPHER_get_name == NULL || SSL_CTX_load_verify_locations == NULL ||
		BIO_free == NULL || BIO_ctrl == NULL || BIO_new == NULL || BIO_s_mem == NULL || BIO_free_all == NULL ||
		X509_get_pubkey == NULL || X509_get_issuer_name == NULL || X509_NAME_oneline == NULL || X509_get_subject_name == NULL ||
		X509_free == NULL || X509_cmp_current_time == NULL || OBJ_nid2sn == NULL || OBJ_obj2nid == NULL || X509_verify_cert_error_string == NULL ||
		ASN1_TIME_print == NULL || EVP_PKEY_free == NULL || BN_num_bits == NULL || PEM_write_bio_X509 == NULL || SSL_get_verify_result == NULL)
	{
		UnloadOpenSSL();
		return false;
	}

	ERR_error_string = (PERR_error_string)::GetProcAddress(m_hLibeay, L"ERR_error_string");
	ERR_get_error = (PERR_get_error)::GetProcAddress(m_hLibeay, L"ERR_get_error");
	ERR_clear_error = (PERR_clear_error)::GetProcAddress(m_hLibeay, L"ERR_clear_error");
	TLSv1_method = (PTLSv1_method)::GetProcAddress(m_hSSLEay, L"TLSv1_method");
	SSL_set_info_callback = (PSSL_set_info_callback)::GetProcAddress(m_hSSLEay, L"SSL_set_info_callback");
	SSL_get_fd =(PSSL_get_fd)::GetProcAddress(m_hSSLEay, L"SSL_get_fd");
	SSL_clear =(PSSL_clear)::GetProcAddress(m_hSSLEay, L"SSL_clear");
	SSL_peek = (PSSL_peek)::GetProcAddress(m_hSSLEay, L"SSL_peek");
	SSL_connect = (PSSL_connect)::GetProcAddress(m_hSSLEay, L"SSL_connect");
	SSL_pending	= (PSSL_pending)::GetProcAddress(m_hSSLEay, L"SSL_pending");
	SSL_accept = (PSSL_accept)::GetProcAddress(m_hSSLEay, L"SSL_accept");
	SSL_want = (PSSL_want)::GetProcAddress(m_hSSLEay, L"SSL_want");
	SSL_CTX_check_private_key = (PSSL_CTX_check_private_key)::GetProcAddress(m_hSSLEay, L"SSL_CTX_check_private_key");
	SSL_CTX_free = (PSSL_CTX_free)::GetProcAddress(m_hSSLEay, L"SSL_CTX_free");
	SSL_CTX_new = (PSSL_CTX_new)::GetProcAddress(m_hSSLEay, L"SSL_CTX_new");
	SSL_CTX_use_certificate_file = (PSSL_CTX_use_certificate_file)::GetProcAddress(m_hSSLEay, L"SSL_CTX_use_certificate_file");
	SSL_CTX_use_PrivateKey_file = (PSSL_CTX_use_PrivateKey_file)::GetProcAddress(m_hSSLEay, L"SSL_CTX_use_PrivateKey_file");
	SSL_CTX_ctrl = (PSSL_CTX_ctrl)::GetProcAddress(m_hSSLEay, L"SSL_CTX_ctrl");
	SSL_free = (PSSL_free)::GetProcAddress(m_hSSLEay, L"SSL_free");
	SSL_do_handshake = (PSSL_do_handshake)::GetProcAddress(m_hSSLEay, L"SSL_do_handshake");
	SSL_get_current_cipher = (PSSL_get_current_cipher)::GetProcAddress(m_hSSLEay, L"SSL_get_current_cipher");
	SSL_get_error = (PSSL_get_error)::GetProcAddress(m_hSSLEay, L"SSL_get_error");
	SSL_get_peer_certificate = (PSSL_get_peer_certificate)::GetProcAddress(m_hSSLEay, L"SSL_get_peer_certificate");
	SSL_library_init = (PSSL_library_init)::GetProcAddress(m_hSSLEay, L"SSL_library_init");
	SSL_load_error_strings = (PSSL_load_error_strings)::GetProcAddress(m_hSSLEay, L"SSL_load_error_strings");
	SSL_new = (PSSL_new)::GetProcAddress(m_hSSLEay, L"SSL_new");
	SSL_read = (PSSL_read)::GetProcAddress(m_hSSLEay, L"SSL_read");
	SSL_set_accept_state = (PSSL_set_accept_state)::GetProcAddress(m_hSSLEay, L"SSL_set_accept_state");
	SSL_set_connect_state = (PSSL_set_connect_state)::GetProcAddress(m_hSSLEay, L"SSL_set_connect_state");
	SSL_set_fd	 = (PSSL_set_fd	)::GetProcAddress(m_hSSLEay, L"SSL_set_fd");
	SSL_shutdown = (PSSL_shutdown)::GetProcAddress(m_hSSLEay, L"SSL_shutdown");
	SSL_state = (PSSL_state)::GetProcAddress(m_hSSLEay, L"SSL_state");
	SSL_state_string_long = (PSSL_state_string_long)::GetProcAddress(m_hSSLEay, L"SSL_state_string_long");
	SSL_write = (PSSL_write)::GetProcAddress(m_hSSLEay, L"SSL_write");
	SSLv23_method = (PSSLv23_method)::GetProcAddress(m_hSSLEay, L"SSLv23_method");
	SSL_set_read_ahead = (PSSL_set_read_ahead)::GetProcAddress(m_hSSLEay, L"SSL_set_read_ahead");
	CRYPTO_free = (PCRYPTO_free)::GetProcAddress(m_hLibeay, L"CRYPTO_free");
	CRYPTO_malloc = (PCRYPTO_malloc)::GetProcAddress(m_hLibeay, L"CRYPTO_malloc");
	CRYPTO_set_locking_callback = (PCRYPTO_set_locking_callback)::GetProcAddress(m_hLibeay, L"CRYPTO_set_locking_callback");
	CRYPTO_num_locks = (PCRYPTO_num_locks)::GetProcAddress(m_hLibeay, L"CRYPTO_num_locks");

	if( SSL_library_init && SSL_load_error_strings && SSL_CTX_new && ERR_clear_error && CRYPTO_num_locks && ERR_error_string
		&& SSL_CTX_free && SSL_new && SSL_free && SSL_set_fd && SSL_accept && SSL_get_error && CRYPTO_set_locking_callback
		&& SSL_write && SSL_read && SSL_shutdown && SSL_state && SSL_set_connect_state && CRYPTO_malloc && SSL_CTX_ctrl
		&& SSL_set_accept_state && SSL_CTX_use_certificate_file && SSL_CTX_use_PrivateKey_file && ERR_get_error
		&& SSL_CTX_check_private_key && SSL_get_peer_certificate && SSL_get_current_cipher && SSL_set_info_callback
		&& SSL_set_read_ahead
		&& CRYPTO_free && SSL_get_fd
		&& SSL_state_string_long && SSL_do_handshake && SSL_want 
		&& SSL_pending && SSL_connect && SSL_peek)
	{
		if(bUseSSL && SSLv23_method)
			return true;
		if(!bUseSSL && TLSv1_method)
			return true;
	}
	UnloadOpenSSL();
	return false;
}

bool CWSAStartup::StartOpenSSL()
{
	int i;
	if(!SSL_library_init())
		return false;
	if(SSLv23_method)
		m_pMeth = SSLv23_method();
	else
		m_pMeth = TLSv1_method();
	if(!m_pMeth)
	{
		StopOpenSSL();
		return false;
	}
	SSL_load_error_strings();
	m_pCtx = SSL_CTX_new(m_pMeth);
	if(!m_pCtx)
	{
		StopOpenSSL();
		return false;
	}
	SSL_CTX_ctrl(m_pCtx, SSL_CTRL_MODE, SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER, NULL);
	m_pSSLLockHandle = (HANDLE*)CRYPTO_malloc(CRYPTO_num_locks()*sizeof(HANDLE), __FILE__,__LINE__);
	ATLASSERT(m_pSSLLockHandle);
	for(i=0; i<CRYPTO_num_locks(); i++)
	{
		m_pSSLLockHandle[i] = ::CreateMutex(NULL, FALSE, NULL);
		ATLASSERT(m_pSSLLockHandle[i]);
	}

	CRYPTO_set_locking_callback(LockingCallback);
	return true;
}

void CWSAStartup::StopOpenSSL()
{
	if(CRYPTO_set_locking_callback)
		CRYPTO_set_locking_callback(NULL);
	if(m_pSSLLockHandle)
	{
		int i;
		for(i=0; i<CRYPTO_num_locks(); i++)
		{
			::CloseHandle(m_pSSLLockHandle[i]);
		}
		CRYPTO_free(m_pSSLLockHandle); //OPENSSL_free
		m_pSSLLockHandle = NULL;
	}
	if(m_pCtx)
	{
		SSL_CTX_free(m_pCtx);
		m_pCtx=NULL;
	}
	if(m_pMeth)
		m_pMeth=NULL;
}

void CWSAStartup::LockingCallback(int nMode, int nType, const char *strFile, int nLine)
{
	ATLASSERT(nType<g_pWSAStartup->CRYPTO_num_locks());
	if(nMode & CRYPTO_LOCK)
	{
		::WaitForSingleObject(g_pWSAStartup->m_pSSLLockHandle[nType], INFINITE);
	}
	else
	{
		::ReleaseMutex(g_pWSAStartup->m_pSSLLockHandle[nType]);
	}
}

void CWSAStartup::SetTimer()
{
	KillTimer();
	CAutoLock AutoLock(&m_cs.m_sec);
	m_nTimer = ::SetTimer(NULL, 0x10101010, 350*(1+g_pWSAStartup->m_dwCountSockets/25), UTimerProc);
}

void CWSAStartup::KillTimer()
{
	if(m_nTimer)
	{
		::KillTimer(NULL, m_nTimer);
		m_nTimer = 0;
	}
}

HANDLE CWSAStartup::GetEvent()
{
	int n;
	int nCount = MAXIMUM_WAIT_OBJECTS;
	ULONG ul = 0;
	HANDLE hEvent = NULL;
	CAutoLock AutoLock(&m_cs.m_sec);
	ULONG ulCount = m_mapUSocket.GetSize();
	for(n=0; n<nCount; n++)
	{
		hEvent = m_pEvents[n];
		for(ul=0; ul<ulCount; ul++)
		{
			CUSocket	*pUSocket = m_mapUSocket.GetValueAt(ul);
			if(pUSocket != NULL && pUSocket->m_hSocketEvent == hEvent)
			{
				hEvent = NULL;
				break;
			}
		}
		if(ulCount == 0 || ul == ulCount)
			break;
	}
	return hEvent;
}

void CWSAStartup::PostSocketMessage(HANDLE hEvent)
{
	ULONG ul;
	CAutoLock AutoLock(&m_cs.m_sec);
	ULONG ulCount = m_mapUSocket.GetSize();
	for(ul=0; ul<ulCount; ul++)
	{
		CUSocket *pUSocket = m_mapUSocket.GetValueAt(ul);
		if(pUSocket != NULL && pUSocket->m_hSocketEvent == hEvent)
		{
			long lParam;
			WORD wRead;
			WORD wWrite;
			WORD wClose;
			WORD wConnect;
			
			WSANETWORKEVENTS	WsaEvents;
			memset(&WsaEvents, 0, sizeof(WsaEvents));
			int nError = ::WSAEnumNetworkEvents(pUSocket->m_SBAttr.m_hSocket, hEvent, &WsaEvents);
//			ATLASSERT(nError == 0);
			wRead = (WsaEvents.lNetworkEvents & FD_READ); //1
			wWrite = (WsaEvents.lNetworkEvents & FD_WRITE);
			wClose = (WsaEvents.lNetworkEvents & FD_CLOSE);
			wConnect = (WsaEvents.lNetworkEvents & FD_CONNECT);
			if(wRead > 0)
			{
/*				if(pUSocket->m_SBAttr.m_EncryptionMethod == MSTLSv1 || pUSocket->m_SBAttr.m_EncryptionMethod == MSSSL)
				{
					if(pUSocket->m_Sspi.GetSSLState() != ssFinished)
					{
						SECURITY_STATUS sc = pUSocket->m_Sspi.ClientHandshakeLoop(pUSocket->m_SBAttr.m_hSocket);
						if(sc != SEC_E_OK)
						{
							return;
						}
						else if(pUSocket->m_Sspi.GetSSLState() == ssFinished)
						{
						}
						else
						{
							return;
						}
					}
				}*/
				::ResetEvent(hEvent);
				m_cs.Unlock();
				pUSocket->m_bIO = true;
				lParam = MAKELONG(FD_READ, WsaEvents.iErrorCode[FD_READ_BIT]);
				while(!::PostMessage(pUSocket->m_MyWindow.m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, lParam))
				{
					::Sleep(1);
				}
				DWORD dw = ::WaitForSingleObject(hEvent, 1000); 
				while(dw == WAIT_TIMEOUT)
				{
					while(!::PostMessage(pUSocket->m_MyWindow.m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, lParam))
					{
						::Sleep(1);
					}
					dw = ::WaitForSingleObject(hEvent, 1000); 
				}
				m_cs.Lock();
				//::Sleep(1);  
				//pUSocket->m_bIO = false;
			} 
			if(wWrite > 0)
			{
				lParam = MAKELONG(FD_WRITE, WsaEvents.iErrorCode[FD_WRITE_BIT]);
				while(!::PostMessage(pUSocket->m_MyWindow.m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, lParam))
				{
					::Sleep(1);
				}
			}
			if(wConnect > 0)
			{
				lParam = MAKELONG(FD_CONNECT, WsaEvents.iErrorCode[FD_CONNECT_BIT]);
				while(!::PostMessage(pUSocket->m_MyWindow.m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, lParam))
				{
					::Sleep(1);
				}
			}
			if(wClose > 0)
			{
				lParam = MAKELONG(FD_CLOSE, WsaEvents.iErrorCode[FD_CLOSE_BIT]);
				while(!::PostMessage(pUSocket->m_MyWindow.m_hWnd, msgSocketEvent, pUSocket->m_SBAttr.m_hSocket, lParam))
				{
					::Sleep(1);
				}
			}
			
		}
	}
}

DWORD WINAPI CWSAStartup::UThreadProc(LPVOID lpParameter)
{
	DWORD dwCount = 0;
	do
	{
		dwCount = ::WSAWaitForMultipleEvents(MAXIMUM_WAIT_OBJECTS, g_pWSAStartup->m_pEvents, FALSE, 200, FALSE);
		switch(dwCount)
		{
		case WSA_WAIT_TIMEOUT:
			break;
		case WSA_WAIT_FAILED:
			ATLASSERT(FALSE);
			break;
//		case WAIT_IO_COMPLETION:
//			ATLASSERT(FALSE);
//			break;
		default:
			if(dwCount >= WSA_WAIT_EVENT_0 && dwCount< (WSA_WAIT_EVENT_0 + MAXIMUM_WAIT_OBJECTS))
			{
				int nIndex = dwCount - WSA_WAIT_EVENT_0;
				g_pWSAStartup->PostSocketMessage(g_pWSAStartup->m_pEvents[nIndex]);
				::WSAResetEvent(g_pWSAStartup->m_pEvents[nIndex]);
			}
			else
			{
				ATLASSERT(FALSE);
			}
			break;
		}

	}while(!g_pWSAStartup->m_bQuit);

	return 0;
}
