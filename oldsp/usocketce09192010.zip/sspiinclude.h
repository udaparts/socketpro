#ifndef __SECURE_SOCKET_CHANNEL_INCLUDE_H__
#define __SECURE_SOCKET_CHANNEL_INCLUDE_H__

#include "uqueue.h"
using namespace SocketProAdapter;

#include <schnlsp.h>
#include <schannel.h>
//#define SECURITY_WIN32
#include <sspi.h>

#define IO_BUFFER_SIZE		(0x800)
#define DLL_NAME		L"Secur32.dll"

enum tagSSLState
{
	ssUnknown = 0,
	ssClientHello,
	ssHandshaking,
	ssFinished,
};

#endif