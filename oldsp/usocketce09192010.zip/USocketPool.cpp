// USocketPool.cpp : Implementation of CUSocketPool
#include "stdafx.h"
#include "USocket.h"
#include "USocketPool.h"
#include "socketpoolevent.h"
//#include <Winsock2.h>

#define NO_IDLE_SOCKET_FOUND	(0xFFFFFFFF)
#define NOT_BELONG_THIS_POOL	(0xFFFFFFFE)
#define NO_CONNECTED_SOCKET		(0xFFFFFFFD)

#include "WSAStartup.h"

extern CWSAStartup	*g_pWSAStartup;

/////////////////////////////////////////////////////////////////////////////
// CUSocketPool
HRESULT CUSocketPool::FinalConstruct()
{
	HRESULT hr = ::CoInitializeEx(NULL, COINIT_MULTITHREADED);
	if(hr == S_FALSE)
	{
		hr = S_OK;
	}
	else if(hr == RPC_E_CHANGED_MODE)
	{
//		hr = specWrongApartment;
		hr = S_OK;
	}
	else
	{
		ATLASSERT(FALSE);
		hr = specUnexpected;
	}
	return hr;
}

void CUSocketPool::FinalRelease()
{
	CleanAll();
}

STDMETHODIMP CUSocketPool::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IUSocketPool,
		&IID_IDispatch
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (IsEqualGUID(*arr[i], riid))
			return S_OK;
	}
	return S_FALSE;
}

DWORD WINAPI CUSocketPool::ThreadFunction(LPVOID lpParameter)
{
	UINT nTimer;
	long bIndex;
	CSContext	SContext;
	MSG	msg;
	HANDLE	pSEvent[MAXIMUM_WAIT_OBJECTS] = {NULL};
	DWORD	dwCount;
	DWORD	dwRtn = 0;
	::PeekMessage(&msg, NULL, 0, 0, 0);
	{
		CAutoLock AutoLock(&g_pWSAStartup->m_cs.m_sec);
		nTimer = ::SetTimer(NULL, 0x10101010, 5000*(1 + g_pWSAStartup->m_mapUSocket.GetSize()/25), UTimerProc);
	}
	CSimpleMap<HANDLE, IUSocketInternal*> mapUSI;
	HRESULT hr = S_OK;
	CUSocketPool *pSPool = (CUSocketPool*)lpParameter;
	ULONG bPos = pSPool->m_ulIndex;
	BYTE bSocketsPerThread = pSPool->m_bSocketsPerThread;
	BYTE bThreads = (BYTE)(pSPool->m_ulCount/bSocketsPerThread);

	SContext.m_dwThreadID = ::GetCurrentThreadId();
	::CoInitializeEx(NULL, COINIT_MULTITHREADED);
	pSPool->Fire_OnSocketPoolEvent(speThreadCreated, NULL);
	{
		CCSEvent	SEvent;
		CSimpleMap<HANDLE, IUSocket*> mapUSocket;
		CComPtr<IUSocket> pIUSocket;
		dwCount = bSocketsPerThread;
		for(bIndex=0; bIndex<bSocketsPerThread; bIndex++)
		{
			hr = pIUSocket.CoCreateInstance(__uuidof(USocket));
			ATLASSERT(hr == S_OK);
			SContext.m_hEvent = ::CreateEvent(NULL, FALSE, TRUE, NULL);
			mapUSocket.Add(SContext.m_hEvent, pIUSocket.p);
			IUSocketInternal *pUI = NULL;
			pIUSocket.p->AddRef();
			
			pSPool->m_mapSocket.GetKeyAt(bIndex + bPos*bSocketsPerThread) = pIUSocket.p;
		
			pSPool->m_mapSocket.GetValueAt(bIndex + bPos*bSocketsPerThread) = SContext;
			pSPool->Fire_OnSocketPoolEvent(speUSocketCreated, pIUSocket);
			hr = pIUSocket->QueryInterface(__uuidof(IUSocketInternal), (void**)&pUI);
			ATLASSERT(hr == S_OK);
			pSEvent[bIndex] = ::CreateEvent(NULL, FALSE, FALSE, NULL);
			mapUSI.Add(pSEvent[bIndex], pUI);
			hr = pUI->SetEvent((long)(pSEvent[bIndex]));
			pIUSocket.p = NULL;
		}
		::SetEvent(pSPool->m_hEvent);
		do
		{
			dwRtn = ::MsgWaitForMultipleObjects(dwCount, pSEvent, FALSE, 5000, QS_ALLEVENTS);
			if(dwRtn >= WAIT_OBJECT_0 && dwRtn < (WAIT_OBJECT_0 + dwCount))
			{
				long hSocket;
				WSANETWORKEVENTS NetworkEvents;
				memset(&NetworkEvents, 0, sizeof(NetworkEvents));
				IUSocket *pIUSocket = mapUSocket.GetValueAt(dwRtn - WAIT_OBJECT_0);
				hr = pIUSocket->get_Socket(&hSocket);
				HANDLE hEvent = pSEvent[dwRtn - WAIT_OBJECT_0];
				IUSocketInternal *pUI = mapUSI.Lookup(hEvent);
				int nRtn = ::WSAEnumNetworkEvents((SOCKET)hSocket, hEvent, &NetworkEvents);
				switch(NetworkEvents.lNetworkEvents)
				{
				case FD_READ:
					hr = pUI->OnSRead(NetworkEvents.iErrorCode[FD_READ_BIT]);
					if(pUI->IsWaiting())
						hr = pUI->Notify(FD_READ);
					break;
				case FD_WRITE:
					hr = pUI->OnSWrite(NetworkEvents.iErrorCode[FD_WRITE_BIT]);	
					if(pUI->IsWaiting())
						hr = pUI->Notify(FD_WRITE);
					break;
				case FD_CLOSE:
					hr = pUI->OnSClosed(NetworkEvents.iErrorCode[FD_CLOSE_BIT]);
					if(pUI->IsWaiting())
						hr = pUI->Notify(FD_CLOSE);
					break;
				default:
					break;
				}
			}
			else if(dwRtn == (dwCount + WAIT_OBJECT_0))
			{
				while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
				{
					if(msg.message == WM_QUIT || msg.message == 0)
						break;
					switch(msg.message)
					{
					case WM_CONNECT_SERVER:
						{
							HANDLE hEvent = (HANDLE)msg.wParam;
							ATLASSERT(hEvent != NULL);
							CHostInfo	*pHostInfo = (CHostInfo*)msg.lParam;
							IUSocket *pIUSocket = mapUSocket.Lookup(hEvent);
							ATLASSERT(pIUSocket);
							if(SEvent.m_dwEventCookie != 0xFEFEFEFE)
							{
								ATLASSERT(SEvent.m_pIUSocket != NULL);
								SEvent.DispEventUnadvise(SEvent.m_pIUSocket);
							}
							else
							{
								ATLASSERT(SEvent.m_pIUSocket == NULL);
							}
							SEvent.m_pIUSocket = pIUSocket;
							SEvent.m_bZip = pHostInfo->m_bZip;
							SEvent.m_hEvent = hEvent;
							SEvent.m_lSvsID = pHostInfo->m_lSvsID;
							hr = SEvent.DispEventAdvise(pIUSocket);
							ATLASSERT(hr == S_OK);
							SEvent.m_pSocketPool = pSPool;
							pSPool->Fire_OnSocketPoolEvent(speConnecting, pIUSocket);
							SEvent.m_bstrPassword = pHostInfo->m_bstrPassword;
							hr = pIUSocket->put_UseBaseSocketOnly((SEvent.m_lSvsID == 0) ? VARIANT_TRUE : VARIANT_FALSE);
							hr = pIUSocket->Connect(pHostInfo->m_bstrHost, pHostInfo->m_nPort, VARIANT_FALSE);
							if(hr != S_OK)
							{
								::SetEvent(hEvent);
							}
							ATLASSERT(hr == S_OK);
						}
						continue;
						break;
					default:
						break;
					}
					::TranslateMessage(&msg);
					::DispatchMessage(&msg);
				}
				if(msg.message == WM_QUIT)
					break;
			}
			else if(dwRtn == WAIT_TIMEOUT)
			{
				UTimerProc(NULL, 0, 0, ::GetTickCount());
			}
			else if(dwRtn == 0xFFFFFFFF)
			{
				hr = ::GetLastError();
				break;
			}
			else
			{
				break;
			}
			
		}while(true);

		if(SEvent.m_dwEventCookie != 0xFEFEFEFE)
		{
			ATLASSERT(SEvent.m_pIUSocket != NULL);
			SEvent.DispEventUnadvise(SEvent.m_pIUSocket);
		}

		for(bIndex=0; bIndex<mapUSocket.GetSize(); bIndex++)
		{
			try
			{
				long hWnd;
				IUSocket *pIUSocket = mapUSocket.GetValueAt(bIndex);
				pIUSocket->get_hWnd(&hWnd);
				::DestroyWindow((HWND)hWnd);
				ULONG ul = pIUSocket->Release();
			}
			catch(...)
			{
				
			}
		}

		for(bIndex=0; bIndex<mapUSI.GetSize(); bIndex++)
		{
			try
			{
				IUSocketInternal *pIUSocket = mapUSI.GetValueAt(bIndex);
				HANDLE hKey = mapUSI.GetKeyAt(bIndex);
				::CloseHandle(hKey);
				pIUSocket->SetEvent(NULL);
				ULONG ul = pIUSocket->Release();
//				ATLASSERT(ul == 0);
			}
			catch(...)
			{
				int n;
				n = 0;
			}
		}
		
	}

	pSPool->Fire_OnSocketPoolEvent(speKillingThread, NULL);
	::CoUninitialize();
	::KillTimer(NULL, nTimer);
	return hr;
}

STDMETHODIMP CUSocketPool::AddOneThreadIntoPool()
{
	int n;
	int nIndex;
	DWORD	dwThreadId;
	CSContext	SContext;
	CAutoLock AutoLock(&m_cs.m_sec);
	if(m_bSocketsPerThread == 0 || m_ulCount == 0 || m_mapThread.GetSize() == 0 || m_mapSocket.GetSize() == 0)
	{
		Error(L"Socket pool is not started yet. Must call the method StartPool successfully first", __uuidof(IUSocketPool));
		return specPoolNotCreatedYet;
	}
	
	for(n=0; n<(int)m_bSocketsPerThread; n++)
	{
		nIndex = m_ulCount++;
		SContext.m_dwThreadID = nIndex;
		m_mapSocket.Add((IUSocket*)nIndex, SContext);
	}
	
	m_ulIndex = m_mapThread.GetSize();
	Fire_OnSocketPoolEvent(speCreatingThread, NULL);
	HANDLE hThread = ::CreateThread(NULL, 0, ThreadFunction, this, 0, &dwThreadId);
	m_mapThread.Add(hThread, dwThreadId);
	m_mapThreadLocks.Add(dwThreadId, 0);
	::WaitForSingleObject(m_hEvent, INFINITE);
	::ResetEvent(m_hEvent);
	
	return S_OK;
}

STDMETHODIMP CUSocketPool::StartPool(BYTE bThreadCount, BYTE bSocketsPerThread)
{
	unsigned long lIndex;
	HANDLE hThread =NULL;
	DWORD	dwThreadId = 0;

	if(bSocketsPerThread >= MAXIMUM_WAIT_OBJECTS)
	{
		bSocketsPerThread = MAXIMUM_WAIT_OBJECTS - 1;
	}

	{
		CAutoLock AutoLock(&m_cs.m_sec);
		if(m_mapThread.GetSize() > 0 || m_mapSocket.GetSize() > 0)
		{
			Error(L"Socket pool is already started. To re-start a socket pool, please shutdown the pool first.", __uuidof(IUSocketPool));
			return specUnexpected;
		}
		
	}

	if(bThreadCount == 0)
	{
		SYSTEM_INFO SysInfo;
		::GetSystemInfo(&SysInfo);
		bThreadCount = (BYTE)SysInfo.dwNumberOfProcessors;
	}

	{

		CAutoLock AutoLock(&m_cs.m_sec);

		m_ulCount = bThreadCount;
		m_bSocketsPerThread = bSocketsPerThread; 
		m_ulCount *= m_bSocketsPerThread;

		CSContext	SContext;
		for(lIndex = 0; lIndex < m_ulCount; lIndex++)
		{
			SContext.m_dwThreadID = lIndex;
			m_mapSocket.Add((IUSocket*)lIndex, SContext);
		}

		for(lIndex=0; lIndex<bThreadCount; lIndex++)
		{
			m_ulIndex = lIndex;
			Fire_OnSocketPoolEvent(speCreatingThread, NULL);
			hThread = ::CreateThread(NULL, 0, ThreadFunction, this, 0, &dwThreadId);
			m_mapThread.Add(hThread, dwThreadId);
			m_mapThreadLocks.Add(dwThreadId, 0);
			::WaitForSingleObject(m_hEvent, INFINITE);
			::ResetEvent(m_hEvent);
		}
	}
	Fire_OnSocketPoolEvent(speStarted, NULL);
	return S_OK;
}

STDMETHODIMP CUSocketPool::LockASocket(long lTimeout, IUSocket *pIUSocketSameThreadWith, IUSocket **ppIUSocket)
{
	ULONG ulWait;
	DWORD dwRtn;
	DWORD dwStart;
	ULONG ulTimeout = (ULONG)lTimeout;
	if(ppIUSocket == NULL)
		return S_OK;
	m_cs.Lock();
	if(m_mapSocket.GetSize() == 0 || m_mapThread.GetSize() == 0)
	{
		m_cs.Unlock();
		Error(L"Socket pool has not been started yet.", __uuidof(IUSocketPool));
		return specPoolNotStarted;
	}
	if(pIUSocketSameThreadWith)
	{
		CComQIPtr<IUSocket> pIUSocket(pIUSocketSameThreadWith);
		if(pIUSocket == NULL)
		{
			m_cs.Unlock();
			Error(L"Input interface doesn't point to a valid USocket object.", __uuidof(IUSocketPool));
			return specNotUSocket;
		}
	}
	
GAI:	ulWait = GetAnIdleSocketHandle(pIUSocketSameThreadWith);
	switch(ulWait)
	{
	case NO_CONNECTED_SOCKET:
		m_cs.Unlock();
		Error(L"No more connected USocket object available.", __uuidof(IUSocketPool));
		return specNoOpenedSocket;
		break;
	case NOT_BELONG_THIS_POOL:
		m_cs.Unlock();
		Error(L"Input interface doesn't belong to this socket pool object.", __uuidof(IUSocketPool));
		return specNotPooledSocket;
		break;
	case NO_IDLE_SOCKET_FOUND:
		m_cs.Unlock();
		if(ulTimeout > 0)
		{
nh:			dwStart = ::GetTickCount();
			dwRtn = ::MsgWaitForMultipleObjects(1, &m_hLock, FALSE, ulTimeout, QS_ALLEVENTS);
			if(dwRtn >= WAIT_OBJECT_0 && dwRtn < (WAIT_OBJECT_0 + 1))
			{
				m_cs.Lock();
				ulWait = GetAnIdleSocketHandle(pIUSocketSameThreadWith);
				goto GAI;
			}
			else if(dwRtn == (WAIT_OBJECT_0 + 1))
			{
				MSG msg;
				while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
				{
					if(msg.message == WM_QUIT)
						break;
					::TranslateMessage(&msg);
					::DispatchMessage(&msg);
				}
				if(msg.message == WM_QUIT)
				{
					Error(L"Locking is interrupted.", __uuidof(IUSocketPool));
					return specLockingInterrupted;
				}
				DWORD dwNow = ::GetTickCount();
				if(dwNow > dwStart)
				{
					if((dwNow - dwStart) >= ulTimeout)
						ulTimeout = 0;
					else
					{
						ulTimeout -= (dwNow - dwStart);
					}
				}
				goto nh;
			}
			else if(dwRtn == WAIT_TIMEOUT)
			{
				Error(L"Locking is timed out.", __uuidof(IUSocketPool));
				return specLockTimeOut;
			}
			else if(dwRtn == 0xFFFFFFFF)
			{
				Error(L"An error happens inside the socket pool object.", __uuidof(IUSocketPool));
				return ::GetLastError();
			}
			else
			{
				Error(L"Locking is abandoned.", __uuidof(IUSocketPool));
				return specLockingAbandoned;	
			}
		}
		else
		{
			Error(L"Locking is timed out.", __uuidof(IUSocketPool));
			return specLockTimeOut;
		}
	default:
		ATLASSERT((int)ulWait < m_mapSocket.GetSize());
		*ppIUSocket = m_mapSocket.GetKeyAt(ulWait);
		ATLASSERT(!m_mapSocket.GetValueAt(ulWait).m_bLocked);
		m_mapSocket.GetValueAt(ulWait).m_bLocked = TRUE;
		dwRtn = m_mapSocket.GetValueAt(ulWait).m_dwThreadID;
		int nIndex = m_mapThreadLocks.FindKey(dwRtn);
		ATLASSERT(nIndex != -1);
		m_mapThreadLocks.GetValueAt(nIndex) += 1;
		ATLASSERT(m_mapThreadLocks.GetValueAt(nIndex) <= m_bSocketsPerThread);
		(*ppIUSocket)->AddRef();
		m_cs.Unlock();
		break;
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::UnlockASocket(IUSocket *pIUSocket)
{
	long nIndex;
	if(!pIUSocket)
	{
		Error(L"Input interface must point to a USocket object.", __uuidof(IUSocketPool));
		return specUnexpected;
	}

	CComQIPtr<IUSocket> pIUS(pIUSocket);
	if(pIUS == NULL)
	{
		Error(L"Input interface doesn't point to a valid USocket object.", __uuidof(IUSocketPool));
		return specNotUSocket;
	}
	m_cs.Lock();
	for(nIndex=0; nIndex<m_mapSocket.GetSize(); nIndex++)
	{
		if(pIUS.IsEqualObject(m_mapSocket.GetKeyAt(nIndex)))
		{
			CSContext &cs = m_mapSocket.GetValueAt(nIndex);
			if(cs.m_bLocked)
			{
				cs.m_bLocked = FALSE;
				::SetEvent(m_hLock);
				ATLASSERT(m_mapThreadLocks.Lookup(cs.m_dwThreadID) > 0);
				int nIndex = m_mapThreadLocks.FindKey(cs.m_dwThreadID);
				m_mapThreadLocks.GetValueAt(nIndex) -= 1;
				ATLASSERT(m_mapThreadLocks.GetValueAt(nIndex) <= m_bSocketsPerThread);
			}
			m_cs.Unlock();
			return S_OK;	
		}
	}
	m_cs.Unlock();
	Error(L"Input interface doesn't belong to this socket pool.", __uuidof(IUSocketPool));
	return specNotInPool;
}

STDMETHODIMP CUSocketPool::ConnectAll(BSTR bstrHost, long lPort, long lSvsID, BSTR bstrUID, BSTR bstrPWD, short EncryptionMethod, VARIANT_BOOL bEnableZip)
{
	int		n;
	int		nSize;
	HRESULT hr;
//	VARIANT_BOOL bTimeout = VARIANT_FALSE;
	if(/*lSvsID == 0 ||*/ lSvsID == sidStartup || lSvsID == sidReserved2 || lSvsID == sidReserved1)
	{
		Error(L"Input interface doesn't point to a valid USocket object.", __uuidof(IUSocketPool));
		return specNotValidService;
	}
	CHostInfo	HostInfo;
	HostInfo.m_bstrHost = bstrHost;
	HostInfo.m_nPort = lPort;
	HostInfo.m_lSvsID = lSvsID;
	HostInfo.m_bZip = bEnableZip ? true : false;
	HostInfo.m_bstrPassword = bstrPWD;
	{
		CAutoLock AutoLock(&m_cs.m_sec);
		if(m_mapSocket.GetSize() == 0 || m_mapThread.GetSize() == 0)
		{
			Error(L"Socket pool has not been started yet.", __uuidof(IUSocketPool));
			return specPoolNotStarted;
		}
	}
	{
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = NULL;
			pIUSocket = m_mapSocket.GetKeyAt(n);
			hr = pIUSocket->put_EncryptionMethod(EncryptionMethod);
			if(lSvsID != 0)
			{
				hr = pIUSocket->put_UserID(bstrUID);
				hr = pIUSocket->put_ZipIsOn(bEnableZip);
			}
			CSContext &SContext = m_mapSocket.GetValueAt(n);
			ATLASSERT(SContext.m_hEvent);
			::ResetEvent(SContext.m_hEvent);
//			ATLTRACE("Connecting .......\n");
			while(!::PostThreadMessage(SContext.m_dwThreadID, WM_CONNECT_SERVER, (UINT)SContext.m_hEvent, (long)&HostInfo))
			{
				::Sleep(1);
			}
			m_cs.Unlock();
			::WaitForSingleObject(SContext.m_hEvent, INFINITE);
			::SetEvent(SContext.m_hEvent);
			m_cs.Lock();
//			ATLTRACE("Connected .......\n");
		}
	}
	
	long lConnected = 0;
	get_ConnectedSocketsEx(&lConnected);
	if(lConnected == 0)
	{
		Error(L"No connected USocket object available.", __uuidof(IUSocketPool));
		return specNoOpenedSocket;
	}

	return S_OK;
}

STDMETHODIMP CUSocketPool::DisconnectAll()
{
	int n;
	int nSize;
	CAutoLock AutoLock(&m_cs.m_sec);
	nSize = m_mapSocket.GetSize();
	for(n=0; n<nSize; n++)
	{
		IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
		ATLASSERT(pIUSocket);
		try
		{
			long hSocket = 0;
			long hWnd = 0;
			pIUSocket->get_Socket(&hSocket);
			if(hSocket != 0 && hSocket != -1)
			{
				pIUSocket->get_hWnd(&hWnd);
				int nIndex = 0;
				while(!::PostMessage((HWND)hWnd, msgSocketEvent, hSocket, MAKELONG(FD_CLOSE, 0)))
				{
					nIndex++;
					if(nIndex > 5)
						break;
					::Sleep(1);
				}
				pIUSocket->get_Socket(&hSocket);
				nIndex = 0;
				while(!(hSocket == 0 || hSocket == -1))
				{
					nIndex++;
					if(nIndex > 5)
						break;
					Sleep(1);
//					ATLTRACE("**** Circle *****\n");
					pIUSocket->get_Socket(&hSocket);
				}
			}
//			pIUSocket->Disconnect();
		}
		catch(...)
		{
			CSContext &SC = m_mapSocket.GetValueAt(n);
			if(SC.m_hEvent != NULL)
			{
				::CloseHandle(SC.m_hEvent);
			}
			n--;
			nSize--;
			m_mapSocket.Remove(pIUSocket);
		}
	}
	if(m_mapSocket.GetSize() == 0)
	{
		CleanAll();
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::get_IdleSockets(BYTE *pVal)
{
	if(pVal)
	{
		int n;
		int nSize;
		HRESULT hr;
		long hSocket;
		*pVal = 0;
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
			ATLASSERT(pIUSocket);
			hr = pIUSocket->get_Socket(&hSocket);
			ATLASSERT(hr == S_OK);
			if(hSocket != 0 && hSocket != -1)
			{
				long lCount;
				hr = pIUSocket->get_CountOfRequestsInQueue(&lCount);
				ATLASSERT(hr == S_OK);
				if(lCount == 0)
				{
					*pVal += 1;
				}
			}	
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::get_DisconnectedSockets(BYTE *pVal)
{
	if(pVal)
	{
		int n;
		int nSize;
		HRESULT hr;
		long hSocket;
		*pVal = 0;
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
			ATLASSERT(pIUSocket);
			hr = pIUSocket->get_Socket(&hSocket);
			ATLASSERT(hr == S_OK);
			if(hSocket == 0 || hSocket == -1)
			{
				*pVal += 1;
			}	
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::get_ConnectedSockets(BYTE *pVal)
{
	if(pVal)
	{
		int n;
		int nSize;
		long hSocket;
		HRESULT hr;
		*pVal = 0;
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
			ATLASSERT(pIUSocket);
			hr = pIUSocket->get_Socket(&hSocket);
			ATLASSERT(hr == S_OK);
			if(hSocket != 0 && hSocket != -1)
			{
				*pVal += 1;
			}	
		}
	}
	return S_OK;
}

void CUSocketPool::CleanAll()
{
	int n;
	int nSize;
	{
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		if(nSize)
		{
			for(n=0; n<nSize; n++)
			{
				IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
				try
				{
					if(pIUSocket)
					{
						long hSocket = 0;
						long hWnd = 0;
						pIUSocket->get_Socket(&hSocket);
						if(hSocket != 0 && hSocket != -1)
						{
							pIUSocket->get_hWnd(&hWnd);
							int nIndex = 0;
							while(!::PostMessage((HWND)hWnd, msgSocketEvent, hSocket, MAKELONG(FD_CLOSE, 0)))
							{
								if(nIndex > 5)
									break;
								nIndex++;
								::Sleep(1);
							}
	/*						pIUSocket->get_Socket(&hSocket);
							nIndex = 0;
							while(!(hSocket == 0 || hSocket == -1) && nIndex < 10)
							{
								Sleep(1);
	//							ATLTRACE("**** Circle *****\n");
								pIUSocket->get_Socket(&hSocket);
								nIndex++;
							}*/
						}
						pIUSocket->Release();
					}
				}
				catch(...)
				{
	//				int n;
	//				n = 0;
				}

				CSContext &SContext = m_mapSocket.GetValueAt(n);
				if(SContext.m_hEvent != NULL)
				{
					::CloseHandle(SContext.m_hEvent);
				}
			}
			m_mapSocket.RemoveAll();
		}
	}

	CAutoLock AutoLock(&m_cs.m_sec);
	nSize = m_mapThread.GetSize();
	if(nSize)
	{
		for(n=0; n<nSize; n++)
		{
			int nIndex = 0;
			while(!::PostThreadMessage(m_mapThread.GetValueAt(n), WM_QUIT, 0, 0))
			{
				::Sleep(1);
				nIndex++;
				if(nIndex > 10)
				{
					ATLASSERT(FALSE);
					break;
				}
			}
			::WaitForSingleObject(m_mapThread.GetKeyAt(n), INFINITE);
			::CloseHandle(m_mapThread.GetKeyAt(n));
		}
		m_mapThread.RemoveAll();
	}
	m_ulCount = 0;
	m_bSocketsPerThread = 0;
	m_mapThreadLocks.RemoveAll();
}

STDMETHODIMP CUSocketPool::ShutdownPool()
{
	CleanAll();
	Fire_OnSocketPoolEvent(speShutdown, NULL);
	return S_OK;
}

IUSocket* CUSocketPool::GetSocket(HANDLE hEvent)
{
	long bIndex;
	IUSocket *pIUSocket = NULL;
	for(bIndex=0; bIndex<m_mapSocket.GetSize(); bIndex++)
	{
		if(m_mapSocket.GetValueAt(bIndex).m_hEvent == hEvent)
		{
			pIUSocket = m_mapSocket.GetKeyAt(bIndex);
			break;
		}
	}
	return pIUSocket;
}

ULONG CUSocketPool::GetAvailable(int nIndex)
{
	if(nIndex >= m_mapSocket.GetSize())
		return 0;
	ULONG nCount = 0;
	DWORD dwThreadID = m_mapThread.GetValueAt(nIndex);
	for(nIndex=0; nIndex<m_mapSocket.GetSize(); nIndex++)
	{
		CSContext &SC = m_mapSocket.GetValueAt(nIndex);
		if(SC.m_dwThreadID == dwThreadID && !SC.m_bLocked)
		{
			IUSocket *pUS = m_mapSocket.GetKeyAt(nIndex);
			ATLASSERT(pUS);
			long lSocket = 0;
			HRESULT hr = pUS->get_Socket(&lSocket);
			ATLASSERT(hr == S_OK);
			if(lSocket != 0 && lSocket != -1)
			{
				++nCount;
			}	
		}
	}
	return nCount;
}

/*
#define NO_IDLE_SOCKET_FOUND	(0xFFFFFFFF)
#define NOT_BELONG_THIS_POOL	(0xFFFFFFFE)
*/

ULONG CUSocketPool::GetAnIdleSocketHandle(IUSocket *pIUSocketSameThreadWith)
{
	int nIndex;
	if(pIUSocketSameThreadWith != NULL)
	{
		DWORD dwThreadID = 0;
		IUSocket *pFound = NULL;
		CComQIPtr<IUSocket>	pThis(pIUSocketSameThreadWith);
		ATLASSERT(pThis != NULL);
		for(nIndex=0; nIndex<m_mapSocket.GetSize(); nIndex++)
		{
			pFound = m_mapSocket.GetKeyAt(nIndex);
			if(pThis.IsEqualObject(pFound))
			{
				dwThreadID = m_mapSocket.GetValueAt(nIndex).m_dwThreadID;
				break;
			}
		}
		if(dwThreadID != 0)
		{
			for(nIndex=0; nIndex<m_mapSocket.GetSize(); nIndex++)
			{
				CSContext &SC = m_mapSocket.GetValueAt(nIndex);
				if(SC.m_dwThreadID == dwThreadID && !SC.m_bLocked)
				{
					IUSocket *pUS = m_mapSocket.GetKeyAt(nIndex);
					ATLASSERT(pUS);
					if(pFound != pUS)
					{
						long lSocket = 0;
						HRESULT hr = pUS->get_Socket(&lSocket);
						ATLASSERT(hr == S_OK);
						if(lSocket != 0 && lSocket != -1)
						{
							return (ULONG)nIndex;
						}
					}
				}
			}
			return NO_IDLE_SOCKET_FOUND;
		}
		else
		{
			return NOT_BELONG_THIS_POOL;
		}
	}
	else
	{
		int nBest = 0;
		int nAvailableBest = GetAvailable(nBest);
		for(nIndex=1; nIndex<m_mapThread.GetSize(); nIndex++)
		{
			int nAvailable = GetAvailable(nIndex);
			if(nAvailable > nAvailableBest)
			{
				nBest = nIndex;
				nAvailableBest = nAvailable;
			}
		}
		
		DWORD dwThreadID = m_mapThread.GetValueAt(nBest);
		for(nIndex=0; nIndex<m_mapSocket.GetSize(); nIndex++)
		{
			CSContext &SC = m_mapSocket.GetValueAt(nIndex);
			if(SC.m_dwThreadID == dwThreadID && !SC.m_bLocked)
			{
				IUSocket *pUS = m_mapSocket.GetKeyAt(nIndex);
				ATLASSERT(pUS);
				long lSocket = 0;
				HRESULT hr = pUS->get_Socket(&lSocket);
				ATLASSERT(hr == S_OK);
				if(lSocket != 0 && lSocket != -1)
				{
					return (ULONG)nIndex;
				}	
			}
		}
	}

	return NO_IDLE_SOCKET_FOUND;
}

STDMETHODIMP CUSocketPool::get_LockedSockets(BYTE *pVal)
{
	if(pVal)
	{
		long bIndex;
		*pVal = 0;
		HRESULT hr;
		long hSocket;
		CAutoLock AutoLock(&m_cs.m_sec);
		for(bIndex=0; bIndex<m_mapSocket.GetSize(); bIndex++)
		{
			hSocket = 0;
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(bIndex);
			hr = pIUSocket->get_Socket(&hSocket);
			CSContext &SC = m_mapSocket.GetValueAt(bIndex);
			*pVal += (SC.m_bLocked  && hSocket != 0 && hSocket != -1)? 1 : 0;
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::get_ThreadCounts(BYTE *pVal)
{
	if(pVal)
	{
		CAutoLock AutoLock(&m_cs.m_sec);
		*pVal = m_mapThread.GetSize();
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::FindAClosedSocket(IUSocket **ppIUSocket)
{
	if(ppIUSocket != NULL)
	{
		int n;
		if(*ppIUSocket != NULL)
		{
			try
			{
				(*ppIUSocket)->Release();
			}
			catch(...)
			{
			}
			*ppIUSocket = NULL;
		}
		CAutoLock AutoLock(&m_cs.m_sec);
		int nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
			ATLASSERT(pIUSocket);
			try
			{
				HRESULT hr;
				long hSocket;
				hr = pIUSocket->get_Socket(&hSocket);
				ATLASSERT(hr == S_OK);
				if(hSocket == 0 || hSocket == -1)
				{
					pIUSocket->AddRef();
					*ppIUSocket = pIUSocket;
					break;
				}	
			}
			catch(...)
			{
				break;
			}
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::Connect(IUSocket *pIUSocket, BSTR bstrHost, long lPort, long lInitialSvsID, BSTR bstrUID, BSTR bstrPWD, short EncryptionMethod, VARIANT_BOOL bEnableZip)
{
	int nIndex;
	HRESULT hr;
	long hSocket = 0;
	{
		m_cs.Lock();
		if(m_mapSocket.GetSize() == 0 || m_mapThread.GetSize() == 0)
		{
			m_cs.Unlock();
			Error(L"Socket pool has not been started yet.", __uuidof(IUSocketPool));
			return specPoolNotStarted;
		}
		m_cs.Unlock();
	}
	if(!pIUSocket)
	{
		Error(L"Input interface must point to a USocket object.", __uuidof(IUSocketPool));
		return specUnexpected;
	}

	CComQIPtr<IUSocket> pIUS(pIUSocket);
	if(pIUS == NULL)
	{
		Error(L"Input interface doesn't point to a valid USocket object.", __uuidof(IUSocketPool));
		return specNotUSocket;
	}

	if(/*lInitialSvsID == 0 ||*/ lInitialSvsID == sidStartup || lInitialSvsID == sidReserved2 || lInitialSvsID == sidReserved1)
	{
		Error(L"Input interface doesn't point to a valid USocket object.", __uuidof(IUSocketPool));
		return specNotValidService;
	}
	
	pIUS->get_Socket(&hSocket);
	if(hSocket != 0 && hSocket != -1)
	{
		Error(L"USocket is already opened.", __uuidof(IUSocketPool));
		return specSocketOpenedAlready;
	}
	m_cs.Lock();
	for(nIndex=0; nIndex<m_mapSocket.GetSize(); nIndex++)
	{
		if(pIUS.IsEqualObject(m_mapSocket.GetKeyAt(nIndex)))
		{
			CHostInfo	HostInfo;
			HostInfo.m_bstrHost = bstrHost;
			HostInfo.m_nPort = lPort;
			HostInfo.m_lSvsID = lInitialSvsID;
			HostInfo.m_bZip = bEnableZip ? true : false;
			HostInfo.m_bstrPassword = bstrPWD;
			hr = pIUSocket->put_EncryptionMethod(EncryptionMethod);
			if(lInitialSvsID != 0)
			{
				hr = pIUSocket->put_UserID(bstrUID);
				hr = pIUSocket->put_ZipIsOn(bEnableZip);
			}
			CSContext &SContext = m_mapSocket.GetValueAt(nIndex);
			ATLASSERT(SContext.m_hEvent);
			::ResetEvent(SContext.m_hEvent);
			while(!::PostThreadMessage(SContext.m_dwThreadID, WM_CONNECT_SERVER, (UINT)SContext.m_hEvent, (long)&HostInfo))
			{
				::Sleep(1);
			}
			m_cs.Unlock();
			::WaitForSingleObject(SContext.m_hEvent, INFINITE);
			::SetEvent(SContext.m_hEvent);
			if(lInitialSvsID == 0)
				hr = S_OK;
			else
				pIUSocket->get_Rtn(&hr);
			if(hr != S_OK)
			{
				CComBSTR bstr;
				pIUSocket->get_ErrorMsg(&bstr);
				Error(bstr.m_str, __uuidof(IUSocketPool));
			}
			return hr;
		}
	}
	m_cs.Unlock();
	Error(L"Input interface doesn't point to a pooled USocket object.", __uuidof(IUSocketPool));
	return specNotPooledSocket;
}

STDMETHODIMP CUSocketPool::get_ConnectedSocketsEx(long *pVal)
{
	if(pVal)
	{
		int n;
		int nSize;
		*pVal = 0;
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
			ATLASSERT(pIUSocket);
		
			long hSocket;
			HRESULT hr;
			hr = pIUSocket->get_Socket(&hSocket);
			ATLASSERT(hr == S_OK);
			if(hSocket != 0 && hSocket != -1)
			{
				*pVal += 1;
			}	
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::get_DisconnectedSocketsEx(long *pVal)
{
	if(pVal)
	{
		HRESULT hr;
		long hSocket;
		int n;
		int nSize;
		*pVal = 0;
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
			ATLASSERT(pIUSocket);
			hr = pIUSocket->get_Socket(&hSocket);
			ATLASSERT(hr == S_OK);
			if(hSocket == 0 || hSocket == -1)
			{
				*pVal += 1;
			}	
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::get_IdleSocketsEx(long *pVal)
{
	if(pVal)
	{
		int n;
		int nSize;
		HRESULT hr;
		long hSocket;
		*pVal = 0;
		CAutoLock AutoLock(&m_cs.m_sec);
		nSize = m_mapSocket.GetSize();
		for(n=0; n<nSize; n++)
		{
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(n);
			ATLASSERT(pIUSocket);
			hr = pIUSocket->get_Socket(&hSocket);
			ATLASSERT(hr == S_OK);
			if(hSocket != 0 && hSocket != -1)
			{
				long lCount;
				hr = pIUSocket->get_CountOfRequestsInQueue(&lCount);
				ATLASSERT(hr == S_OK);
				if(lCount == 0)
				{
					*pVal += 1;
				}
			}	
		}
	}
	return S_OK;
}

STDMETHODIMP CUSocketPool::get_LockedSocketsEx(long *pVal)
{
	if(pVal)
	{
		long bIndex;
		*pVal = 0;
		HRESULT hr;
		long hSocket;
		CAutoLock AutoLock(&m_cs.m_sec);
		for(bIndex=0; bIndex<m_mapSocket.GetSize(); bIndex++)
		{
			hSocket = 0;
			IUSocket *pIUSocket = m_mapSocket.GetKeyAt(bIndex);
			hr = pIUSocket->get_Socket(&hSocket);
			CSContext &SC = m_mapSocket.GetValueAt(bIndex);
			*pVal += (SC.m_bLocked  && hSocket != 0 && hSocket != -1)? 1 : 0;
		}
	}
	return S_OK;
}
