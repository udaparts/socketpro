// JSSerialization.h : Declaration of the CJSSerialization

#ifndef __JSSERIALIZATION_H_
#define __JSSERIALIZATION_H_

#include "resource.h"       // main symbols
#include <shlguid.h>
#include <mshtml.h>

extern const CLSID CLSID_JSSerialization;

/////////////////////////////////////////////////////////////////////////////
// CJSSerialization
class ATL_NO_VTABLE CJSSerialization : 
	public CComObjectRootEx<CComMultiThreadModel>,
//	public CComCoClass<CJSSerialization, &CLSID_JSSerialization>,
	public IDispatchImpl<IJSSerialization, &IID_IJSSerialization, &LIBID_USOCKETLib>
{
public:
	CJSSerialization()
	{
		m_hr = S_OK;
	}
	virtual ~CJSSerialization()
	{
		m_hr = S_OK;
	}
	HRESULT FinalConstruct();
	void FinalRelease();

//DECLARE_REGISTRY_RESOURCEID(IDR_JSSERIALIZATION)

//DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CJSSerialization)
	COM_INTERFACE_ENTRY(IJSSerialization)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IJSSerialization
public:
	STDMETHOD(get_errorMessage)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_errorCode)(/*[out, retval]*/ long *pVal);
	STDMETHOD(loadDate)(/*[out, retval]*/VARIANT *pvtDate);
	STDMETHOD(saveDate)(/*[in]*/VARIANT vtDate);
	STDMETHOD(loadInt64)(/*[out,retval]*/double *pdInt64);
	STDMETHOD(saveInt64)(/*[in]*/double dInt64);
	STDMETHOD(loadDecimal)(/*[out,retval]*/double *pdDecimal);
	STDMETHOD(saveDecimal)(/*[in]*/double dDecimal);
	STDMETHOD(get_size)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_size)(/*[in]*/ long newVal);
	STDMETHOD(loadGuid)(/*[out, retval]*/BSTR *pbstrGuid);
	STDMETHOD(loadString)(/*[out, retval]*/BSTR *pbstrData);
	STDMETHOD(loadDouble)(/*[out, retval]*/double *pdData);
	STDMETHOD(loadFloat)(/*[out, retval]*/float *pfData);
	STDMETHOD(loadInt32)(/*[out, retval]*/long *pnData);
	STDMETHOD(loadInt16)(/*[out, retval]*/short *psData);
	STDMETHOD(loadByte)(/*[out, retval]*/BYTE *pbData);
	STDMETHOD(loadBool)(/*[out, retval]*/VARIANT_BOOL *pbData);
	STDMETHOD(load)(/*[out, retval]*/VARIANT *pvtData);
	STDMETHOD(saveString)(/*[in]*/BSTR bstrData);
	STDMETHOD(saveDouble)(/*[in]*/double dData);
	STDMETHOD(saveFloat)(/*[in]*/float fData);
	STDMETHOD(saveInt32)(/*[in]*/long nData);
	STDMETHOD(saveInt16)(/*[in]*/short sData);
	STDMETHOD(saveByte)(/*[in]*/BYTE bData);
	STDMETHOD(saveBool)(/*[in]*/VARIANT_BOOL bData);
	STDMETHOD(save)(/*[in]*/VARIANT vtData);
	STDMETHOD(saveGuid)(/*[in]*/BSTR bstrGuid);

	CUQueue	m_UQueue;
	CComPtr<IHTMLDocument2>			m_spWebDoc;
	
private:
	HRESULT ConvertVariant(VARIANT &vtSrc, VARIANT &vtOut);
	bool LoadWeb(VARIANT &vtSrc, VARIANT &vtWeb);
	bool CreateInitJSObject(LPOLESTR strCmd, VARIANT &vtObject);
	bool push(IDispatch *pIScript, const VARIANT &vtObject);
	bool setTime(IDispatch *pIScript, const VARIANT &vtObject);
	
	HRESULT CopyArrayVariant(VARIANT &vtSrc, VARIANT &vtDestination);
	HRESULT EnsureAllVariants(VARIANT& vtSrc);
	HRESULT ChangeArrayOntoVariantArray(VARIANT &vtSrc, VARIANT &vtOut);
	
	bool SetArray(IDispatch *pIArray, VARIANT& vtArray);
	void SetMaps(IDispatch *pIDispatch);
	CSimpleMap<CComBSTR, FUNCDESC>	m_mapFunc;
	HRESULT m_hr;
};

#endif //__JSSERIALIZATION_H_
