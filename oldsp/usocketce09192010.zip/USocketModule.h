// USocketModule.h: interface for the CUSocketModule class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USOCKETMODULE_H__2AE5DC4A_DF63_47A7_B41B_4F4449608070__INCLUDED_)
#define AFX_USOCKETMODULE_H__2AE5DC4A_DF63_47A7_B41B_4F4449608070__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#endif // !defined(AFX_USOCKETMODULE_H__2AE5DC4A_DF63_47A7_B41B_4F4449608070__INCLUDED_)
