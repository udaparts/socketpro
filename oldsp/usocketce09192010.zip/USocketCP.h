#ifndef __4_USOCKETCP_H_
#define __4_USOCKETCP_H_

#include "USocketImp.h"

template <class T>
class CProxy_IUSocketEvent : public IConnectionPointImpl<T, &DIID__IUSocketEvent, CComDynamicUnkArray>
{
protected:
	ULONG RemoveLock()
	{
		ULONG ul = 0;
		HANDLE	hOwnerThread = ::GetCurrentThread();
		while(m_pCS->OwnerThread == hOwnerThread)
		{
			ul++;
			::LeaveCriticalSection(m_pCS);
		}
		
		return ul;
	}

	void Relock(ULONG ulCount)
	{
		while(ulCount > 0)
		{
			::EnterCriticalSection(m_pCS);
			ulCount--;
		}
	}

protected:
	CRITICAL_SECTION	*m_pCS;
	//Warning this class may be recreated by the wizard.
public:
	HRESULT Fire_OnDataAvailable(LONG hSocket, LONG lBytes, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[3];
//		CComVariant* pvars = new CComVariant[3];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[2] = hSocket;
			pvars[1] = lBytes;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnDataAvailable"), pvars, 3, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[2] = hSocket;
				pvars[1] = lBytes;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 3, 0 };
				pDispatch->Invoke(0x1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnOtherMessage(LONG hSocket, LONG nMsg, LONG wParam, LONG lParam)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[4];
//		CComVariant* pvars = new CComVariant[4];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[3] = hSocket;
			pvars[2] = nMsg;
			pvars[1] = wParam;
			pvars[0] = lParam;
			pT->Invoke(CComBSTR(L"OnOtherMessage"), pvars, 4, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[3] = hSocket;
				pvars[2] = nMsg;
				pvars[1] = wParam;
				pvars[0] = lParam;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				pDispatch->Invoke(0x2, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSocketClosed(LONG hSocket, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnSocketClosed"), pvars, 2, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x3, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}

	HRESULT Fire_OnSocketConnected(LONG hSocket, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnSocketConnected"), pvars, 2, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x4, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnConnecting(LONG hSocket, LONG hWnd)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = hWnd;
			pT->Invoke(CComBSTR(L"OnConnecting"), pvars, 2, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = hWnd;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x5, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnSendingData(LONG hSocket, LONG lError, LONG lSent)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[3];
		CComVariant pvars[3];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[2] = hSocket;
			pvars[1] = lError;
			pvars[0] = lSent;
			pT->Invoke(CComBSTR(L"OnSendingData"), pvars, 3, varResult);
			varResult.Clear();
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[2] = hSocket;
				pvars[1] = lError;
				pvars[0] = lSent;
				DISPPARAMS disp = { pvars, NULL, 3, 0 };
				pDispatch->Invoke(0x6, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnGetHostByAddr(LONG hHandle, BSTR bstrHostName, BSTR bstrHostAlias, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[4];
		CComVariant pvars[4];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[3] = hHandle;
			pvars[2] = bstrHostName;
			pvars[1] = bstrHostAlias;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnGetHostByAddr"), pvars, 4, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[3] = hHandle;
				pvars[2] = bstrHostName;
				pvars[1] = bstrHostAlias;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				pDispatch->Invoke(0x7, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnGetHostByName(LONG hHandle, BSTR bstrHostName, BSTR bstrAlias, BSTR bstrIPAddr, LONG lError)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[5];
		CComVariant pvars[5];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[4] = hHandle;
			pvars[3] = bstrHostName;
			pvars[2] = bstrAlias;
			pvars[1] = bstrIPAddr;
			pvars[0] = lError;
			pT->Invoke(CComBSTR(L"OnGetHostByName"), pvars, 5, varResult);
			varResult.Clear();
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[4] = hHandle;
				pvars[3] = bstrHostName;
				pvars[2] = bstrAlias;
				pvars[1] = bstrIPAddr;
				pvars[0] = lError;
				DISPPARAMS disp = { pvars, NULL, 5, 0 };
				pDispatch->Invoke(0x8, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
	HRESULT Fire_OnClosing(LONG hSocket, LONG hWnd)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
		CComVariant pvars[2];
//		CComVariant* pvars = new CComVariant[2];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(pT->m_spWebDoc != NULL)
		{
			pvars[1] = hSocket;
			pvars[0] = hWnd;
			pT->Invoke(CComBSTR(L"OnClosing"), pvars, 2, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = hSocket;
				pvars[0] = hWnd;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x9, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}

	HRESULT Fire_OnRequestProcessed(LONG hSocket, SHORT nRequestID, LONG lLen, LONG lLenInBuffer, SHORT sFlag)
	{
		HRESULT hr;
		((CUSocket*)this)->m_sLastRequestID = nRequestID;
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[5];
		CComVariant pvars[5];
		int nConnections = m_vec.GetSize();
		ULONG ulCount = RemoveLock();
		if(sFlag == rfCompleted && pT->m_spWebDoc != NULL)
		{
			pvars[4] = hSocket;
			pvars[3] = nRequestID;	
			lLen = pT->m_USAttr.m_curRcvStreamHeader.m_ulLen;
			pvars[2] = lLen;
			lLenInBuffer = pT->m_rcvQueue.GetSize();
			if((ULONG)lLenInBuffer > (ULONG)lLen)
				lLenInBuffer = lLen;
			if(lLenInBuffer != 0)
			{
				pT->m_pJSSerialization->m_UQueue.Push(pT->m_rcvQueue.GetBuffer(), (ULONG)lLenInBuffer);
				pT->m_rcvQueue.Pop((ULONG)lLenInBuffer);
			}
			pvars[1] = lLenInBuffer;
			pvars[0] = sFlag;
			hr = pT->Invoke(CComBSTR(L"OnRequestProcessed"), pvars, 5, varResult);
		}
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[4] = hSocket;
				pvars[3] = nRequestID;	
				lLen = ((CUSocket*)this)->m_USAttr.m_curRcvStreamHeader.m_ulLen;
				pvars[2] = lLen;
				lLenInBuffer = ((CUSocket*)this)->m_rcvQueue.GetSize();
				if((ULONG)lLenInBuffer > (ULONG)lLen)
					lLenInBuffer = lLen;
				pvars[1] = lLenInBuffer;
				pvars[0] = sFlag;
				DISPPARAMS disp = { pvars, NULL, 5, 0 };
				hr = pDispatch->Invoke(0xa, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
		Relock(ulCount);
//		delete[] pvars;
		return varResult.scode;
	
	}
};


template <class T>
class CProxy_IUSocketPoolEvents : public IConnectionPointImpl<T, &DIID__IUSocketPoolEvents, CComDynamicUnkArray>
{
	//Warning this class may be recreated by the wizard.
public:
	HRESULT Fire_OnSocketPoolEvent(tagSocketPoolEvent spe, IUSocket * pIUSocket)
	{
		CComVariant varResult;
		T* pT = static_cast<T*>(this);
		int nConnectionIndex;
//		CComVariant* pvars = new CComVariant[2];
		CComVariant pvars[2];
		int nConnections = m_vec.GetSize();
		for (nConnectionIndex = 0; nConnectionIndex < nConnections; nConnectionIndex++)
		{
			pT->Lock();
			CComPtr<IUnknown> sp = m_vec.GetAt(nConnectionIndex);
			pT->Unlock();
			IDispatch* pDispatch = reinterpret_cast<IDispatch*>(sp.p);
			if (pDispatch != NULL)
			{
				VariantClear(&varResult);
				pvars[1] = spe;
				pvars[0] = (IDispatch*)pIUSocket;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				pDispatch->Invoke(0x1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, &varResult, NULL, NULL);
			}
		}
//		delete[] pvars;
		return varResult.scode;
	
	}
};
#endif