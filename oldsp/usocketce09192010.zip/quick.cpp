/*                    QuickLZ 1.10 data compression library
                  Copyright (C) 2006 by Lasse Mikkel Reinhold

QuickLZ can be used for free under the GPL license (where anything released into
public must be open source) or under a commercial license if such has been 
acquired (see http://www.quicklz.com/order.html).

The #define x86x64 flag will generate code which is highly optimized for x86 and
x64 but isn't compatible with other architectures. 

Use the #define short_input flag to improve compression ratio if the size of 
input is smaller than 100 Kbyte.

Caution! qlz_compress expects the size of the destination buffer to be exactly 
"size + 36000" bytes or more and will crash otherwise because these 36000 bytes
are used as scratch storage. 
*/

#include "stdafx.h"

#ifndef ARM
	#define x86x64
#endif

#define short_input
//#define very_short_input

typedef unsigned int ui32;

enum HEADERFIELDS {UNCOMPSIZE = 0};

__inline ui32 fast_read(void const *src, unsigned int bytes)
{
	// fast when 'bytes' is passed as a constant known at compile time
#ifndef x86x64
	unsigned char *p = (unsigned char*)src;
	switch (bytes)
	{
		case 4:
			return(*p | *(p + 1) << 8 | *(p + 2) << 16 | *(p + 3) << 24);
		case 3: 
			return(*p | *(p + 1) << 8 | *(p + 2) << 16);
		case 2:
			return(*p | *(p + 1) << 8);
		case 1: 
			return(*p);
	}
	return 0;
#else
	return *((ui32*)src);
#endif
}

__inline void fast_write(unsigned int f, void *dst, unsigned int bytes)
{
	// fast when 'bytes' is passed as a constant known at compile time
#ifndef x86x64
	unsigned char *p = (unsigned char*)dst;
	switch (bytes)
	{
		case 4: 
			*p = f;
			*(p + 1) = f >> 8;
			*(p + 2) = f >> 16;
			*(p + 3) = f >> 24;
			return;
		case 3:
			*p = f;
			*(p + 1) = f >> 8;
			*(p + 2) = f >> 16;
			return;
		case 2:
			*p = f;
			*(p + 1) = f >> 8;
			return;
		case 1:
			*p = f;
			return;
	}
#else
	switch (bytes)
	{
		case 4: 
			*((ui32*)dst) = f;
			return;
		case 3:
			*((ui32*)dst) = f;
			return;
		case 2:
			*((ui32*)dst) = f;
			return;
		case 1:
			*((unsigned char*)dst) = f;
			return;
	}
#endif
}

__inline void memcpy_up(char *dst, const char *src, unsigned int n)
{
	// cannot be replaced by overlap handling of memmove() due to LZ77 algorithm
#ifndef x86x64

	if(n > 8 && src + n < dst)
		memcpy(dst, src, n);
	else
	{
		char *end = dst + n;
		while(dst < end)
		{
			*dst = *src;
			dst++;
			src++;
		}
	}
#else
	if (n < 5)
		*((ui32*)dst) = *((ui32*)src);
	else
	{
		char *end = dst + n;
		while(dst < end)
		{
			*((ui32*)dst) = *((ui32*)src);
			dst = dst + 4;
			src = src + 4;
		}
	}
#endif
}

unsigned int qlz_size_decompressed(const char *source)
{
	ui32 *header;
	header = (ui32*)source;
	return fast_read(&header[UNCOMPSIZE], 4);
}

unsigned int qlz_compress(const void *source, char *destination, unsigned int size)
{
	const char *source_c = (const char*)source;
	char *destination_c = (char*)destination;
	const ui32 headerlen = 4;
	const char *last_byte = source_c + size - 1;
	const char *src = source_c + 1;
	const char **hashtable = (const char**)(destination_c + size + 36000 - sizeof(char *)*4096 - (((size_t)(destination_c + size)) % 8));
	ui32 SEQLEN;

	if(size <= 256)
	{
		SEQLEN = 32;
	}
	else if(size <= 1024)
	{
		SEQLEN = size/4;
	}
	else if(size <= 128 *1024)
	{
		SEQLEN = 256;
	}
	else
	{
		SEQLEN = 512;
	}

	char *cword_ptr = destination_c + headerlen;
	char *dst = destination_c + headerlen + 4 + 1;
	char *prev_dst = dst;
	const char *prev_src = src;
	ui32 cword_val = 1 << 30;
	ui32 hash;
	ui32 *header = (ui32*)destination_c;
	const char *guarantee_uncompressed = last_byte - 4*4;

	fast_write(size, &header[UNCOMPSIZE], 4);

	for(hash = 0; hash < 4096; hash++)
	{
		// If this line crashes, remember to allocate size+36000 bytes for the destination_c
		hashtable[hash] = source_c;
	}

	// save first byte uncompressed
	*(destination_c + headerlen + 4) = *source_c;

	while(src < guarantee_uncompressed - SEQLEN)
	{
		ui32 fetch;
		if ((cword_val & 1) == 1)
		{
			// check if destination_c pointer could exceed destination_c buffer
			if (dst + SEQLEN + 128 > destination_c + size + SEQLEN + 256)
			{
				memcpy(destination_c + headerlen, source_c, size);
				return (size + headerlen + 4);
			}

			// store control word
			fast_write((cword_val >> 1) | (1 << (4*8 - 1)), cword_ptr, 4);
			cword_ptr = dst;
			dst += 4;
			cword_val = 1 << 31;

			// check if source_c chunk is compressible
			if (dst - prev_dst > src - prev_src && src + 2*SEQLEN < guarantee_uncompressed)
			{
				while(src < prev_src + SEQLEN - 4*8)
				{
					fast_write( (1 << (4*8 - 1)), dst - 4, 4);
					memcpy_up(dst , src, 4*8 - 1);
					dst += 4*8 - 1 + 4;
					src += 4*8 - 1;
				}
				prev_src = src;
				prev_dst = dst;
				cword_ptr = dst - 4;
			}
		}

		// check for rle sequence
		if (fast_read(src, 4) == fast_read(src + 1, 4))
		{
			const char *orig_src; 
			fetch = fast_read(src, 4);
			orig_src = src;
			src += 5;
			const char *pEnd = orig_src + SEQLEN - 4;
			while (fetch == fast_read(src, 4) && src < pEnd)
				src += 4;
			fast_write(((fetch & 0xff) << 16) | (ui32)((src - orig_src) << 4) | 15, dst, 4);
			dst += 3;
			cword_val = (cword_val >> 1) | (1 << (4*8 - 1));
		}
		else
		{
			const char *o;
			// fetch source_c data and update hash table
			fetch = fast_read(src, 4);
			hash = ((fetch >> 12) ^ fetch) & 0x0fff;
			o = hashtable[hash];
			hashtable[hash] = src;
#ifndef x86x64
			if (src - o <= 131071 && src - o > 3 && *src == *o && *(src + 1) == *(o + 1) && *(src + 2) == *(o + 2))
#else
			if (src - o <= 131071 && src - o > 3 && (((*(unsigned int*)o) ^ (*(const unsigned int*)src)) & 0xffffff) == 0)
#endif
			{
				ui32 offset;
				ui32 matchlen;

				offset = (unsigned int)(src - o);
#ifndef x86x64
				if (*(o + 3) != *(src + 3))
#else
				if ((*(unsigned int*)o) != (*(unsigned int*)src))
#endif
				{
					if(offset <= 63)
					{
						// encode lz match
						*dst = (offset << 2);
						++dst;
						cword_val = (cword_val >> 1) | (1 << (4*8 - 1));
						src += 3;
					}
					else if (offset <= 16383)
					{
						// encode lz match
						unsigned int f = (offset << 2) | 1;
						fast_write(f, dst, 2);
						dst += 2;
						cword_val = (cword_val >> 1) | (1 << (4*8 - 1));
						src += 3;
					}
					else
					{
						// encode literal
						*dst = *src;
						++src;
						++dst;
						cword_val = (cword_val >> 1);
					}
				}
				else
				{
					// encode lz match
					cword_val = (cword_val >> 1) | (1 << (4*8 - 1));
					matchlen = 3;

					while(*(o + matchlen) == *(src + matchlen) && matchlen < SEQLEN)
					{
						++matchlen;
					}
					src += matchlen;
					
					if (matchlen <= 18 && offset <= 1023)
					{
						unsigned int f = ((matchlen - 3) << 2) | (offset << 6) | 2;
						fast_write(f, dst, 2);
						dst += 2;
					}

					else if (matchlen <= 34 && offset <= 65535)
					{
						unsigned int f = ((matchlen - 3) << 3) | (offset << 8) | 3;
						fast_write(f, dst, 3);
						dst += 3;
					}
					else if (matchlen >= 3)
					{
						unsigned int f = ((matchlen - 3) << 4) | (offset << 15) | 7;
						fast_write(f, dst, 4);
						dst += 4;
					}
				}
			}
			else
			{
				// encode literal
				*dst = *src;
				++src;
				++dst;
				cword_val = (cword_val >> 1);
			}
		}
	}

	// save last source_c bytes as literals
	while (src <= last_byte)
	{
		if ((cword_val & 1) == 1)
		{
			fast_write((cword_val >> 1) | (1 << (4*8 - 1)), cword_ptr, 4);
			cword_ptr = dst;
			dst += 4;
			cword_val = 1 << 31;
		}
		*dst = *src;
		++src;
		++dst;
		cword_val = (cword_val >> 1);
	}

	while((cword_val & 1) != 1)
		cword_val = (cword_val >> 1);

	fast_write((cword_val >> 1) | (1 << (4*8 - 1)), cword_ptr, 4);
	dst += 4;
	return (ui32)(dst - destination_c - 1 + 4);
}

unsigned int qlz_decompress(const char *source, void *destination)
{
	const char *source_c = (const char*)source;
	char *destination_c = (char*)destination;
	const ui32 headerlen = 4;
	const char *src = source_c + headerlen;
	char *dst = destination_c;
	const ui32 *header = (ui32*)source_c;
	const char* last_byte = destination_c + fast_read(&header[UNCOMPSIZE], 4);
	ui32 cword_val = 1;
	const ui32 bitlut[16] = {4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0};
	const char *guaranteed_uncompressed = last_byte - 4;

	// prevent spurious memory read on a source_c with size < 4
	if (dst >= guaranteed_uncompressed)
	{
		src += 4;
		while(dst < last_byte)
		{
			*dst = *src;
			++dst;
			++src;
		}
		return (unsigned int)(dst - destination_c);
	}

	while(1)
	{
		ui32 fetch;
		if (cword_val == 1)
		{
			// fetch control word
			cword_val = fast_read(src, 4);
			src += 4;
		}
		
		fetch = fast_read(src, 4);

		// check if we must decode lz match
		if ((cword_val & 1) == 1)
		{
			ui32 offset;
			ui32 matchlen;

			cword_val = cword_val >> 1;
			if ((fetch & 3) == 0)
			{
				offset = (fetch & 0xff) >> 2;
				memcpy_up(dst, dst - offset, 3);
				dst += 3;
				++src;
			}
			else if ((fetch & 2) == 0)
			{
				offset = (fetch & 0xffff) >> 2;
				memcpy_up(dst, dst - offset, 3);
				dst += 3;
				src += 2;
			}
			else if ((fetch & 1) == 0)
			{
				offset = (fetch & 0xffff) >> 6;
				matchlen = ((fetch >> 2) & 15) + 3;
				memcpy_up(dst, dst - offset, matchlen);
				src += 2;
				dst += matchlen;
			}
			else if ((fetch & 4) == 0)
			{
				offset = (fetch & 0xffffff) >> 8;
				matchlen = ((fetch >> 3) & (4*8 -1)) + 3;
				memcpy_up(dst, dst - offset, matchlen);
				src += 3;
				dst += matchlen;
			}
			else if ((fetch & 8) == 0)
			{
				offset = (fetch >> 15);
				matchlen = ((fetch >> 4) & 2047) + 3;
				memcpy_up(dst, dst - offset, matchlen);
				src += 4;
				dst += matchlen;
			}
			else
			{
				// decode rle sequence
				unsigned char rle_char;
				rle_char = (unsigned char)(fetch >> 16);
				matchlen = ((fetch >> 4) & 0xfff);
				memset(dst, rle_char, matchlen);
				src += 3;
				dst += matchlen;
			}
		}
		else
		{
			// decode literal
			memcpy_up(dst, src, 4);
			dst += bitlut[cword_val & 0xf];
			src += bitlut[cword_val & 0xf];
			cword_val = cword_val >> (bitlut[cword_val & 0xf]);

			if (dst >= guaranteed_uncompressed)
			{
				// decode last literals and exit
				while(dst < last_byte)
				{
					if (cword_val == 1)
					{
						src += 4;
						cword_val = 1 << 31;
					}
					*dst = *src;
					++dst;
					++src;
					cword_val = cword_val >> 1;
				}
				return (unsigned int)(dst - destination_c);
			}
		}
	}
}
