// UCert.cpp: implementation of the CUCert class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UCert.h"

extern CWSAStartup	*g_pWSAStartup;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
void asn1time_to_string(ASN1_TIME *tm, char *buf)
{
	char *expires;
	char *pos;
	BIO *bio;

	strcpy(buf,"[invalid date]");
	bio = g_pWSAStartup->BIO_new(g_pWSAStartup->BIO_s_mem());
	if (bio)
	{
		g_pWSAStartup->ASN1_TIME_print(bio,tm);
//		BIO_get_mem_data(bio,&expires);
//		#define BIO_get_mem_data(b,pp)	BIO_ctrl(b,BIO_CTRL_INFO,0,(char *)pp)
		g_pWSAStartup->BIO_ctrl(bio, BIO_CTRL_INFO, 0, &expires);
		if (expires)
		{
			::strcpy(buf,expires);
			pos = ::strstr(buf,"GMT");
			if (pos)
			{
				pos += 3;
				*pos = 0;
			}
		}
		else
			strcpy(buf,"Invalid Time");
		g_pWSAStartup->BIO_free(bio);
	}
}

void GetSessionInfo(SSL *ssl, char *strBuffer)
{
	SSL_CIPHER *ciph;
	X509 *cert;
	ciph = g_pWSAStartup->SSL_get_current_cipher(ssl);
	char enc[4096] = {0};
	cert=g_pWSAStartup->SSL_get_peer_certificate(ssl);

	if (cert != NULL)
	{
		EVP_PKEY *pkey = g_pWSAStartup->X509_get_pubkey(cert);
		if (pkey != NULL)
		{
			if (0)
				;
#ifndef NO_RSA
			else if (pkey->type == EVP_PKEY_RSA && pkey->pkey.rsa != NULL
				&& pkey->pkey.rsa->n != NULL)
				sprintf(enc,	"%d bit RSA", g_pWSAStartup->BN_num_bits(pkey->pkey.rsa->n));
#endif
#ifndef NO_DSA
			else if (pkey->type == EVP_PKEY_DSA && pkey->pkey.dsa != NULL
					&& pkey->pkey.dsa->p != NULL)
				sprintf(enc,	"%d bit DSA", g_pWSAStartup->BN_num_bits(pkey->pkey.dsa->p));
#endif
			g_pWSAStartup->EVP_PKEY_free(pkey);
		}
		g_pWSAStartup->X509_free(cert);
		/* The SSL API does not allow us to look at temporary RSA/DH keys,
		 * otherwise we should print their lengths too */
	}

	::sprintf(strBuffer, "SSL version = %s, Cipher = %s, %s, %s",
			g_pWSAStartup->SSL_get_version(ssl),
			g_pWSAStartup->SSL_CIPHER_get_version(ciph),
			g_pWSAStartup->SSL_CIPHER_get_name(ciph),
			enc);
}

CUCert::CUCert()
{
	m_pSSL = NULL;
	m_pUSocket = NULL;
}

CUCert::~CUCert()
{

}


STDMETHODIMP CUCert::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IUCert,
		&IID_IDispatch
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (IsEqualGUID(*arr[i], riid))
			return uecOK;
	}
	return S_FALSE;
}

STDMETHODIMP CUCert::get_Version(VARIANT *pVal)
{
	if(pVal == NULL)
		return S_OK;
	
	::VariantClear(pVal);
	
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}

		if(server_cert->cert_info && 
			server_cert->cert_info->version && 
			server_cert->cert_info->version->length > 0 && 
			server_cert->cert_info->version->data != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {server_cert->cert_info->version->length, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, server_cert->cert_info->version->data, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
		g_pWSAStartup->X509_free (server_cert);
		return S_OK;
	}
	else
	{
		pVal->vt = VT_I4;
		pVal->lVal = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->dwVersion;
	}
	
	return S_OK;
}

STDMETHODIMP CUCert::get_Issuer(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		USES_CONVERSION;
		char strSubject[4096] = {0};
		CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}
		char *str = g_pWSAStartup->X509_NAME_oneline (g_pWSAStartup->X509_get_issuer_name(server_cert), 0, 0);
		if(str != NULL)
		{
			::strcpy(strSubject, str);
			g_pWSAStartup->CRYPTO_free (str);
		}
		g_pWSAStartup->X509_free (server_cert);
		*pVal = A2BSTR(strSubject);
		return S_OK;
	}
	else
	{
		TCHAR szName[4096]= {0};
		if(!CertNameToStr(m_pUSocket->m_Sspi.m_pRemoteCertContext->dwCertEncodingType,
                      &m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->Issuer,
                      CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG,
                      szName, sizeof(szName)/sizeof(TCHAR)))
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving Issuer.", __uuidof(IUCert));
			return uecFail;
		}
		*pVal = T2BSTR(szName);
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_Subject(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		USES_CONVERSION;
		char strSubject[4096] = {0};
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}
		char *str = g_pWSAStartup->X509_NAME_oneline (g_pWSAStartup->X509_get_subject_name(server_cert), 0, 0);
		if(str != NULL)
		{
			::strcpy(strSubject, str);
			g_pWSAStartup->CRYPTO_free (str);
		}
		g_pWSAStartup->X509_free (server_cert);
		*pVal = A2BSTR(strSubject);
		return S_OK;
	}
	else
	{
		TCHAR szName[4096]= {0};
		if(!CertNameToStr(m_pUSocket->m_Sspi.m_pRemoteCertContext->dwCertEncodingType,
                      &m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->Subject,
                      CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG,
                      szName, sizeof(szName)/sizeof(TCHAR)))
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving Subject.", __uuidof(IUCert));
			return uecFail;
		}
		*pVal = T2BSTR(szName);
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_Validity(VARIANT_BOOL *pVal)
{
	if(pVal == NULL)
		return S_OK;
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		bool bOK;
		X509 *cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}
		ASN1_TIME *pNotAfter = X509_get_notAfter(cert);
		ASN1_TIME *pNotBefore = X509_get_notBefore(cert);
		bOK = (g_pWSAStartup->X509_cmp_current_time(pNotAfter) >= 0);
		bOK = (bOK && (g_pWSAStartup->X509_cmp_current_time(pNotBefore) <= 0));
		g_pWSAStartup->X509_free (cert);
		*pVal = bOK ? VARIANT_TRUE : VARIANT_FALSE;
		return S_OK;
	}
	else
	{
		long lData = CertVerifyTimeValidity(NULL, m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo);
		*pVal = ((lData == 0) ? VARIANT_TRUE : VARIANT_FALSE);
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_NotBefore(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL && pVal != NULL)
	{
		USES_CONVERSION;
		char strNotBefore[256] = {0};
		X509 *cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}
		ASN1_TIME *pNotBefore = X509_get_notBefore(cert);
		asn1time_to_string(pNotBefore, strNotBefore);
		*pVal = A2BSTR(strNotBefore);
		g_pWSAStartup->X509_free (cert);
		return S_OK;
	}
	else
	{
		USES_CONVERSION;
		SYSTEMTIME st;
		char strNotAfter[256] = {0};
		FileTimeToSystemTime(&m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->NotBefore, &st);
		::sprintf(strNotAfter, "%d %.2d %.2d %.2d:%.2d:%.2d", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
		*pVal = A2BSTR(strNotAfter);
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_NotAfter(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal != NULL)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		USES_CONVERSION;
		char strNotAfter[256] = {0};
		X509 *cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}
		ASN1_TIME *pNotAfter = X509_get_notAfter(cert);
		asn1time_to_string(pNotAfter, strNotAfter);
		*pVal = A2BSTR(strNotAfter);
		g_pWSAStartup->X509_free (cert);
		return S_OK;
	}
	else
	{
		USES_CONVERSION;
		SYSTEMTIME st;
		char strNotAfter[256] = {0};
		FileTimeToSystemTime(&m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->NotAfter, &st);
		::sprintf(strNotAfter, "%d %.2d %.2d %.2d:%.2d:%.2d", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
		*pVal = A2BSTR(strNotAfter);
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_SigAlg(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		USES_CONVERSION;
		char strSubject[4096] = {0};
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}
		int nTypeTwo = g_pWSAStartup->OBJ_obj2nid(server_cert->sig_alg->algorithm); 
		const char *strSN = g_pWSAStartup->OBJ_nid2sn(nTypeTwo);
		::strcpy(strSubject, strSN);

		g_pWSAStartup->X509_free (server_cert);
		*pVal = A2BSTR(strSubject);
		return S_OK;
	}
	else
	{
//		CertAlgIdToOID
		USES_CONVERSION;
		SecPkgContext_KeyInfoA KeyInfo;
		DWORD Status = m_pUSocket->m_Sspi.m_pSSPI->QueryContextAttributesA(&m_pUSocket->m_Sspi.m_hContext,
                 SECPKG_ATTR_KEY_INFO, (PVOID)&KeyInfo);
		if(Status == SEC_E_OK)
		{
			*pVal = A2BSTR(KeyInfo.sSignatureAlgorithmName);
		}
	}
	return S_OK;
}

void CUCert::GetDomain(unsigned int addr, char *strDomain, char *strHost, bool bNeedDomain)
{
	hostent* remoteHost;
	remoteHost = ::gethostbyaddr((char *) &addr, 4, AF_INET);
	if(remoteHost && remoteHost->h_name)
	{
		::strcpy(strHost, remoteHost->h_name);
		if(bNeedDomain)
		{
			::_strlwr(remoteHost->h_name);
			char *strWWW = ::strstr(remoteHost->h_name, "www.");
			strcpy(strDomain, strWWW ? strWWW + 4 : remoteHost->h_name);
		}
	}
}

STDMETHODIMP CUCert::CompareDomain(BSTR *pbstrDomain, BSTR *pbstrHost, VARIANT_BOOL *pbMatchable)
{
	unsigned int addr;
	int nRtn;
	int nLen;
	if(pbMatchable)
		*pbMatchable = VARIANT_FALSE;
	if(pbstrDomain != NULL)
	{
		if(*pbstrDomain != NULL)
		{
			::SysFreeString(*pbstrDomain);

			*pbstrDomain = NULL;
		}
	}

	if(pbstrHost != NULL)
	{
		if(*pbstrHost != NULL)
		{
			::SysFreeString(*pbstrHost);
			*pbstrHost = NULL;
		}
	}

	if(pbMatchable == NULL && pbstrDomain == NULL)
	{
		CComCoClass<CUCert>::Error(L"Programming error.", __uuidof(IUCert));
		return uecUnexpected;
	}
	
	long hSocket = m_pUSocket->m_SBAttr.m_hSocket;
	
	if(hSocket == 0 || hSocket == -1)
	{
		CComCoClass<CUCert>::Error(L"Socket closed.", __uuidof(IUCert));
		return uecUnexpected;
	}

	char strDomain[256] = {0};
	sockaddr	sockAddr;
	sockaddr	sockAddrLocal;
	nLen = sizeof(sockAddr);
	memset(&sockAddr, 0, nLen);
	memset(&sockAddrLocal, 0, nLen);

	CAutoLock AutoLock(&m_pUSocket->m_csGeneral.m_sec);

	if(m_pUSocket->m_bstrAddrConn.Length() > 0)
	{
		USES_CONVERSION;
		char *str = OLE2A(m_pUSocket->m_bstrAddrConn);
		char *strWWW = ::strstr(str, "www.");
		if(strWWW != NULL)
		{
			::strcpy(strDomain, strWWW+4);
		}
		else
		{
			::strcpy(strDomain, str);
		}
	}
	if(pbstrHost != NULL || (m_pUSocket->m_bstrAddrConn.Length() == 0 && pbstrDomain != NULL))
	{
		char strHost[256] = {0};
		nRtn = getpeername(hSocket, &sockAddr, &nLen);
		addr = ((sockaddr_in*)&sockAddr)->sin_addr.s_addr;
		GetDomain(addr, strDomain, strHost, (m_pUSocket->m_bstrAddrConn.Length() == 0));
		if(pbstrHost != NULL)
		{
			*pbstrHost = A2BSTR(strHost);
		}
	}
	if(pbstrDomain != NULL)
	{
		USES_CONVERSION;
		*pbstrDomain = A2BSTR(strDomain);
	}
	
	if(pbMatchable == NULL)
	{
		return S_OK;
	}

	nRtn = getsockname(hSocket, &sockAddrLocal, &nLen);
	
	*pbMatchable = (((sockaddr_in*)&sockAddr)->sin_addr.s_addr == ((sockaddr_in*)&sockAddrLocal)->sin_addr.s_addr) ? VARIANT_TRUE : VARIANT_FALSE;
	
	if(*pbMatchable == VARIANT_FALSE)
	{
		char *strFind;
		char strSubject[4096] = {0};
		if(m_pSSL)
		{
			X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
			if(server_cert == NULL)
			{
				CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
				return uecFail;
			}
			char *str = g_pWSAStartup->X509_NAME_oneline (g_pWSAStartup->X509_get_subject_name(server_cert), 0, 0);
			if(str != NULL)
			{
				if(strSubject != NULL)
				{
					::strcpy(strSubject, str);
				}
				g_pWSAStartup->CRYPTO_free (str);
			}
			g_pWSAStartup->X509_free (server_cert);
		}
		else
		{
			USES_CONVERSION;
			TCHAR str[2048] = {0};
			CertNameToStr(m_pUSocket->m_Sspi.m_pRemoteCertContext->dwCertEncodingType,
                      &m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->Subject,
                      CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG,
                      str, sizeof(str)/sizeof(TCHAR));
			::strcpy(strSubject, T2A(str));
		}
		::_strlwr(strSubject);
		::_strlwr(strDomain);
		strFind = ::strstr(strSubject, strDomain);
		if(strFind != NULL)
			*pbMatchable = VARIANT_TRUE;
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_SerialNumber(VARIANT *pVal)
{
	if(pVal == NULL)
	{
		return S_OK;
	}

	::VariantClear(pVal);
	
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}

		if(server_cert->cert_info && 
			server_cert->cert_info->serialNumber && 
			server_cert->cert_info->serialNumber->length > 0 && 
			server_cert->cert_info->serialNumber->data != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {server_cert->cert_info->serialNumber->length, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, server_cert->cert_info->serialNumber->data, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
		g_pWSAStartup->X509_free (server_cert);
		return S_OK;
	}
	else
	{
		DWORD cbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->SerialNumber.cbData;
		BYTE *pbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->SerialNumber.pbData;
		if(cbData > 0 && pbData != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {cbData, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, pbData, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_Algorithm(VARIANT *pVal)
{
	if(pVal == NULL)
	{
		return S_OK;
	}

	::VariantClear(pVal);
	
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}

		if(server_cert->cert_info && 
			server_cert->cert_info->signature && 
			server_cert->cert_info->signature->algorithm && 
			server_cert->cert_info->signature->algorithm->length > 0 &&
			server_cert->cert_info->signature->algorithm->data != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {server_cert->cert_info->signature->algorithm->length, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, server_cert->cert_info->signature->algorithm->data, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
		g_pWSAStartup->X509_free (server_cert);
		return S_OK;
	} 
	else
	{
		USES_CONVERSION;
		PCERT_INFO pInfo = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo;
		pVal->vt = VT_BSTR;
		pVal->bstrVal = A2BSTR(pInfo->SignatureAlgorithm.pszObjId);
	}

	return S_OK;
}

STDMETHODIMP CUCert::get_PublicKey(VARIANT *pVal)
{
	if(pVal == NULL)
	{
		return S_OK;
	}
	
	::VariantClear(pVal);

	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}

		if(server_cert->cert_info && 
			server_cert->cert_info->key && 
			server_cert->cert_info->key->public_key && 
			server_cert->cert_info->key->public_key->length > 0 &&
			server_cert->cert_info->key->public_key->data != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {server_cert->cert_info->key->public_key->length, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, server_cert->cert_info->key->public_key->data, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
		g_pWSAStartup->X509_free (server_cert);
		return S_OK;
	}
	else
	{
		DWORD cbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->SubjectPublicKeyInfo.PublicKey.cbData;
		BYTE *pbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->SubjectPublicKeyInfo.PublicKey.pbData;
		if(cbData > 0 && pbData != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {cbData, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, pbData, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_IssuerUID(VARIANT *pVal)
{
	if(pVal == NULL)
		return S_OK;
	
	::VariantClear(pVal);
	
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}

		if(server_cert->cert_info && 
			server_cert->cert_info->issuerUID && 
			server_cert->cert_info->issuerUID->length && 
			server_cert->cert_info->issuerUID->data != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {server_cert->cert_info->issuerUID->length, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, server_cert->cert_info->issuerUID->data, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
		g_pWSAStartup->X509_free (server_cert);
		return S_OK;
	}
	else
	{
		DWORD cbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->IssuerUniqueId.cbData;
		BYTE *pbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->IssuerUniqueId.pbData;
		if(cbData > 0 && pbData != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {cbData, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, pbData, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_SubjectUID(VARIANT *pVal)
{
	if(pVal == NULL)
		return S_OK;

	::VariantClear(pVal);

	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}

		if(server_cert->cert_info && 
			server_cert->cert_info->subjectUID && 
			server_cert->cert_info->subjectUID->length && 
			server_cert->cert_info->subjectUID->data != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {server_cert->cert_info->subjectUID->length, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, server_cert->cert_info->subjectUID->data, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
		g_pWSAStartup->X509_free (server_cert);
		return S_OK;
	}
	else
	{
		DWORD cbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->SubjectUniqueId.cbData;
		BYTE *pbData = m_pUSocket->m_Sspi.m_pRemoteCertContext->pCertInfo->SubjectUniqueId.pbData;
		if(cbData > 0 && pbData != NULL)
		{
			BYTE *pByte;
			pVal->vt = (VT_ARRAY|VT_UI1);
			SAFEARRAYBOUND sabByte[1] = {cbData, 0};
			pVal->parray = ::SafeArrayCreate(VT_UI1, 1, sabByte);
			::SafeArrayAccessData(pVal->parray, (void**)&pByte);
			memcpy(pByte, pbData, sabByte[0].cElements);
			::SafeArrayUnaccessData(pVal->parray);
		}
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_CertPem(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		X509 *server_cert = g_pWSAStartup->SSL_get_peer_certificate (m_pSSL);
		if(server_cert == NULL)
		{
			CComCoClass<CUCert>::Error(L"Failed in retrieving peer certificate.", __uuidof(IUCert));
			return uecFail;
		}

		BIO *pMem = g_pWSAStartup->BIO_new(g_pWSAStartup->BIO_s_mem());
		if(pMem != NULL)
		{
			BUF_MEM *bptr = NULL;
			int nRtn = g_pWSAStartup->PEM_write_bio_X509(pMem, server_cert);
			nRtn = g_pWSAStartup->BIO_get_mem_ptr(pMem, &bptr);
			if(nRtn > 0 && bptr != NULL && bptr->data && bptr->length > 0)
			{
				USES_CONVERSION;
				int nTotal = bptr->length;
				char *pData = new char[nTotal + 1];
				::memcpy(pData, bptr->data, nTotal);
				pData[nTotal] = 0;
				*pVal = A2WBSTR(pData, nTotal);
				delete []pData;

			}
			g_pWSAStartup->BIO_free_all(pMem);
		}

		g_pWSAStartup->X509_free (server_cert);
		return S_OK;
	}
	else
	{

	}
	
	return S_OK;
}

STDMETHODIMP CUCert::get_VerifyLocation(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal != NULL)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pUSocket->m_bstrLocation.m_str != NULL)
	{
		*pVal = m_pUSocket->m_bstrLocation.Copy();
	}
	return S_OK;
}

STDMETHODIMP CUCert::put_VerifyLocation(BSTR newVal)
{
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		m_pUSocket->m_bstrLocation = newVal;
		if(m_pUSocket->m_bstrLocation.Length() > 4)
		{
			USES_CONVERSION;
			int err = g_pWSAStartup->SSL_CTX_load_verify_locations(m_pSSL->ctx, OLE2A(m_pUSocket->m_bstrLocation), NULL);
			if(err == 0)
			{
				CComCoClass<CUCert>::Error(L"Failed in setting verify location.", __uuidof(IUCert));
				return uecFail;
			}
			return S_OK;
		}
	}
	else
	{
		m_pUSocket->m_bstrLocation = newVal;
	}
	return S_OK;
}

STDMETHODIMP CUCert::Verify(long *plErrorCode, BSTR *pbstrErrorMsg)
{
	if(plErrorCode != NULL)
		*plErrorCode = S_OK;
	if(pbstrErrorMsg)
	{
		if(*pbstrErrorMsg != NULL)
		{
			::SysFreeString(*pbstrErrorMsg);
			*pbstrErrorMsg = NULL;
		}
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		int err = g_pWSAStartup->SSL_get_verify_result(m_pSSL);
		if(plErrorCode)
			*plErrorCode = err;
		if(pbstrErrorMsg)
		{
			const char *str = g_pWSAStartup->X509_verify_cert_error_string(err);
			if(str != NULL)
			{
				*pbstrErrorMsg = A2BSTR(str);
			}
		}
		return S_OK;
	}
	else
	{
		USES_CONVERSION;
		SECURITY_STATUS sc = m_pUSocket->m_Sspi.VerifyServerCertificate(m_pUSocket->m_bstrLocation, 4);
		if(plErrorCode != NULL)
			*plErrorCode = sc;
		if(FAILED(sc) && pbstrErrorMsg != NULL)
		{
			*pbstrErrorMsg = m_pUSocket->m_Sspi.DisplayWinVerifyTrustError(sc).Copy();
		}
	}
	return S_OK;
}

STDMETHODIMP CUCert::get_SessionInfo(BSTR *pVal)
{
	if(pVal == NULL)
		return S_OK;
	if(*pVal)
	{
		::SysFreeString(*pVal);
		*pVal = NULL;
	}
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		USES_CONVERSION;
		char strSubject[4096] = {0};
		GetSessionInfo(m_pSSL, strSubject);
		*pVal = A2BSTR(strSubject);
		return S_OK;
	}
	else
	{
		CComBSTR bstr(L"SSL version: ");
		SECURITY_STATUS Status;
		SecPkgContext_ConnectionInfo ConnectionInfo;
		Status = m_pUSocket->m_Sspi.m_pSSPI->QueryContextAttributesA(&m_pUSocket->m_Sspi.m_hContext,
                                    SECPKG_ATTR_CONNECTION_INFO,
                                    (PVOID)&ConnectionInfo);
		if(Status != SEC_E_OK)
		{
			CComCoClass<CUCert>::Error(L"Failed in quering connection information.", __uuidof(IUCert));
			return uecFail;
		}

		switch(ConnectionInfo.dwProtocol)
		{
			case SP_PROT_TLS1_CLIENT:
				bstr += L"TLS1";
				break;
			case SP_PROT_SSL3_CLIENT:
				bstr += L"SSL3";
				break;
			case SP_PROT_PCT1_CLIENT:
				bstr += L"PCT";
				break;
			case SP_PROT_SSL2_CLIENT:
				bstr += L"SSL2";
				break;
			default:
				break;
		}
		bstr += L", ";
		switch(ConnectionInfo.aiCipher)
		{
			case CALG_RC4: 
				bstr += L"Cipher: RC4";
				break;
			case CALG_3DES: 
				bstr += L"Cipher: Triple DES";
				break;
			case CALG_RC2: 
				bstr += L"Cipher: RC2";
				break;
			case CALG_DES: 
			case CALG_CYLINK_MEK:
				bstr += L"Cipher: DES";
				break;
			case CALG_SKIPJACK: 
				bstr += L"Cipher: Skipjack";
				break;
			default: 
				break;
		}
		
		bstr += L", ";
		switch(ConnectionInfo.aiHash)
		{
			case CALG_MD5: 
				bstr += L"Hash: MD5";
				break;
			case CALG_SHA: 
				bstr += L"Hash: SHA";
				break;
			default: 
				break;
		}
		
		bstr += L", ";
		switch(ConnectionInfo.aiExch)
		{
			case CALG_RSA_KEYX: 
			case CALG_RSA_SIGN: 
				bstr += L"Key exchange: RSA";
				break;
			case CALG_KEA_KEYX: 
				bstr += L"Key exchange: KEA";
				break;
			case CALG_DH_EPHEM:
				bstr += L"Key exchange: DH Ephemeral";
				break;
			default: 
				break;
		}

		char strSize[128];
		sprintf(strSize, "Key size %d bit", ConnectionInfo.dwExchStrength);
		bstr += L", ";
		bstr += strSize;
		*pVal = bstr.Copy();
	}
	return S_OK;
}

STDMETHODIMP CUCert::AddCertificateToStore(VARIANT_BOOL bRoot)
{
	CAutoLock AutoLockLocal(&m_pUSocket->m_csGeneral.m_sec);
	if(m_pSSL != NULL)
	{
		CComCoClass<CUCert>::Error(L"Not implemented yet with OpenSSL.", __uuidof(IUCert));
		return uecNotImplemented;
	}

	HCERTSTORE hStore = CertOpenSystemStoreA(NULL, (bRoot != VARIANT_FALSE) ? "ROOT" : "MY");
	if(hStore == NULL)
	{
		CComCoClass<CUCert>::Error(L"Can't open system store.", __uuidof(IUCert));
		return ::GetLastError();
	}
	
	BOOL bSuc = ::CertAddCertificateContextToStore(hStore, m_pUSocket->m_Sspi.m_pRemoteCertContext, CERT_STORE_ADD_REPLACE_EXISTING, NULL);
	::CertCloseStore(hStore, 0);
	if(!bSuc)
	{
		CComCoClass<CUCert>::Error(L"Fail in adding certificate into system store.", __uuidof(IUCert));
		return ::GetLastError();
	}
	return S_OK;
}
