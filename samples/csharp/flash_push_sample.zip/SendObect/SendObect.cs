﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SendObectclass
{
    [Serializable]
    public enum GameEvent
    {
        StartGame,
        NoMoreBets
    }
    public class SendObect
    {
        public int GameId;
        public string DealerName;
        public GameEvent Gevent;

        public override string ToString()
        {
            string str = "GameId=" + GameId + ";DealerName=" + DealerName + ";Gevent=" + Gevent.ToString();
            return str;
        }
    }
}
