/* **** including all of defines, service id(s) and request id(s) ***** */
using System;
using SocketProAdapter;
using SocketProAdapter.ServerSide;
using USOCKETLib;
using SendObectclass;
public class ChatWebAppPeer : CClientPeer
{
    protected override void OnSwitchFrom(int nServiceID)
    {
        //initialize the object here
        int[] groups = { 1 };
        bool k = Push.Enter(groups);
    }

    protected override void OnReleaseResource(bool bClosing, int nInfo)
    {
        if (bClosing)
        {
            //closing the socket with error code = nInfo
        }
        else
        {
            //switch to a new service with the service id = nInfo
        }

        //release all of your resources here as early as possible
    }
    protected override void OnChatRequestComing(USOCKETLib.tagChatRequestID ChatRequestId, object Param0, object Param1)
    {
        string str = "";
        int[] Groups;
        switch (ChatRequestId)
        {
            case tagChatRequestID.idEnter:
            case tagChatRequestID.idXEnter:
                Groups = (int[])Param0;
                foreach (int n in Groups)
                {
                    if (str.Length > 0) str += ", ";
                    str += n.ToString();
                }
                Console.WriteLine("User {0} joins chat groups {1}", UserID, str);
                break;
            case tagChatRequestID.idSpeak:
            case tagChatRequestID.idXSpeak:
                Groups = (int[])Param1;
                foreach (int n in Groups)
                {
                    if (str.Length > 0) str += ", ";
                    str += n.ToString();
                }
                if (Param0 == null)
                    Param0 = "null";
                Console.WriteLine("User {0} sends a message '{1}' to chat groups {2}", UserID, Param0.ToString(), str);
                break;
            case tagChatRequestID.idExit:
                Console.WriteLine("User {0} exits his or her chat groups", UserID);
                break;
            case tagChatRequestID.idSendUserMessage:
                if (Param0 == null)
                    Param0 = "null";
                if (Param1 == null)
                    Param1 = "null";
                Console.WriteLine("User {0} sends a message '{1}' to {2}", UserID, Param1.ToString(), Param0.ToString());
                break;
            default:
                break;
        }
    }
    protected void Send(SendObect txt)
    {
        int[] groups = { 1 };
        string s = txt.ToString();
        Push.Broadcast(s, groups);
    }

    protected override void OnFastRequestArrive(short sRequestID, int nLen)
    {
        switch (sRequestID)
        {
            case ChatConst.idSendChatWebApp:
                M_I1_R0<SendObect>(Send);
                break;
            default:
                break;
        }
    }

    protected override int OnSlowRequestArrive(short sRequestID, int nLen)
    {
        switch (sRequestID)
        {
            default:
                break;
        }
        return 0;
    }


}

public class CMySocketProServer : CSocketProServer
{

	protected override bool OnSettingServer()
	{
		//try amIntegrated and amMixed instead by yourself
		Config.AuthenticationMethod = tagAuthenticationMethod.amOwn;

		//add service(s) into SocketPro server
		AddService();

		//You may set others here

		return true; //true -- ok; false -- no listening server
	}

	protected override void OnAccept(int hSocket, int nError)
	{
		//when a socket is initially established
        Console.WriteLine("Socket {0} accepted with error = {1}", hSocket, nError);
	}

	protected override bool OnIsPermitted(int hSocket, int nSvsID)
	{
		//give permission to all
		return true;
	}

	protected override void OnClose(int hSocket, int nError)
	{
        Console.WriteLine("Socket {0} closed with error = {1}", hSocket, nError);
	}

	private CSocketProService<ChatWebAppPeer> m_ChatWebApp = new CSocketProService<ChatWebAppPeer>();
    private CSocketProService<CHttpPeer> m_HttpSvs = new CSocketProService<CHttpPeer>();

	//One SocketPro server supports any number of services. You can list them here!

	private void AddService()
	{
		bool ok;

		//No COM -- taNone; STA COM -- taApartment; and Free COM -- taFree
		
		//If ok is false, very possibly you have two services with the same service id!
        ok = PushManager.AddAChatGroup(1, "Group for SOne");
        //one default page
        CHttpPushPeer.Default = "httppush.htm";

        ok = m_HttpSvs.AddMe((int)USOCKETLib.tagServiceID.sidHTTP, 0, tagThreadApartment.taNone);
        ok = m_HttpSvs.AddSlowRequest((short)USOCKETLib.tagHttpRequestID.idGet);
        ok = m_HttpSvs.AddSlowRequest((short)USOCKETLib.tagHttpRequestID.idPost);
        ok = m_ChatWebApp.AddMe(ChatConst.sidChatWebApp, 0, tagThreadApartment.taNone);
        ok = m_ChatWebApp.AddMe((int)USOCKETLib.tagServiceID.sidChat, 0, tagThreadApartment.taNone);
      


		//Add all of other services into SocketPro server here!
	}


}

