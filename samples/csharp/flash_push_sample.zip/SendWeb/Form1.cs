﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SocketProAdapter.ClientSide;
using SocketProAdapter;
using USOCKETLib;
using SendObectclass;

namespace SendWeb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_sen_Click(object sender, EventArgs e)
        {
            SendObect ob = new SendObect {DealerName ="davitshergilashvili", GameId = 11,Gevent=GameEvent.StartGame};
            int []groups = {1};
            handler.GetAttachedClientSocket().Push.Broadcast(ob.ToString(), groups);
            //or handler.SendRequest(ChatConst.idSendChatWebApp, ob, delegate(CAsyncResult ar) { });
        } 
        private void Btn_con_Click(object sender, EventArgs e)
        {
            socket.Connect("localhost", 20901);
        }

        private void Btn_dis_Click(object sender, EventArgs e)
        {
            socket.Disconnect();
        }
        public void OnBaseRequestPerocess(short srequestid)
        {
            switch (srequestid)
            {
                case (short) USOCKETLib.tagChatRequestID.idEnter:
                case (short)USOCKETLib.tagChatRequestID.idXEnter:
                    {
                        string strMsg;
                        int nGroup = 0;
                        int nPort = 0;
                        int nSvsID = 0;
                        string strUID = null;
                        string strIPAddr =socket.GetUSocket().GetInfo(0, out nGroup, out strUID, out nSvsID, out nPort);
                        strMsg = strUID;
                        strMsg += "@";
                        strMsg += strIPAddr;
                        strMsg += ":";
                        strMsg += nPort;
                        strMsg += " has just joined the group";
                        txt_in.Text = strMsg;
                    }
                    break;
                case (short) USOCKETLib.tagChatRequestID.idExit:
                    {
                        string strMsg;
                        int nGroup = 0;
                        int nPort = 0;
                        int nSvsID = 0;
                        string strUID = null;
                        string strIPAddr = socket.GetUSocket().GetInfo(0, out nGroup, out strUID, out nSvsID, out nPort);
                        strMsg = strUID;
                        strMsg += "@";
                        strMsg += strIPAddr;
                        strMsg += ":";
                        strMsg += nPort;
                        strMsg += " has just exited from the group";
                        txt_in.Text = strMsg;
                    }
                    break;

                case (short) USOCKETLib.tagChatRequestID.idSpeak:
                case (short) USOCKETLib.tagChatRequestID.idXSpeak:
                    //{
                    //    int nGroup = 0;
                    //    int nPort = 0;
                    //    int nSvsID = 0;
                    //    string strUID = null;
                    //    System.Text.UTF8Encoding utf8 = new System.Text.UTF8Encoding();
                    //    string strMsg = utf8.GetString((byte[])socket.GetUSocket().Message);
                    //    string strIPAddr = socket.GetUSocket().GetInfo(0, out nGroup, out strUID, out nSvsID, out nPort);
                    //    strMsg += " from ";
                    //    strMsg += strUID;
                    //    strMsg += "@";
                    //    strMsg += strIPAddr;
                    //    strMsg += ":";
                    //    strMsg += nPort;
                    //    txt_in.Text = strMsg;
                    //}
                    //break;
                case (short) USOCKETLib.tagChatRequestID.idSpeakEx:
                case (short) USOCKETLib.tagChatRequestID.idXSpeakEx:
                    {
                        try
                        {
                            
                            byte[] bytes = (byte[])socket.GetUSocket().Message;
                            using (CScopeUQueue su = new CScopeUQueue())
                            {
                                su.UQueue.Push(bytes);
                                SendObect msg;
                                su.Load(out msg);
                                txt_in.Text = msg.DealerName.ToString() + "   " + msg.GameId.ToString();
                            }
                        }
                        catch
                        {
                            string strMsg = "";
                            int nGroup = 0;
                            int nPort = 0;
                            int nSvsID = 0;
                            string strUID = null;
                            //System.Text.UTF8Encoding utf8 = new System.Text.UTF8Encoding();
                            //byte[] data = utf8.GetString((byte[])socket.GetUSocket().Message);
                            strMsg = socket.GetUSocket().Message.ToString();
                            string strIPAddr = socket.GetUSocket().GetInfo(0, out nGroup, out strUID, out nSvsID,
                                                                           out nPort);
                            strMsg += " from ";
                            strMsg += strUID;
                            strMsg += "@";
                            strMsg += strIPAddr;
                            strMsg += ":";
                            strMsg += nPort;
                            txt_in.Text = strMsg.ToString();
                        }

                    }
                    break;
                //case (short)USOCKETLib.tagChatRequestID.idSendUserMessage:
                //case (short)USOCKETLib.tagChatRequestID.idSendUserMessageEx:
                //    {

                //    }
                //    break;
            }
  
        }

        public void OnClosed(int hSocket, int nerrorCode)
        {
            Btn_dis.Enabled = false;
            Btn_con.Enabled = true;
        }

        public void OnConnected(int hSocket, int nErrorCode)
        {

            if (nErrorCode == 0)
            {
                Btn_con.Enabled = false;
                socket.SetUID("deskApp");
                socket.SetPassword("MyPassword");
                socket.SwitchTo(handler);
            }
            else
            {
                MessageBox.Show(socket.GetErrorMsg());
            }
        }

        CAsyncServiceHandler handler = new CAsyncServiceHandler(ChatConst.sidChatWebApp);
        CClientSocket socket = new CClientSocket();
        private void Form1_Load(object sender, EventArgs e)
        {
            handler.Attach(socket);
            socket.m_OnSocketClosed += OnClosed;
            socket.m_OnSocketConnected += OnConnected;
            socket.m_OnBaseRequestProcessed += OnBaseRequestPerocess;
            
        }
    }
}
