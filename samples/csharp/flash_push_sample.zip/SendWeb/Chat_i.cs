public static class ChatConst
{
	//defines for service ChatWebApp
	public const int sidChatWebApp = ((int)USOCKETLib.tagOtherDefine.odUserServiceIDMin + 20);

	public const short idSendChatWebApp = ((short)USOCKETLib.tagOtherDefine.odUserRequestIDMin + 0);
}