

using System;
using SocketProAdapter;
using SocketProAdapter.ClientSide;
using USOCKETLib;
using SendObectclass;

public class ChatWebApp : CAsyncServiceHandler
{
	public ChatWebApp() : base(ChatConst.sidChatWebApp)
	{
	}

	public ChatWebApp(CClientSocket cs) : base(ChatConst.sidChatWebApp, cs)
	{
	}

	public ChatWebApp(CClientSocket cs, IAsyncResultsHandler DefaultAsyncResultsHandler) : base(ChatConst.sidChatWebApp, cs, DefaultAsyncResultsHandler)
	{
	}

	public void Send(SendObect txt)
	{
		bool bProcessRy = ProcessR0(ChatConst.idSendChatWebApp, txt);
	}
}
