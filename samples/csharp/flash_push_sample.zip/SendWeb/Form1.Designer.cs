﻿namespace SendWeb
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_con = new System.Windows.Forms.Button();
            this.Btn_dis = new System.Windows.Forms.Button();
            this.Btn_sen = new System.Windows.Forms.Button();
            this.txt_in = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Btn_con
            // 
            this.Btn_con.Location = new System.Drawing.Point(12, 12);
            this.Btn_con.Name = "Btn_con";
            this.Btn_con.Size = new System.Drawing.Size(75, 23);
            this.Btn_con.TabIndex = 0;
            this.Btn_con.Text = "connection";
            this.Btn_con.UseVisualStyleBackColor = true;
            this.Btn_con.Click += new System.EventHandler(this.Btn_con_Click);
            // 
            // Btn_dis
            // 
            this.Btn_dis.Location = new System.Drawing.Point(183, 12);
            this.Btn_dis.Name = "Btn_dis";
            this.Btn_dis.Size = new System.Drawing.Size(75, 23);
            this.Btn_dis.TabIndex = 1;
            this.Btn_dis.Text = "disconected";
            this.Btn_dis.UseVisualStyleBackColor = true;
            this.Btn_dis.Click += new System.EventHandler(this.Btn_dis_Click);
            // 
            // Btn_sen
            // 
            this.Btn_sen.Location = new System.Drawing.Point(98, 53);
            this.Btn_sen.Name = "Btn_sen";
            this.Btn_sen.Size = new System.Drawing.Size(75, 23);
            this.Btn_sen.TabIndex = 3;
            this.Btn_sen.Text = "Send";
            this.Btn_sen.UseVisualStyleBackColor = true;
            this.Btn_sen.Click += new System.EventHandler(this.Btn_sen_Click);
            // 
            // txt_in
            // 
            this.txt_in.Location = new System.Drawing.Point(9, 98);
            this.txt_in.Multiline = true;
            this.txt_in.Name = "txt_in";
            this.txt_in.Size = new System.Drawing.Size(268, 86);
            this.txt_in.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 209);
            this.Controls.Add(this.txt_in);
            this.Controls.Add(this.Btn_sen);
            this.Controls.Add(this.Btn_dis);
            this.Controls.Add(this.Btn_con);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_con;
        private System.Windows.Forms.Button Btn_dis;
        private System.Windows.Forms.Button Btn_sen;
        private System.Windows.Forms.TextBox txt_in;
    }
}

