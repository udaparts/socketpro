
namespace RemoteFileClient
{
    public static class TFileConst
    {
        //defines for service CFileAsyncHandler
        public const int sidRemoteFile = ((int)USOCKETLib.tagOtherDefine.odUserServiceIDMin + 1010);

        public const short idDownloadFile = ((short)USOCKETLib.tagOtherDefine.odUserRequestIDMin + 0);
        public const short idUploadFile = (idDownloadFile + 1);

        //maually add extra request ids for different purposes
        public const short idDownloadData = (idUploadFile + 1);
        public const short idUploadData = (idDownloadData + 1);
        public const short idRemoteFileOpened = (idUploadData + 1);
        public const short idLocalFileSize = (idRemoteFileOpened + 1);
    }

}