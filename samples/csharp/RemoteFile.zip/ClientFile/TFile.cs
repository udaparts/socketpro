

using System;
using SocketProAdapter;
using SocketProAdapter.ClientSide;
using USOCKETLib;
using System.IO;
using System.Text;

namespace RemoteFileClient
{
    public delegate void DReportStatus(double dPercent);

    public class CFileAsyncHandler : CAsyncServiceHandler
    {
        private DReportStatus m_rs;
        private FileStream m_file;
        private long m_lFileSize;
        private long m_lRemoteFileSize;
        private const int MAX_SENDING_PENDING_DATA_SIZE = 100 * 1024;
        private const int MAX_DATA_PACKET_SIZE = 20 * 1024;

        public CFileAsyncHandler()
            : base(TFileConst.sidRemoteFile)
        {

        }

        public CFileAsyncHandler(CClientSocket cs)
            : base(TFileConst.sidRemoteFile, cs)
        {

        }

        public CFileAsyncHandler(CClientSocket cs, IAsyncResultsHandler DefaultAsyncResultsHandler)
            : base(TFileConst.sidRemoteFile, cs, DefaultAsyncResultsHandler)
        {
        }

        public long GetFileSize()
        {
            return m_lRemoteFileSize;
        }

        protected override void OnResultReturned(short sRequestID, CUQueue UQueue)
        {
            switch (sRequestID)
            {
                case TFileConst.idRemoteFileOpened:
                    UQueue.Load(out m_lRemoteFileSize);
                    break;
                case TFileConst.idDownloadData:
                    if (UQueue.GetSize() > 0)
                    {
                        byte[] array;
                        m_lFileSize += UQueue.GetSize();
                        UQueue.Pop(out array);
                        m_file.Write(array, 0, array.Length);
                        if (m_rs != null)
                        {
                            double dAll = m_lRemoteFileSize;
                            m_rs.Invoke(100 * m_lFileSize / dAll);
                        }
                    }
                    break;
                case TFileConst.idUploadData:
                    //check how many bytes of data in client sending buffer
                    if (GetAttachedClientSocket().GetUSocket().BytesInSndMemory < MAX_SENDING_PENDING_DATA_SIZE)
                    {
                        //If there is not much data inside client sending buffer, upload data asynchronously here
                        UploadData();
                    }
                    break;
                default:
                    break;
            }
        }

        //You need to study the following samples and sites:
        //1. Tutorial 3 at C:\Program Files (x86)\UDAParts\SocketPro\tutorial\CSharp\SampleThree and 
        //   site http://www.udaparts.com/document/Tutorial/TutorialThree.htm
        //2. Video turorial Video tutorial 3-2 at the site http://www.udaparts.com/document/videos/videos.htm 
        //   and its attached sample.
        //3. Pay close attention to how to exchange any size of large data or file or collection of items.
        public bool DownloadFile(string RemoteFilePath, string LocalFilePath, DReportStatus rs)
        {
            //You may throw exception here instead of prompting a message.
            if (GetAttachedClientSocket().GetCountOfRequestsInQueue() > 0)
            {
                System.Windows.Forms.MessageBox.Show("Previous request not completed yet");
                return false;
            }
            try
            {
                m_rs = rs;
                m_lFileSize = 0;
                m_lRemoteFileSize = -1;
                m_file = new FileStream(LocalFilePath, FileMode.Create, FileAccess.Write);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show("Can not open a local file for writing data with error message = " + err.Message);
                return false;
            }
            bool bProcessRy = ProcessR0(TFileConst.idDownloadFile, RemoteFilePath);
            m_file.Close();
            if (!bProcessRy)
            {
                System.Windows.Forms.MessageBox.Show("Socket closed with error message = " + GetAttachedClientSocket().GetErrorMsg());
            }
            else if (m_lRemoteFileSize == -1)
            {
                bProcessRy = false;
                System.Windows.Forms.MessageBox.Show("Remote file not found");
            }
            else if (m_lRemoteFileSize != m_lFileSize)
            {
                bProcessRy = false;
                System.Windows.Forms.MessageBox.Show("Something wrong in downloading a remote file or downloading canceled");
            }
            if (!bProcessRy)
                System.IO.File.Delete(LocalFilePath);
            m_file = null;
            m_rs = null;
            return bProcessRy;
        }

        /// <summary>
        /// Upload data from client to server asynchronously until client sending buffer data is over 100*1024 in byte. 
        /// </summary>
        private void UploadData()
        {
            byte[] buffer = new byte[MAX_DATA_PACKET_SIZE];
            using (CScopeUQueue su = new CScopeUQueue())
            {
                int nRead = m_file.Read(buffer, 0, MAX_DATA_PACKET_SIZE);
                while (nRead > 0)
                {
                    su.UQueue.Push(buffer, nRead);
                    if (!SendRequest(TFileConst.idUploadData, su))
                        break;
                    if (m_rs != null)
                    {
                        m_lFileSize += nRead;
                        double dAll = m_lRemoteFileSize;
                        m_rs.Invoke(100 * m_lFileSize / dAll);
                    }

                    //check how many bytes of data in client sending buffer
                    if (GetAttachedClientSocket().GetUSocket().BytesInSndMemory > MAX_SENDING_PENDING_DATA_SIZE)
                        break;

                    nRead = m_file.Read(buffer, 0, MAX_DATA_PACKET_SIZE);
                    su.UQueue.SetSize(0);
                }
            }
        }

        //You need to study the following samples and sites:
        //1. Tutorial 3 at C:\Program Files (x86)\UDAParts\SocketPro\tutorial\CSharp\SampleThree and 
        //   site http://www.udaparts.com/document/Tutorial/TutorialThree.htm
        //2. Video turorial Video tutorial 3-2 at the site http://www.udaparts.com/document/videos/videos.htm 
        //   and its attached sample.
        //3. Pay close attention to how to exchange any size of large data or file or collection of items.
        public bool UploadFile(string RemoteFilePath, string LocalFilePath, DReportStatus rs)
        {
            bool UploadFileRtn;
            //You may throw exception here instead of prompting a message.
            if (GetAttachedClientSocket().GetCountOfRequestsInQueue() > 0)
            {
                System.Windows.Forms.MessageBox.Show("Previous request not completed yet");
                return false;
            }
            try
            {
                m_rs = rs;
                m_lFileSize = 0;
                m_lRemoteFileSize = -1;
                m_file = new FileStream(LocalFilePath, FileMode.Open, FileAccess.Read);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show("Can not open a local file for reading data with error message = " + err.Message);
                return false;
            }

            m_lRemoteFileSize = m_file.Length;

            //tell remote server that the client is about to send a file with the length = m_lRemoteFileSize
            bool bProcessRy = ProcessR1(TFileConst.idLocalFileSize, RemoteFilePath, m_lRemoteFileSize, out UploadFileRtn);
            if (!bProcessRy)
            {
                m_file.Close();
                m_file = null;
                System.Windows.Forms.MessageBox.Show("Socket closed with error message = " + GetAttachedClientSocket().GetErrorMsg());
                return false;
            }
            if (!UploadFileRtn)
            {
                m_file.Close();
                m_file = null;
                System.Windows.Forms.MessageBox.Show("Can't open a remote file for writing at server side");
                return false;
            }
            UploadData();
            if (!WaitAll()) //wait until all of data is uploaded onto server
            {
                m_file.Close();
                m_file = null;
                System.Windows.Forms.MessageBox.Show("Socket closed with error message = " + GetAttachedClientSocket().GetErrorMsg());
                return false;
            }

            //inform remote server that there is no more data available
            bProcessRy = ProcessR1(TFileConst.idUploadFile, out UploadFileRtn);
            m_file.Close();
            m_file = null;
            return UploadFileRtn;
        }
    }

}