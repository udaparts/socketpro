﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SocketProAdapter;
using SocketProAdapter.ClientSide;
using USOCKETLib;

namespace ClientFile
{
    public partial class frmMain : Form
    {
        CClientSocket m_cs;
        RemoteFileClient.CFileAsyncHandler m_RemoteFile;

        public frmMain()
        {
            InitializeComponent();
            m_cs = new CClientSocket();
            m_RemoteFile = new RemoteFileClient.CFileAsyncHandler(m_cs);
        }

        private void EnableButtens(bool b)
        {
            btnDownload.Enabled = b;
            btnUpload.Enabled = b;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            m_cs.m_OnSocketConnected = delegate(int hSocket, int nErrorCode)
            {
                if (nErrorCode == 0)
                {
                    //Increasing sending and receiving buffer sizes properly at client side may speed up file exchange speed.
                    m_cs.GetUSocket().SetSockOpt((int)tagSocketOption.soSndBuf, 116800, (int)tagSocketLevel.slSocket);
                    m_cs.GetUSocket().SetSockOpt((int)tagSocketOption.soRcvBuf, 116800, (int)tagSocketLevel.slSocket);
                    m_cs.SetUID("Matt");
                    m_cs.SetPassword("Matt's Password");
                    EnableButtens(true);
                    
                    m_cs.BeginBatching();
                    m_cs.SwitchTo(m_RemoteFile);
                    //Increasing sending and receiving buffer sizes properly at server side may speed up file exchange speed.
                    m_cs.GetUSocket().SetSockOptAtSvr((int)tagSocketOption.soSndBuf, 116800, (int)tagSocketLevel.slSocket);
                    m_cs.GetUSocket().SetSockOptAtSvr((int)tagSocketOption.soRcvBuf, 116800, (int)tagSocketLevel.slSocket);
                    m_cs.Commit(false); //can't be true here !!!!
                }
                else
                    MessageBox.Show(m_cs.GetErrorMsg());
            };
            m_cs.m_OnSocketClosed = delegate(int hSocket, int nErrorCode)
            {
                EnableButtens(false);
                if(nErrorCode != 0)
                    MessageBox.Show(m_cs.GetErrorMsg());
            };

            m_cs.Connect("localhost", 20901);
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            string localFile;
            char []sep = {'/', '\\'};
            int pos = txtRemoteFile.Text.LastIndexOfAny(sep);
            localFile = txtRemoteFile.Text.Substring(pos + 1);
            m_RemoteFile.DownloadFile(txtRemoteFile.Text, localFile, delegate(double dPercent) {
                lblStatus.Text = "Downloaded: " + dPercent.ToString() + "%";
            });
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            string localFile = txtRemoteFile.Text;
            char[] sep = { '/', '\\' };
            int pos = localFile.LastIndexOfAny(sep);
            string remoteFile = localFile.Substring(pos + 1);
            m_RemoteFile.UploadFile(remoteFile, localFile, delegate(double dPercent)
            {
                lblStatus.Text = "Uploaded: " + dPercent.ToString() + "%";
            });
        }
    }
}
