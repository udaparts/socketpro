﻿using System;
using System.Text;
using SocketProAdapter.ServerSide;

namespace RemoteFileServer
{
    class Program
    {
        //we set this to MTA usually.
        [MTAThread] 
        static void Main(string[] args)
        {
            FileServer.CMySocketProServer MySocketProServer = new FileServer.CMySocketProServer();
            if (!MySocketProServer.Run(20901))
                Console.WriteLine("Error code = " + CSocketProServer.LastSocketError.ToString());
            Console.WriteLine("Input a line to close the application ......");
            string str = Console.ReadLine();
            MySocketProServer.StopSocketProServer(); //or MySocketProServer.Dispose();
        }
    }
}
