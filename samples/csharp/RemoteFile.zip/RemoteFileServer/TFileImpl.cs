/* **** including all of defines, service id(s) and request id(s) ***** */
using System;
using SocketProAdapter;
using SocketProAdapter.ServerSide;
using USOCKETLib; //you may need it for accessing various constants
using System.IO;

namespace FileServer
{
    class CFilePeer : CClientPeer
    {
        private FileStream m_file;
        private long m_lFileLength;
        private const int MAX_DATA_PACKET_SIZE = 20 * 1024;

        protected override void OnSwitchFrom(int nServiceID)
        {
            //initialize the object here
        }

        protected override void OnReleaseResource(bool bClosing, int nInfo)
        {
            if (bClosing)
            {
                //closing the socket with error code = nInfo
            }
            else
            {
                //switch to a new service with the service id = nInfo
            }

            CloseLocalFile();
            //release all of your resources here as early as possible
        }

        private void CloseLocalFile()
        {
            if (m_file != null)
            {
                m_file.Close();
                m_file = null;
            }
        }

        private void DownloadFile(string RemoteFilePath)
        {
            int res;
            FileStream readIn = null;
            try
            {
                readIn = new FileStream(RemoteFilePath, FileMode.Open, FileAccess.Read);
                SendResult(TFileConst.idRemoteFileOpened, (long)readIn.Length);
            }
            catch (Exception err)
            {
                //If failed, we tell a client that we can not open a file for downloading by sending -1.
                SendResult(TFileConst.idRemoteFileOpened, (long)-1);
                Console.WriteLine(err.Message);
                return;
            }
            byte[] buffer = new byte[MAX_DATA_PACKET_SIZE];
            using (CScopeUQueue su = new CScopeUQueue())
            {
                int nRead = readIn.Read(buffer, 0, MAX_DATA_PACKET_SIZE);
                while (nRead > 0)
                {
                    su.UQueue.Push(buffer, nRead);
                    res = SendResult(TFileConst.idDownloadData, su);

                    //client cancels downloading or shuts down TCP/IP connection
                    if (res == CClientPeer.REQUEST_CANCELED || res == CClientPeer.SOCKET_NOT_FOUND)
                        break;

                    nRead = readIn.Read(buffer, 0, MAX_DATA_PACKET_SIZE);
                    su.UQueue.SetSize(0);
                }
            }
            readIn.Close();
        }

        private void UploadFile(out bool UploadFileRtn)
        {
            UploadFileRtn = (m_file != null);
            CloseLocalFile();
        }

        private void IsAboutToUploadFile(string filePath, long length, out bool ok)
        {
            m_lFileLength = length;
            CloseLocalFile();
            try
            {
                m_file = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                ok = true;
            }
            catch (Exception err)
            {
                ok = false;
                Console.WriteLine(err.Message);
            }
        }

        private void UploadData()
        {
            if (m_file != null && m_UQueue.GetSize() > 0)
            {
                byte[] bytes;
                m_UQueue.Pop(out bytes);

                //write upload data from a client into server file
                m_file.Write(bytes, 0, bytes.Length);
            }
        }

        protected override void OnFastRequestArrive(short sRequestID, int nLen)
        {
            //pay close attention to the difference between finnal and generated codes.
            switch (sRequestID)
            {
                case TFileConst.idUploadFile:
                    M_I0_R1<bool>(UploadFile);
                    break;
                case TFileConst.idLocalFileSize:
                    M_I2_R1<string, long, bool>(IsAboutToUploadFile);
                    break;
                default:
                    break;
            }
        }

        protected override int OnSlowRequestArrive(short sRequestID, int nLen)
        {
            //pay close attention to the difference between finnal and generated codes.
            switch (sRequestID)
            {
                case TFileConst.idDownloadFile:
                    M_I1_R0<string>(DownloadFile);
                    break;
                case TFileConst.idUploadData:
                    M_I0_R0(UploadData);
                    break;
                default:
                    break;
            }
            return 0;
        }

    }

    public class CMySocketProServer : CSocketProServer
    {
        protected override bool OnSettingServer()
        {
            //try amIntegrated and amMixed instead by yourself
            Config.AuthenticationMethod = tagAuthenticationMethod.amOwn;

            //add service(s) into SocketPro server
            AddService();

            //You may set others here

            return true; //true -- ok; false -- no listening server
        }

        protected override void OnAccept(int hSocket, int nError)
        {
            //when a socket is initially established
        }

        protected override bool OnIsPermitted(int hSocket, int nSvsID)
        {
            //give permission to all
            return true;
        }

        protected override void OnClose(int hSocket, int nError)
        {
            //when a socket is closed
        }

        private CSocketProService<CFilePeer> m_File = new CSocketProService<CFilePeer>();
        //One SocketPro server supports any number of services. You can list them here!

        private void AddService()
        {
            bool ok;

            //No COM -- taNone; STA COM -- taApartment; and Free COM -- taFree
            ok = m_File.AddMe(TFileConst.sidRemoteFile, 0, tagThreadApartment.taNone);
            //If ok is false, very possibly you have two services with the same service id!


            ok = m_File.AddSlowRequest(TFileConst.idDownloadFile);
            
            //manually add this slow request so that we can write data into file within a worker thread
            ok = m_File.AddSlowRequest(TFileConst.idUploadData);

            //Add all of other services into SocketPro server here!
        }
    }

}