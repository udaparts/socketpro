﻿namespace TOneCe
{
    partial class frmDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.btnSleep = new System.Windows.Forms.Button();
            this.btnGetAll = new System.Windows.Forms.Button();
            this.btnQueryCount = new System.Windows.Forms.Button();
            this.btnQueryGlobalCount = new System.Windows.Forms.Button();
            this.btnGlobalFastCount = new System.Windows.Forms.Button();
            this.btnEchoData = new System.Windows.Forms.Button();
            this.txtSleep = new System.Windows.Forms.TextBox();
            this.txtCount = new System.Windows.Forms.TextBox();
            this.txtGlobalCount = new System.Windows.Forms.TextBox();
            this.txtGlobalFastCount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSleep
            // 
            this.btnSleep.Enabled = false;
            this.btnSleep.Location = new System.Drawing.Point(3, 59);
            this.btnSleep.Name = "btnSleep";
            this.btnSleep.Size = new System.Drawing.Size(77, 23);
            this.btnSleep.TabIndex = 0;
            this.btnSleep.Text = "Sleep";
            this.btnSleep.Click += new System.EventHandler(this.btnSleep_Click);
            // 
            // btnGetAll
            // 
            this.btnGetAll.Enabled = false;
            this.btnGetAll.Location = new System.Drawing.Point(3, 89);
            this.btnGetAll.Name = "btnGetAll";
            this.btnGetAll.Size = new System.Drawing.Size(111, 25);
            this.btnGetAll.TabIndex = 1;
            this.btnGetAll.Text = "Get All Counts";
            this.btnGetAll.Click += new System.EventHandler(this.btnGetAll_Click);
            // 
            // btnQueryCount
            // 
            this.btnQueryCount.Enabled = false;
            this.btnQueryCount.Location = new System.Drawing.Point(3, 120);
            this.btnQueryCount.Name = "btnQueryCount";
            this.btnQueryCount.Size = new System.Drawing.Size(97, 25);
            this.btnQueryCount.TabIndex = 2;
            this.btnQueryCount.Text = "QueryCount";
            this.btnQueryCount.Click += new System.EventHandler(this.btnQueryCount_Click);
            // 
            // btnQueryGlobalCount
            // 
            this.btnQueryGlobalCount.Enabled = false;
            this.btnQueryGlobalCount.Location = new System.Drawing.Point(3, 152);
            this.btnQueryGlobalCount.Name = "btnQueryGlobalCount";
            this.btnQueryGlobalCount.Size = new System.Drawing.Size(127, 26);
            this.btnQueryGlobalCount.TabIndex = 3;
            this.btnQueryGlobalCount.Text = "QueryGlobalCount";
            this.btnQueryGlobalCount.Click += new System.EventHandler(this.btnQueryGlobalCount_Click);
            // 
            // btnGlobalFastCount
            // 
            this.btnGlobalFastCount.Enabled = false;
            this.btnGlobalFastCount.Location = new System.Drawing.Point(3, 185);
            this.btnGlobalFastCount.Name = "btnGlobalFastCount";
            this.btnGlobalFastCount.Size = new System.Drawing.Size(154, 20);
            this.btnGlobalFastCount.TabIndex = 4;
            this.btnGlobalFastCount.Text = "QueryGlobalFastCount";
            this.btnGlobalFastCount.Click += new System.EventHandler(this.btnGlobalFastCount_Click);
            // 
            // btnEchoData
            // 
            this.btnEchoData.Enabled = false;
            this.btnEchoData.Location = new System.Drawing.Point(3, 212);
            this.btnEchoData.Name = "btnEchoData";
            this.btnEchoData.Size = new System.Drawing.Size(97, 20);
            this.btnEchoData.TabIndex = 5;
            this.btnEchoData.Text = "Echo Data";
            this.btnEchoData.Click += new System.EventHandler(this.btnEchoData_Click);
            // 
            // txtSleep
            // 
            this.txtSleep.AcceptsReturn = true;
            this.txtSleep.Location = new System.Drawing.Point(86, 59);
            this.txtSleep.Name = "txtSleep";
            this.txtSleep.Size = new System.Drawing.Size(71, 21);
            this.txtSleep.TabIndex = 6;
            this.txtSleep.Text = "1000";
            // 
            // txtCount
            // 
            this.txtCount.Location = new System.Drawing.Point(106, 124);
            this.txtCount.Name = "txtCount";
            this.txtCount.ReadOnly = true;
            this.txtCount.Size = new System.Drawing.Size(63, 21);
            this.txtCount.TabIndex = 7;
            // 
            // txtGlobalCount
            // 
            this.txtGlobalCount.Location = new System.Drawing.Point(136, 157);
            this.txtGlobalCount.Name = "txtGlobalCount";
            this.txtGlobalCount.ReadOnly = true;
            this.txtGlobalCount.Size = new System.Drawing.Size(53, 21);
            this.txtGlobalCount.TabIndex = 8;
            // 
            // txtGlobalFastCount
            // 
            this.txtGlobalFastCount.Location = new System.Drawing.Point(164, 183);
            this.txtGlobalFastCount.Name = "txtGlobalFastCount";
            this.txtGlobalFastCount.ReadOnly = true;
            this.txtGlobalFastCount.Size = new System.Drawing.Size(64, 21);
            this.txtGlobalFastCount.TabIndex = 9;
            // 
            // frmDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.txtGlobalFastCount);
            this.Controls.Add(this.txtGlobalCount);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.txtSleep);
            this.Controls.Add(this.btnEchoData);
            this.Controls.Add(this.btnGlobalFastCount);
            this.Controls.Add(this.btnQueryGlobalCount);
            this.Controls.Add(this.btnQueryCount);
            this.Controls.Add(this.btnGetAll);
            this.Controls.Add(this.btnSleep);
            this.Enabled = false;
            this.Menu = this.mainMenu1;
            this.Name = "frmDemo";
            this.Text = "Tutorial One on CE";
            this.Load += new System.EventHandler(this.frmDemo_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSleep;
        private System.Windows.Forms.Button btnGetAll;
        private System.Windows.Forms.Button btnQueryCount;
        private System.Windows.Forms.Button btnQueryGlobalCount;
        private System.Windows.Forms.Button btnGlobalFastCount;
        private System.Windows.Forms.Button btnEchoData;
        private System.Windows.Forms.TextBox txtSleep;
        private System.Windows.Forms.TextBox txtCount;
        private System.Windows.Forms.TextBox txtGlobalCount;
        private System.Windows.Forms.TextBox txtGlobalFastCount;
    }
}

