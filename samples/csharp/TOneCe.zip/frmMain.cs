﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SocketProAdapter;
using SocketProAdapter.ClientSide;

namespace TOneCe
{
    public partial class frmDemo : Form
    {
        private CTOne m_TOneAsync;
        private CClientSocket m_cs = new CClientSocket();
        public frmDemo()
        {
            InitializeComponent();
            m_TOneAsync = new CTOne(m_cs);
        }

        private void btnSleep_Click(object sender, EventArgs e)
        {
            int Sleep;
            try
            {
                Sleep = int.Parse(txtSleep.Text);
            }
            catch
            {
                Sleep = 1000;
            }
            m_TOneAsync.Sleep(Sleep);
        }

        private void btnGetAll_Click(object sender, EventArgs e)
        {
            int Count, GlobalCount, FastCount;
            m_TOneAsync.GetAllCounts(out Count, out GlobalCount, out FastCount);
            txtCount.Text = Count.ToString();
            txtGlobalCount.Text = GlobalCount.ToString();
            txtGlobalFastCount.Text = FastCount.ToString();
        }

        private void btnQueryCount_Click(object sender, EventArgs e)
        {
            txtCount.Text = m_TOneAsync.QueryCount().ToString();
        }

        private void btnQueryGlobalCount_Click(object sender, EventArgs e)
        {
            txtGlobalCount.Text = m_TOneAsync.QueryGlobalCount().ToString();
        }

        private void btnGlobalFastCount_Click(object sender, EventArgs e)
        {
            txtGlobalFastCount.Text = m_TOneAsync.QueryGlobalFastCount().ToString();
        }

        private void btnEchoData_Click(object sender, EventArgs e)
        {
            object[] arr = { DateTime.Now, "some" };
            object[] data = { 1, "test", true, 2456.23, null, arr};
            object res = m_TOneAsync.Echo(data);
            res = null; //compare data and res here by use of debug break point
        }

        private void EnableButtons(bool bEnable)
        {
            btnEchoData.Enabled = bEnable;
            btnGetAll.Enabled = bEnable;
            btnGlobalFastCount.Enabled = bEnable;
            btnQueryCount.Enabled = bEnable;
            btnSleep.Enabled = bEnable;
            btnQueryGlobalCount.Enabled = bEnable;
        }

        private void frmDemo_Load(object sender, EventArgs e)
        {
            m_cs.m_OnSocketClosed += delegate(int hSocket, int nError)
            {
                EnableButtons(false);
            };

            m_cs.m_OnSocketConnected += delegate(int hSocket, int nError)
            {
                if (nError == 0)
                {
                    EnableButtons(true);
                    m_cs.SetPassword("MyPasswordXYZ");
                    m_cs.SetUID("MyUserId");
                    m_cs.SwitchTo(m_TOneAsync);
                }
                else
                {
                    MessageBox.Show("Bad connection with error code = " + nError.ToString());
                }
            };

            m_cs.Connect("SomeRemoteServerName_Or_111.222.212.121", 20901);
        }
    }
}