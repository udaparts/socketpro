
#ifndef ___SECURE_COMM_SSPI_I_H__
#define ___SECURE_COMM_SSPI_I_H__

#include "../../shared/membuffer.h"

#ifndef SECURITY_WIN32
#define SECURITY_WIN32
#endif
#include <security.h>
#include <wincrypt.h>
#include <sspi.h>
#include <schannel.h>

namespace SC {

	enum tagCertType
	{
		ctRoot = 0,
		ctCa = 1,
		ctMy = 2,
		ctSpc = 3
	};

	typedef BOOL (WINAPI *PCertGetCertificateChain)(HCERTCHAINENGINE hChainEngine,
		PCCERT_CONTEXT pCertContext,
		LPFILETIME pTime,
		HCERTSTORE hAdditionalStore,
		PCERT_CHAIN_PARA pChainPara,
		DWORD dwFlags,
		LPVOID pvReserved,
		PCCERT_CHAIN_CONTEXT* ppChainContext);

	class CScCert
	{
	public:
		CScCert();
		~CScCert();

	public:
		bool IsOpened() const;
		bool OpenFromPfxFile(const wchar_t *filePfx, const wchar_t *password);
		void Close();
		HCERTSTORE GetCertStore() const;
		bool OpenStore(tagCertType ct = ctRoot);
		bool OpenStore(const wchar_t *certFile);
		static void SetCertGetCertificateChainFunc();

	public:
		static PCertGetCertificateChain CertGetCertificateChain;

	private:
		CScCert(const CScCert &cert);
		CScCert& operator=(const CScCert &cert);
		HCERTSTORE m_hCertStore;
	};

	enum tagSslHandshakeState
	{
		hsStart = 0,
		hsShaking = 1,
		hsDone = 2
	};

	class CSspi
	{
	public:
		CSspi(bool client, PCredHandle pCredHandle);
		~CSspi();

	public:
		bool IsInitialized() const;
		bool DoHandshake(const unsigned char *buffer, DWORD dwSize, CBuffer &token);
		tagSslHandshakeState GetHandshakeState() const;
		SECURITY_STATUS GetLastStatus() const;
		bool Decrypt(const unsigned char *buffer, DWORD dwSize, CBuffer &read);
		SECURITY_STATUS Encrypt(const unsigned char *buffer, DWORD dwSize, CBuffer &write);
		PCCERT_CONTEXT GetCertContext() const;
		PSecHandle GetCtxHandle() const;

	private:
		CSspi(const CSspi &sspi);
		CSspi& operator=(const CSspi &sspi);
		void DeleteContext();
		void DeleteCertContext();

	private:
		CScopeBuffer m_sbIn;
		CScopeBuffer m_sbOut;
		bool m_client;
		PCredHandle m_pCredHandle;
		CtxtHandle m_CtxHandle;
		SecPkgContext_StreamSizes	m_StreamSizes;
		tagSslHandshakeState m_hs;
		SECURITY_STATUS m_ss;
		TimeStamp m_tsExpiry;
		CBuffer &m_qIn;
		CBuffer &m_qOut;
		PCCERT_CONTEXT	m_pCertContext;
	};

}

#endif