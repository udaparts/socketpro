
namespace SC {
	enum tagSSLState {
		ssUnknown = 0,
		ssClientHello,
		ssHandshaking,
		ssFinished,
	};
	
} //namespace SC
