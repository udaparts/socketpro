
#include "stdafx.h"
#include "../../shared/sccommclient.h"
#include "sslsession.h"
#include "clientcertificateimpl.h"
#include <string>

namespace SC 
{
	CWinSocketStartup CWinSocketStartup::m_startup;
	namespace ClientSide {
		CClientInit CClientInit::ClientInit;
	}
}

using namespace SC;
using namespace SC::ClientSide;

IClientSession* WINAPI DoClientConnection(SessionCallback sc, const char *host, unsigned int port, unsigned int timedout, bool autoConnecting, bool v6)
{
	if (!sc.OnArrive)
		return nullptr;
	CSslSession *session = new CSslSession(sc, host, port, timedout, autoConnecting, v6);
	session->Start();
	return session;
}

void WINAPI DestroyClient(IClientSession *session)
{
	CSslSession *s = dynamic_cast<CSslSession *>(session);
	if (s)
	{
		s->Destroy();
		delete s;
	}
}

int WINAPI SetCertificateVerifyFile(const char *caFile)
{
	SC::CErrCode ec;
	CClientCertificateImpl::CertStore.Close();
	if (caFile)
	{
		bool ok;
		if (std::string("ROOT") == caFile)
			ok = CClientCertificateImpl::CertStore.OpenStore(ctRoot);
		else if (std::string("MY") == caFile)
			ok = CClientCertificateImpl::CertStore.OpenStore(ctMy);
		else if (std::string("CA") == caFile)
			ok = CClientCertificateImpl::CertStore.OpenStore(ctCa);
		else if (std::string("SPC") == caFile)
			ok = CClientCertificateImpl::CertStore.OpenStore(ctSpc);
		else
		{
			std::string s(caFile);
			std::wstring file(s.begin(), s.end());
			ok = CClientCertificateImpl::CertStore.OpenStore(file.c_str());
		}
		if (!ok)
			ec.assign(::GetLastError(), std::system_category());
		else
		{
			CScCert::SetCertGetCertificateChainFunc();
		}
	}
	return ec.value();
}