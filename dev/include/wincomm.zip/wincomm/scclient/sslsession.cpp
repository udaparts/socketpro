#include "stdafx.h"
#include "sslsession.h"

namespace SC { namespace ClientSide {

	CSslSession::CSslSession(SessionCallback sc, const char *host, unsigned int port, unsigned int timedout, bool autoConnecting, bool v6)
		: m_bEndianDiff(false),
		m_ss(ssClosed),
		m_hSocket(INVALID_SOCKET),
		m_qRead(256 * 1024, 128 * 1024),
		m_qWrite(256 * 1024, 128 * 1024),
		m_sc(sc),
		m_AutoConnecting(autoConnecting),
		m_strHost(host),
		m_port(port),
		m_timedout(timedout),
		m_v6(v6),
		m_id(0),
		m_hEvent(::CreateEvent(nullptr, FALSE, FALSE, nullptr)),
		m_bReconnecting(false)
	{
		::memset(&m_hCreds, 0, sizeof(m_hCreds));
	}

	CSslSession::~CSslSession()
	{
		FreeCredHandle();
		if (m_hSocket != INVALID_SOCKET)
			::closesocket(m_hSocket);
		::CloseHandle(m_hEvent);
	}

	void CSslSession::OnCloseInternal()
	{
		int res = ::closesocket(m_hSocket);
		m_cv.notify_all();
		if (m_sc.OnClose && !m_bReconnecting)
			m_sc.OnClose(this);
		m_cs.lock();
		m_ss = ssClosed;
		m_cs.unlock();
		m_hSocket = INVALID_SOCKET;
		m_pCert.reset();
		Initialize();
	}

	ICertificate* CSslSession::GetCertificate()
	{
		CAutoLock al(m_cs);
		return m_pCert.get();
	}

	void CSslSession::PostClose(int errCode)
	{
		PostThreadMessage(m_id, WM_POSTCLOSE, errCode, 0);
	}

	tagSessionState CSslSession::GetSessionState()
	{
		CAutoLock al(m_cs);
		return m_ss;
	}

	bool CSslSession::IsDiffEndian()
	{
		CAutoLock al(m_cs);
		return m_bEndianDiff;
	}

	bool CSslSession::IsAutoConnecting()
	{
		return m_AutoConnecting;
	}

	bool CSslSession::WaitAll(unsigned int ms)
	{
		//don't permit calling this method from hosting thread
		if (::GetCurrentThreadId() == m_id)
			return false;

		auto now = std::chrono::system_clock::now();
		CAutoLock al(m_cs);
		if (!m_deqRequest.size())
			return true;
		return (m_cv.wait_until(al, now + std::chrono::milliseconds(ms)) == std::cv_status::no_timeout && m_ss >= ssConnected);
	}

	bool CSslSession::ProcessInternal()
	{
		unsigned short id;
		if (m_qRead.GetSize() < sizeof(CRequestHeader) && !m_rh.RequestId)
			return false;
		if (!m_rh.RequestId) {
			m_qRead >> m_rh;
			if (m_bEndianDiff) {
				CBuffer::ChangeEndian((unsigned char*)m_rh.RequestId, sizeof(m_rh.RequestId));
				CBuffer::ChangeEndian((unsigned char*)m_rh.Size, sizeof(m_rh.Size));
			}
		}
		if (m_qRead.GetSize() < m_rh.Size)
			return false;
		if (m_rh.RequestId == idServerException)
			id = *((const unsigned short *)m_qRead.GetBuffer());
		else
			id = m_rh.RequestId;

		if (m_sc.OnArrive)
			m_sc.OnArrive(this, m_rh.RequestId, m_rh.Size);

		{
			CAutoLock al(m_cs);
			size_t count = m_deqRequest.size();
			if (count)
			{
				if (m_deqRequest.front() == id)
				{
					m_deqRequest.pop_front();
					--count;
				}
				if (!count)
					m_cv.notify_all();
			}
		}
		m_qRead.Pop(m_rh.Size);
		m_rh.Reset();
		return true;
	}

	unsigned int CSslSession::Retrieve(unsigned char *receiver, unsigned int size)
	{
		if(!receiver || !size)
			return 0;
		if (::GetCurrentThreadId() != m_id)
			return BAD_RETRIEVE_THREAD;
		if (size > m_rh.Size)
			size = m_rh.Size;
		if (size > m_qRead.GetSize())
			size = m_qRead.GetSize();
		m_qRead.Pop(receiver, size);
		m_rh.Size -= size;
		return size;
	}

	unsigned int CSslSession::Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool oneWay)
	{
		if (RequestId < idStartRequestId && RequestId != idAuthentication) 
			return BAD_REQUEST;
		if (!buffer)
			size = 0;
		CRequestHeader rh;
		rh.RequestId = RequestId;
		rh.Size = size;
		m_cs.lock();
		if (m_ss < ssConnected)
		{
			m_cs.unlock();
			return SESSION_CLOSED;
		}
		if (m_pSspi)
		{
			m_cs.unlock();
			CScopeBuffer sb;
			sb << rh;
			sb->Push(buffer, size);
			m_cs.lock();
			SECURITY_STATUS ss = m_pSspi->Encrypt(sb->GetBuffer(), sb->GetSize(), m_qWrite);
			assert(ss == SEC_E_OK);
		}
		else
		{
			m_qWrite << rh;
			m_qWrite.Push(buffer, size);
		}
		Write();
		if (!oneWay)
			m_deqRequest.push_back(RequestId);
		m_cs.unlock();
		return size;
	}

	unsigned int CSslSession::GetSendingBufferSize()
	{
		CAutoLock al(m_cs);
		return m_qWrite.GetSize();
	}

	int CSslSession::GetErrCode()
	{
		CAutoLock al(m_cs);
		return m_ec.value();
	}

	unsigned int CSslSession::GetErrMsg(char *recv, unsigned int size)
	{
		if (!size || !recv)
			return 0;
		--size;
		if (!size)
			return 0;
		std::string str;
		m_cs.lock();
		if (m_ec)
			str = m_ec.message();
		m_cs.unlock();

		size_t len = str.size();
		if(size > (unsigned int)len)
			size = (unsigned int)len;
		::memcpy(recv, str.c_str(), size);
		recv[size] = '\0';
		return size;
	}

	size_t CSslSession::GetRequestCountQueued()
	{
		CAutoLock al(m_cs);
		return m_deqRequest.size();
	}

	void CSslSession::handle_read() 
	{
		m_bReconnecting = false;
		{
			CAutoLock al(m_cs);
			if (m_ss < ssAuthentcated && m_qRead.GetSize() >= sizeof(m_rh))
			{
				//peek the first 8 bytes of data
				CRequestHeader *rh = (CRequestHeader*)m_qRead.GetBuffer();
				switch (rh->RequestId)
				{
				case idAuthenticationReserved:
					m_bEndianDiff = true;
				case idAuthentication:
					{
						unsigned int size = rh->Size;
						if (m_bEndianDiff)
							CBuffer::ChangeEndian((unsigned char*)&size, sizeof(size));
						if (rh->Size <= MAX_LEN_PER_IO_TRANS)
						{
							m_ss = ssAuthentcated;
							break;
						}
					}
				default:
					m_ec.assign(ERROR_ACCESS_DENIED, std::system_category());
					OnCloseInternal();
					break;
				}	 
			}
		}
		while(ProcessInternal())
		{
		}
	}

	void CSslSession::Write()
	{
		if (m_qWrite.GetSize() == 0)
			return;
		int res = send(m_hSocket, (const char*)m_qWrite.GetBuffer(), (int)m_qWrite.GetSize(), 0);
		if (res > 0)
			m_qWrite.Pop((unsigned int)res);
		else if (res == SOCKET_ERROR)
		{
			res = ::WSAGetLastError();
			if (res != WSAEWOULDBLOCK)
			{
				PostClose(res);
				return;
			}
		}
		if (m_ss >= ssAuthentcated && m_qWrite.GetSize() == 0 && m_sc.OnLess)
			m_sc.OnLess(this);
	}

	void CSslSession::OnLessInternal()
	{
		m_sc.OnLess(this);
	}

	void CSslSession::Initialize()
	{
		m_bEndianDiff = false;
		m_ss = ssClosed;
		m_qRead.SetSize(0);
		m_qWrite.SetSize(0);
		::memset(&m_rh, 0, sizeof(m_rh));
		m_deqRequest.clear();
		m_pSspi.reset();
		m_bReconnecting = false;
	}

	bool CSslSession::StartConnecting()
	{
		m_hSocket = socket(m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (m_hSocket == INVALID_SOCKET)
		{
			m_ec.assign(::WSAGetLastError(), std::system_category());
			return false;
		}
		int res = WSAEventSelect(m_hSocket, m_hEvent, FD_CONNECT|FD_CLOSE|FD_READ|FD_WRITE);
		if (res != 0)
		{
			m_ec.assign(::WSAGetLastError(), std::system_category());
			return false;
		}

		std::string port = std::to_string(m_port);
		struct addrinfo aiHints;
		struct addrinfo *aiList = nullptr;
		memset(&aiHints, 0, sizeof(aiHints));
		aiHints.ai_family = m_v6 ? AF_INET6 : AF_INET;
		aiHints.ai_socktype = SOCK_STREAM;
		aiHints.ai_protocol = IPPROTO_TCP;
		res = getaddrinfo(m_strHost.c_str(), port.c_str(), &aiHints, &aiList);
		if (res != 0)
		{
			m_ec.assign(::WSAGetLastError(), std::system_category());
			return false;
		}
		m_ss = ssConnecting;
		res = connect(m_hSocket, aiList->ai_addr, m_v6 ? sizeof(sockaddr_in6) : sizeof(sockaddr_in));
		if (res == SOCKET_ERROR)
		{
			res = ::WSAGetLastError();
			if (res != WSAEWOULDBLOCK)
			{
				m_ec.assign(res, std::system_category());
				return false;
			}
		}
		return true;
	}

	void CSslSession::OnConencted(int errCode)
	{
		m_pCert.reset();
		m_qRead.SetSize(0);
		m_qWrite.SetSize(0);
		if (errCode == 0)
		{
			m_ss = ssConnected;
			int optValue = 64 * 1024;
			int res = setsockopt(m_hSocket, SOL_SOCKET, SO_RCVBUF, (const char*)&optValue, sizeof(optValue));
			res = setsockopt(m_hSocket, SOL_SOCKET, SO_SNDBUF, (const char*)&optValue, sizeof(optValue));
			u_long iMode = 1;
			res = ::ioctlsocket(m_hSocket, FIONBIO, &iMode);
			if (!CClientCertificateImpl::CertStore.IsOpened())
			{
				m_cv.notify_all();
				if (m_bReconnecting) {
					//re-send authentication data
				}
			}
		}
		else
		{
			m_cs.lock();
			m_ec.assign(errCode, std::system_category());
			m_cs.unlock();
			OnCloseInternal();
		}
	}

	void CSslSession::OnWritable(int errCode)
	{
		if (m_ss < ssConnected)
			return;
		if (errCode)
		{
			PostClose(errCode);
		}
		else
		{
			if (CClientCertificateImpl::CertStore.IsOpened() && m_ss <= ssSslHandshaking)
			{
				SECURITY_STATUS ss = OpenCred();
				if (ss == SEC_E_OK)
				{
					m_pSspi.reset(new CSspi(true, &m_hCreds));
					bool ok = m_pSspi->DoHandshake(m_qRead.GetBuffer(), m_qRead.GetSize(), m_qWrite);
					assert(ok);
					m_ss = ssSslHandshaking;
					Write();
				}
				else
					PostClose(ss);
			}
			else
			{
				CAutoLock al(m_cs);
				Write();
			}
		}
	}

	void CSslSession::OnAvailable(int errCode)
	{
		if (m_ss == ssClosed && m_AutoConnecting) 
		{
			m_bReconnecting = true;
			StartConnecting();
			return;
		}

		if (m_ss < ssConnected)
			return;

		if (errCode)
		{
			PostClose(errCode);
		}
		else
		{
			if (m_pSspi)
			{
				if (m_ss < ssSslHandshaked)
				{
					int res = recv(m_hSocket, (char*)m_qRead.GetBuffer(m_qRead.GetSize()), m_qRead.GetTailSize(), 0);
					if (res == SOCKET_ERROR || res == 0)
					{
						PostClose(WSAECONNABORTED);
						return;
					}

					m_qRead.SetSize(m_qRead.GetSize() + (unsigned int)res);
					bool ok = m_pSspi->DoHandshake(m_qRead.GetBuffer(), m_qRead.GetSize(), m_qWrite);
					m_qRead.SetSize(0);
					if (ok)
					{
						if (m_pSspi->GetHandshakeState() == hsDone)
						{
							m_ss = ssSslHandshaked;
							m_pCert.reset(new CClientCertificateImpl(m_pSspi, m_strHost.c_str()));
							m_cv.notify_all();
							if (m_sc.OnSslHandshakeDone)
								m_sc.OnSslHandshakeDone(this);
							if (m_bReconnecting) {
								//re-send authentication data
							}
						}
						else
							Write();
					}
					else
					{
						PostClose(m_pSspi->GetLastStatus());
					}
				}
				else
				{
					int res;
					CScopeBuffer sb;
					do
					{
						res = ::recv(m_hSocket, (char*)sb->GetBuffer(), (int)sb->GetMaxSize(), 0);
						if (res > 0)
						{
							if (!m_pSspi->Decrypt(sb->GetBuffer(), (DWORD)res, m_qRead))
							{
								PostClose(m_pSspi->GetLastStatus());
								return;
							}
						}
						else if (res == SOCKET_ERROR)
						{
							res = ::WSAGetLastError();
							if (res != WSAEWOULDBLOCK)
							{
								PostClose(res);
								return;
							}
						}
						handle_read();
					} while(res == (int)sb->GetMaxSize());
				}
			}
			else
			{
				int res;
				int max;
				do
				{
					m_qRead.SetHeadPosition();
					max = (int)m_qRead.GetTailSize();
					if (max == 0) {
						m_qRead.ReallocBuffer(m_qRead.GetSize() + MAX_LEN_PER_IO_TRANS);
						max = (int)m_qRead.GetTailSize();
					}
					res = recv(m_hSocket, (char*)m_qRead.GetBuffer(m_qRead.GetSize()), max, 0);
					if (res > 0)
					{
						m_qRead.SetSize(m_qRead.GetSize() + (unsigned int)res);
						handle_read();
					}
					else if (res == SOCKET_ERROR)
					{
						res = ::WSAGetLastError();
						if (res != WSAEWOULDBLOCK)
							PostClose(res);
						break;
					}
				}while(res >= max);
			}
		}
	}

	void CSslSession::FreeCredHandle()
	{
		if (m_hCreds.dwLower || m_hCreds.dwUpper)
		{
			FreeCredentialsHandle(&m_hCreds);
			memset(&m_hCreds, 0, sizeof(m_hCreds));
		}
	}

	SECURITY_STATUS CSslSession::OpenCred()
	{
		SECURITY_STATUS Status = SEC_E_OK;
		SCHANNEL_CRED SchannelCred;
		memset(&SchannelCred, 0, sizeof(SchannelCred));
		SchannelCred.dwVersion  = SCHANNEL_CRED_VERSION;
		SchannelCred.grbitEnabledProtocols = SP_PROT_SSL3TLS1_X_CLIENTS;
		SchannelCred.dwFlags = (SCH_CRED_NO_DEFAULT_CREDS | SCH_CRED_MANUAL_CRED_VALIDATION | SCH_CRED_REVOCATION_CHECK_CHAIN);
		SECURITY_STATUS ss = AcquireCredentialsHandle(	nullptr,
			SCHANNEL_NAME,
			SECPKG_CRED_OUTBOUND,
			nullptr,
			&SchannelCred,
			nullptr,
			nullptr,
			&m_hCreds,
			nullptr);
		return ss;
	}

	void CSslSession::OnClosed(int errCode)
	{
		m_cs.lock();
		m_ec.assign(errCode, std::system_category());
		m_cs.unlock();
		OnCloseInternal();
		FreeCredHandle();
	}

	void CSslSession::DoConnetionInternal()
	{
		DWORD dwRes;
		m_id = ::GetCurrentThreadId();
		if (!StartConnecting())
			return;
		DWORD nCount = 1;
		do
		{
			dwRes = ::MsgWaitForMultipleObjects(nCount, &m_hEvent, FALSE, 40, QS_ALLEVENTS);
			if (dwRes >= WAIT_OBJECT_0 && dwRes <= (WAIT_OBJECT_0 + nCount - 1))
			{
				WSANETWORKEVENTS NetworkEvents;
				memset(&NetworkEvents, 0, sizeof(NetworkEvents));
				int nRtn = ::WSAEnumNetworkEvents(m_hSocket, m_hEvent, &NetworkEvents);
				if ((NetworkEvents.lNetworkEvents & FD_CONNECT) == FD_CONNECT)
					OnConencted(NetworkEvents.iErrorCode[FD_CONNECT_BIT]);
				if ((NetworkEvents.lNetworkEvents & FD_WRITE) == FD_WRITE)
					OnWritable(NetworkEvents.iErrorCode[FD_WRITE_BIT]);
				else if ((NetworkEvents.lNetworkEvents & FD_READ) == FD_READ)
					OnAvailable(NetworkEvents.iErrorCode[FD_READ_BIT]);
				else if ((NetworkEvents.lNetworkEvents & FD_CLOSE) == FD_CLOSE)
					OnClosed(NetworkEvents.iErrorCode[FD_CLOSE_BIT]);
			}
			else if (dwRes == WAIT_OBJECT_0 + nCount)
			{
				MSG	msg;
				while (::PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
				{
					switch(msg.message)
					{
					case WM_POSTCLOSE:
						{
							m_cs.lock();
							m_ec.assign((int)msg.wParam, std::system_category());
							m_cs.unlock();
							OnCloseInternal();
						}
						break;
					case WM_QUIT:
						return; //thread shutdown
					default:
						break;
					}
				}
			}
			else if (dwRes >= WAIT_ABANDONED_0 && dwRes <= (WAIT_ABANDONED_0 + nCount - 1))
			{
				dwRes = 0;
			}
			else if (dwRes == WAIT_TIMEOUT)
			{
				OnAvailable(0);
				CAutoLock al(m_cs);
				if (m_ss >= ssAuthentcated)
					Write();
			}
			else
			{
				assert(false);
			}
		}while(true);
	}

	void CSslSession::Destroy()
	{
		::PostThreadMessage(m_id, WM_QUIT, 0, 0);
		m_pHostThread->join();
		CAutoLock al(m_cs);
		m_pHostThread.reset();
	}

	bool CSslSession::Start()
	{
		CAutoLock al(m_cs);
		if (m_pHostThread)
			return true;
		m_pHostThread.reset(new std::thread(std::bind(&CSslSession::DoConnetionInternal, this)));
		return (m_cv.wait_for(al, std::chrono::milliseconds(m_timedout)) != std::cv_status::timeout);
	}

} //namespace ClientSide
} //namespace SC
