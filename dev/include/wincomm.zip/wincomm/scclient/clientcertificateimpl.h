
#ifndef _SECURE_COMM_CLIENT_CERTIFICATE_IMPL_H_
#define _SECURE_COMM_CLIENT_CERTIFICATE_IMPL_H_

#include "initclient.h"
#include "../../shared/sccommclient.h"
#include "../commshared/scsspi.h"

namespace SC { namespace ClientSide {

	class CClientCertificateImpl : public ICertificate
	{
	public:
		CClientCertificateImpl(std::shared_ptr<CSspi> pSspi, const char *serverName);
		virtual ~CClientCertificateImpl();

	public:
		//implementation for interface ICertificate
		virtual const char* const Verify(int *errCode);
		virtual const char* const GetCertPem();
		virtual bool IsValid();
		virtual const char* const GetSessionInfo();
		virtual const char* const GetSubject();
		virtual const char* const GetIssuer();
		virtual const unsigned char* const GetPublicKey(unsigned int *pKeySize);

	private:
		//disable copy constructor and assignment operator
		CClientCertificateImpl(const CClientCertificateImpl &cert);
		CClientCertificateImpl& operator=(const CClientCertificateImpl &cert);

		void SetPerm();
		void SetSessionInfo();
		void SetPublickey();
		static const char* const DisplayErrorMessage(DWORD status);

	public:
		static CScCert CertStore;

	private:
		std::shared_ptr<CSspi> m_pSspi;
		std::string m_strIssuer;
		std::string m_strSubject;
		std::string m_strPerm;
		std::string m_strSessionInfo;
		std::vector<unsigned char> m_vPublicKey;
		std::wstring m_strServerName;
	};

} //namespace ClientSide
} //namespace SC

#endif