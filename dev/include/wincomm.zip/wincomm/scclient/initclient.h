
#ifndef _SC_CLIENT_DEFAULT_INIT_H_
#define _SC_CLIENT_DEFAULT_INIT_H_

#include "../commshared/scsspi.h"

namespace SC { namespace ClientSide {

	struct CClientInit
	{
		CClientInit();
		static CClientInit ClientInit;
	};

} //namespace ClientSide
} //namespace SC

#endif