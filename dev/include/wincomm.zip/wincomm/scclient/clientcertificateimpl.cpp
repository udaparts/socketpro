#include "stdafx.h"
#include "clientcertificateimpl.h"
#include "../../shared/membuffer.h"
#include "../../shared/sccommclient.h"

namespace SC { namespace ClientSide {

	CScCert CClientCertificateImpl::CertStore;

	CClientCertificateImpl::CClientCertificateImpl(std::shared_ptr<CSspi> pSspi, const char *serverName)
		: m_pSspi(pSspi),
		m_strSessionInfo("SSL version: ")
	{
		std::string s(serverName);
		m_strServerName.assign(s.begin(), s.end());
		SetSessionInfo();
		SetPerm();
		SetPublickey();
	}

	CClientCertificateImpl::~CClientCertificateImpl()
	{

	}

	void CClientCertificateImpl::SetPublickey()
	{
		unsigned char *p = m_pSspi->GetCertContext()->pCertInfo->SubjectPublicKeyInfo.PublicKey.pbData;
		unsigned int len = m_pSspi->GetCertContext()->pCertInfo->SubjectPublicKeyInfo.PublicKey.cbData;
		m_vPublicKey.assign(p, p + len);
	}

	void CClientCertificateImpl::SetSessionInfo()
	{
		char szName[4096] = {0};
		PCCERT_CONTEXT p = m_pSspi->GetCertContext();
		CertNameToStrA(p->dwCertEncodingType, &p->pCertInfo->Issuer, CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, szName, sizeof(szName));
		m_strIssuer = szName;
		CertNameToStrA(p->dwCertEncodingType, &p->pCertInfo->Subject, CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, szName, sizeof(szName));
		m_strSubject = szName;

		SecPkgContext_ConnectionInfo ConnectionInfo;
		PSecHandle sc = m_pSspi->GetCtxHandle();
		SECURITY_STATUS ss = QueryContextAttributes(sc, SECPKG_ATTR_CONNECTION_INFO, &ConnectionInfo);
		if (ss == SEC_E_OK)
		{
			switch(ConnectionInfo.dwProtocol)
			{
			case SP_PROT_TLS1_2_CLIENT:
				m_strSessionInfo += "TLS1_2";
				break;
			case SP_PROT_TLS1_1_CLIENT:
				m_strSessionInfo += "TLS1_1";
				break;
			case SP_PROT_TLS1_CLIENT:
				m_strSessionInfo += "TLS1";
				break;
			case SP_PROT_SSL3_CLIENT:
				m_strSessionInfo += "SSL3";
				break;
			default:
				break;
			}

			switch (ConnectionInfo.aiCipher)
			{
			case CALG_3DES:
				m_strSessionInfo += ", Cipher: 3DES";
				break;
			case CALG_DES:
				m_strSessionInfo += ", Cipher: DES";
				break;
			case CALG_RC2:
				m_strSessionInfo += ", Cipher: RC2";
				break;
			case CALG_RC4:
				m_strSessionInfo += ", Cipher: RC4";
				break;
			case CALG_AES_128:
				m_strSessionInfo += ", Cipher: AES_128";
				break;
			case CALG_AES_192:
				m_strSessionInfo += ", Cipher: AES_192";
				break;
			case CALG_AES_256:
				m_strSessionInfo += ", Cipher: AES_256";
				break;
			default:
				break;
			}

			m_strSessionInfo += (", Cipher strength: " + std::to_string(ConnectionInfo.dwCipherStrength) + " Bits");

			switch(ConnectionInfo.aiHash)
			{
			case CALG_MD5: 
				m_strSessionInfo += ", Hash: MD5";
				break;
			case CALG_SHA: 
				m_strSessionInfo += ", Hash: SHA";
				break;
			default: 
				break;
			}

			m_strSessionInfo += ", ";
			switch(ConnectionInfo.aiExch)
			{
			case CALG_RSA_KEYX: 
			case CALG_RSA_SIGN: 
				m_strSessionInfo += "Key exchange: RSA";
				break;
			case CALG_KEA_KEYX: 
				m_strSessionInfo += "Key exchange: KEA";
				break;
			case CALG_DH_EPHEM:
				m_strSessionInfo += "Key exchange: DH Ephemeral";
				break;
			default: 
				break;
			}

			m_strSessionInfo += ", Key size ";
			m_strSessionInfo += std::to_string(ConnectionInfo.dwExchStrength);
			m_strSessionInfo += " Bits";
		}
	}

	void CClientCertificateImpl::SetPerm()
	{

	}

	const char* const CClientCertificateImpl::Verify(int *errCode)
	{
		const char *errMsg = nullptr;
		if (CScCert::CertGetCertificateChain)
		{
			PCCERT_CHAIN_CONTEXT pChainContext = nullptr;
			LPSTR rgszUsages[] = {  szOID_PKIX_KP_SERVER_AUTH,
				szOID_SERVER_GATED_CRYPTO,
				szOID_SGC_NETSCAPE };
			DWORD	cUsages = sizeof(rgszUsages) / sizeof(LPSTR);
			CERT_CHAIN_PARA ChainPara;
			memset(&ChainPara, 0, sizeof(ChainPara));
			ChainPara.cbSize = sizeof(ChainPara);
			ChainPara.RequestedUsage.dwType = USAGE_MATCH_TYPE_OR;
			ChainPara.RequestedUsage.Usage.cUsageIdentifier     = cUsages;
			ChainPara.RequestedUsage.Usage.rgpszUsageIdentifier = rgszUsages;
			do
			{
				BOOL ok = CScCert::CertGetCertificateChain(nullptr,
					m_pSspi->GetCertContext(),
					nullptr,
					m_pSspi->GetCertContext()->hCertStore,
					&ChainPara,
					0,
					nullptr,
					&pChainContext);
				if (!ok)
				{
					if (errCode)
						*errCode = (int)::GetLastError();
					break;
				}

				HTTPSPolicyCallbackData  polHttps;
				CERT_CHAIN_POLICY_PARA   PolicyPara;
				CERT_CHAIN_POLICY_STATUS PolicyStatus;

				// Validate certificate chain.
				memset(&polHttps, 0, sizeof(HTTPSPolicyCallbackData));
				polHttps.cbStruct = sizeof(HTTPSPolicyCallbackData);
				polHttps.dwAuthType = AUTHTYPE_SERVER;
				polHttps.fdwChecks = 0;
				polHttps.pwszServerName = (wchar_t*)m_strServerName.c_str();

				memset(&PolicyPara, 0, sizeof(PolicyPara));
				PolicyPara.cbSize            = sizeof(PolicyPara);
				PolicyPara.pvExtraPolicyPara = &polHttps;
				PolicyPara.dwFlags = 4;

				memset(&PolicyStatus, 0, sizeof(PolicyStatus));
				PolicyStatus.cbSize = sizeof(PolicyStatus);

				ok = CertVerifyCertificateChainPolicy(	CERT_CHAIN_POLICY_SSL,
					pChainContext,
					&PolicyPara,
					&PolicyStatus);
				if (!ok)
				{
					if (errCode)
						*errCode = (int)::GetLastError();
					break;
				}
				else
				{
					if (errCode)
						*errCode = (int)PolicyStatus.dwError;
				}
				errMsg = DisplayErrorMessage(PolicyStatus.dwError);

			}while(false);
			if (pChainContext)
			{
				CertFreeCertificateChain(pChainContext);
			}
		}
		return errMsg;
	}

	const char* const CClientCertificateImpl::DisplayErrorMessage(DWORD status)
	{
		char *pszName;
		switch(status)
		{
		case CERT_E_EXPIRED:                pszName = "CERT_E_EXPIRED";                 break;
		case CERT_E_VALIDITYPERIODNESTING:  pszName = "CERT_E_VALIDITYPERIODNESTING";   break;
		case CRYPT_E_NO_REVOCATION_CHECK:   pszName = "CRYPT_E_NO_REVOCATION_CHECK";    break;
		case CRYPT_E_REVOCATION_OFFLINE:    pszName = "CRYPT_E_REVOCATION_OFFLINE";     break;
		case CRYPT_E_SELF_SIGNED:			pszName = "CRYPT_E_SELF_SIGNED";			break;
		case CERT_E_ROLE:                   pszName = "CERT_E_ROLE";                    break;
		case CERT_E_PATHLENCONST:           pszName = "CERT_E_PATHLENCONST";            break;
		case CERT_E_INVALID_NAME:           pszName = "CERT_E_INVALID_NAME";            break;
		case CERT_E_INVALID_POLICY:         pszName = "CERT_E_INVALID_POLICY";          break;
		case TRUST_E_BASIC_CONSTRAINTS:     pszName = "TRUST_E_BASIC_CONSTRAINTS";      break;
		case CERT_E_CRITICAL:               pszName = "CERT_E_CRITICAL";                break;
		case CERT_E_PURPOSE:                pszName = "CERT_E_PURPOSE";                 break;
		case CERT_E_ISSUERCHAINING:         pszName = "CERT_E_ISSUERCHAINING";          break;
		case CERT_E_MALFORMED:              pszName = "CERT_E_MALFORMED";               break;
		case CERT_E_UNTRUSTEDROOT:          pszName = "CERT_E_UNTRUSTEDROOT";           break;
		case CERT_E_CHAINING:               pszName = "CERT_E_CHAINING";                break;
		case TRUST_E_FAIL:                  pszName = "TRUST_E_FAIL";                   break;
		case CERT_E_REVOKED:                pszName = "CERT_E_REVOKED";                 break;
		case CERT_E_UNTRUSTEDTESTROOT:      pszName = "CERT_E_UNTRUSTEDTESTROOT";       break;
		case CERT_E_REVOCATION_FAILURE:     pszName = "CERT_E_REVOCATION_FAILURE";      break;
		case CERT_E_CN_NO_MATCH:            pszName = "CERT_E_CN_NO_MATCH";             break;
		case CERT_E_WRONG_USAGE:            pszName = "CERT_E_WRONG_USAGE";             break;
		default:                            pszName = "";								break;
		}
		return pszName;
	}

	const char* const CClientCertificateImpl::GetCertPem()
	{
		return m_strPerm.c_str();
	}

	bool CClientCertificateImpl::IsValid()
	{
		long res = CertVerifyTimeValidity(nullptr, m_pSspi->GetCertContext()->pCertInfo);
		return (res == 0);
	}

	const char* const CClientCertificateImpl::GetSessionInfo()
	{
		return m_strSessionInfo.c_str();
	}

	const char* const CClientCertificateImpl::GetSubject()
	{
		return m_strSubject.c_str();
	}

	const char* const CClientCertificateImpl::GetIssuer()
	{
		return m_strIssuer.c_str();
	}

	const unsigned char* const CClientCertificateImpl::GetPublicKey(unsigned int *pKeySize)
	{
		if (pKeySize)
			*pKeySize = (unsigned int)m_vPublicKey.size();
		return m_vPublicKey.data();
	}

} //namespace ClientSide
} //namespace SC
