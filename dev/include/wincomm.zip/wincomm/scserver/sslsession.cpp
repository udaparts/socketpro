#include "stdafx.h"
#include "sslsession.h"
#include "sclisten.h"
#include "../commshared/scsslsocketbase.h"

namespace SC {
	namespace ServerSide {

		CSslSession::CSslSession()
			: m_bEndianDiff(false),
			m_ss(ssClosed),
			m_bReading(false),
			m_ReadBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
			m_qRead(312 * 1024, 128 * 1024),
			m_bWriting(false),
			m_WriteBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
			m_qWrite(128 * 1024, 64 * 1024),
			m_bThreadingProcessing(false),
			m_hSocket(INVALID_SOCKET),
			m_dwBytesRecvd(0),
			m_dwFlagsRecvd(0),
			m_dwBytesSent(0),
			m_bWaiting(false)
		{
			memset(&m_sc, 0, sizeof(m_sc));
			memset(&m_olRead, 0, sizeof(m_olRead));
			memset(&m_olSent, 0, sizeof(m_olSent));
			memset(&m_wsaRecv, 0, sizeof(m_wsaRecv));
			memset(&m_wsaSend, 0, sizeof(m_wsaSend));
			m_hSocket = ::WSASocket(g_pListenServer->m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0,  WSA_FLAG_OVERLAPPED);
		}

		CSslSession::~CSslSession()
		{
			::free(m_ReadBuffer);
			::free(m_WriteBuffer);
			if (m_hSocket != INVALID_SOCKET)
				::closesocket(m_hSocket);
		}

		void CSslSession::OnCloseInternal()
		{
			{
				CAutoLock al(m_cs);
				m_ss = ssClosing;
				if (m_bThreadingProcessing)
					return;
				m_ss = ssClosed;
			}
			int res = ::closesocket(m_hSocket);
			m_cv.notify_all();
			if (m_sc.OnClose)
				m_sc.OnClose(this);
			m_hSocket = ::WSASocket(g_pListenServer->m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0,  WSA_FLAG_OVERLAPPED);
			g_pListenServer->Recycle(this);
		}

		void CSslSession::PostClose(int errCode)
		{
			m_cs.lock();
			m_ec.assign(errCode, std::system_category());
			m_ss = ssClosing;
			m_cs.unlock();
			BOOL ok = ::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SHUT_DOWN_SOCKET, (ULONG_PTR)this, nullptr);
		}

		tagSessionState CSslSession::GetSessionState()
		{
			CAutoLock al(m_cs);
			return m_ss;
		}

		bool CSslSession::IsDiffEndian()
		{
			return m_bEndianDiff;
		}

		bool CSslSession::ProcessInternal()
		{
			if (m_bThreadingProcessing)
				return false;
			if (m_qRead.GetSize() < sizeof(CRequestHeader) && !m_rh.RequestId)
				return false;
			if (!m_rh.RequestId) {
				m_qRead >> m_rh;
				if (m_bEndianDiff) {
					CBuffer::ChangeEndian((unsigned char*)m_rh.RequestId, sizeof(m_rh.RequestId));
					CBuffer::ChangeEndian((unsigned char*)m_rh.Size, sizeof(m_rh.Size));
				}
			}
			if (m_qRead.GetSize() < m_rh.Size)
				return false;
			if (m_sc.OnArrive)
				m_sc.OnArrive(this, m_rh.RequestId, m_rh.Size);
			m_qRead.Pop(m_rh.Size);

			//clean all trace as early as possible for better security when a client sends sensitive data like password
			if (m_rh.RequestId == idAuthentication || m_rh.RequestId == idAuthenticationReserved)
			{
				::memset(m_ReadBuffer, 0, MAX_LEN_PER_IO_TRANS);
				m_qRead.SetSize(0);
				unsigned char *buffer = (unsigned char*)m_qRead.GetBuffer();
				::memset(buffer, 0, m_qRead.GetMaxSize());
			}

			m_rh.Reset();
			return (!m_bThreadingProcessing);
		}

		unsigned int CSslSession::Retrieve(unsigned char *receiver, unsigned int size)
		{
			//must call this within main thread!!
			if (::GetCurrentThreadId() != g_pListenServer->m_id)
				return BAD_RETRIEVE_THREAD;
			if(!receiver || !size)
				return 0;
			if (size > m_rh.Size)
				size = m_rh.Size;
			if (size > m_qRead.GetSize())
				size = m_qRead.GetSize();
			m_qRead.Pop(receiver, size);
			m_rh.Size -= size;
			return size;
		}

		unsigned int CSslSession::SendException(unsigned short RequestId, int errCode, const char *errMsg, const char *stack)
		{
			if (RequestId < idStartRequestId && RequestId != idAuthentication) 
				return BAD_RESULT;
			CScopeBuffer sb;
			sb << RequestId << errCode << errMsg << stack;
			CRequestHeader rh;
			rh.RequestId = idServerException;
			rh.Size = sb->GetSize();
			{
				CAutoLock al(m_cs);
				if (m_qWrite.GetSize() > 200 * MAX_LEN_PER_IO_TRANS && ::GetCurrentThreadId() != g_pListenServer->m_id)
					m_cv.wait(al);
				if (m_ss < ssSslHandshaked)
					return SESSION_CLOSED;
				if (m_pSspi)
				{
					CScopeBuffer temp;
					temp << rh;
					temp->Push(sb->GetBuffer(), sb->GetSize());
					SECURITY_STATUS ss = m_pSspi->Encrypt(temp->GetBuffer(), temp->GetSize(), m_qWrite);
					if (ss != SEC_E_OK)
						PostClose(ss);	
				}
				else
				{
					m_qWrite << rh;
					m_qWrite.Push(sb->GetBuffer(), sb->GetSize());
				}
				Write();
			}
			return sb->GetSize();
		}

		unsigned int CSslSession::Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size)
		{
			if (RequestId < idStartRequestId && RequestId != idAuthentication) 
				return BAD_RESULT;
			if(!buffer)
				size = 0;
			CRequestHeader rh;
			rh.RequestId = RequestId;
			rh.Size = size;
			{
				CAutoLock al(m_cs);
				if (m_qWrite.GetSize() > 64 * MAX_LEN_PER_IO_TRANS && ::GetCurrentThreadId() != g_pListenServer->m_id)
				{
					m_bWaiting = true;
					m_cv.wait(al);
					m_bWaiting = false;
				}
				if (m_ss < ssSslHandshaked)
					return SESSION_CLOSED;
				if (m_pSspi)
				{
					CScopeBuffer sb;
					sb << rh;
					sb->Push(buffer, size);
					SECURITY_STATUS ss = m_pSspi->Encrypt(sb->GetBuffer(), sb->GetSize(), m_qWrite);
					if (ss != SEC_E_OK)
						PostClose(ss);
				}
				else
				{
					m_qWrite << rh;
					m_qWrite.Push(buffer, size);
				}
				Write();
			}
			return size;
		}

		unsigned int CSslSession::GetSendingBufferSize()
		{
			CAutoLock al(m_cs);
			return m_qWrite.GetSize();
		}

		int CSslSession::GetErrCode()
		{
			CAutoLock al(m_cs);
			return m_ec.value();
		}

		unsigned int CSslSession::GetErrMsg(char *recv, unsigned int size)
		{
			if (!size || !recv)
				return 0;
			--size;
			if (!size)
				return 0;
			std::string str;
			m_cs.lock();
			if (m_ec)
				str = m_ec.message();
			m_cs.unlock();

			size_t len = str.size();
			if(size > (unsigned int)len)
				size = (unsigned int)len;
			::memcpy(recv, str.c_str(), size);
			recv[size] = '\0';
			return size;
		}

		bool CSslSession::StartThreadProcessing()
		{
			//must call this method from main thread
			if (::GetCurrentThreadId() != g_pListenServer->m_id)
				return false;
			m_cs.lock();
			m_bThreadingProcessing = true;
			m_cs.unlock();
			return true;
		}

		void CSslSession::OnSlowRequestProcessed()
		{
			m_cs.lock();
			bool ok = (m_ss >= ssAuthentcated);
			m_cs.unlock();
			if (ok)
			{
				while (ProcessInternal())
				{
				}
				Read();
			}
			else
				OnCloseInternal();
		}

		bool CSslSession::EndThreadProcessing()
		{
			//must call this method from worker thread
			if (::GetCurrentThreadId() == g_pListenServer->m_id)
				return false;
			if (m_bThreadingProcessing)
			{
				m_bThreadingProcessing = false;
				::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CK_SLOW_REQUEST_PROCESSED, (ULONG_PTR)this, nullptr);
				return true;
			}
			return false;
		}

		bool CSslSession::DoDecryption(const unsigned char* buffer, DWORD dwSize)
		{
			bool ok = m_pSspi->Decrypt(buffer, dwSize, m_qRead);
			if (!ok)
				PostClose(m_pSspi->GetLastStatus());
			return ok;
		}

		bool CSslSession::DoHandshake(DWORD dwSize)
		{
			bool ok;
			switch(m_pSspi->GetHandshakeState())
			{
			case hsStart:
			case hsShaking:
				ok = m_pSspi->DoHandshake(m_ReadBuffer, dwSize, m_qWrite);
				break;
			default:
				ok = false;
				assert(false); //never come here
				break;
			}
			if (ok)
				Write();
			return ok;
		}

		void CSslSession::handle_read(DWORD bytes_transferred)
		{
			if (!bytes_transferred)
			{
				OnCloseInternal();
				return;
			}
			if (m_pSspi)
			{
				m_bReading = false;
				if (m_pSspi->GetHandshakeState() < hsDone)
				{
					if (DoHandshake(bytes_transferred))
					{
						Read();
						if (m_pSspi->GetHandshakeState() == hsDone)
						{
							m_ss = ssSslHandshaked;
							if (m_sc.OnSslHandshakeDone)
								m_sc.OnSslHandshakeDone(this);
						}
					}
					else
						PostClose(m_pSspi->GetLastStatus());
					return;
				}
				if (!DoDecryption(m_ReadBuffer, bytes_transferred))
					return;
			}
			else
				m_qRead.Push(m_ReadBuffer, (unsigned int)bytes_transferred);

			if (bytes_transferred >= MAX_LEN_PER_IO_TRANS)
				ReadEx();

			{
				CAutoLock al(m_cs);
				if (m_ss < ssAuthentcated && m_qRead.GetSize() >= sizeof(m_rh))
				{
					//peek the first 8 bytes of data
					CRequestHeader *rh = (CRequestHeader*)m_qRead.GetBuffer();
					switch (rh->RequestId)
					{
					case idAuthenticationReserved:
						m_bEndianDiff = true;
					case idAuthentication:
						{
							unsigned int size = rh->Size;
							if (m_bEndianDiff)
								CBuffer::ChangeEndian((unsigned char*)&size, sizeof(size));
							if (rh->Size <= MAX_LEN_PER_IO_TRANS)
							{
								m_ss = ssAuthentcated;
								break;
							}
						}
					default:
						m_ss = ssClosing;
						PostClose(ERROR_ACCESS_DENIED);
						return;
						break;
					}	 
				}
			}
			while(ProcessInternal())
			{
			}
			m_bReading = false;
			Read();
		}

		void CSslSession::ReadEx()
		{
			int res;
			CScopeBuffer sb(DEFAULT_INITIAL_MEMORY_BUFFER_SIZE);
			while (m_qRead.GetSize() < (MAX_LEN_PER_IO_TRANS * 256 + m_rh.Size))
			{
				res = ::recv(m_hSocket, (char*)sb->GetBuffer(), (int)DEFAULT_INITIAL_MEMORY_BUFFER_SIZE, 0);
				if (res > 0)
				{
					if (m_pSspi)
					{
						if (!DoDecryption(sb->GetBuffer(), (DWORD)res))
							break;
					}
					else
					{
						m_qRead.Push(sb->GetBuffer(), (unsigned int)res);
					}
				}
				if (res < (int)DEFAULT_INITIAL_MEMORY_BUFFER_SIZE)
					break;
			}
		}

		bool CSslSession::Read()
		{
			if (m_bReading)
				return true;
			if (m_bThreadingProcessing && m_qRead.GetSize() > (MAX_LEN_PER_IO_TRANS * 256 + m_rh.Size))
				return true;
			m_bReading = true;
			m_dwBytesRecvd = 0;
			m_dwFlagsRecvd = 0;
			memset(&m_olRead, 0, sizeof(m_olRead));
			m_wsaRecv.buf = (char*)m_ReadBuffer;
			m_wsaRecv.len = MAX_LEN_PER_IO_TRANS;
			int res = ::WSARecv(m_hSocket, &m_wsaRecv, 1, &m_dwBytesRecvd, &m_dwFlagsRecvd, &m_olRead, nullptr);
			if (res == SOCKET_ERROR)
			{
				int errCode = ::WSAGetLastError();
				if (errCode != WSA_IO_PENDING)
				{
					PostClose(errCode);
					return true;
				}
			}
			return false;
		}

		void CSslSession::handle_write(DWORD bytes_transferred)
		{
			{
				CAutoLock al(m_cs);
				m_bWriting = false;
				Write();
			}
			Read();
		}

		void CSslSession::Write()
		{
			int res;
			if (m_bWriting)
				return;
			if (m_qWrite.GetSize() == 0)
				return;
			res = ::send(m_hSocket, (const char*)m_qWrite.GetBuffer(), (int)m_qWrite.GetSize(), 0);
			if (res > 0)
				m_qWrite.Pop((unsigned int)res);
			unsigned int size = (m_qWrite.GetSize() > MAX_LEN_PER_IO_TRANS) ? MAX_LEN_PER_IO_TRANS : m_qWrite.GetSize();
			if (size)
			{
				m_qWrite.Pop(m_WriteBuffer, size);
				m_bWriting = true;
				m_wsaSend.buf = (CHAR*)m_WriteBuffer;
				m_wsaSend.len = (ULONG)size;
				memset(&m_olSent, 0, sizeof(m_olSent));
				res = WSASend(m_hSocket, &m_wsaSend, 1, &m_dwBytesSent, 0, &m_olSent, nullptr);
				if (res == SOCKET_ERROR)
				{
					int errCode = WSAGetLastError();
					if (errCode != WSA_IO_PENDING)
						PostClose(errCode);
				}
			}

			if (m_bWaiting && m_qWrite.GetSize() < MAX_LEN_PER_IO_TRANS * 10 && ::GetCurrentThreadId() == g_pListenServer->m_id)
				m_cv.notify_all();

			if (m_qWrite.GetSize() == 0 && m_sc.OnLess && m_ss == ssAuthentcated)
			{
				if (::GetCurrentThreadId() == g_pListenServer->m_id)
					m_sc.OnLess(this);
				else
					::PostQueuedCompletionStatus(g_pListenServer->m_hRootIoPort, CH_LESS_INTERNAL, (ULONG_PTR)this, nullptr);
			}
		}

		void CSslSession::OnLessInternal()
		{
			m_cs.lock();
			bool ok = (m_ss >= ssConnected);
			m_cs.unlock();
			if (ok && m_sc.OnLess)
			{
				m_sc.OnLess(this);
			}
		}

		void CSslSession::Initialize()
		{
			m_bWaiting = false;
			m_bEndianDiff = false;
			m_ss = ssConnected;
			m_bThreadingProcessing = false;
			m_bReading = false;
			m_bWriting = false;
			m_qRead.SetSize(0);
			m_qWrite.SetSize(0);
			::memset(&m_rh, 0, sizeof(m_rh));
			if (g_pListenServer->IsSecure())
				m_pSspi.reset(new CSspi(false, g_pListenServer->GetCredHandle()));
			u_long iMode = 1;
			int res = ::ioctlsocket(m_hSocket, FIONBIO, &iMode);
			//int optValue = 1460 * 40;
			//res = setsockopt(m_hSocket, SOL_SOCKET, SO_RCVBUF, (const char*)&optValue, sizeof(optValue));
		}

		void CSslSession::Start()
		{
			Initialize();
			if (g_pListenServer->IsSecure())
				m_ss = ssSslHandshaking;
			HANDLE hPort = CreateIoCompletionPort((HANDLE)m_hSocket, g_pListenServer->m_hRootIoPort, (ULONG_PTR)this, 1);
			assert(hPort == g_pListenServer->m_hRootIoPort);
			Read(); 
		}

	} //ServerSide
} //SC
