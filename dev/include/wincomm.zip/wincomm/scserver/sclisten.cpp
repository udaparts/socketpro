
#include "stdafx.h"
#include "sclisten.h"
#include <algorithm>

namespace SC {
	namespace ServerSide {
		CListenServer *g_pListenServer = nullptr;
		CMutex CListenServer::m_cs;

		CListenServer::CListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog)
			: m_id(0), 
			m_OnAccepted(OnAccepted),
			m_v6(v6),
			m_port(port),
			m_maxBacklog(maxBacklog),
			AcceptEx(nullptr),
			GetAcceptExSockaddrs(nullptr),
			m_hSocket(INVALID_SOCKET),
			m_hRootIoPort(nullptr),
			m_session(nullptr),
			m_key(0),
			m_dwBytes(0),
			m_reading(false)
		{
			assert(!g_pListenServer);
			g_pListenServer = this;
			m_dwSockAddrSize = (m_v6 ? sizeof(sockaddr_in6) : sizeof(sockaddr_in)) + 16;
			memset(&m_hCreds, 0, sizeof(m_hCreds));
		}

		CListenServer::~CListenServer()
		{
			CAutoLock al(m_cs);
			if (IsRunning())
				Shutdown();
			CleanDeadSockets();
			g_pListenServer = nullptr;
			CleanListeningSocket();
			FreeCredHandle();
		}

		CListenServer* CListenServer::CreateListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog)
		{
			CAutoLock al(m_cs);
			if (g_pListenServer)
				return g_pListenServer;
			g_pListenServer = new CListenServer(OnAccepted, port, v6, maxBacklog);
			return g_pListenServer;
		}

		void CListenServer::Recycle(CSslSession *session)
		{
			if (!session)
				return;
			auto it = std::find(m_vAliveSession.begin(), m_vAliveSession.end(), session);
			if (it != m_vAliveSession.end())
				m_vAliveSession.erase(it);
			m_vTrashedSession.push_back(session);
		}

		void CListenServer::Host()
		{
			BOOL ok = ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
			m_id = ::GetCurrentThreadId();
			if (!CreateListeningSocket())
				return;
			start_accept();
			StartIOPump();
		}

		bool CListenServer::CreateListeningSocket()
		{
			DWORD dwBytes;
			int res = 0;
			GUID guidAcceptEx = WSAID_ACCEPTEX;
			GUID guidGetAcceptExSockaddrs = WSAID_GETACCEPTEXSOCKADDRS;
			do
			{
				m_hSocket = ::WSASocket(m_v6 ? AF_INET6 : AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_OVERLAPPED);
				if (m_hSocket == INVALID_SOCKET)
				{
					res = SOCKET_ERROR;
					break;
				}
				BOOL val = TRUE;
				res = ::setsockopt(m_hSocket, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, (char*)&val, sizeof(val));
				if (res == SOCKET_ERROR)
					break;
				if (m_v6)
				{
					DWORD ipv6only = 0;
					res = ::setsockopt(m_hSocket, IPPROTO_IPV6, IPV6_V6ONLY, (char*)&ipv6only, sizeof(ipv6only));
				}
				if (m_v6)
				{
					sockaddr_in6 service;
					memset(&service,0,sizeof(service));
					service.sin6_family = AF_INET6;
					service.sin6_port = htons(m_port);
					res = ::bind(m_hSocket, (SOCKADDR*)&service, sizeof(service));
				}
				else
				{
					sockaddr_in service;
					memset(&service,0,sizeof(service));
					service.sin_family = AF_INET;
					service.sin_addr.s_addr = htonl(INADDR_ANY);
					service.sin_port = htons(m_port);
					res = ::bind(m_hSocket, (SOCKADDR*)&service, sizeof(service));
				}
				if (res == SOCKET_ERROR)
				{
					res = ::WSAGetLastError();
					break;
				}
				res = ::listen(m_hSocket, m_maxBacklog);
				if (res == SOCKET_ERROR)
					break;

				ULONG_PTR CompletionKey = (ULONG_PTR)this;
				m_hRootIoPort = ::CreateIoCompletionPort((HANDLE)m_hSocket, nullptr, CompletionKey, 1); 
				if (!m_hRootIoPort)
				{
					res = SOCKET_ERROR;
					break;
				}
				res = ::WSAIoctl(m_hSocket,
					SIO_GET_EXTENSION_FUNCTION_POINTER,
					&guidAcceptEx,
					sizeof(guidAcceptEx),
					&AcceptEx,
					sizeof(AcceptEx),
					&dwBytes,
					nullptr,
					nullptr);
				if (res == SOCKET_ERROR)
					break;

				res = ::WSAIoctl(m_hSocket,
					SIO_GET_EXTENSION_FUNCTION_POINTER,
					&guidGetAcceptExSockaddrs,
					sizeof(guidGetAcceptExSockaddrs),
					&GetAcceptExSockaddrs,
					sizeof(guidGetAcceptExSockaddrs),
					&dwBytes,
					nullptr,
					nullptr);

			} while(false);

			if (res == SOCKET_ERROR)
			{
				m_ec.assign(::WSAGetLastError(), std::system_category());
				CleanListeningSocket();
				return false;
			}
			return true;
		}

		void CListenServer::CleanListeningSocket()
		{
			if (m_hSocket != INVALID_SOCKET)
			{
				::closesocket(m_hSocket);
				m_hSocket = INVALID_SOCKET;
			}

			if (m_hRootIoPort)
			{
				::CloseHandle(m_hRootIoPort);
				m_hRootIoPort = nullptr;
			}
		}

		bool CListenServer::Run()
		{
			m_pMainThread.reset(new std::thread(std::bind(&CListenServer::Host, this)));
			return true;
		}

		void CListenServer::Shutdown()
		{
			if (m_pMainThread)
			{
				CloseAcitiveSockets();
				BOOL ok = ::PostQueuedCompletionStatus(m_hRootIoPort, CK_SHUT_DOWN_IO_PORT, (ULONG_PTR)this, nullptr);
				assert(ok);
				m_pMainThread->join();
				assert(m_vAliveSession.size() == 0);
				m_pMainThread.reset();
			}
		}

		bool CListenServer::IsRunning() const
		{
			return (!!m_pMainThread);
		}

		std::string CListenServer::GetErrorMessage() const {
			if (!m_ec)
				return "";
			return m_ec.message();
		}

		int CListenServer::GetErrCode() const
		{
			return m_ec.value();
		}

		void CListenServer::CloseAcitiveSockets()
		{
			for(auto it = m_vAliveSession.begin(), end = m_vAliveSession.end(); it != end; ++it)
			{
				(*it)->PostClose(0);
			}
		}

		CSslSession* CListenServer::SeekByOverLapped(LPOVERLAPPED pOverlap)
		{
			for (auto it = m_vAliveSession.begin(), end = m_vAliveSession.end(); it != end; ++it)
			{
				if (pOverlap == &(*it)->m_olRead)
				{
					m_reading = true;
					return *it;
				}
				else if (pOverlap == &(*it)->m_olSent)
				{
					m_reading = false;
					return *it;
				}
			}
			m_reading = false;
			return nullptr;
		}

		void CListenServer::CleanDeadSockets()
		{
			//clean all trashed sessions
			for(auto it = m_vTrashedSession.begin(), end = m_vTrashedSession.end(); it != end; ++it)
			{
				delete *it;
			}
			m_vTrashedSession.clear();
		}

		void CListenServer::StartIOPump()
		{
			bool killLoop = false;
			LPOVERLAPPED pOverlap;
			do
			{
				::memset(&m_ol, 0, sizeof(m_ol));
				BOOL ok = GetQueuedCompletionStatus(m_hRootIoPort, &m_dwBytes, &m_key, &pOverlap, 1000);
				if (ok)
				{
					switch(m_dwBytes)
					{
					case CK_SHUT_DOWN_IO_PORT:
						killLoop = true;
						m_vTrashedSession.push_back(m_session);
						m_session = nullptr;
						CleanDeadSockets();
						break;
					case CK_SHUT_DOWN_SOCKET:
						{
							CSslSession *pSession = (CSslSession*)m_key;
							pSession->OnCloseInternal();
						}
						break;
					case CK_SLOW_REQUEST_PROCESSED:
						{
							CSslSession *pSession = (CSslSession*)m_key;
							pSession->OnSlowRequestProcessed();
						}
						break;
					case CH_LESS_INTERNAL:
						{
							CSslSession *pSession = (CSslSession*)m_key;
							pSession->OnLessInternal();
						}
						break;
					default:
						if (m_key == (ULONG_PTR)this)
						{
							m_vAliveSession.push_back(m_session);
							m_session->m_sc = m_OnAccepted(m_session);
							m_session->Start();
							start_accept();
						}
						else
						{
							CSslSession *session = SeekByOverLapped(pOverlap);
							if (session)
							{
								if (m_reading)
									session->handle_read(m_dwBytes);
								else
									session->handle_write(m_dwBytes);
							}
							else
								assert(false); //unknown or not implemented
						}
						break;
					}
				}
				else
				{
					DWORD res = ::GetLastError();
					switch (res)
					{
					case WAIT_TIMEOUT:
						// idle
						break;
					case ERROR_NETNAME_DELETED:
						{
							CSslSession *session = SeekByOverLapped(pOverlap);
							if (session)
								session->OnCloseInternal();
							else
								assert(false); //unknown or not implemented
						}
						break;
					default:
						assert(false); //unknown or not implemented
						break;
					}
				}
			} while(!killLoop);
		}

		void CListenServer::SetSession()
		{
			if (m_vTrashedSession.size())
			{
				m_session = m_vTrashedSession.back();
				m_vTrashedSession.pop_back();
			}
			else
				m_session = new CSslSession();
		}

		void CListenServer::start_accept()
		{
			BOOL ok;
			DWORD dwBytes;
			int res = 0;
			do
			{
				dwBytes = 0;
				memset(&m_ol, 0, sizeof(m_ol));
				SetSession();
				::memset(m_session->m_buffAccept, 0, sizeof(m_session->m_buffAccept));
				ok = AcceptEx(m_hSocket,
					m_session->m_hSocket,
					m_session->m_buffAccept,
					0,
					m_dwSockAddrSize,
					m_dwSockAddrSize,
					&dwBytes,
					&m_ol);
				if (ok)
				{
					m_vAliveSession.push_back(m_session);
					m_session->m_sc = m_OnAccepted(m_session);
					assert(dwBytes == 0);
					m_session->Start();
				}
			} while (ok);
			assert(dwBytes == 0);
			res = ::WSAGetLastError();
			assert(!ok && res == WSA_IO_PENDING);
		}

		void CListenServer::FreeCredHandle()
		{
			if (m_hCreds.dwLower || m_hCreds.dwUpper)
			{
				FreeCredentialsHandle(&m_hCreds);
				memset(&m_hCreds, 0, sizeof(m_hCreds));
			}
		}

		bool CListenServer::IsSecure() const 
		{
			return (m_hCreds.dwLower || m_hCreds.dwUpper);
		}

		PCredHandle CListenServer::GetCredHandle()
		{
			return &m_hCreds;
		}

		bool CListenServer::OpenPfx(const wchar_t *filePfx, const wchar_t *password)
		{
			bool ok;

			//if pfx file or password not set, we don't use secure channel
			if (!filePfx || !password || !std::wcslen(filePfx) || !std::wcslen(password))
				return true;
			PCCERT_CONTEXT pCertContext = nullptr;
			FreeCredHandle();
			do
			{
				ok = m_pfx.OpenFromPfxFile(filePfx, password);
				if (!ok)
					break;
				pCertContext = ::CertFindCertificateInStore(m_pfx.GetCertStore(), X509_ASN_ENCODING|PKCS_7_ASN_ENCODING, 0, CERT_FIND_ANY, nullptr, nullptr);
				if (!pCertContext) {
					ok = false;
					break;
				}
				SCHANNEL_CRED SchannelCred;
				memset(&SchannelCred, 0, sizeof(SchannelCred));
				SchannelCred.dwVersion  = SCHANNEL_CRED_VERSION;
				SchannelCred.cCreds = 1;
				SchannelCred.paCred = &pCertContext;
				SchannelCred.grbitEnabledProtocols = SP_PROT_SSL3TLS1_X_SERVERS;
				SECURITY_STATUS status = AcquireCredentialsHandle(nullptr,
					SCHANNEL_NAME,
					SECPKG_CRED_INBOUND,
					nullptr,
					&SchannelCred,
					nullptr,
					nullptr,
					&m_hCreds,
					nullptr);
				if (status != SEC_E_OK)
				{
					memset(&m_hCreds, 0, sizeof(m_hCreds));
					ok = false;
				}
			} while(false);
			if (!ok)
				m_ec.assign(::GetLastError(), std::system_category());
			if (pCertContext)
				::CertFreeCertificateContext(pCertContext);
			return ok;
		}
	} //ScServer
} //SC
