#ifndef __SECURE_COMM_SSL_TLS_SESSION_H_
#define __SECURE_COMM_SSL_TLS_SESSION_H_

#include "../../shared/membuffer.h"
#include "../../shared/sccommserver.h"
#include <condition_variable>
#include <memory>
#include "../commshared/scsspi.h"

namespace SC {
	namespace ServerSide {

		class CListenServer;

		class CSslSession : public IServerSession
		{
		private:
			CSslSession();
			~CSslSession();

		public:
			const static unsigned int MAX_LEN_PER_IO_TRANS = 1024;

			//implementations for IServerSession methods
			virtual tagSessionState GetSessionState();
			virtual void PostClose(int errCode);
			virtual unsigned int Retrieve(unsigned char *receiver, unsigned int size);
			virtual unsigned int Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size);
			virtual unsigned int GetSendingBufferSize();
			virtual int GetErrCode();
			virtual unsigned int GetErrMsg(char *recv, unsigned int size);
			virtual bool IsDiffEndian();
			virtual bool StartThreadProcessing();
			virtual bool EndThreadProcessing();
			virtual unsigned int SendException(unsigned short CurrentRequestId, int errCode, const char *errMsg, const char *stack);

		private:
			void Start();
			bool Read();
			void Write();
			void OnCloseInternal();
			bool ProcessInternal();
			void Initialize();
			void OnLessInternal();
			void OnSlowRequestProcessed();
			void handle_read(DWORD bytes_transferred);
			void handle_write(DWORD bytes_transferred);
			bool DoHandshake(DWORD dwSize);
			bool DoDecryption(const unsigned char* buffer, DWORD dwSize);
			void ReadEx();

		private:
			//no copy constructor and assignment operator
			CSslSession(const CSslSession &session);
			CSslSession& operator=(const CSslSession &session);

		private:
			CMutex m_cs;
			bool m_bEndianDiff;
			tagSessionState m_ss; //protected by m_cs
			CErrCode m_ec; //protected by m_cs

			//reading
			bool m_bReading;
			unsigned char *m_ReadBuffer;
			CBuffer m_qRead;

			//writing
			bool m_bWriting; //protected by m_cs
			unsigned char *m_WriteBuffer; //protected by m_cs
			CBuffer m_qWrite; //protected by m_cs
			CRequestHeader m_rh;
			SessionCallback m_sc;

			bool m_bThreadingProcessing; //protected by m_cs
			std::condition_variable m_cv;

			SOCKET m_hSocket;
			unsigned char m_buffAccept[128];

			//reading
			WSAOVERLAPPED m_olRead;
			WSABUF m_wsaRecv;
			DWORD m_dwBytesRecvd;
			DWORD m_dwFlagsRecvd;

			//writing
			WSABUF m_wsaSend;
			WSAOVERLAPPED m_olSent;
			DWORD m_dwBytesSent;
			std::shared_ptr<CSspi> m_pSspi;
			bool m_bWaiting;
			friend class CListenServer;
		};

	} //ServerSide
} //SC

#endif;