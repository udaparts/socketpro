
#include "stdafx.h"

namespace SC 
{
	CWinSocketStartup CWinSocketStartup::m_startup;
}