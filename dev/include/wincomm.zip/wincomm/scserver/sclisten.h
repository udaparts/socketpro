

#ifndef ___SECURE_COMM_LISTENING_SERVER_AUTOSAVE_H__
#define ___SECURE_COMM_LISTENING_SERVER_AUTOSAVE_H__

#include "sslsession.h"
#include "mswsock.h"

namespace SC {
	namespace ServerSide {

		class CListenServer
		{
		private:
			CListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog);

		public:
			~CListenServer();

		public:
			bool Run();
			void Shutdown();
			bool IsRunning() const;
			std::string GetErrorMessage() const;
			int GetErrCode() const;
			static CListenServer* CreateListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog);
			bool OpenPfx(const wchar_t *filePfx, const wchar_t *password);
			bool IsSecure() const;
			PCredHandle GetCredHandle();

		private:
			//disable copy constructor and assignment operator
			CListenServer(const CListenServer &ls);
			CListenServer& operator=(const CListenServer &ls);

			void start_accept();
			void Host();
			void Recycle(CSslSession *session);
			bool CreateListeningSocket();
			void CleanListeningSocket();
			void StartIOPump();
			void SetSession();
			void CloseAcitiveSockets();
			void CleanDeadSockets();
			CSslSession* SeekByOverLapped(LPOVERLAPPED pOverlap);
			void FreeCredHandle();

		private:
			std::shared_ptr<std::thread> m_pMainThread;
			CErrCode m_ec;

			std::vector<CSslSession*> m_vTrashedSession;
			std::vector<CSslSession*> m_vAliveSession;
			DWORD m_id; //main thread id

			POnAccepted m_OnAccepted;

			bool m_v6;
			unsigned short m_port;
			unsigned int m_maxBacklog;

			LPFN_ACCEPTEX AcceptEx;
			LPFN_GETACCEPTEXSOCKADDRS GetAcceptExSockaddrs;

			CScCert m_pfx;
			SOCKET m_hSocket;
			HANDLE m_hRootIoPort;
			CSslSession *m_session;
			DWORD m_dwSockAddrSize;
			ULONG_PTR m_key;
			DWORD m_dwBytes;
			OVERLAPPED m_ol;
			bool m_reading;
			CredHandle m_hCreds;
			static CMutex m_cs;

			friend class CSslSession;
		};

		extern CListenServer *g_pListenServer;

	} //ScServer
} //SC

#endif