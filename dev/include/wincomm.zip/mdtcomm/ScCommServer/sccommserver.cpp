
#include "stdafx.h"
#include "../../shared/sccommserver.h"
#include "sclisten.h"

namespace SC {
	namespace ServerSide {
		std::mutex g_mutex;
		std::string g_strErrorMessage;
	}
}

using namespace SC::ServerSide;

const char* WINAPI InitializeSecureCommServer(POnAccepted OnAccepted, unsigned int port, bool v6, unsigned int backlog) {
	std::unique_lock<std::mutex> lg(g_mutex);
	g_strErrorMessage.clear();
	if (g_pListenServer)
		return g_strErrorMessage.c_str();
	if (!OnAccepted)
		g_strErrorMessage = "OnAccepted callback required";
	else
		SC::ServerSide::CListenServer::CreateListenServer(OnAccepted, port, v6, backlog);
	return g_strErrorMessage.c_str();
}

const char* WINAPI RunSecureCommServer(const char *certFile, const char *keyFile, const char *pwdForPrivateKeyFile, const char *dhFile) {
	std::unique_lock<std::mutex> lg(g_mutex);
	g_strErrorMessage.clear();
	if (!g_pListenServer)
		g_strErrorMessage = "Sc server not initialized yet";
	else
	{
		if (certFile)
			g_pListenServer->SetCertFile(certFile);
		if (keyFile)
			g_pListenServer->SetPrivateKeyFile(keyFile);
		if (pwdForPrivateKeyFile)
			g_pListenServer->SetPrivateKeyPassword(pwdForPrivateKeyFile);
		if (dhFile)
			g_pListenServer->SetDhFile(dhFile);
		if (!g_pListenServer->Run())
			g_strErrorMessage = g_pListenServer->GetErrorMessage();
	}
	return g_strErrorMessage.c_str();
}

void WINAPI ShutdownSecureCommServer() {
	std::unique_lock<std::mutex> lg(g_mutex);
	g_strErrorMessage.clear();
	delete g_pListenServer;
}