
#include "stdafx.h"
#include "sclisten.h"
#include <algorithm>

namespace SC {
	namespace ServerSide {
		CListenServer *g_pListenServer = nullptr;
		CMutex CListenServer::m_cs;

		CListenServer::CListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog)
			: m_Acceptor(m_io),
			m_SslContext(CSslContext::tlsv11_server),
			m_OnAccepted(OnAccepted),
			m_v6(v6),
			m_port(port),
			m_maxBacklog(maxBacklog)
		{
			assert(!g_pListenServer);
			g_pListenServer = this;
		}

		CListenServer::~CListenServer()
		{
			CAutoLock al(m_cs);
			if (IsRunning())
				Shutdown();
			//clean all trashed sessions
			for(auto it = m_vTrashedSession.begin(), end = m_vTrashedSession.end(); it != end; ++it)
			{
				delete *it;
			}
			m_vTrashedSession.clear();
			g_pListenServer = nullptr;
		}

		CListenServer* CListenServer::CreateListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog)
		{
			CAutoLock al(m_cs);
			if (g_pListenServer)
				return g_pListenServer;
			g_pListenServer = new CListenServer(OnAccepted, port, v6, maxBacklog);
			return g_pListenServer;
		}

		void CListenServer::Recycle(CSslSession *session)
		{
			if (!session)
				return;
			m_vTrashedSession.push_back(session);
		}

		void CListenServer::Host()
		{
			m_id = std::this_thread::get_id();

			boost::asio::ip::tcp::endpoint endpoint(m_v6 ? BOOST_IP::tcp::v6() : BOOST_IP::tcp::v4(), m_port);
			m_Acceptor.open(endpoint.protocol(), m_ec);
			if (m_ec)
				return;
			m_Acceptor.bind(endpoint, m_ec);
			if (m_ec)
				return;
			m_Acceptor.listen(m_maxBacklog, m_ec);
			if (m_ec)
				return;

			start_accept();
			m_strPrivateKeyPwd.clear();
			m_io.run(m_ec);
		}

		bool CListenServer::Run()
		{
			long options = (CSslContext::default_workarounds|CSslContext::no_sslv2);
			if (m_strDhFile.size())
				options |= CSslContext::single_dh_use;
			m_SslContext.set_options(options, m_ec);
			if (m_ec)
				return false;
			m_SslContext.set_password_callback(std::bind(&CListenServer::get_password, this), m_ec);
			if (m_ec)
				return false;
			if (m_strDhFile.size())
			{
				m_SslContext.use_tmp_dh_file(m_strDhFile, m_ec);
				if (m_ec)
					return false;
				m_SslContext.use_certificate_chain_file(m_strCertFile, m_ec);
			}
			else
				m_SslContext.use_certificate_file(m_strCertFile, CSslContext::pem, m_ec);
			if (m_ec)
				return false;
			std::transform(m_strPrivateKeyFile.begin(), m_strPrivateKeyFile.end(), m_strPrivateKeyFile.begin(), ::tolower);
			size_t pos = m_strPrivateKeyFile.rfind(".pem");
			if (pos == std::string::npos)
				m_SslContext.use_private_key_file(m_strPrivateKeyFile, CSslContext::asn1, m_ec);
			else
				m_SslContext.use_private_key_file(m_strPrivateKeyFile, CSslContext::pem, m_ec);
			if (m_ec)
				return false;
			m_pMainThread.reset(new std::thread(std::bind(&CListenServer::Host, this)));
			return (!!m_ec);
		}

		void CListenServer::Shutdown()
		{
			m_io.stop();
			m_pMainThread->join();
			m_pMainThread.reset();
		}

		bool CListenServer::IsRunning()
		{
			return (!!m_pMainThread);
		}

		std::string CListenServer::get_password() const
		{
			return m_strPrivateKeyPwd;
		}

		std::string CListenServer::GetErrorMessage() {
			if (!m_ec)
				return "";
			return m_ec.message();
		}

		int CListenServer::GetErrCode()
		{
			return m_ec.value();
		}

		void CListenServer::SetPrivateKeyPassword(const char *pwd)
		{
			m_strPrivateKeyPwd = pwd;
		}

		void CListenServer::SetPrivateKeyFile(const char* file)
		{
			m_strPrivateKeyFile = file;
		}

		void CListenServer::SetCertFile(const char* file)
		{
			m_strCertFile = file;
		}

		void CListenServer::SetDhFile(const char* file)
		{
			m_strDhFile = file;
		}

		void CListenServer::start_accept()
		{
			CSslSession* new_session;
			if (m_vTrashedSession.size())
			{
				new_session = m_vTrashedSession.back();
				m_vTrashedSession.pop_back();
			}
			else
				new_session = new CSslSession(m_io, m_SslContext);
			m_Acceptor.async_accept(new_session->GetLayer(), boost::bind(&CListenServer::handle_accept, this, new_session, BOOST_ASIO::placeholders::error));
		}

		void CListenServer::handle_accept(CSslSession* new_session, const boost::system::error_code& error)
		{
			if (error)
			{
				Recycle(new_session);
				m_ec = error;
			}
			else
			{
				new_session->Initialize();
				new_session->m_sc = m_OnAccepted(new_session);
				new_session->Start();
			}
			start_accept();
		}

	} //ScServer
} //SC
