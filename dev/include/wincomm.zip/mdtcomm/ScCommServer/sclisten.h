

#ifndef ___SECURE_COMM_LISTENING_SERVER_AUTOSAVE_H__
#define ___SECURE_COMM_LISTENING_SERVER_AUTOSAVE_H__

#include "sslsession.h"

namespace SC {
	namespace ServerSide {

		class CListenServer
		{
		private:
			CListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog);

		public:
			~CListenServer();

		public:
			void SetPrivateKeyPassword(const char *pwd);
			void SetPrivateKeyFile(const char* file);
			void SetCertFile(const char* file);
			void SetDhFile(const char* file);
			bool Run();
			void Shutdown();
			bool IsRunning();
			std::string GetErrorMessage();
			int GetErrCode();
			static CListenServer* CreateListenServer(POnAccepted OnAccepted, unsigned short port, bool v6, unsigned int maxBacklog);

		private:
			//disable copy constructor and assignment operator
			CListenServer(const CListenServer &ls);
			CListenServer& operator=(const CListenServer &ls);

			void handle_accept(CSslSession* new_session, const CErrCode& ec);
			std::string get_password() const;
			void start_accept();
			void Host();
			void Recycle(CSslSession *session);

		private:
			std::shared_ptr<std::thread> m_pMainThread;
			CErrCode m_ec;
			CIoService m_io;
			BOOST_IP::tcp::acceptor m_Acceptor;
			CSslContext m_SslContext;

			//openssl
			std::string m_strCertFile;
			std::string m_strPrivateKeyFile;
			std::string m_strPrivateKeyPwd;
			std::string m_strDhFile;

			std::vector<CSslSession*> m_vTrashedSession;
			std::thread::id m_id; //main thread id

			POnAccepted m_OnAccepted;

			bool m_v6;
			unsigned short m_port;
			unsigned int m_maxBacklog;

			static CMutex m_cs;

			friend class CSslSession;
		};

		extern CListenServer *g_pListenServer;

	} //ScServer
} //SC

#endif