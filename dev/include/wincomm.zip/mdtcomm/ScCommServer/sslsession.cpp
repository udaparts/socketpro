#include "stdafx.h"
#include "sslsession.h"
#include "sclisten.h"

namespace SC {
	namespace ServerSide {

		CSslSession::CSslSession(CIoService &io, CSslContext &SslContext)
			: m_bEndianDiff(false),
			m_ss(ssClosed),
			m_SslSocket(io, SslContext),
			m_bReading(false),
			m_ReadBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
			m_bWriting(false),
			m_WriteBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
			m_bThreadingProcessing(false)
		{
			memset(&m_sc, 0, sizeof(m_sc));
		}

		CSslSession::~CSslSession()
		{
			::free(m_ReadBuffer);
			::free(m_WriteBuffer);
		}

		CSslSocket::lowest_layer_type& CSslSession::GetLayer() 
		{
			return m_SslSocket.lowest_layer();
		}

		void CSslSession::OnCloseInternal()
		{
			{
				CErrCode ec;
				CAutoLock al(m_cs);
				if (m_bThreadingProcessing)
					return;
				m_SslSocket.shutdown(ec);
				m_SslSocket.next_layer().shutdown(BOOST_ASIO::socket_base::shutdown_type::shutdown_both, ec);
				m_ss = ssClosed;
				m_SslSocket.next_layer().close(ec);
			}
			m_cv.notify_all();
			if (m_sc.OnClose)
				m_sc.OnClose(this);
			g_pListenServer->Recycle(this);
		}

		void CSslSession::PostClose(int errCode)
		{
			{
				CAutoLock al(m_cs);
				m_ec.assign(errCode, boost::system::get_system_category());
				m_ss = ssClosing;
			}

			m_SslSocket.get_io_service().post(std::bind(&CSslSession::OnCloseInternal, this));
		}

		tagSessionState CSslSession::GetSessionState()
		{
			CAutoLock al(m_cs);
			return m_ss;
		}

		bool CSslSession::IsDiffEndian()
		{
			return m_bEndianDiff;
		}

		bool CSslSession::ProcessInternal()
		{
			{
				CAutoLock al(m_cs);
				if (m_bThreadingProcessing)
					return false;
			}
			if (m_qRead.GetSize() < sizeof(CRequestHeader) && !m_rh.RequestId)
				return false;
			if (!m_rh.RequestId) {
				m_qRead >> m_rh;
				if (m_bEndianDiff) {
					CBuffer::ChangeEndian((unsigned char*)m_rh.RequestId, sizeof(m_rh.RequestId));
					CBuffer::ChangeEndian((unsigned char*)m_rh.Size, sizeof(m_rh.Size));
				}
			}
			if (m_qRead.GetSize() < m_rh.Size)
				return false;
			if (m_sc.OnArrive)
				m_sc.OnArrive(this, m_rh.RequestId, m_rh.Size);
			m_qRead.Pop(m_rh.Size);
			m_rh.Reset();
			CAutoLock al(m_cs);
			return (!m_bThreadingProcessing);
		}

		unsigned int CSslSession::Retrieve(unsigned char *receiver, unsigned int size)
		{
			//must call this within main thread!!
			if (std::this_thread::get_id() != g_pListenServer->m_id)
				return BAD_RETRIEVE_THREAD;
			if(!receiver || !size)
				return 0;
			if (size > m_rh.Size)
				size = m_rh.Size;
			if (size > m_qRead.GetSize())
				size = m_qRead.GetSize();
			m_qRead.Pop(receiver, size);
			m_rh.Size -= size;
			return size;
		}

		unsigned int CSslSession::SendException(unsigned short RequestId, int errCode, const char *errMsg, const char *stack)
		{
			if (RequestId < idStartRequestId && RequestId != idAuthentication) 
				return BAD_RESULT;
			CScopeBuffer sb;
			sb << RequestId << errCode << errMsg << stack;
			CRequestHeader rh;
			rh.RequestId = idServerException;
			rh.Size = sb->GetSize();
			CAutoLock al(m_cs);
			if (m_qWrite.GetSize() > 200 * MAX_LEN_PER_IO_TRANS && std::this_thread::get_id() != g_pListenServer->m_id)
				m_cv.wait(al);
			if (m_ss < ssSslHandshaked)
				return SESSION_CLOSED;
			m_qWrite << rh;
			m_qWrite.Push(sb->GetBuffer(), sb->GetSize());
			Write();
			return sb->GetSize();
		}

		unsigned int CSslSession::Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size)
		{
			if (RequestId < idStartRequestId && RequestId != idAuthentication) 
				return BAD_RESULT;
			if(!buffer)
				size = 0;
			CRequestHeader rh;
			rh.RequestId = RequestId;
			rh.Size = size;
			CAutoLock al(m_cs);
			if (m_qWrite.GetSize() > 200 * MAX_LEN_PER_IO_TRANS && std::this_thread::get_id() != g_pListenServer->m_id)
				m_cv.wait(al);
			if (m_ss < ssSslHandshaked)
				return SESSION_CLOSED;
			m_qWrite << rh;
			m_qWrite.Push(buffer, size);
			Write();
			return size;
		}

		unsigned int CSslSession::GetSendingBufferSize()
		{
			CAutoLock al(m_cs);
			return m_qWrite.GetSize();
		}

		int CSslSession::GetErrCode()
		{
			CAutoLock al(m_cs);
			return m_ec.value();
		}

		unsigned int CSslSession::GetErrMsg(char *recv, unsigned int size)
		{
			if (!size || !recv)
				return 0;
			--size;
			if (!size)
				return 0;
			m_cs.lock();
			std::string str = m_ec.message();
			m_cs.unlock();

			size_t len = str.size();
			if(size > (unsigned int)len)
				size = (unsigned int)len;
			::memcpy(recv, str.c_str(), size);
			recv[size] = '\0';
			return size;
		}

		void CSslSession::handle_read(const CErrCode& ec, size_t bytes_transferred) 
		{
			{
				CAutoLock al(m_cs);
				if (m_ss < ssConnected)
					return;
				Write();
				m_ec = ec;
			}
			if (ec)
			{
				OnCloseInternal();
				return;
			}
			else
			{
				if (m_qRead.GetHeadPosition() > MAX_LEN_PER_IO_TRANS && m_qRead.GetTailSize() < bytes_transferred)
					m_qRead.SetHeadPosition();
				m_qRead.Push(m_ReadBuffer, (unsigned int)bytes_transferred);
			}

			if (m_ss < ssAuthentcated && m_qRead.GetSize() >= sizeof(m_rh))
			{
				//peek the first 8 bytes of data
				CRequestHeader *rh = (CRequestHeader*)m_qRead.GetBuffer();
				switch (rh->RequestId)
				{
				case idAuthenticationReserved:
					m_bEndianDiff = true;
				case idAuthentication:
					{
						unsigned int size = rh->Size;
						if (m_bEndianDiff)
							CBuffer::ChangeEndian((unsigned char*)&size, sizeof(size));
						if (rh->Size <= MAX_LEN_PER_IO_TRANS)
						{
							m_ss = ssAuthentcated;
							break;
						}
					}
				default:
					//assign a value with string error message like "Unsupported transportation"
					m_ss = ssClosing;
					m_SslSocket.get_io_service().post(std::bind(&CSslSession::OnCloseInternal, this));
					return;
					break;
				}	 
			}
			while(ProcessInternal())
			{
			}
			m_bReading = false;
			Read();
		}

		void CSslSession::handle_handshake(const CErrCode& ec)
		{
			m_ec = ec;
			if (ec) {
				m_ss = ssClosing;
				m_SslSocket.get_io_service().post(std::bind(&CSslSession::OnCloseInternal, this));
			}
			else
			{
				m_ss = ssSslHandshaked;
				Read();
			}
			if (m_sc.OnSslHandshakeDone)
				m_sc.OnSslHandshakeDone(this);
		}

		bool CSslSession::StartThreadProcessing()
		{
			//must call this method from main thread
			if (std::this_thread::get_id() != g_pListenServer->m_id)
				return false;
			CAutoLock al(m_cs);
			m_bThreadingProcessing = true;
			return true;
		}

		void CSslSession::OnSlowRequestProcessed()
		{
			m_cs.lock();
			bool ok = (m_ss > ssConnected);
			m_cs.unlock();
			if (ok)
			{
				while (ProcessInternal())
				{
				}
				Read();
			}
		}

		bool CSslSession::EndThreadProcessing()
		{
			//must call this method from worker thread
			if (std::this_thread::get_id() == g_pListenServer->m_id)
				return false;
			CAutoLock al(m_cs);
			if (m_bThreadingProcessing)
			{
				m_bThreadingProcessing = false;
				if (m_ss < ssConnected)
					m_SslSocket.get_io_service().post(std::bind(&CSslSession::OnCloseInternal, this));
				else
					m_SslSocket.get_io_service().post(std::bind(&CSslSession::OnSlowRequestProcessed, this));
				return true;
			}
			return false;
		}

		void CSslSession::Read()
		{
			if (m_bReading)
				return;
			{
				CAutoLock al(m_cs);
				if (m_bThreadingProcessing && m_qRead.GetSize() > (MAX_LEN_PER_IO_TRANS * 100 + m_rh.Size))
					return;
			}
			m_bReading = true;
			m_SslSocket.async_read_some(BOOST_ASIO::buffer(m_ReadBuffer, MAX_LEN_PER_IO_TRANS), 
				boost::bind(&CSslSession::handle_read, this, BOOST_ASIO::placeholders::error, 
				BOOST_ASIO::placeholders::bytes_transferred));
		}

		void CSslSession::handle_write(const CErrCode& ec)
		{
			{
				CAutoLock al(m_cs);
				if (m_ss < ssConnected)
					return;
				m_ec = ec;
			}
			if (ec)
			{
				OnCloseInternal();
				return;
			}
			{
				CAutoLock al(m_cs);
				m_bWriting = false;
				Write();
			}
			Read();
		}

		void CSslSession::Write()
		{
			if (m_bWriting)
				return;
			unsigned int size = (m_qWrite.GetSize() > MAX_LEN_PER_IO_TRANS) ? MAX_LEN_PER_IO_TRANS : m_qWrite.GetSize();
			if (!size)
				return;
			m_qWrite.Pop(m_WriteBuffer, size);
			m_bWriting = true;
			BOOST_ASIO::async_write(m_SslSocket,
				BOOST_ASIO::buffer(m_WriteBuffer, size),
				boost::bind(&CSslSession::handle_write, this, BOOST_ASIO::placeholders::error));
			if ((m_qWrite.GetHeadPosition() > 10 * MAX_LEN_PER_IO_TRANS && m_qWrite.GetTailSize() < 5 * MAX_LEN_PER_IO_TRANS) || (m_qWrite.GetHeadPosition() > 300 * MAX_LEN_PER_IO_TRANS))
				m_qWrite.SetHeadPosition();
			if (m_qWrite.GetSize() > 3 * MAX_LEN_PER_IO_TRANS && m_qWrite.GetSize() < MAX_LEN_PER_IO_TRANS * 5) {
				if (std::this_thread::get_id() == g_pListenServer->m_id)
					m_cv.notify_all();
			}
			else if (m_qWrite.GetSize() == 0 && m_sc.OnLess)
				m_SslSocket.get_io_service().post(std::bind(&CSslSession::OnLessInternal, this));
		}

		void CSslSession::OnLessInternal()
		{
			m_cs.lock();
			bool ok = (m_ss >= ssConnected);
			m_cs.unlock();
			if (ok)
			{
				m_sc.OnLess(this);
			}
		}

		void CSslSession::Initialize()
		{
			m_bEndianDiff = false;
			m_ss = ssConnected;
			m_bThreadingProcessing = false;
			m_bReading = false;
			m_bWriting = false;
			m_ec.clear();
			m_qRead.SetSize(0);
			m_qWrite.SetSize(0);
			::memset(&m_rh, 0, sizeof(m_rh));
		}

		void CSslSession::Start()
		{
			Initialize();
			m_ss = ssSslHandshaking;
			m_SslSocket.async_handshake(BOOST_SSL::stream_base::server,
				boost::bind(&CSslSession::handle_handshake, this, BOOST_ASIO::placeholders::error));
		}

	} //ServerSide
} //SC
