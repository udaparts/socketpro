#include "stdafx.h"
#include "sslsession.h"

namespace SC { namespace ClientSide {

	CSslContext CSslSession::m_SslContext(CSslContext::context_base::tlsv11_client);


	CSslSession::CSslSession(SessionCallback sc, const char *host, unsigned int port, unsigned int timedout, bool autoConnecting, bool v6)
		: m_bEndianDiff(false),
		m_ss(ssClosed),
		m_pSslSocket(nullptr),
		m_bReading(false),
		m_ReadBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
		m_bWriting(false),
		m_WriteBuffer((unsigned char*)::malloc(MAX_LEN_PER_IO_TRANS + 16)),
		m_sc(sc),
		m_AutoConnecting(autoConnecting),
		m_strHost(host),
		m_port(port),
		m_timedout(timedout),
		m_v6(v6)
	{

	}

	CSslSession::~CSslSession()
	{
		::free(m_ReadBuffer);
		::free(m_WriteBuffer);
	}

	void CSslSession::OnCloseInternal()
	{
		{
			CErrCode ec;
			CAutoLock al(m_cs);
			m_pSslSocket->shutdown(ec);
			m_pSslSocket->next_layer().shutdown(BOOST_ASIO::socket_base::shutdown_type::shutdown_both, ec);
			m_ss = ssClosed;
			m_pSslSocket->next_layer().close(ec);
			m_pCert.reset();
		}
		m_cv.notify_all();
		if (m_sc.OnClose)
			m_sc.OnClose(this);
		{
			CAutoLock al(m_cs);
			Initialize();
		}
	}

	ICertificate* CSslSession::GetCertificate()
	{
		CAutoLock al(m_cs);
		return m_pCert.get();
	}

	void CSslSession::PostClose(int errCode)
	{
		{
			CAutoLock al(m_cs);
			m_ec.assign(errCode, boost::system::get_system_category());
			m_ss = ssClosing;
		}

		m_pSslSocket->get_io_service().post(std::bind(&CSslSession::OnCloseInternal, this));
	}

	tagSessionState CSslSession::GetSessionState()
	{
		CAutoLock al(m_cs);
		return m_ss;
	}

	bool CSslSession::IsDiffEndian()
	{
		CAutoLock al(m_cs);
		return m_bEndianDiff;
	}

	bool CSslSession::IsAutoConnecting()
	{
		return m_AutoConnecting;
	}

	bool CSslSession::WaitAll(unsigned int ms)
	{
		//don't permit calling this method from hosting thread
		if (std::this_thread::get_id() == m_id)
			return false;

		auto now = std::chrono::system_clock::now();
		CAutoLock al(m_cs);
		if (!m_deqRequest.size())
			return true;
		return (m_cv.wait_until(al, now + std::chrono::milliseconds(ms)) == std::cv_status::no_timeout && m_ss >= ssConnected);
	}

	bool CSslSession::ProcessInternal()
	{
		unsigned short id;
		if (m_qRead.GetSize() < sizeof(CRequestHeader) && !m_rh.RequestId)
			return false;
		if (!m_rh.RequestId) {
			m_qRead >> m_rh;
			if (m_bEndianDiff) {
				CBuffer::ChangeEndian((unsigned char*)m_rh.RequestId, sizeof(m_rh.RequestId));
				CBuffer::ChangeEndian((unsigned char*)m_rh.Size, sizeof(m_rh.Size));
			}
		}
		if (m_qRead.GetSize() < m_rh.Size)
			return false;
		if (m_rh.RequestId == idServerException)
			id = *((const unsigned short *)m_qRead.GetBuffer());
		else
			id = m_rh.RequestId;

		if (m_sc.OnArrive)
			m_sc.OnArrive(this, m_rh.RequestId, m_rh.Size);

		{
			CAutoLock al(m_cs);
			size_t count = m_deqRequest.size();
			if (count)
			{
				if (m_deqRequest.front() == id)
				{
					m_deqRequest.pop_front();
					--count;
				}
				if (!count)
					m_cv.notify_all();
			}
		}
		m_qRead.Pop(m_rh.Size);
		m_rh.Reset();
		return true;
	}

	unsigned int CSslSession::Retrieve(unsigned char *receiver, unsigned int size)
	{
		if(!receiver || !size)
			return 0;
		if (std::this_thread::get_id() != m_id)
			return BAD_RETRIEVE_THREAD;
		if (size > m_rh.Size)
			size = m_rh.Size;
		if (size > m_qRead.GetSize())
			size = m_qRead.GetSize();
		m_qRead.Pop(receiver, size);
		m_rh.Size -= size;
		return size;
	}

	unsigned int CSslSession::Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool oneWay)
	{
		if (RequestId < idStartRequestId && RequestId != idAuthentication) 
			return BAD_REQUEST;
		if (!buffer)
			size = 0;
		CRequestHeader rh;
		rh.RequestId = RequestId;
		rh.Size = size;
		CAutoLock al(m_cs);
		if (m_ss < ssSslHandshaked)
			return SESSION_CLOSED;
		m_qWrite << rh;
		m_qWrite.Push(buffer, size);
		Write();
		if (!oneWay)
			m_deqRequest.push_back(RequestId);
		return size;
	}

	unsigned int CSslSession::GetSendingBufferSize()
	{
		CAutoLock al(m_cs);
		return m_qWrite.GetSize();
	}

	int CSslSession::GetErrCode()
	{
		CAutoLock al(m_cs);
		return m_ec.value();
	}

	unsigned int CSslSession::GetErrMsg(char *recv, unsigned int size)
	{
		if (!size || !recv)
			return 0;
		--size;
		if (!size)
			return 0;
		m_cs.lock();
		std::string str = m_ec.message();
		m_cs.unlock();

		size_t len = str.size();
		if(size > (unsigned int)len)
			size = (unsigned int)len;
		::memcpy(recv, str.c_str(), size);
		recv[size] = '\0';
		return size;
	}

	size_t CSslSession::GetRequestCountQueued()
	{
		CAutoLock al(m_cs);
		return m_deqRequest.size();
	}

	void CSslSession::handle_read(const CErrCode& ec, size_t bytes_transferred) 
	{
		{
			CAutoLock al(m_cs);
			if (m_ss < ssConnected)
				return;
			Write();
			m_ec = ec;
		}

		if (ec)
		{
			OnCloseInternal();
			return;
		}
		else
		{
			if (m_qRead.GetHeadPosition() > MAX_LEN_PER_IO_TRANS && m_qRead.GetTailSize() < bytes_transferred)
				m_qRead.SetHeadPosition();
			m_qRead.Push(m_ReadBuffer, (unsigned int)bytes_transferred);
		}
		{
			CAutoLock al(m_cs);
			if (m_ss < ssAuthentcated && m_qRead.GetSize() >= sizeof(m_rh))
			{
				//peek the first 8 bytes of data
				CRequestHeader *rh = (CRequestHeader*)m_qRead.GetBuffer();
				switch (rh->RequestId)
				{
				case idAuthenticationReserved:
					m_bEndianDiff = true;
				case idAuthentication:
					{
						unsigned int size = rh->Size;
						if (m_bEndianDiff)
							CBuffer::ChangeEndian((unsigned char*)&size, sizeof(size));
						if (rh->Size <= MAX_LEN_PER_IO_TRANS)
						{
							m_ss = ssAuthentcated;
							break;
						}
					}
				default:
					//assign a value with string error message like "Unsupported transportation"
					m_ss = ssClosing;
					m_pSslSocket->get_io_service().post(std::bind(&CSslSession::OnCloseInternal, this));
					return;
					break;
				}	 
			}
		}
		while(ProcessInternal())
		{
		}
		m_bReading = false;
		Read();
	}

	void CSslSession::OnSslHandshakeDone(const CErrCode& ec)
	{
		if (ec) {
			{
				CAutoLock al(m_cs);
				m_ss = ssClosing;
				m_ec = ec;
			}
			m_cv.notify_all();
			m_pSslSocket->get_io_service().post(std::bind(&CSslSession::OnCloseInternal, this));
		}
		else
		{
			{
				CAutoLock al(m_cs);
				m_ss = ssSslHandshaked;
				m_ec = ec;
				m_pCert.reset(new CClientCertificateImpl(m_pSslSocket->native_handle()));
			}
			m_cv.notify_all();
			Read();
		}
		if (m_sc.OnSslHandshakeDone)
			m_sc.OnSslHandshakeDone(this);
	}

	void CSslSession::Read()
	{
		if (m_bReading)
			return;
		if (m_qRead.GetSize() > (MAX_LEN_PER_IO_TRANS * 100 + m_rh.Size))
			return;
		m_bReading = true;
		m_pSslSocket->async_read_some(BOOST_ASIO::buffer(m_ReadBuffer, MAX_LEN_PER_IO_TRANS), 
			boost::bind(&CSslSession::handle_read, this, BOOST_ASIO::placeholders::error, 
			BOOST_ASIO::placeholders::bytes_transferred));
	}

	void CSslSession::handle_write(const CErrCode& ec)
	{
		{
			CAutoLock al(m_cs);
			if (m_ss < ssConnected)
				return;
			m_ec = ec;
		}
		if (ec)
		{
			OnCloseInternal();
			return;
		}

		{
			CAutoLock al(m_cs);
			m_bWriting = false;
			Write();
		}

		Read();
	}

	void CSslSession::Write()
	{
		if (m_bWriting)
			return;
		unsigned int size = (m_qWrite.GetSize() > MAX_LEN_PER_IO_TRANS) ? MAX_LEN_PER_IO_TRANS : m_qWrite.GetSize();
		if (!size)
			return;
		m_qWrite.Pop(m_WriteBuffer, size);
		m_bWriting = true;
		BOOST_ASIO::async_write(*m_pSslSocket,
			BOOST_ASIO::buffer(m_WriteBuffer, size),
			boost::bind(&CSslSession::handle_write, this, BOOST_ASIO::placeholders::error));
		if (m_qWrite.GetHeadPosition() > MAX_LEN_PER_IO_TRANS * 10 && m_qWrite.GetTailSize() < m_qWrite.GetMaxSize()/4)
			m_qWrite.SetHeadPosition();
		if (m_qWrite.GetSize() == 0 && m_sc.OnLess)
			m_pSslSocket->get_io_service().post(std::bind(&CSslSession::OnLessInternal, this));
	}

	void CSslSession::OnLessInternal()
	{
		m_sc.OnLess(this);
	}

	void CSslSession::Initialize()
	{
		m_bEndianDiff = false;
		m_ss = ssClosed;
		m_bReading = false;
		m_bWriting = false;
		m_qRead.SetSize(0);
		m_qWrite.SetSize(0);
		::memset(&m_rh, 0, sizeof(m_rh));
		m_deqRequest.clear();
	}

	void CSslSession::DoConnetionInternal()
	{
		CIoService io;
		BOOST_IP::tcp::resolver resolver(io);
		{
			CAutoLock al(m_cs);
			m_id = std::this_thread::get_id();
			std::string port = std::to_string(m_port);
			BOOST_IP::tcp::resolver::query query(m_v6 ? BOOST_IP::tcp::v6() : BOOST_IP::tcp::v4(), m_strHost, port);
			BOOST_IP::tcp::resolver::iterator iterator = resolver.resolve(query);
			m_ss = ssConnecting;
			m_pSslSocket = new CSslSocket(io, m_SslContext);
			m_pSslSocket->lowest_layer().async_connect(iterator->endpoint(), boost::bind(&CSslSession::OnConnected, this, BOOST_ASIO::placeholders::error));
		}
		io.run();
		{
			CAutoLock al(m_cs);
			delete m_pSslSocket;
			m_pSslSocket = nullptr;
		}
	}

	void CSslSession::OnConnected(const CErrCode& error)
	{
		{
			CAutoLock al(m_cs);
			m_ec = error;
		}
		if (!error) {
			CAutoLock al(m_cs);
			m_ss = ssConnected;
			m_pSslSocket->async_handshake(BOOST_SSL::stream_base::client, boost::bind(&CSslSession::OnSslHandshakeDone, this, BOOST_ASIO::placeholders::error));
		}
		else
			m_cv.notify_all();
	}

	void CSslSession::Destroy()
	{
		{
			CAutoLock al(m_cs);
			if (!m_pHostThread || !m_pSslSocket)
				return;
			m_pSslSocket->get_io_service().stop();
		}
		m_pHostThread->join();
		CAutoLock al(m_cs);
		delete m_pHostThread;
		m_pHostThread = nullptr;
	}

	bool CSslSession::Start()
	{
		CAutoLock al(m_cs);
		if (m_pHostThread)
			return true;
		m_pHostThread = new std::thread(std::bind(&CSslSession::DoConnetionInternal, this));
		return (m_cv.wait_for(al, std::chrono::milliseconds(m_timedout)) != std::cv_status::timeout);
	}

} //namespace ClientSide
} //namespace SC
