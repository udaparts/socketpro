

#ifndef _SECURE_COMM_CLIENT_SSL_SESSION_IMPLEMENTATION_H_
#define _SECURE_COMM_CLIENT_SSL_SESSION_IMPLEMENTATION_H_

#include "../../shared/membuffer.h"
#include "../../shared/sccommclient.h"
#include <deque>
#include <condition_variable>
#include <memory>
#include <string>
#include <thread>
#include "clientcertificateimpl.h"

namespace SC { namespace ClientSide {

	class CSslSession : public IClientSession
	{
	public:
		static CSslContext m_SslContext;
		CSslSession(SessionCallback sc, const char *host, unsigned int port, unsigned int timedout, bool autoConnecting, bool b6);
		virtual ~CSslSession();

	public:
		const static unsigned int MAX_LEN_PER_IO_TRANS = 2 * 1460;

		//implementations for IServerSession methods
		virtual tagSessionState GetSessionState();
		virtual void PostClose(int errCode);
		virtual unsigned int Retrieve(unsigned char *receiver, unsigned int size);
		virtual unsigned int Send(unsigned short RequestId, const unsigned char * const buffer, unsigned int size, bool oneWay);
		virtual unsigned int GetSendingBufferSize();
		virtual int GetErrCode();
		virtual unsigned int GetErrMsg(char *recv, unsigned int size);
		virtual bool IsDiffEndian();
		virtual bool WaitAll(unsigned int ms);
		virtual bool IsAutoConnecting();
		virtual size_t GetRequestCountQueued();
		virtual ICertificate* GetCertificate();

	public:
		bool Start();
		void Destroy();

	private:
		//no copy constructor and assignment operator
		CSslSession(const CSslSession &session);
		CSslSession& operator=(const CSslSession &session);

	private:
		void OnSslHandshakeDone(const CErrCode& ec);
		void handle_read(const CErrCode& ec, size_t bytes_transferred);
		void handle_write(const CErrCode& ec);
		void OnConnected(const CErrCode& ec);
		void Read();
		void Write();
		void OnCloseInternal();
		bool ProcessInternal();
		void Initialize();
		void DoConnetionInternal();
		void OnLessInternal();

	private:
		CMutex m_cs;
		bool m_bEndianDiff;
		tagSessionState m_ss; //protected by m_cs
		CErrCode m_ec; //protected by m_cs
		CSslSocket *m_pSslSocket;

		//reading
		bool m_bReading;
		unsigned char *m_ReadBuffer;
		CBuffer m_qRead;

		//writing
		bool m_bWriting; //protected by m_cs
		unsigned char *m_WriteBuffer; //protected by m_cs
		CBuffer m_qWrite; //protected by m_cs
		CRequestHeader m_rh;
		SessionCallback m_sc;
		bool m_AutoConnecting;

		std::deque<unsigned short> m_deqRequest; //protected by m_cs
		std::condition_variable m_cv;

		std::string m_strHost;
		unsigned int m_port;
		unsigned int m_timedout;
		bool m_v6;
		std::thread::id m_id;
		std::thread *m_pHostThread;

		std::shared_ptr<CClientCertificateImpl> m_pCert; //protected by m_cs
	};

} //namespace ClientSide
} //namespace SC

#endif