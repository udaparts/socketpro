
#ifndef _SECURE_COMM_CLIENT_CERTIFICATE_IMPL_H_
#define _SECURE_COMM_CLIENT_CERTIFICATE_IMPL_H_

#include "../../shared/sccommclient.h"

namespace SC { namespace ClientSide {

class CClientCertificateImpl : public ICertificate
{
public:
	CClientCertificateImpl(SSL *pSsl);
	virtual ~CClientCertificateImpl();

public:
	//implementation for interface ICertificate
	virtual const char* const Verify(int *errCode);
	virtual const char* const GetCertPem();
	virtual bool IsValid();
	virtual const char* const GetSessionInfo();
	virtual const char* const GetSubject();
	virtual const char* const GetIssuer();
	virtual const unsigned char* const GetPublicKey(unsigned int *pKeySize);

private:
	//disable copy constructor and assignment operator
	CClientCertificateImpl(const CClientCertificateImpl &cert);
	CClientCertificateImpl& operator=(const CClientCertificateImpl &cert);

	void SetPerm();
	void SetSessionInfo();
	void SetPublickey();

private:
	SSL *m_pSsl;
	X509 *m_pCert;
	std::string m_strIssuer;
	std::string m_strSubject;
	std::string m_strPerm;
	std::string m_strSessionInfo;
	std::vector<unsigned char> m_vPublicKey;
};

} //namespace ClientSide
} //namespace SC

#endif