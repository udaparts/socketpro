
#include "stdafx.h"
#include "../../shared/sccommclient.h"
#include "sslsession.h"

using namespace SC;
using namespace SC::ClientSide;

IClientSession* WINAPI DoClientConnection(SessionCallback sc, const char *host, unsigned int port, unsigned int timedout, bool autoConnecting, bool v6)
{
	if (!sc.OnArrive || !sc.OnSslHandshakeDone)
		return nullptr;
	CSslSession *session = new CSslSession(sc, host, port, timedout, autoConnecting, v6);
	session->Start();
	return session;
}

void WINAPI DestroyClient(IClientSession *session)
{
	CSslSession *s = dynamic_cast<CSslSession *>(session);
	if (s)
	{
		s->Destroy();
		delete s;
	}
}

int WINAPI SetCertificateVerifyFile(const char *caFile)
{
	SC::CErrCode ec;
	if (caFile)
	{
		SC::ClientSide::CSslSession::m_SslContext.set_verify_mode(BOOST_SSL::context::verify_peer, ec);
		if (!ec)
			SC::ClientSide::CSslSession::m_SslContext.load_verify_file(caFile, ec);
	}
	else
		SC::ClientSide::CSslSession::m_SslContext.set_verify_mode(BOOST_SSL::context::verify_none, ec);
	return ec.value();
}