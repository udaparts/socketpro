#include "stdafx.h"
#include "clientcertificateimpl.h"
#include "../../shared/membuffer.h"

namespace SC { namespace ClientSide {

	CClientCertificateImpl::CClientCertificateImpl(SSL *pSsl)
		: m_pSsl(pSsl), m_pCert(::SSL_get_peer_certificate(m_pSsl))
	{
		m_strIssuer = ::X509_NAME_oneline(::X509_get_issuer_name(m_pCert), nullptr, 0);
		m_strSubject = ::X509_NAME_oneline(::X509_get_subject_name(m_pCert), nullptr, 0);
		SetSessionInfo();
		SetPerm();
		SetPublickey();
	}

	CClientCertificateImpl::~CClientCertificateImpl()
	{
		if (m_pCert)
			::X509_free(m_pCert);
	}

	void CClientCertificateImpl::SetPublickey()
	{
		if (m_pCert->cert_info &&
			m_pCert->cert_info->key &&
			m_pCert->cert_info->key->public_key &&
			m_pCert->cert_info->key->public_key->length > 0 &&
			m_pCert->cert_info->key->public_key->data != nullptr) 
		{
			unsigned char *data = m_pCert->cert_info->key->public_key->data;
			m_vPublicKey.assign(data, data + m_pCert->cert_info->key->public_key->length);
		}
	}

	void CClientCertificateImpl::SetSessionInfo()
	{
		char enc[4096] = {0};
		if (m_pCert != nullptr) {
			EVP_PKEY *pkey = ::X509_get_pubkey(m_pCert);
			if (pkey != nullptr) {
				if (0)
					;
#ifndef NO_RSA
				else if (pkey->type == EVP_PKEY_RSA && pkey->pkey.rsa != nullptr
					&& pkey->pkey.rsa->n != nullptr)
					sprintf_s(enc, "%d bit RSA", ::BN_num_bits(pkey->pkey.rsa->n));
#endif
#ifndef NO_DSA
				else if (pkey->type == EVP_PKEY_DSA && pkey->pkey.dsa != nullptr
					&& pkey->pkey.dsa->p != nullptr)
					sprintf_s(enc, "%d bit DSA", BN_num_bits(pkey->pkey.dsa->p));
#endif
				::EVP_PKEY_free(pkey);
			}
			/* The SSL API does not allow us to look at temporary RSA/DH keys,
			* otherwise we should print their lengths too */
		}
		CScopeBuffer sb;
		if (m_pSsl != nullptr) {
			const SSL_CIPHER *ciph = ::SSL_get_current_cipher(m_pSsl);
			sb->Push("SSL version = ");
			sb->Push(::SSL_get_version(m_pSsl));
			sb->Push(", Cipher = ");
			sb->Push((const char*) ::SSL_CIPHER_get_version(ciph));
			sb->Push(", ");
			sb->Push(::SSL_CIPHER_get_name(ciph));
			sb->Push(", ");
		}
		sb->Push(enc);
		sb->SetNull();
		m_strSessionInfo = (const char*)sb->GetBuffer();
	}

	void CClientCertificateImpl::SetPerm()
	{
		CScopeBuffer sb;
		BIO *pMem = ::BIO_new(::BIO_s_mem());
		if (pMem != nullptr) {
			BUF_MEM *bptr = nullptr;
			int nRtn = ::PEM_write_bio_X509(pMem, m_pCert);
			nRtn = ::BIO_get_mem_ptr(pMem, &bptr);
			if (nRtn > 0 && bptr != nullptr && bptr->data && bptr->length > 0)
				sb->Push(bptr->data, (unsigned int) bptr->length);
			::BIO_free_all(pMem);
		}
		sb->SetNull();
		m_strPerm = (const char*)sb->GetBuffer();
	}

	const char* const CClientCertificateImpl::Verify(int *errCode)
	{
		int res = ::SSL_get_verify_result(m_pSsl);
		if (errCode)
			*errCode = res;
		return ::X509_verify_cert_error_string(res);
	}

	const char* const CClientCertificateImpl::GetCertPem()
	{
		return m_strPerm.c_str();
	}

	bool CClientCertificateImpl::IsValid()
	{
		ASN1_TIME *pNotAfter = X509_get_notAfter(m_pCert);
		ASN1_TIME *pNotBefore = X509_get_notBefore(m_pCert);
		return (::X509_cmp_current_time(pNotAfter) >= 0 && (::X509_cmp_current_time(pNotBefore) <= 0));
	}

	const char* const CClientCertificateImpl::GetSessionInfo()
	{
		return m_strSessionInfo.c_str();
	}

	const char* const CClientCertificateImpl::GetSubject()
	{
		return m_strSubject.c_str();
	}

	const char* const CClientCertificateImpl::GetIssuer()
	{
		return m_strIssuer.c_str();
	}

	const unsigned char* const CClientCertificateImpl::GetPublicKey(unsigned int *pKeySize)
	{
		if (pKeySize)
			*pKeySize = (unsigned int)m_vPublicKey.size();
		return m_vPublicKey.data();
	}

} //namespace ClientSide
} //namespace SC
