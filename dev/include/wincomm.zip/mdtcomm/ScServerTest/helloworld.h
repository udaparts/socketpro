#pragma once


class CHelloWorld
{
public:
	CHelloWorld(SC::ServerSide::CServerHandlerBase &handler);

public:
	void ExecuteCommnds(const std::string &cmdName, const std::vector<std::string> &args);

private:
	CHelloWorld(const CHelloWorld &hw);
	CHelloWorld& operator=(const CHelloWorld &hw);

	void Sleep(unsigned int ms);
	void SayHello(const std::string &firstName, const std::string &lastName);

private:
	SC::ServerSide::CServerHandlerBase &m_Handler;
};

