#pragma once

#include "../../shared/sccommserver.h"
#include <fstream>

class CScFile
{
public:
	CScFile(SC::ServerSide::CServerHandlerBase &handler);
	virtual ~CScFile();

public:
	void StartDownloadFile(SC::CBuffer &buffer);
	void StartUploadFile(SC::CBuffer &buffer);
	void DataFromClientToServer(SC::CBuffer &buffer);
	void EndUploadFile(SC::CBuffer &buffer);
	void EndDownloadFile(SC::CBuffer &buffer);

private:
	CScFile(const CScFile &file);
	CScFile& operator=(const CScFile &file);
	void Clean();

private:
	SC::ServerSide::CServerHandlerBase &m_Handler;
	HANDLE m_hFile;
};

