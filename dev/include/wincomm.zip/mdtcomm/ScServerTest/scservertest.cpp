// ScServerTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "requesthander.h"

using namespace SC;
using namespace SC::ServerSide;
using namespace std;

int wmain(int argc, wchar_t* argv[]) {
	string errMsg  = InitializeSecureCommServer(CServerHandlerBase::OnAccepted<CRequestHandler>, 20901);
	if (!errMsg.size())
	{
#ifdef USE_OPENSSL
		errMsg = RunSecureCommServer("server.pem", "server.pem", "test", "dh512.pem");
#else
#ifndef NOT_SECURE
		errMsg = RunSecureCommServer(L"server.pfx", L"test");
#else
		errMsg = RunSecureCommServer(L"", L"");
#endif
#endif
	}
	if (errMsg.size())
		cout << "Error message = " << errMsg <<endl;
	cout << "Press any key to shutdown the application ......" << endl;
	getchar();
	ShutdownSecureCommServer();
	return 0;
}
