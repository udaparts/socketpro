﻿#include "stdafx.h"
#include "helloworld.h"
#include <iostream>
#include <future>

CHelloWorld::CHelloWorld(SC::ServerSide::CServerHandlerBase &handler)
	: m_Handler(handler)
{

}

void CHelloWorld::ExecuteCommnds(const std::string &cmdName, const std::vector<std::string> &args)
{
	if (cmdName == "sleep")
	{
		if (args.size() != 1)
			throw CExCode("Bad number of arguments!", SC::BAD_NUMBER_OF_ARGUMENTS);
		Sleep((unsigned int)atoi(args[0].c_str()));
	}
	else if (cmdName == "sayHello")
	{
		if (args.size() != 2)
			throw CExCode("Bad number of arguments!", SC::BAD_NUMBER_OF_ARGUMENTS);
		SayHello(args[0], args[1]);
	}
	else
	{
		throw CExCode("Request not supported at server side", SC::NOT_SUPPORTED_AT_SERVER_SIDE);
	}
}

void CHelloWorld::Sleep(unsigned int ms)
{
	//must call this method before using a worker thread
	bool ok = m_Handler.StartThreadProcessing();

	std::async(std::launch::async, [ms, this](){

		//std::cout <<"Going to sleep for " << ms << " millisconds" << std::endl;
		//std::this_thread::sleep_for(std::chrono::milliseconds(ms));
		::Sleep((DWORD)ms);

		this->m_Handler.Send();

		//must call this method at end
		this->m_Handler.EndThreadProcessing();
	});
}

void CHelloWorld::SayHello(const std::string &firstName, const std::string &lastName)
{
	std::string s = "Hello " + firstName + " " + lastName + "!";
	//std::cout << s << std::endl;
	m_Handler.Send(s);
}