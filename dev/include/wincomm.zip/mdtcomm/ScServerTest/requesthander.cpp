#include "stdafx.h"
#include "requesthander.h"
#include <iostream>


CRequestHandler::CRequestHandler(SC::ServerSide::IServerSession *session)
	: SC::ServerSide::CServerHandlerBase(session),
	m_HelloWorldImpl(*this),
	m_FileImpl(*this)
{

}

void CRequestHandler::OnArrive(SC::CBuffer &buffer)
{
	unsigned short reqId = GetCurrentRequestId();
	switch (reqId)
	{
	case SC::idAuthentication:
		{
			std::string userId;
			std::string password;
			std::string machineName;
			buffer >> m_nClientVersion >> userId >> password >> machineName;
			std::cout << "client version = " << m_nClientVersion << " user Id = " << userId << " pwd = " << password << " machineName = " << machineName << std::endl;
			SC::CScopeBuffer sb;
			sb << (SC::SC_SERVER_VERSION)2;
			Send(SC::idAuthentication, sb->GetBuffer(), sb->GetSize());
		}
		break;
	case SC::idDoFastRequest:
	case SC::idDoSlowRequest:
		{
			std::string cmdName;
			buffer >> cmdName;
			std::vector<std::string> args;
			while (buffer.GetSize())
			{
				std::string arg;
				buffer >> arg;
				args.push_back(arg);
			}
			m_HelloWorldImpl.ExecuteCommnds(cmdName, args);
		}
		break;
	case SC::idStartDownloadFile:
		m_FileImpl.StartDownloadFile(buffer);
		break;
	case SC::idStartUploadFile:
		m_FileImpl.StartUploadFile(buffer);
		break;
	case SC::idDataFromClientToServer:
		m_FileImpl.DataFromClientToServer(buffer);
		break;
	case SC::idEndUploadFile:
		m_FileImpl.EndUploadFile(buffer);
		break;
	case SC::idEndDownloadFile:
		m_FileImpl.EndDownloadFile(buffer);
		break;
	case SC::idHeartBeat:
		break;
	default:
		throw CExCode("Request not supported at server side", SC::NOT_SUPPORTED_AT_SERVER_SIDE);
		break;
	}
	if (buffer.GetSize() != 0)
		std::cout << "Warning: data not depacked completely with remaining " << buffer.GetSize() << " byte(s). Request id = " << reqId << std::endl;
}

void CRequestHandler::OnClosed()
{
	std::cout << "Session closed and removed with error code = " << GetErrCode() << ", err message = " << GetErrMsg() << std::endl;
}
