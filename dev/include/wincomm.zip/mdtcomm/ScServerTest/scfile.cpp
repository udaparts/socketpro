#include "stdafx.h"
#include "scfile.h"
#include "../testreqs.h"
#include <future>

CScFile::CScFile(SC::ServerSide::CServerHandlerBase &handler)
	: m_Handler(handler),
	m_hFile(INVALID_HANDLE_VALUE)
{

}

CScFile::~CScFile()
{
	Clean();
}

void CScFile::Clean()
{
	if (m_hFile != INVALID_HANDLE_VALUE)
	{
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
}

void CScFile::StartDownloadFile(SC::CBuffer &buffer)
{
	unsigned __int64 fileSize = (~0);
	std::string filePath;
	Clean();
	buffer >> filePath;

	m_hFile = ::CreateFileA(filePath.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (m_hFile == INVALID_HANDLE_VALUE)
		m_Handler.Send(idStartDownloadFile, fileSize, (int)::GetLastError());
	else
	{
		DWORD high;
		DWORD low = ::GetFileSize(m_hFile, &high);
		fileSize = high;
		fileSize <<= 32;
		fileSize += low;
		m_Handler.Send(idStartDownloadFile, fileSize, "");

		//must call this method before using a worker thread
		bool ok = m_Handler.StartThreadProcessing();

		//doing this by use of a worker thread
		std::async(std::launch::async, [this](){
			DWORD res = 0;
			SC::CScopeBuffer sb(SC_FILE_CHUNK_SIZE);
			BOOL ok = ::ReadFile(this->m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
			while (ok && res)
			{
				res = this->m_Handler.Send(idDataFromServerToClient, sb->GetBuffer(), (unsigned int)res);
				if (res == SC::SESSION_CLOSED)
					break;
				ok = ::ReadFile(this->m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
			}

			//must call this method at end
			this->m_Handler.EndThreadProcessing();
		});
	}
}

void CScFile::EndDownloadFile(SC::CBuffer &buffer)
{
	m_Handler.Send(idEndDownloadFile);
	Clean();
}

void CScFile::StartUploadFile(SC::CBuffer &buffer)
{
	std::string filePath;
	Clean();
	buffer >> filePath;
	m_hFile = ::CreateFileA(filePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (m_hFile == INVALID_HANDLE_VALUE)
		m_Handler.Send(idStartUploadFile, (int)::GetLastError());
	else
		m_Handler.Send(idStartUploadFile, "");
}

void CScFile::DataFromClientToServer(SC::CBuffer &buffer)
{
	if (m_hFile != INVALID_HANDLE_VALUE)
	{
		DWORD written;
		::WriteFile(m_hFile, buffer.GetBuffer(), buffer.GetSize(), &written, nullptr);
		assert(buffer.GetSize() == written);
		buffer.SetSize(0);
	}
	m_Handler.Send(idDataFromClientToServer);
}

void CScFile::EndUploadFile(SC::CBuffer &buffer)
{
	m_Handler.Send(idEndUploadFile);
	Clean();
}