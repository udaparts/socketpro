

#ifndef __SECURE_COMM_SERVER_SIDE_REQUEST_HANDLER_H_
#define __SECURE_COMM_SERVER_SIDE_REQUEST_HANDLER_H_

#include "helloworld.h"
#include "../../shared/scserverfile.h"

class CRequestHandler : public SC::ServerSide::CServerHandlerBase
{
private:
	virtual ~CRequestHandler(){}

public:
	CRequestHandler(SC::ServerSide::IServerSession *session);

protected:
	virtual void OnArrive(SC::CBuffer &buffer);
	virtual void OnClosed();

private:
	CHelloWorld m_HelloWorldImpl;
	SC::ServerSide::CScFile m_FileImpl;
};


#endif