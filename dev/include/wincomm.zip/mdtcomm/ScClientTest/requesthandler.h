
#ifndef __SECURE_COMM_CLIENT_SIDE_REQUEST_HANDLER_H_
#define __SECURE_COMM_CLIENT_SIDE_REQUEST_HANDLER_H_

#include "../../shared/sccommclient.h"


class CRequestHandler : public SC::ClientSide::CClientHandlerBase
{
public:
	CRequestHandler(const char *host, unsigned int port = 22260, unsigned int timedout = 60000, bool autoConnecting = true, bool v6 = false);

protected:
	virtual void OnClosed();
};


#endif