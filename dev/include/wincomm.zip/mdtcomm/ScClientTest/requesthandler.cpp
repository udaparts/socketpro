#include "stdafx.h"
#include "requesthandler.h"
#include <iostream>


CRequestHandler::CRequestHandler(const char *host, unsigned int port, unsigned int timedout, bool autoConnecting, bool v6)
	: SC::ClientSide::CClientHandlerBase(host, port, timedout, autoConnecting, v6)
{

}

void CRequestHandler::OnClosed()
{
	std::cout << "Session closed" << std::endl;
}
