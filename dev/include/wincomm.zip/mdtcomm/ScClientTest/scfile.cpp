#include "stdafx.h"
#include "scfile.h"
#include "../testreqs.h"

CScFile::CScFile(SC::ClientSide::CClientHandlerBase &handler)
	: m_Handler(handler),
	m_nFileSize(~0),
	m_hFile(INVALID_HANDLE_VALUE)
{

}

CScFile::~CScFile()
{
	Clean();
	m_Handler.SetDelegate(nullptr);
}

void CScFile::Clean()
{
	std::lock_guard<std::mutex> al(m_cs);
	if (m_hFile != INVALID_HANDLE_VALUE)
	{
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
	m_nFileSize = (~0);
}

unsigned __int64 CScFile::GetFileSize() const
{
	return m_nFileSize;
}

void CScFile::UploadFile()
{
	BOOL ok;
	DWORD dw;
	unsigned int read;
	unsigned int len = 0;
	unsigned __int64 sent = 0;
	SC::CScopeBuffer sb(SC_FILE_CHUNK_SIZE);
	unsigned int sendingBufferSize = m_Handler.GetSendingBufferSize();
	if (sendingBufferSize > 2 * SC_FILE_CHUNK_SIZE)
		return;
	{
		std::lock_guard<std::mutex> al(m_cs);
		if (m_hFile == INVALID_HANDLE_VALUE)
			return;
		ok = ::ReadFile(m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &dw, NULL);
	}
	read = (unsigned int)dw;
	while (ok && read)
	{
		len = m_Handler.SendRequest(idDataFromClientToServer, sb->GetBuffer(), read, [this](SC::ClientSide::CAsyncResult &ar){
			this->UploadFile();
		});
		if (len == SC::SESSION_CLOSED)
			break;
		assert(len == read);
		sent += read;
		if (read < SC_FILE_CHUNK_SIZE)
			break; //no more data to be read
		sendingBufferSize = m_Handler.GetSendingBufferSize();
		if (sendingBufferSize > 10 * SC_FILE_CHUNK_SIZE)
			break;
		m_cs.lock();
		ok = ::ReadFile(m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &dw, NULL);
		m_cs.unlock();
		read = dw;
	}
	if (sent && len != SC::SESSION_CLOSED && Progress)
	{
		LARGE_INTEGER distance;
		LARGE_INTEGER newPos;
		distance.QuadPart = 0;
		m_cs.lock();
		ok = ::SetFilePointerEx(m_hFile, distance, &newPos, FILE_CURRENT);
		m_cs.unlock();
		assert(ok);
		Progress(this, (unsigned __int64)newPos.QuadPart);
	}
	if (sent < SC_FILE_CHUNK_SIZE && len != SC::SESSION_CLOSED) {
		Clean();
		//we need to inform server there is no more data to be uploaded
		m_Handler.SendRequest(idEndUploadFile, [this](SC::ClientSide::CAsyncResult &ar){
			
		});
	}
}

int CScFile::UploadFile(const char *remoteFile, const char *localFile)
{
	Clean();
	int res = 0;
	{
		std::lock_guard<std::mutex> al(m_cs);
		m_hFile = ::CreateFileA(localFile, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (m_hFile == INVALID_HANDLE_VALUE)
			return ::GetLastError();
		DWORD high;
		DWORD low = ::GetFileSize(m_hFile, &high);
		m_nFileSize = high;
		m_nFileSize <<= 32;
		m_nFileSize += low;
	}

	if (m_Handler.SendRequest(idStartUploadFile, remoteFile, [&res](SC::ClientSide::CAsyncResult &ar){
		ar >> res;
	}) != SC::SESSION_CLOSED)
	{
		if (!m_Handler.WaitAll())
			res = m_Handler.GetErrCode();
		else if (!res)
			UploadFile();
	}
	else
		res = m_Handler.GetErrCode();
	return res;
	
}

int CScFile::DownloadFile(const char *remoteFile, const char *localFile)
{
	Clean();
	int res = 0;
	{
		std::lock_guard<std::mutex> al(this->m_cs);
		m_hFile = ::CreateFileA(localFile, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
		if (m_hFile == INVALID_HANDLE_VALUE)
			return ::GetLastError();
	}
	m_Handler.SetDelegate([this](unsigned short reqId, SC::CBuffer &buffer){
		DWORD written;
		if (reqId != idDataFromServerToClient)
			return;
		std::lock_guard<std::mutex> al(this->m_cs);
		::WriteFile(this->m_hFile, buffer.GetBuffer(), buffer.GetSize(), &written, nullptr);
		assert(buffer.GetSize() == written);
		buffer.SetSize(0);
		if (Progress)
		{
			DWORD high;
			DWORD low = ::GetFileSize(this->m_hFile, &high);
			unsigned __int64 pos = high;
			pos <<= 32;
			pos += low;
			Progress(this, pos);
		}
	});

	if (m_Handler.SendRequest(idStartDownloadFile, remoteFile, [this, &res](SC::ClientSide::CAsyncResult &ar){
		std::lock_guard<std::mutex> al(this->m_cs);
		ar >> this->m_nFileSize >> res;
	}) != SC::SESSION_CLOSED)
	{
		if (!m_Handler.WaitAll())
			res = m_Handler.GetErrCode();
		else 
		{
			if (res == 0 && m_Handler.SendRequest(idEndDownloadFile, [this](SC::ClientSide::CAsyncResult &ar){
				this->Clean();
			}) == SC::SESSION_CLOSED)
				res = m_Handler.GetErrCode();
		}
	}
	else
		res = m_Handler.GetErrCode();
	return res;
}