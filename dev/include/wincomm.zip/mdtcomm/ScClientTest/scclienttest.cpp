﻿// ScClientTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "requesthandler.h"
#include "..\..\shared\scclientfile.h"
#include <fstream>
#include <ctime>
#include <chrono>
using namespace std::chrono;

int TestOne(const std::string &addr);
int TestTwo(const std::string &addr);

int wmain(int argc, wchar_t* argv[]) {

#ifdef USE_OPENSSL
	int errCode = ::SetCertificateVerifyFile("ca.pem");
#else
#ifndef NOT_SECURE
	//default to window system ROOT store
	int errCode = ::SetCertificateVerifyFile("ROOT");
	//int errCode = ::SetCertificateVerifyFile("MY");
	//int errCode = ::SetCertificateVerifyFile("CA");
	//int errCode = ::SetCertificateVerifyFile("C:\\cyedev\\commlib\\mdtcomm\\ca.cer");
#endif
#endif
	std::cout << "Input an ip address to remote server" << std::endl;
	std::string addr;
	std::getline(std::cin, addr);
	return TestTwo(addr);
}

std::string getNow()
{
	std::time_t now = std::time(nullptr);
	std::tm *tm = std::localtime(&now);
	char str[256] = {0};
	::sprintf(str, "%.2d%.2d%.2d%.2d%.2d", tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
	return std::to_string(tm->tm_year + 1900) + str;
}

int TestTwo(const std::string &addr)
{
	int n;
	unsigned int ms;
	int cycles;
	int errCode;

	//Call DoClientConnection within constructor
	//Call DestroyClient within destructor
	CRequestHandler handler(addr.c_str(), 20901); 

#ifndef NOT_SECURE
	SC::ICertificate *cert = handler.GetCertificate();
	if (!cert) {
		std::cout << "No connection! error code = " << handler.GetErrCode() 
			<< ", error message = " << handler.GetErrMsg() << std::endl;
		std::cout << "Press any key to shutdown the application ......" << std::endl;
		std::getchar();
		return 1;
	}
	const char *msg = cert->Verify(&errCode);
#endif
	//do authentication first, which is required from server side for better security
	if (!handler.DoAuthentication("MDTUser", "SomePassword", "charliedev-1")) {
		std::cout << "Authentication failed with error message: " << handler.GetErrMsg() << std::endl;
		std::cout << "Press any key to shutdown the application ......" << std::endl;
		std::getchar();
		return 1;
	}

	std::string res;
	std::cout << "We are going to test a fast request performance. Please tell me testing cycles ......" << std::endl;
	std::cin >> cycles;

	std::ofstream myfile;
	std::string fileName("per_result_" + getNow() + ".txt");
	myfile.open(fileName);
	if (!myfile.is_open())
	{
		std::cout << "File opening failed with error message = " << std::strerror(errno) << std::endl;
		std::cout << "Press any key to shutdown the application ......" << std::endl;
		std::getchar();
		return 1;
	}
	
	myfile << "We are going to test a fast request performance. Testing cycles = " << cycles << std::endl;
	auto start = high_resolution_clock::now();
	for (n = 0; n < cycles; ++n)
	{
		//test method sayHello
		res = handler.ProcessRequest("sayHello",	//command name
			"Philip",		//arg0
			"Dalrymple"		//arg1
			);
	}
	auto end = high_resolution_clock::now();
	duration<double> time_span = duration_cast<duration<double>>(end - start);
	std::cout << "Time required for fast request = " << time_span.count() << std::endl;
	myfile << "Time required for fast request = " << time_span.count() << std::endl;

	std::cout << "We are going to test a slow request performance. Please tell me testing cycles ......" << std::endl;
	std::cin >> cycles;
	std::cout << "Please tell me sleeping time in milliseconds ......" << std::endl;
	std::cin >> ms;
	myfile << "We are going to test a slow request performance. Testing cycles = " << cycles << ", Sleeping time = " << ms << std::endl;
	std::string sleepingTime = std::to_string(ms);
	start = high_resolution_clock::now();
	for (n = 0; n < cycles; ++n)
	{
		res = handler.ProcessRequest("sleep", sleepingTime.c_str());
	}
	end = high_resolution_clock::now();
	time_span = duration_cast<duration<double>>(end - start);
	std::cout << "Time required for slow request = " << time_span.count() << std::endl;
	myfile << "Time required for slow request = " << time_span.count() << std::endl;

	SC::ClientSide::CScFile file(handler);
	std::cout << "We are going to test file echo, including both uploading and downloading. Please tell me testing cycles ......" << std::endl;
	std::cin >> cycles;
	std::getchar();
	std::cout << "Input a local file for uploading and downloading ......" << std::endl;
	std::string localFile;
	std::getline(std::cin, localFile);
	file.Progress = [](SC::ClientSide::CScFile *sender, unsigned __int64 pos) {
#ifdef SHOW_OUTPUT
		pos *= 100;
		std::cout << "Progress = " << pos/sender->GetFileSize() << "%" << std::endl;
#endif
	};
	size_t pos = localFile.rfind('\\');
	std::string remoteFile = localFile.substr(pos + 1);
	myfile << "We are going to test echoing a file " << localFile << ". Testing cycles = " << cycles << std::endl;
	start = high_resolution_clock::now();
	for (n = 0; n < cycles; ++n)
	{
		errCode = file.UploadFile(remoteFile.c_str(), localFile.c_str());
		if (errCode == 0 && handler.WaitAll(~0))
		{
			//std::cout << "File upload successful" << std::endl;
		}
		else if (errCode)
		{
			std::cout << "File upload failed with error code = " << res << std::endl;
			break;
		}
		else
		{
			std::cout << "File upload failed with error message = " << handler.GetErrMsg() << std::endl;
			break;
		}
		if (cycles == 1)
		{
			end = high_resolution_clock::now();
			time_span = duration_cast<duration<double>>(end - start);
			std::cout << "Time required for uploading the file " << remoteFile << " = " << time_span.count() << std::endl;
		}
		std::string lf = "mytest.dat";
		res = file.DownloadFile(remoteFile.c_str(), lf.c_str());
		if (errCode == 0 && handler.WaitAll(~0))
		{
			//std::cout << "File download successful" << std::endl;
		}
		else if (errCode)
		{
			std::cout << "File download failed with error code = " << res << std::endl;
			break;
		}
		else
		{
			std::cout << "File download failed with error message = " << handler.GetErrMsg() << std::endl;
			break;
		}
		//std::cout << "Cycle index = " << n + 1 << std::endl;
		file.Clean();
	}
	end = high_resolution_clock::now();
	time_span = duration_cast<duration<double>>(end - start);
	std::cout << "Time required for echoing the file " << remoteFile << " = " << time_span.count() << std::endl;
	myfile << "Time required for echoing the file = " << time_span.count() << std::endl;
	myfile.close();
	std::cout << "Press any key to shutdown the application ......" << std::endl;
	std::getchar();
	return 0;
}

int TestOne(const std::string &addr)
{
	int n;
	int cycles;
	int errCode;
	
	//Call DoClientConnection within constructor
	//Call DestroyClient within destructor
	CRequestHandler handler(addr.c_str(), 20901); 

	SC::ICertificate *cert = handler.GetCertificate();
	if (!cert) {
		std::cout << "No connection! error code = " << handler.GetErrCode() 
			<< ", error message = " << handler.GetErrMsg() << std::endl;
		return 1;
	}

	//do ceritificate verification before sending any sensitive data
	const char *str = cert->Verify(&errCode);
	std::cout << "Cert verification result = " << str
		<< " with error code = " << errCode << std::endl;
	std::cout << "SSL session info: " << cert->GetSessionInfo() << std::endl;
#ifdef USE_OPENSSL
	std::cout << "Cert perm :\r\n" << cert->GetCertPem() << std::endl;
#endif

	//do authentication first, which is required from server side for better security
	if (!handler.DoAuthentication("MDTUser", "SomePassword", "charliedev-1")) {
		std::cout << "Authentication failed with error message: " << handler.GetErrMsg() << std::endl;
		return 1;
	}

	std::string res;
	std::cout << "Tell me testing cycles, please ......" << std::endl;
	std::cin >> cycles;
	auto start = high_resolution_clock::now();
	for (n = 0; n < cycles; ++n)
	{
		//test method sayHello
		res = handler.ProcessRequest("sayHello",	//command name
			"Philip",		//arg0
			"Dalrymple"		//arg1
			);
#ifdef SHOW_OUTPUT
		std::cout << "sayHello returns: " << res << std::endl;
#endif

		//test method sleep

#ifdef TEST_SLEEP
		res = handler.ProcessRequest("sleep", std::to_string(std::rand() % 5).c_str());
#ifdef SHOW_OUTPUT
		std::cout << "sleep returns: " << res << std::endl;
#endif
#endif	
		//test exception
#ifdef TEST_EXCEPTION
		try
		{
			res = handler.ProcessRequest("doException", true);
#ifdef SHOW_OUTPUT
			std::cout << "Should NOT come here!!!" << std::endl;
#endif
		}
		catch(SC::CException &err)
		{
#ifdef SHOW_OUTPUT
			std::cout << "We caught an exception as expected!" << std::endl;
			std::cout << err.GetStack() << std::endl;
#endif
		}
#endif
	}
	auto end = high_resolution_clock::now();
	duration<double> time_span = duration_cast<duration<double>>(end - start);
	std::cout << "Time required = " << time_span.count() << std::endl;
	std::getchar();

	do
	{
		//test file uploading and downloading
		{
			SC::ClientSide::CScFile file(handler);
			file.Progress = [](SC::ClientSide::CScFile *sender, unsigned __int64 pos){
#ifdef SHOW_OUTPUT
				pos *= 100;
				std::cout << "Progress = " << pos/sender->GetFileSize() << "%" << std::endl;
#endif
			};

			std::cout << "Input a local file for uploading ......" << std::endl;
			std::string localFile;
			std::getline(std::cin, localFile);

			start = high_resolution_clock::now();
			size_t pos = localFile.rfind('\\');
			std::string remoteFile = localFile.substr(pos + 1);
			int res = file.UploadFile(remoteFile.c_str(), localFile.c_str());
			if (res == 0 && handler.WaitAll(~0))
				std::cout << "File upload successful" << std::endl;
			else if (res)
				std::cout << "File upload failed with error code = " << res << std::endl;
			else
				std::cout << "File upload failed with error message = " << handler.GetErrMsg() << std::endl;
			end = high_resolution_clock::now();
			time_span = duration_cast<duration<double>>(end - start);
			std::cout << "Time required = " << time_span.count() << std::endl;

			std::cout << "We are going to test downloading ......" << std::endl;

			std::cout << "Input a local file path to receive a file ......" << std::endl;
			//std::getline(std::cin, localFile);
			localFile = "mytest.dat";
			start = high_resolution_clock::now();
			res = file.DownloadFile(remoteFile.c_str(), localFile.c_str());
			if (res == 0 && handler.WaitAll(~0))
				std::cout << "File download successful" << std::endl;
			else if (res)
				std::cout << "File download failed with error code = " << res << std::endl;
			else
				std::cout << "File download failed with error message = " << handler.GetErrMsg() << std::endl;
			end = high_resolution_clock::now();
			time_span = duration_cast<duration<double>>(end - start);
			std::cout << "Time required = " << time_span.count() << std::endl;
		}
		std::cout << "Input a number (1 or larger for continue ......" << std::endl;
		std::cin >> cycles;
		std::getchar();
	} while(cycles > 0 && handler.GetSessionState() >= SC::ssConnected);
	std::cout << "Press any key to shutdown the application ......" << std::endl;
	std::getchar();
	return 0;
}