
#pragma once

class CScFile {
public:
	CScFile(SC::ClientSide::CClientHandlerBase &handler);
	virtual ~CScFile();

	typedef std::tr1::function<void(CScFile*, unsigned __int64 pos) > DProgress;

public:
	int UploadFile(const char *remoteFile, const char *localFile);
	int DownloadFile(const char *remoteFile, const char *localFile);
	unsigned __int64 GetFileSize() const;
	void Clean();
	DProgress Progress;

private:
	//disable copy constructor and assignment operator
	CScFile(const CScFile& file);
	CScFile& operator=(const CScFile& file);
	void UploadFile();
	
private:
	SC::ClientSide::CClientHandlerBase &m_Handler;
	unsigned __int64 m_nFileSize; //protected by m_cs
	HANDLE m_hFile; //protected by m_cs
	std::mutex m_cs;
};

