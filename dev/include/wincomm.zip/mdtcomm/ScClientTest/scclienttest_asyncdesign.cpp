﻿// ScClientTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "requesthandler.h"
#include "scfile.h"
#include "../testreqs.h"

int wmain(int argc, wchar_t* argv[]) {
	int errCode = ::SetCertificateVerifyFile("ca.pem");

	//Call DoClientConnection within constructor
	//Call DestroyClient within destructor
	std::cout << "Input an ip address to remote server" << std::endl;
	std::string addr;
	std::getline(std::cin, addr);
	CRequestHandler handler(addr.c_str(), 20901); 

	SC::ICertificate *cert = handler.GetCertificate();
	if (!cert) {
		std::cout << "No connection! error code = " << handler.GetErrCode() 
			<< ", error message = " << handler.GetErrMsg() << std::endl;
		return 1;
	}

	//do ceritificate verification before sending any sensitive data
	const char *str = cert->Verify(&errCode);
	std::cout << "Cert verification result = " << str
		<< " with error code = " << errCode << std::endl;
	std::cout << "SSL session info: " << cert->GetSessionInfo() << std::endl;
	std::cout << "Cert perm :\r\n" << cert->GetCertPem() << std::endl;

	//do authentication first, which is required from server side for better security
	if (!handler.DoAuthentication("MDTUser", "SomePassword", "charliedev-1")) {
		std::cout << "Authentication failed" << std::endl;
		return 1;
	}

	//set a callback for returning result
	SC::ClientSide::ResultHandler rh = [](SC::ClientSide::CAsyncResult &ar) {
		std::string res;
		ar >> res;
		std::cout << res << std::endl;
	};
	unsigned int res = handler.SendRequest(idSayHelloWorld, "Philip", "Dalrymple", rh);
	res = handler.SendRequest(idSleep, (unsigned int)5000, [](SC::ClientSide::CAsyncResult &ar){});
	res = handler.SendRequest(idSayHelloWorld, "Bob", "Gargan", rh);
	res = handler.SendRequest(idSayHelloWorldEx, L"Grüß", L"möchte", [](SC::ClientSide::CAsyncResult &ar){
		std::wstring res;
		ar >> res;
		std::wcout << res << std::endl;
	});
	bool ok = handler.WaitAll(); //convert asynchronous computations into synchrnous ones
	{
		CScFile file(handler);
		file.Progress = [](CScFile *sender, unsigned __int64 pos){
			pos *= 100;
			std::cout << "Progress = " << pos/sender->GetFileSize() << "%" << std::endl;
		};

		std::cout << "Input a local file for uploading ......" << std::endl;
		std::string localFile;
		std::getline(std::cin, localFile);

		size_t pos = localFile.rfind('\\');
		std::string remoteFile = localFile.substr(pos + 1);
		int res = file.UploadFile(remoteFile.c_str(), localFile.c_str());
		if (res == 0 && handler.WaitAll())
			std::cout << "File upload successful" << std::endl;
		else if (res)
			std::cout << "File upload failed with error code = " << res << std::endl;
		else
			std::cout << "File upload failed with error message = " << handler.GetErrMsg() << std::endl;
		std::cout << "Press any key to test downloading ......" << std::endl;
		::getchar();

		std::cout << "Input a local file path to receive a file ......" << std::endl;
		std::getline(std::cin, localFile);
		res = file.DownloadFile(remoteFile.c_str(), localFile.c_str());
		if (res == 0 && handler.WaitAll())
			std::cout << "File download successful" << std::endl;
		else if (res)
			std::cout << "File download failed with error code = " << res << std::endl;
		else
			std::cout << "File download failed with error message = " << handler.GetErrMsg() << std::endl;
	}
	std::cout << "Press any key to shutdown the application ......" << std::endl;
	::getchar();
	return 0;
}
