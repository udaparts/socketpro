#ifndef ___SECURE_COMM_SSL_SOCKET_BASE_DEFINES_I_H__
#define ___SECURE_COMM_SSL_SOCKET_BASE_DEFINES_I_H__

#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <memory>
#include <mutex>
#include <thread>

namespace SC {
	namespace BOOST_ASIO = boost::asio;
	namespace BOOST_SSL = BOOST_ASIO::ssl;
	namespace BOOST_IP = BOOST_ASIO::ip;
	typedef BOOST_SSL::stream<BOOST_IP::tcp::socket> CSslSocket;
	typedef BOOST_SSL::context CSslContext;
	typedef BOOST_ASIO::io_service CIoService;
	typedef boost::system::error_code CErrCode;
	typedef BOOST_IP::tcp::endpoint CEndPoint;
	typedef std::mutex CMutex;
	typedef std::unique_lock<std::mutex> CAutoLock;

#pragma pack(push,1)
	typedef struct CRequestHeader {
		CRequestHeader()
			: RequestId(0),
			Reserved(0),
			Size(0) {
		}
		void Reset() {
			RequestId = 0;
			Reserved = 0;
			Size = 0;
		}
		unsigned short RequestId; //A request identification number, which can NOT be zero
		unsigned short Reserved; //Reserved for the future use, for example, online compression/decompression
		unsigned int Size; //Request chunk data size in bytes
	} RequestHeader;
#pragma pack(pop)
}


#endif