
#pragma once


//sample hello world request id
static const unsigned short idSayHelloWorld = SC::idStartRequestId;
static const unsigned short idSleep = idSayHelloWorld + 1;
static const unsigned short idSayHelloWorldEx = idSleep + 1;


//file implementation request id
static const unsigned short idStartDownloadFile = SC::idStartRequestId + 1024;
static const unsigned short idStartUploadFile = idStartDownloadFile + 1;
static const unsigned short idDataFromServerToClient = idStartUploadFile + 1;
static const unsigned short idDataFromClientToServer = idDataFromServerToClient + 1;
static const unsigned short idEndDownloadFile = idDataFromClientToServer + 1;
static const unsigned short idEndUploadFile = idEndDownloadFile + 1;
static const unsigned int SC_FILE_CHUNK_SIZE = 20480; //20 k