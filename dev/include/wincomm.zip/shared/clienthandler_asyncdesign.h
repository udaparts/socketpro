
#ifndef _SECURE_COMM_COMMUNICATION_ADAPTER_CLIENT_HANDLER_H_
#define _SECURE_COMM_COMMUNICATION_ADAPTER_CLIENT_HANDLER_H_

#include "sccommclient.h"
#include "cshandler_asyncdesign.h"

//Client core library does NOT use the below code
#include <deque>
namespace SC { namespace ClientSide {

	class CClientHandlerBase;
	class CAsyncResult;

	typedef std::tr1::function<void(CAsyncResult&) > ResultHandler;
	typedef std::tr1::function<void(unsigned short, CBuffer&) > ResultHandlerEx;

	class CAsyncResult {
	private:
		CAsyncResult(CClientHandlerBase *pAsyncHandler, unsigned short ReqId, CBuffer &buffer, ResultHandler & rh)
			: AsyncHandler(pAsyncHandler), RequestId(ReqId), Buffer(buffer), CurrentAsyncResultHandler(rh) {
		}

	public:
		template<class ctype >
		CBuffer& operator >>(ctype & receiver) {
			Buffer >> receiver;
			return Buffer;
		}

	public:
		CClientHandlerBase *AsyncHandler;
		unsigned short RequestId;
		CBuffer &Buffer;
		ResultHandler &CurrentAsyncResultHandler;

	private:
		//disable copy constructor and assignment operator
		CAsyncResult(const CAsyncResult & ar);
		CAsyncResult& operator=(const CAsyncResult & ar);

		friend class CClientHandlerBase;
	};

	class CClientHandlerBase : public CHandler
	{
	protected:
		CClientHandlerBase(const char *host, unsigned int port = 22260, unsigned int timedout = 60000, bool autoConnecting = true, bool v6 = false)
			: CHandler(nullptr),
			m_nServerVersion(SC_INITIAL_COMM_VERSION),
			m_pException(nullptr)
		{
			SessionCallback sc;
			sc.OnClose = SC::ClientSide::OnClosed;
			sc.OnLess = SC::OnLess;
			sc.OnArrive = SC::OnArrive;
			sc.OnSslHandshakeDone = SC::OnSslHandshakeCompeleted;
			std::unique_lock<std::mutex> al(g_cs);
			m_pSession = ::DoClientConnection(sc, host, port, timedout, autoConnecting, v6);
			if (m_pSession)
			{
				g_mapSessionHandler[m_pSession] = this;
				DelaySet(m_pSession);
			}
		}

		virtual ~CClientHandlerBase()
		{
			Destroy();
			std::unique_lock<std::mutex> al(m_cs);
			delete m_pException;
		}

	public:
		bool DoAuthentication(const char *userId, const char *pwd, const char *machineName, unsigned int version = SC_INITIAL_COMM_VERSION)
		{
			SendRequest(idAuthentication, version, userId, pwd, machineName, [this](CAsyncResult &ar){
				ar >> this->m_nServerVersion;
			});
			return WaitAll();
		}

		inline bool WaitAll(unsigned int ms = (~0)) const
		{
			return m_pSession->WaitAll(ms);
		}

		inline bool IsAutoConnecting() const
		{

			return m_pSession->IsAutoConnecting();
		}

		inline ICertificate* GetCertificate() const
		{
			return m_pSession->GetCertificate();
		}

		inline bool IsConnected() const
		{
			return (m_pSession->GetCertificate() != nullptr);
		}

		inline SC_SERVER_VERSION GetServerVersion() const
		{
			return m_nServerVersion;
		}

		inline size_t GetQueuedRequestCount() const
		{
			return m_pSession->GetRequestCountQueued();
		}

		CException GetLastServerException(unsigned short *pExceptionRequestId = nullptr)
		{
			std::unique_lock<std::mutex> al(m_cs);
			if (pExceptionRequestId)
				*pExceptionRequestId = m_nExceptionRequestId;
			if (m_pException)
				return *m_pException;
			return CException("", "", ERROR_OK);
		}

		virtual unsigned short GetCurrentRequestId()
		{
			std::unique_lock<std::mutex> al(m_cs);
			return CHandler::GetCurrentRequestId();
		}

		virtual unsigned int SendRequest(unsigned short reqId, const unsigned char *pBuffer, unsigned int size, const ResultHandler &rh)
		{
			bool oneway = !rh;
			std::unique_lock<std::mutex> al(m_cs);
			unsigned int res = m_pSession->Send(reqId, pBuffer, size, oneway);
			if (res == size && rh)
				m_vCallback.push_back(std::pair<unsigned short, ResultHandler>(reqId, rh));
			return res;
		}

		unsigned int SendRequest(unsigned short reqId, const ResultHandler &rh)
		{
			return SendRequest(reqId, (const unsigned char *)nullptr, (unsigned int)0, rh);
		}

		template<typename T0>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2, typename T3>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2, typename T3, typename T4>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3 << t4;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3 << t4 << t5;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3 << t4 << t5 << t6;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const T7 &t7, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3 << t4 << t5 << t6 << t7;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const T7 &t7, const T8 &t8, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3 << t4 << t5 << t6 << t7 << t8;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		template<typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9>
		unsigned int SendRequest(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4, const T5 &t5, const T6 &t6, const T7 &t7, const T8 &t8, const T9 &t9, const ResultHandler &rh) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3 << t4 << t5 << t6 << t7 << t8 << t9;
			return SendRequest(reqId, sb->GetBuffer(), sb->GetSize(), rh);
		}

		void SetDelegate(ResultHandlerEx rhe)
		{
			std::unique_lock<std::mutex> al(m_cs);
			m_rhe = rhe;
		}

		ResultHandlerEx GetDelegate()
		{
			std::unique_lock<std::mutex> al(m_cs);
			return m_rhe;
		}

	protected:
		virtual void OnArrive(CBuffer &buffer)
		{

		}

		virtual void OnServerException(const CException * const exception)
		{

		}

	private:
		void Destroy()
		{
			if (!m_pSession)
				return;
			std::unique_lock<std::mutex> al(g_cs);
			std::unordered_map<ISession*, CHandler*>::iterator it = g_mapSessionHandler.find(m_pSession);
			if (it != g_mapSessionHandler.end())
			{
				g_mapSessionHandler.erase(it);
				::DestroyClient(m_pSession);
			}
			m_pSession = nullptr;
		}

		//don't overwrite this version Arrive from your class
		virtual void OnArrive(unsigned short RequestId, CBuffer &buffer) final
		{
			std::pair<unsigned short, ResultHandler> rr;
			{
				std::unique_lock<std::mutex> al(m_cs);
				CHandler::OnArrive(RequestId, buffer);
			}

			if (RequestId != idServerException)
			{
				{
					std::unique_lock<std::mutex> al(m_cs);
					if (m_vCallback.size() && m_vCallback.front().first == RequestId)
					{
						rr = m_vCallback.front();
						m_vCallback.pop_front();
					}
				}
				if (rr.second)
				{
					CAsyncResult ar(this, RequestId, buffer, rr.second);
					rr.second(ar);
				}
				else
				{
					bool processed = false;
					{
						std::unique_lock<std::mutex> al(m_cs);
						if (m_rhe)
						{
							m_rhe(RequestId, buffer);
							processed = true;
						}
					}
					if (!processed)
						OnArrive(buffer);
				}
			}
			else
			{
				int errCode;
				std::string errMsg;
				std::string stack;
				buffer >> errCode >> errMsg >> stack;

				{
					std::unique_lock<std::mutex> al(m_cs);
					delete m_pException;
					m_pException = new CException(errMsg.c_str(), stack.c_str(), errCode);
					m_nExceptionRequestId = CHandler::GetCurrentRequestId();
					if (m_vCallback.size() && m_vCallback.front().first == m_nExceptionRequestId)
					{
						rr = m_vCallback.front();
						m_vCallback.pop_front();
					}
				}
				OnServerException(m_pException);
			}
		}

		//no copy constructor and assigment operator
		CClientHandlerBase(const CClientHandlerBase &handler);
		CClientHandlerBase& operator=(const CClientHandlerBase &handler);

	private:
		IClientSession *m_pSession;
		SC_SERVER_VERSION m_nServerVersion;
		CException *m_pException; //protected by m_cs
		unsigned short m_nExceptionRequestId; //protected by m_cs
		std::mutex m_cs;
		typedef std::deque< std::pair<unsigned short, ResultHandler> > CRHVector;
		CRHVector m_vCallback; //protected by m_cs
		ResultHandlerEx m_rhe; //protected by m_cs
		friend static void CALLBACK OnClosed(ISession *session);
	};

	static void CALLBACK OnClosed(ISession *session)
	{
		ISessionCallback *h = CHandler::Find(session);
		h->OnClosed();
		CClientHandlerBase *ch = dynamic_cast<CClientHandlerBase *>(h);
		if (ch)
		{
			ch->m_cs.lock();
			ch->m_vCallback.clear();
			ch->m_cs.unlock();
		}
	}

} //namespace ClientSide
} //namespace SC

#endif