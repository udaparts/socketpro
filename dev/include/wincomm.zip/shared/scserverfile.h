#pragma once

#include "../../shared/sccommserver.h"
#include <fstream>
#include <future>

namespace SC{ namespace ServerSide {

	class CScFile
	{
	public:
		CScFile(SC::ServerSide::CServerHandlerBase &handler)
			: m_Handler(handler),
			m_hFile(INVALID_HANDLE_VALUE)
		{

		}

		virtual ~CScFile()
		{
			Clean();
		}

	public:
		void StartDownloadFile(SC::CBuffer &buffer)
		{
			unsigned __int64 fileSize = (~0);
			std::string filePath;
			Clean();
			buffer >> filePath;
			CScopeBuffer sb;
			m_hFile = ::CreateFileA(filePath.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
			if (m_hFile == INVALID_HANDLE_VALUE)
			{
				sb << fileSize << (int)::GetLastError();
				m_Handler.Send(idStartDownloadFile, sb->GetBuffer(), sb->GetSize());
			}
			else
			{
				DWORD high;
				DWORD low = ::GetFileSize(m_hFile, &high);
				fileSize = high;
				fileSize <<= 32;
				fileSize += low;

				sb << fileSize << (int)0;
				m_Handler.Send(idStartDownloadFile, sb->GetBuffer(), sb->GetSize());

				//must call this method before using a worker thread
				bool ok = m_Handler.StartThreadProcessing();

				//doing this by use of a worker thread
				std::async(std::launch::async, [this](){
					DWORD res = 0;
					SC::CScopeBuffer sb(SC_FILE_CHUNK_SIZE);
					BOOL ok = ::ReadFile(this->m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
					while (ok && res)
					{
						res = this->m_Handler.Send(idDataFromServerToClient, sb->GetBuffer(), (unsigned int)res);
						if (res == SC::SESSION_CLOSED)
							break;
						ok = ::ReadFile(this->m_hFile, (unsigned char*)sb->GetBuffer(), SC_FILE_CHUNK_SIZE, &res, nullptr);
					}

					//must call this method at end
					this->m_Handler.EndThreadProcessing();
				});
			}
		}

		void StartUploadFile(SC::CBuffer &buffer)
		{
			std::string filePath;
			Clean();
			buffer >> filePath;
			CScopeBuffer sb;
			m_hFile = ::CreateFileA(filePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
			if (m_hFile == INVALID_HANDLE_VALUE)
				sb << (int)::GetLastError();
			else
				sb << (int)0;
			m_Handler.Send(idStartUploadFile, sb->GetBuffer(), sb->GetSize());
		}

		void DataFromClientToServer(SC::CBuffer &buffer)
		{
			if (m_hFile != INVALID_HANDLE_VALUE)
			{
				DWORD written;
				::WriteFile(m_hFile, buffer.GetBuffer(), buffer.GetSize(), &written, nullptr);
				assert(buffer.GetSize() == written);
				buffer.SetSize(0);
			}
			m_Handler.Send(idDataFromClientToServer, (const unsigned char*)nullptr, (unsigned int)0);
		}

		void EndUploadFile(SC::CBuffer &buffer)
		{
			m_Handler.Send(idEndUploadFile, (const unsigned char*)nullptr, (unsigned int)0);
			Clean();
		}

		void EndDownloadFile(SC::CBuffer &buffer)
		{
			m_Handler.Send(idEndDownloadFile, (const unsigned char*)nullptr, (unsigned int)0);
			Clean();
		}

	private:
		CScFile(const CScFile &file);
		CScFile& operator=(const CScFile &file);
		void Clean()
		{
			if (m_hFile != INVALID_HANDLE_VALUE)
			{
				::CloseHandle(m_hFile);
				m_hFile = INVALID_HANDLE_VALUE;
			}
		}

	private:
		SC::ServerSide::CServerHandlerBase &m_Handler;
		HANDLE m_hFile;
	};

} //namespace ServerSide
} //namespace SC