
#ifndef _SECURE_COMM_COMMUNICATION_ADAPTER_SERVER_HANDLER_H_
#define _SECURE_COMM_COMMUNICATION_ADAPTER_SERVER_HANDLER_H_

#include "sccommserver.h"
#include "cshandler_asyncdesign.h"

//Server core library does NOT use the below code
namespace SC { namespace ServerSide {

	class CServerHandlerBase : public CHandler
	{
	protected:
		virtual ~CServerHandlerBase(){}
		CServerHandlerBase(IServerSession *session)
			: CHandler(session),
			m_pSession(session),
			m_nClientVersion(SC_INITIAL_COMM_VERSION)
		{

		}

	public:
		inline bool StartThreadProcessing() const
		{
			return m_pSession->StartThreadProcessing();
		}

		inline bool EndThreadProcessing() const
		{
			return m_pSession->EndThreadProcessing();
		}

		inline SC_CLIENT_VERSION GetClientversion() const
		{
			return m_nClientVersion;
		}

		unsigned int Send(unsigned short reqId, const unsigned char *pBuffer, unsigned int size) const
		{
			return m_pSession->Send(reqId, pBuffer, size);
		}

		unsigned int Send(unsigned short reqId) const
		{
			return Send(reqId, (const unsigned char *)nullptr, (unsigned int)0);
		}

		template<typename T0>
		unsigned int Send(unsigned short reqId, const T0 &t0) const {
			CScopeBuffer sb;
			sb << t0;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename T0, typename T1>
		unsigned int Send(unsigned short reqId, const T0 &t0, const T1 &t1) const {
			CScopeBuffer sb;
			sb << t0 << t1;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename T0, typename T1, typename T2>
		unsigned int Send(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2) {
			CScopeBuffer sb;
			sb << t0 << t1 << t2;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename T0, typename T1, typename T2, typename T3>
		unsigned int Send(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3) const {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		template<typename T0, typename T1, typename T2, typename T3, typename T4>
		unsigned int Send(unsigned short reqId, const T0 &t0, const T1 &t1, const T2 &t2, const T3 &t3, const T4 &t4) const {
			CScopeBuffer sb;
			sb << t0 << t1 << t2 << t3 << t4;
			return Send(reqId, sb->GetBuffer(), sb->GetSize());
		}

		inline unsigned int SendException(unsigned short CurrentRequestId, int errCode, const char *const errMessage, const char *const stack) const
		{
			return m_pSession->SendException(CurrentRequestId, errCode, errMessage, stack);
		}

		inline unsigned int SendException(unsigned short CurrentRequestId, const CException &err) const
		{
			return SendException(CurrentRequestId, err.GetErrCode(), err.what(), err.GetStack().c_str());
		}

	public:
		template <typename ServerHandler>
		static SessionCallback CALLBACK OnAccepted(IServerSession *session)
		{
			assert(session); //valid session pointer required!

			SessionCallback sc;

			//set the four callbacks so that the server core library knows how to call your codes at proper times
			sc.OnClose = SC::ServerSide::OnClosed;
			sc.OnLess = SC::OnLess;
			sc.OnArrive = SC::OnArrive;
			sc.OnSslHandshakeDone = SC::OnSslHandshakeCompeleted;

			std::unique_lock<std::mutex> al(g_cs);

			//we record an interface IServerSession.
			//The adapter will automatically delete the server handler, referring to the function SC::ServerSide::OnClosed
			g_mapSessionHandler[session] = new ServerHandler(session);

			return sc;
		}

	protected:
		//use this version Arrive instead for auto-tracking exception
		virtual void OnArrive(CBuffer &buffer) = 0;

	private:
		//no copy constructor and assigment operator
		CServerHandlerBase(const CServerHandlerBase &handler);
		CServerHandlerBase& operator=(const CServerHandlerBase &handler);

		//don't overwrite this version Arrive from your class
		virtual void OnArrive(unsigned short RequestId, CBuffer &buffer) final
		{
			try
			{
				CHandler::OnArrive(RequestId, buffer);
				OnArrive(buffer);
			}
			catch(const CException& ex)
			{
				SendException(RequestId, ex);
			}
			catch(const std::exception &err)
			{
				CException ex(err, __FILE__, __LINE__, __FUNCTION__);
				SendException(RequestId, ex);
			}
			catch(...)
			{
				m_pSession->SendException(RequestId, ERROR_UNKNOWN, "Unknown C++ exception error", __FUNCTION__);
			}
		}

	private:
		IServerSession *m_pSession;

	protected:
		SC_CLIENT_VERSION m_nClientVersion;
	};

	static void CALLBACK OnClosed(ISession *session)
	{
		assert(session); //valid session pointer required!

		CHandler::Find(session)->OnClosed();
		std::unique_lock<std::mutex> al(g_cs);
		auto it = g_mapSessionHandler.find(session);
		if (it != g_mapSessionHandler.end())
		{
			delete it->second;
			g_mapSessionHandler.erase(it);
		}
	}
} //namespace ServerSide
} //namespace SC

#endif