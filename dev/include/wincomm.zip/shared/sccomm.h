

#ifndef _SECURE_COMMUNICATION_BASE_H_
#define _SECURE_COMMUNICATION_BASE_H_

#include <windows.h>

namespace SC
{
	//reserved request ids from 1 through 1023
	static const unsigned short idAuthentication = 1;
	static const unsigned short idServerException = 2;
	static const unsigned short idHeartBeat = 3;
	static const unsigned short idAuthenticationReserved = 256;

	//your request id must NOT less than this request id
	static const unsigned short idStartRequestId = 1024;
	static const unsigned short idDoFastRequest = 16 * 1024;
	static const unsigned short idDoSlowRequest = idDoFastRequest + 1;

	//error codes for the method Retrieve of interface ISession
	//and the method Send of interfaces IClientSession and IServerSession
	//as well as the method SendException of interface IServerSession
	static const unsigned int SESSION_CLOSED = (~0); //session closed
	static const unsigned int BAD_REQUEST = SESSION_CLOSED - 1; //Unexpected request id at client side 
	static const unsigned int BAD_RETRIEVE_THREAD = BAD_REQUEST - 1; //Retrieve data from wrong thread
	static const unsigned int BAD_RESULT = BAD_REQUEST; //Send result with wrong request id

	typedef enum tagSessionState {
		ssClosed = 0,
		ssClosing = 1,
		ssConnecting = 2,
		ssConnected = 3,
		ssSslHandshaking = 4,
		ssSslHandshaked = 5,
		ssAuthentcated = 6
	} SessionState;

	struct ISession {
		virtual tagSessionState GetSessionState() = 0;
		virtual int GetErrCode() = 0;
		virtual bool IsDiffEndian() = 0;
		virtual void PostClose(int errCode) = 0;

		//Check the data size in bytes to be sent to remote peer. 
		//If it returns a large vaule, it means network bandwidth is not matchable for sending speed
		virtual unsigned int GetSendingBufferSize() = 0;

		//Set a buffer recv with length size in bytes to receive error message terminated by null
		
		virtual unsigned int GetErrMsg(char *recv, unsigned int size) = 0;

		//Set a buffer recv with length size in bytes to receive data
		//Must call this method within the thread hosting boost asio io service object
		//The method returns the actually obtained data length or BAD_RETRIEVE_THREAD
		virtual unsigned int Retrieve(unsigned char *recv, unsigned int size) = 0;

	protected:
		virtual ~ISession(){}
	};

	struct ICertificate {
		virtual const char* const Verify(int *errCode) = 0;
#ifdef USE_OPENSSL
		virtual const char* const GetCertPem() = 0;
#endif
		virtual const char* const GetSessionInfo() = 0;
		virtual bool IsValid() = 0;
		virtual const char* const GetSubject() = 0;
		virtual const char* const GetIssuer() = 0;
		virtual const unsigned char* const GetPublicKey(unsigned int *pKeySize) = 0;
	};
} //namespace SC


#ifdef __cplusplus
extern "C" {
#endif

	typedef void (CALLBACK *POnArrive) (SC::ISession *session, unsigned short RequestId, unsigned int Size);
	typedef void (CALLBACK *POnClose) (SC::ISession *session);
	typedef void (CALLBACK *POnLess) (SC::ISession *session);
	typedef void (CALLBACK *POnSslHandshakeDone) (SC::ISession *session);

#ifdef __cplusplus
}
#endif

namespace SC {

	struct SessionCallback {
		//!!!! must initialize the following callbacks
		POnSslHandshakeDone OnSslHandshakeDone; //SSL handshake done event
		POnArrive OnArrive; //command or result arrive event
		POnClose OnClose; //session disconnection event
		POnLess OnLess; //sending buffer no data event
	};
} //namespace SC

#endif