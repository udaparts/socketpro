
#ifndef __SECURE_COMM_SHARED_MEMORY_QUEUE_H_
#define __SECURE_COMM_SHARED_MEMORY_QUEUE_H_

#include "scexception.h"
#include <vector>
#include <mutex>
#include <assert.h>
#include <windows.h>

namespace SC {

	typedef __int64 INT64;
	typedef unsigned __int64 UINT64;

	static const unsigned int DEFAULT_MEMORY_BUFFER_BLOCK_SIZE = ((unsigned int) 8 * 1024);
	static const unsigned int DEFAULT_INITIAL_MEMORY_BUFFER_SIZE = ((unsigned int) 8 * 1024);
	static const unsigned int SC_BUFFER_END_POSTION = ((unsigned int) (~0));
	static const unsigned int SC_BUFFER_NULL_LENGTH = ((unsigned int) (~0));

	/** 
	* A memory buffer class for packing and unpacking various types of data intelligently and efficiently with auto-memory reallocation as needed. 
	* Operators << and >> are overloaded for easy serialization and de-serialization. All strings are serialized or de-serialized with length ahead.
	* Its copy constructor and assignment operators are disabled.
	*/
	class CBuffer {
	public:

		/** 
		* Construct an instance of CBuffer
		* @param maxLen The initial empty memory size in byte with default to 8 * 1024
		* @param blockSize The size of memory block in byte with default to 8 * 1024
		*/
		CBuffer(unsigned int maxLen = DEFAULT_INITIAL_MEMORY_BUFFER_SIZE, unsigned int blockSize = DEFAULT_MEMORY_BUFFER_BLOCK_SIZE)
			: m_nMaxBuffer(maxLen),
			m_nSize(0),
			m_nHeadPos(0) {
				if (blockSize == 0)
					m_nBlockSize = DEFAULT_MEMORY_BUFFER_BLOCK_SIZE;
				else
					m_nBlockSize = blockSize;
				if (m_nMaxBuffer)
					m_pBuffer = (unsigned char*) ::malloc(m_nMaxBuffer);
				else
					m_pBuffer = nullptr;
		}

		/** 
		* Ensure releasing its internal memory and destruct the object
		*/
		virtual ~CBuffer() {
			Empty();
		}

		/** 
		* Change an integer (int16, int32, int64, uint16, uint32, uint64, float and double only) endian
		* @param p A pointer to an integer
		* @param size The size per integer in byte
		* @return Successfulness of change in integer endian 
		*/
		static bool ChangeEndian(unsigned char *p, unsigned int size) {
			unsigned char byte;
			assert(p != nullptr);
			switch (size) {
			case 2:
				byte = p[0];
				p[0] = p[1];
				p[1] = byte;
				break;
			case 4:
				byte = p[0];
				p[0] = p[3];
				p[3] = byte;
				byte = p[1];
				p[1] = p[2];
				p[2] = byte;
				break;
			case 8:
				byte = p[0];
				p[0] = p[7];
				p[7] = byte;
				byte = p[1];
				p[1] = p[6];
				p[6] = byte;
				byte = p[2];
				p[2] = p[5];
				p[5] = byte;
				byte = p[3];
				p[3] = p[4];
				p[4] = byte;
				break;
			default:
				return false;
				break;
			}
			return true;
		}

	private:
		// no copy constructor!
		CBuffer(const CBuffer &mc);
		// no assignment operator! 
		CBuffer& operator=(const CBuffer &mc);

	public:

		/**
		* Replace internal memory content with a new buffer
		* @param pos Memory start position
		* @param len The length of memory content in byte
		* @param buffer Pointer to a new buffer
		* @param size The size of a new buffer in byte 
		*/
		inline void Replace(unsigned int pos, unsigned int len, const unsigned char *buffer, unsigned int size) {
			assert(pos <= m_nSize);
			assert(len <= m_nSize);
			assert((pos + len) <= m_nSize);

			unsigned char *p = (unsigned char *) GetBuffer(pos);
			if (buffer == nullptr)
				size = 0;
			if (len > size) {
				::memcpy(p, buffer, size);
				unsigned int diff = len - size;
				Pop(diff, pos + size);
			} else if (len == size) {
				::memcpy(p, buffer, size);
			} else //size > len
			{
				::memcpy(p, buffer, len);
				unsigned int diff = size - len;
				Insert(buffer + len, diff, pos + len);
			}
		}

		inline void Put(char c) {
			Push((const unsigned char*) &c, sizeof (c));
		}

		inline void SetNull() {
			unsigned int pos = m_nHeadPos + m_nSize;
			if (m_nMaxBuffer >= pos + sizeof (wchar_t)) {
				::memset(m_pBuffer + pos, 0, sizeof (wchar_t));
			} else {
				wchar_t c = 0;
				Push((unsigned char*) &c, sizeof (c));
				m_nSize -= sizeof (c);
			}
		}

		/**
		* Release memory buffer, and zero all members except endian equality.
		*/
		inline void Empty() {
			if (m_pBuffer) {
				::free(m_pBuffer);
				m_pBuffer = nullptr;
				m_nMaxBuffer = 0;
				m_nSize = 0;
				m_nHeadPos = 0;
			}
		}

		/**
		* Get internal buffer pointer.
		* @param offset Offset to internal buffer in byte with default equal to 0
		* @return Internal buffer pointer
		*/
		inline const unsigned char* const GetBuffer(unsigned int offset = 0) const {
			if (offset >= m_nSize)
				offset = m_nSize;
			return (m_pBuffer + offset + m_nHeadPos);
		}

		/**
		* Get content size in byte.
		* @return Content length in byte
		*/
		inline unsigned int GetSize() const {
			return m_nSize;
		}

		/**
		* Get unused buffer size in byte.
		* @return Unused buffer length in byte
		*/
		inline unsigned int GetIdleSize() const {
			return (m_nMaxBuffer - m_nSize);
		}

		/**
		* Get unused tail buffer size in byte.
		* @return Unused tail buffer length in byte
		*/
		inline unsigned int GetTailSize() const {
			return (m_nMaxBuffer - m_nSize - m_nHeadPos);
		}

		CBuffer(CBuffer && q)
			: m_nMaxBuffer(q.m_nMaxBuffer),
			m_nSize(q.m_nSize),
			m_nHeadPos(q.m_nHeadPos),
			m_nBlockSize(q.m_nBlockSize),
			m_pBuffer(q.m_pBuffer) {
				q.m_pBuffer = nullptr;
				q.m_nSize = 0;
				q.m_nHeadPos = 0;
		}

		CBuffer& operator=(CBuffer && q) {
			Swap(q);
			return *this;
		}

		/**
		* Swap two memory buffer 
		* @param q A reference to a memory buffer object that will be swapped with this object
		*/
		void Swap(CBuffer &q) {
			unsigned int n = m_nBlockSize;
			m_nBlockSize = q.m_nBlockSize;
			q.m_nBlockSize = n;

			n = m_nHeadPos;
			m_nHeadPos = q.m_nHeadPos;
			q.m_nHeadPos = n;

			n = m_nMaxBuffer;
			m_nMaxBuffer = q.m_nMaxBuffer;
			q.m_nMaxBuffer = n;

			n = m_nSize;
			m_nSize = q.m_nSize;
			q.m_nSize = n;

			unsigned char *p = m_pBuffer;
			m_pBuffer = q.m_pBuffer;
			q.m_pBuffer = p;
		}

		/**
		* Set content size in byte.
		* @param size New content length in byte
		* @param adjustHeadPos Indicator for adjusting content head position with default to true
		*/
		inline void SetSize(unsigned int size, bool adjustHeadPos = true) {
			assert(m_nMaxBuffer >= (size + m_nHeadPos));
			if (adjustHeadPos && m_nHeadPos) {
				m_nSize = size;
				if (m_nSize)
					::memmove(m_pBuffer, m_pBuffer + m_nHeadPos, m_nSize);
				m_nHeadPos = 0;
			} else {
				m_nSize = size;
				if (size == 0)
					m_nHeadPos = 0;
			}
		}

		/**
		* Check the max buffer size in byte.
		* @see ReallocBuffer()
		* @return The totally allocated buffer size in byte
		*/
		inline unsigned int GetMaxSize() const {
			return m_nMaxBuffer;
		}

		/**
		* Check the buffer block size in byte
		* @return The buffer block size in byte
		*/
		inline unsigned int GetBlockSize() const {
			return m_nBlockSize;
		}

		/**
		* Reset the buffer block size in byte
		* @param blockSize A new buffer block size in byte with default to 1024
		*/
		inline void SetBlockSize(unsigned int blockSize = DEFAULT_MEMORY_BUFFER_BLOCK_SIZE) {
			if (blockSize == 0)
				blockSize = DEFAULT_MEMORY_BUFFER_BLOCK_SIZE;
			m_nBlockSize = blockSize;
		}

		/**
		* Append a new buffer
		* @param buffer Pointer to a new buffer
		* @param len Size of the buffer in byte
		*/
		inline void Push(const unsigned char* buffer, unsigned int len) {
			Insert(buffer, len, SC_BUFFER_END_POSTION);
		}

		/**
		* Check the header position of content. If there is no content available, the method returns 0
		* @return The header position of content in byte
		*/
		inline unsigned int GetHeadPosition() const {
			return m_nHeadPos;
		}

		/**
		* Move the header of content to very beginning.
		*/
		inline void SetHeadPosition() {
			if (m_nHeadPos) {
				if (m_nSize)
					::memmove(m_pBuffer, m_pBuffer + m_nHeadPos, m_nSize);
				m_nHeadPos = 0;
			}
		}

		/**
		* Zero all of buffer except content
		*/
		inline void CleanTrack() {
			assert(m_nMaxBuffer >= (m_nHeadPos + m_nSize));
			if (m_pBuffer != nullptr && m_nMaxBuffer > 0) {
				if (m_nHeadPos > 0) {
					::memset(m_pBuffer, 0, m_nHeadPos);
				}
				unsigned int position = m_nHeadPos + m_nSize;
				unsigned int ulLen = m_nMaxBuffer - position;
				if (ulLen > 0) {
					::memset(m_pBuffer + position, 0, ulLen);
				}
			}
		}

		/**
		* Re-allocate buffer and keep existing content as much as possible
		* @param size The new size of buffer in byte
		* @param adjustHeadPos Indicator for adjusting content head position with default to true
		*/
		inline void ReallocBuffer(unsigned int size, bool adjustHeadPos = true) {
			if (adjustHeadPos && m_nHeadPos) {
				if (m_nSize)
					::memmove(m_pBuffer, m_pBuffer + m_nHeadPos, m_nSize);
				m_nHeadPos = 0;
			}
			if (size == 0)
				size = m_nBlockSize;
			if (m_nSize > size)
				m_nSize = size;
			m_nMaxBuffer = (size + m_nHeadPos);
			m_pBuffer = (unsigned char*) ::realloc(m_pBuffer, m_nMaxBuffer);
		}

		/**
		* Insert a buffer of data into a proper location. The internal buffer will be automatically reallocated if required.
		* @param buffer Pointer to a buffer
		* @param len The size of the buffer in byte
		* @param position The position in byte with default to 0
		*/
		inline void Insert(const unsigned char* buffer, unsigned int len, unsigned int position = 0) {
			if (!buffer || !len)
				return;
			if (position > m_nSize)
				position = m_nSize;
			if (m_nHeadPos >= len && position == 0) {
				m_nHeadPos -= len;
				::memmove(m_pBuffer + m_nHeadPos, buffer, len);
				m_nSize += len;
				return;
			}

			if ((m_nMaxBuffer - m_nHeadPos - m_nSize) >= len && position == m_nSize) {
				::memmove(m_pBuffer + m_nHeadPos + m_nSize, buffer, len);
				m_nSize += len;
				return;
			}

			if ((m_nSize + len + m_nHeadPos) > m_nMaxBuffer) {
				if ((m_nMaxBuffer - m_nSize) >= len && position == m_nSize) {
					::memmove(m_pBuffer, m_pBuffer + m_nHeadPos, m_nSize);
					m_nHeadPos = 0;
					memmove(m_pBuffer + m_nSize, buffer, len);
					m_nSize += len;
					return;
				}
				else {
					m_nMaxBuffer = (m_nSize + len + m_nBlockSize + m_nHeadPos);
					if (m_nHeadPos) {
						unsigned char *buffer = (unsigned char*)::malloc(m_nMaxBuffer);
						::memcpy(buffer, m_pBuffer + m_nHeadPos, m_nSize);
						m_nHeadPos = 0;
						::free(m_pBuffer);
						m_pBuffer = buffer;
					}
					else
						m_pBuffer = (unsigned char*) ::realloc(m_pBuffer, m_nMaxBuffer);
				}
			}
			if (m_nSize - position) {
				::memmove(m_pBuffer + position + len + m_nHeadPos, m_pBuffer + position + m_nHeadPos, m_nSize - position);
			}
			m_nSize += len;
			::memmove(m_pBuffer + position + m_nHeadPos, buffer, len);
		}

		/**
		* Insert an ASCII string into a proper location
		* @param str Pointer to an ASCII string
		* @param chars The size of the string in char with default to string null-terminated
		* @param position The position in byte with default to 0
		*/
		inline void Insert(const char* str, unsigned int chars = SC_BUFFER_NULL_LENGTH, unsigned int position = 0) {
			if (str) {
				if (chars == SC_BUFFER_NULL_LENGTH)
					chars = (unsigned int) ::strlen(str);
				Insert((const unsigned char*) str, chars, position);
			}
		}

		/**
		* Append an ASCII string
		* @param str Pointer to an ASCII string
		* @param chars The size of the string in char with default to string null-terminated
		*/
		inline void Push(const char* str, unsigned int chars = SC_BUFFER_NULL_LENGTH) {
			Insert(str, chars, SC_BUFFER_END_POSTION);
		}

		/**
		* Append an ASCII string
		* @param str An instance of standard library ASCII string
		*/
		inline void Push(const std::string& str) {
			Insert(str.c_str(), (unsigned int) str.size(), SC_BUFFER_END_POSTION);
		}

		/**
		* Append an ASCII string with string length ahead (4 bytes)
		* @param str A pointer to an array of ASCII chars
		* @return Reference to this memory buffer
		*/
		CBuffer& operator <<(const char* str) {
			unsigned int size;
			if (str == nullptr) {
				size = SC_BUFFER_NULL_LENGTH;
			} else {
				size = (unsigned int) ::strlen(str);
			}
			Push(&size);
			if (str && size) {
				Push(str, size);
			}
			return *this;
		}

		CBuffer& operator << (const wchar_t* str) {
			unsigned int utf8Size;
			if (!str)
			{
				utf8Size = SC_BUFFER_NULL_LENGTH;
				Push(&utf8Size);
			}
			else
			{
				unsigned int chars = (unsigned int)::wcslen(str);
				utf8Size = (unsigned int)::WideCharToMultiByte(CP_UTF8, 0, str, (int) chars, nullptr, (int)0, nullptr, nullptr);
				Push(&utf8Size);
				if (utf8Size)
				{
					if (GetTailSize() < utf8Size)
						ReallocBuffer(utf8Size + GetSize());
					::WideCharToMultiByte(CP_UTF8, 0, str, (int) chars, (char*)(GetBuffer() + GetSize()), (int)GetTailSize(), nullptr, nullptr);
					SetSize(GetSize() + utf8Size);
				}
			}
			return *this;
		}

		CBuffer& operator <<(wchar_t* str) {
			const wchar_t *s = (const wchar_t*) str;
			return (*this << s);
		}

		/**
		* Append an ASCII string with string length ahead (4 bytes)
		* @param str A pointer to an array of ASCII chars
		* @return Reference to this memory buffer
		*/
		CBuffer& operator <<(char* str) {
			const char *s = (const char*) str;
			return (*this << s);
		}

		/**
		* Append an ASCII string with string length ahead (4 bytes)
		* @param str An instance of standard library ASCII string
		* @return Reference to this memory buffer
		*/
		inline CBuffer& operator<<(const std::string& str) {
			unsigned int size = (unsigned int) str.size();
			Push(&size);
			if (size != 0)
				Push(str.c_str(), size);
			return *this;
		}

		inline CBuffer& operator<<(const std::wstring& str) {
			*this << str.c_str();
			return *this;
		}

		/**
		* Pop content into standard library ASCII string
		* @param str An instance of standard library ASCII string for receiving
		* @return Reference to this memory buffer
		*/
		inline CBuffer& operator>>(std::string& str) {
			unsigned int size;
			Pop(&size);
			switch (size) {
			case SC_BUFFER_NULL_LENGTH:
			case 0:
				str.clear();
				break;
			default:
				if (size > GetSize())
					throw CSEx("Bad data for loading ASCII string");
				str.assign((const char*) GetBuffer(), size);
				Pop(size);
				break;
			}
			return *this;
		}

		/**
		* Pop content into standard library wstring
		* @param str An instance of standard library wstring for receiving data
		* @return Reference to this memory buffer
		*/
		CBuffer& operator>>(std::wstring& str)
		{
			unsigned int utf8Chars;
			*this >> utf8Chars;
			switch (utf8Chars)
			{
			case 0:
			case SC_BUFFER_NULL_LENGTH:
				str.clear();
				break;
			default:
				if (utf8Chars > GetSize())
					throw CSEx("Bad data for loading UNICODE string");
				{
					unsigned int chars = (unsigned int)::MultiByteToWideChar(CP_UTF8, 0, (const char*)GetBuffer(), (int)utf8Chars, nullptr, 0);
					CBuffer buffer((chars + 2) * sizeof(wchar_t));
					::MultiByteToWideChar(CP_UTF8, 0, (const char*)GetBuffer(), (int)utf8Chars, (wchar_t*)buffer.GetBuffer(), chars + 2);
					buffer.SetSize(chars * sizeof(wchar_t));
					buffer.SetNull();
					Pop(utf8Chars);
					str = (const wchar_t*)buffer.GetBuffer();
				}
				break;
			}
			return *this;
		}

		/**
		* Discard internal buffer at a proper position
		* @param len The size of buffer in byte
		* @param position The offset location of content in byte with default to 0
		* @return The actual size of content discarded in byte
		*/
		inline unsigned int Pop(unsigned int len, unsigned int position = 0) {
			if (len == 0)
				return 0;
			if (position >= m_nSize)
				return 0;
			if (len > m_nSize - position) {
				len = m_nSize - position;
			}
			m_nSize -= len;
			if (m_nSize) {
				if (position == 0)
					m_nHeadPos += len;
				else
					::memmove(m_pBuffer + position + m_nHeadPos, m_pBuffer + len + position + m_nHeadPos, m_nSize - position);
			} else {
				m_nHeadPos = 0;
			}
			return len;
		}

		/**
		* Pop internal content at a proper position into a buffer
		* @param buffer Pointer to a buffer for receiving data
		* @param len The size of the buffer in byte
		* @param position The offset location of internal content in byte with default to 0
		* @return The actual size of content popped in byte
		*/
		inline unsigned int Pop(unsigned char* buffer, unsigned int len, unsigned int position = 0) {
			if (buffer == nullptr || len == 0 || m_pBuffer == nullptr || m_nSize == 0)
				return 0;
			if (position >= m_nSize)
				return 0;
			if (len > m_nSize - position)
				throw CSEx("Remaining data in size smaller than expected size");
			unsigned int ulTemp = position + m_nHeadPos;
			::memcpy(buffer, m_pBuffer + ulTemp, len);
			m_nSize -= len;
			if (m_nSize) {
				if (position != 0)
					::memmove(m_pBuffer + ulTemp, m_pBuffer + len + ulTemp, m_nSize - position);
				else
					m_nHeadPos += len;
			} else {
				m_nHeadPos = 0;
			}
			return len;
		}

		/**
		* Append an unsigned short into the memory buffer
		* @param data an unsigned short
		* @return The reference to this memory buffer
		*/
		CBuffer& operator <<(unsigned short data) {
			Push((unsigned char*) &data, sizeof (data));
			return *this;
		}

		/**
		* Append a memory buffer with length ahead (4 bytes)
		* @param mc An instance of memory buffer
		* @return The reference to this memory buffer
		*/
		inline CBuffer& operator <<(const CBuffer &mc) {
			unsigned int size = mc.GetSize();
			Push(&size);
			Push(mc.GetBuffer(), size);
			return *this;
		}

		/**
		* Pop a memory buffer with length ahead (4 bytes) into a memory buffer
		* @param mc An instance of memory buffer for receiving data
		* @return The reference to this memory buffer
		*/
		inline CBuffer& operator>>(CBuffer &mc) {
			unsigned int size;
			Pop(&size);
			if (size != SC_BUFFER_NULL_LENGTH && size != 0) {
				if (size > GetSize())
					throw CSEx("Bad data for loading a memory chunk");
				mc.Push(GetBuffer(), size);
				Pop(size);
			}
			return *this;
		}

		/**
		* Insert a data into this memory object at a position
		* @param buffer Pointer to a primitive type of data or a structure
		* @param position A position indicator with default to 0
		*/
		template<class ctype>
		inline void Insert(const ctype* buffer, unsigned int position = 0) {
			Insert((const unsigned char*) buffer, sizeof (ctype), position);
		}

		/**
		* Pop a data from this memory object at a position
		* @param buffer Pointer to a primitive type of data or a structure for receiving data
		* @param position A position indicator with default to 0
		* @return Actual data length in byte
		*/
		template <class ctype>
		inline unsigned int Pop(ctype *buffer, unsigned int position = 0) {
			return Pop((unsigned char*) buffer, sizeof (ctype), position);
		}

		/**
		* Append a data into this memory object
		* @param buffer Pointer to a primitive type of data or a structure
		*/
		template <class ctype>
		inline void Push(const ctype *buffer) {
			Push((const unsigned char*) buffer, sizeof (ctype));
		}

		/**
		* 
		* @param c
		* @return 
		*/
		CBuffer& operator <<(const char &c) {
			Push((unsigned char*) &c, 1);
			return *this;
		}

		/**
		* Append a data into this memory object
		* @param data A reference to a primitive type of data or a structure
		* @return The reference to this memory buffer
		*/
		template<class ctype>
		CBuffer& operator <<(const ctype &data) {
			Push(&data);
			return *this;
		}

		/**
		* 
		* @param data
		* @return 
		*/
		CBuffer& operator >>(char &data) {
			assert(GetSize() >= sizeof (data));
			Pop((unsigned char*) &data, sizeof (data));
			return *this;
		}

		/**
		* Pop a data from this memory object
		* @param data A reference to a primitive type of data or a structure for receiving data
		* @return The reference to this memory buffer
		*/
		template<class ctype>
		CBuffer& operator >>(ctype &data) {
			assert(GetSize() >= sizeof (data));
			Pop(&data);
			return *this;
		}

	private:
		unsigned int m_nMaxBuffer;
		unsigned int m_nSize;
		unsigned int m_nHeadPos;
		unsigned int m_nBlockSize;
		unsigned char *m_pBuffer;
	};

	/** 
	* The template class CScopeBufferEx (a smart pointer for CBuffer) stores a pointer to a dynamically allocated memory buffer object. 
	* The object pointed to, if available, is guaranteed to be recycled into a memory buffer pool for reuse on destruction of the CScopeBufferEx.
	* Internal CBuffer objects are guaranteed to be reused or recycled from or into buffer pool thread-safely.
	* Operators << and >> are overloaded for easy serialization and de-serialization. 
	* Note that you can detach or re-attach a pointer to CBuffer object at run time. Also, various methods will throw exceptions if no CBuffer object is attached.
	* Its copy constructor and assignment operators are disabled.
	*/
	template<unsigned int InitSize, unsigned int BlockSize, typename mb = CBuffer>
	class CScopeBufferEx {
		/// Copy constructor disabled
		CScopeBufferEx(const CScopeBufferEx& sb);

		/// Assignment operator disabled
		CScopeBufferEx& operator=(const CScopeBufferEx& sb);

	public:

		/** 
		* Construct an instance of CScopeBufferEx, and automatically lock a memory buffer object from its pool
		* @param initSize The size of memory allocated in byte for internal memory buffer object
		* @param blockSize The block size in byte for internal memory buffer object
		*/
		CScopeBufferEx(unsigned int initSize = InitSize, unsigned int blockSize = BlockSize)
			: m_pBuffer(Lock(initSize, blockSize)) {
		}

		/** 
		* Ensure recycling its internal memory buffer object if available into memory buffer pool for reuse, and destruct this object
		*/
		~CScopeBufferEx() {
			Unlock(m_pBuffer);
		}

		/** 
		* Movable copy constructor
		*/
		CScopeBufferEx(CScopeBufferEx && su)
			: m_pBuffer(su.m_pBuffer) {
				su.m_pBuffer = nullptr;
		}

		typedef mb *PMB;

	public:

		/** 
		* Movable assignment operator
		*/
		CScopeBufferEx& operator=(CScopeBufferEx && su) {
			Swap(su);
			return *this;
		}
		/** 
		* Return a pointer to an internal memory buffer object. The method will return nullptr if no internal memory buffer object is available
		* @return A pointer to an internal memory buffer object
		*/
		inline mb* operator->() const {
			return m_pBuffer;
		}

		/** 
		* Return a pointer to an internal memory buffer object. The method will return nullptr if no internal memory buffer object is available
		* @return A pointer to an internal memory buffer object
		*/
		inline mb* Get() const {
			return m_pBuffer;
		}

		/** 
		* Return a pointer to an internal memory buffer object. The method will return nullptr if no internal memory buffer object is available
		* @return A pointer to an internal memory buffer object
		*/
		inline operator PMB() const {
			return m_pBuffer;
		}

		/** 
		* Return a reference to an internal memory buffer object. The method may throw exception if no internal memory buffer object is available
		* @return A reference to an internal memory buffer object
		*/
		inline mb& operator*() const throw () {
			return *m_pBuffer;
		}

		/** 
		* Check if there is an internal memory buffer object available
		* @return True or false
		*/
		inline bool Available() const {
			return (m_pBuffer != nullptr);
		}

		/** 
		* Swap internal memory buffer objects between two instances of CScopeBufferEx
		* @param sb A reference to a CScopeBufferEx object
		*/
		inline void Swap(CScopeBufferEx& sb) {
			mb *p = sb.m_pBuffer;
			sb.m_pBuffer = m_pBuffer;
			m_pBuffer = p;
		}

		/** 
		* Detach internal memory buffer object from this CScopeBufferEx object
		* @return A pointer to a memory buffer object
		*/
		inline mb* Detach() {
			mb *p = m_pBuffer;
			m_pBuffer = nullptr;
			return p;
		}

		/** 
		* Recycle an existing memory buffer object into its pool if available, and attach a new memory buffer object
		* @param p A pointer to a new memory buffer object
		*/
		inline void Attach(mb *p) {
			Unlock(m_pBuffer);
			m_pBuffer = p;
		}

		inline mb& operator<<(const mb &q) {
			if (!m_pBuffer)
				m_pBuffer = Lock(InitSize, BlockSize);
			*m_pBuffer << q;
			return *m_pBuffer;
		}

		inline mb& operator>>(mb &q) {
			if (!m_pBuffer)
				m_pBuffer = Lock(InitSize, BlockSize);
			*m_pBuffer >> q;
			return *m_pBuffer;
		}

		/**
		* Push a data into internal memory buffer object, and throw an exception if no memory buffer object is available
		* @param data A reference to a primitive type of data or a structure
		* @return The reference to this memory buffer
		*/
		template<class ctype>
		inline mb& operator <<(const ctype &data) throw () {
			*m_pBuffer << data;
			return *m_pBuffer;
		}

		/**
		* Pop a data from internal memory buffer object, and throw an exception if no memory buffer object is available
		* @param data A reference to a primitive type of data or a structure for receiving data
		* @return The reference to internal memory buffer object
		*/
		template<class ctype>
		inline mb& operator >>(ctype &data) throw () {
			*m_pBuffer >> data;
			return *m_pBuffer;
		}

		/**
		* Destroy all existing memory objects in pool
		*/
		static void DestroyPool() {
			size_t n;
			mb *p;
			m_cs.lock();
			size_t size = m_vBuffer.size();
			for (n = 0; n < size; n++) {
				p = m_vBuffer[n];
				delete p;
			}
			m_vBuffer.clear();
			m_cs.unlock();
		}

		/**
		* Reset all existing memory objects in pool to initial size (InitSize)
		*/
		static void ResetSize() {
			size_t n;
			mb *p;
			m_cs.lock();
			size_t size = m_vBuffer.size();
			for (n = 0; n < size; n++) {
				p = m_vBuffer[n];
				if (p->GetMaxSize() > InitSize)
					p->ReallocBuffer(InitSize);
			}
			m_cs.unlock();
		}

		/**
		* Zero all existing memory objects in pool
		*/
		static void CleanPool() {
			size_t n;
			mb *p;
			m_cs.lock();
			size_t size = m_vBuffer.size();
			for (n = 0; n < size; n++) {
				p = m_vBuffer[n];
				p->CleanTrack();
			}
			m_cs.unlock();
		}

		/**
		* Lock a memory buffer object from pool
		* @param initSize The size of memory allocated in byte for internal memory buffer object
		* @param blockSize The block size in byte for internal memory buffer object
		* @return A pointer to a memory buffer object
		*/
		static mb* Lock(unsigned int initSize = InitSize, unsigned int blockSize = BlockSize) {
			mb *p;
			m_cs.lock();
			size_t size = m_vBuffer.size();
			if (size != 0) {
				--size;
				p = m_vBuffer[size];
				m_vBuffer.pop_back();
				m_cs.unlock();
				p->SetBlockSize(blockSize);
				if (p->GetMaxSize() < initSize)
					p->ReallocBuffer(initSize);
			} else {
				m_cs.unlock();
				p = new mb(initSize, blockSize);
			}
			return p;
		}

		/**
		* Recycle a memory buffer object into pool for reuse
		* @param memoryChunk A pointer to a memory buffer object
		*/
		static void Unlock(mb *memoryChunk) {
			if (memoryChunk == nullptr)
				return;
			memoryChunk->SetSize(0);
			m_cs.lock();
			m_vBuffer.push_back(memoryChunk);
			m_cs.unlock();
		}

		/**
		* Get the total size of pooled memory buffer objects
		* @return The total size of pooled memory buffer objects in byte
		*/
		static UINT64 GetMemoryConsumed() {
			UINT64 size = 0;
			m_cs.lock();
			size_t count = m_vBuffer.size();
			for (size_t n = 0; n < count; ++n) {
				size += (m_vBuffer[n])->GetMaxSize();
			}
			m_cs.unlock();
			return size;
		}

	private:
		mb *m_pBuffer;
		static std::vector<mb*> m_vBuffer;
		static std::mutex m_cs;
	};

	template<unsigned int InitSize, unsigned int BlockSize, typename mb>
	std::vector<mb*> CScopeBufferEx<InitSize, BlockSize, mb>::m_vBuffer;

	template<unsigned int InitSize, unsigned int BlockSize, typename mb>
	std::mutex CScopeBufferEx<InitSize, BlockSize, mb>::m_cs;

	typedef CScopeBufferEx<DEFAULT_INITIAL_MEMORY_BUFFER_SIZE, DEFAULT_MEMORY_BUFFER_BLOCK_SIZE> CScopeBuffer;

}; //namespace SPA

#endif //__UCOMM_SHARED_MEMORY_QUEUE_H_

