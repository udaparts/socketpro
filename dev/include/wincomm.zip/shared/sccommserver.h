
#ifndef _SECURE_COMM_COMMUNICATION_SERVER_H_
#define _SECURE_COMM_COMMUNICATION_SERVER_H_

#include "sccomm.h"

namespace SC { namespace ServerSide {
	struct IServerSession : public ISession {
		//Send a result chunk buffer with length size onto remote client for a request RequestId
		//It returns the actually length data, SESSION_CLOSED, or BAD_RESULT
		virtual unsigned int Send(unsigned short ReqId, const unsigned char * const buffer, unsigned int size) = 0;

		//Send an exception (ec, msg and stack) onto remote client for current request CurReqtId
		//It returns the actually length data in bytes, SESSION_CLOSED, or BAD_RESULT
		virtual unsigned int SendException(unsigned short CurrReqId, int ec, const char *msg, const char *stack) = 0;

		//Tell the underlying server core library that we are going to use a worker thread for processing
		//Must call this method within main thread before starting a worker thread. Otherwise, it returns false.
		virtual bool StartThreadProcessing() = 0;

		//Tell the underlying server core library that worker thread for processing is completed
		//Must call this method from a worker thread. Otherwise, it returns false or no processing for this session.
		virtual bool EndThreadProcessing() = 0;

	protected:
		virtual ~IServerSession(){}
	};
} //namespace ServerSide
} //namespace SC

#ifdef __cplusplus
extern "C" {
#endif

	//session initialization event
	typedef SC::SessionCallback (CALLBACK *POnAccepted)(SC::ServerSide::IServerSession *session);

	const char* WINAPI InitializeSecureCommServer(POnAccepted OnAccepted, unsigned int port = 22260, bool v6 = false, unsigned int backlog = 16);

#ifdef USE_OPENSSL
	const char* WINAPI RunSecureCommServer(const char *certFile, const char *keyFile, const char *pwdForPrivateKeyFile, const char *dhFile = nullptr);
#else
	const char* WINAPI RunSecureCommServer(const wchar_t *filePfx, const wchar_t *password);
#endif

	void WINAPI ShutdownSecureCommServer();

#ifdef __cplusplus
}
#endif

#endif