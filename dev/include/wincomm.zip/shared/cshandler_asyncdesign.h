

#ifndef _SECURE_COMMUNICATION_ADAPTER_HANDLER_BASE_H_
#define _SECURE_COMMUNICATION_ADAPTER_HANDLER_BASE_H_

#include "sccomm.h"

#include "membuffer.h"
#include <unordered_map>

namespace SC {

	//version control
	typedef int SC_CLIENT_VERSION;
	typedef int SC_SERVER_VERSION;
	static const int SC_INITIAL_COMM_VERSION = 0;

	struct ISessionCallback
	{
		virtual void OnArrive(unsigned short RequestId, CBuffer &buffer) = 0;
		virtual void OnClosed() = 0;
		virtual void OnLess() = 0;
		virtual void OnSslHandshakeDone() = 0;

	protected:
		virtual ~ISessionCallback() {}
	};

	class CHandler;

	static std::mutex g_cs;

	//don't access it from your code!!!
	static std::unordered_map<ISession*, CHandler*> g_mapSessionHandler;

	namespace ClientSide
	{
		static void CALLBACK OnClosed(ISession *session);
	}

	namespace ServerSide
	{
		static void CALLBACK OnClosed(ISession *session);
	}

	class CHandler : protected ISessionCallback
	{
	protected:
		virtual ~CHandler(){}

	public:
		static size_t GetHandlerCount()
		{
			std::unique_lock<std::mutex> al(g_cs);
			return g_mapSessionHandler.size();
		}

		inline tagSessionState GetSessionState() const
		{
			return m_s->GetSessionState();
		}

		inline void PostClose(int errCode = 0) const
		{
			m_s->PostClose(errCode);
		}

		inline unsigned int GetSendingBufferSize() const
		{
			return m_s->GetSendingBufferSize();
		}

		inline int GetErrCode() const
		{
			return m_s->GetErrCode();
		}

		inline bool IsDiffEndian() const
		{
			return m_s->IsDiffEndian();
		}

		inline std::string GetErrMsg() const
		{
			CScopeBuffer sb;
			unsigned int size = m_s->GetErrMsg((char*)sb->GetBuffer(), sb->GetMaxSize());
			sb->SetSize(size);
			sb->SetNull();
			return (const char*)sb->GetBuffer();
		}

		virtual unsigned short GetCurrentRequestId()
		{
			return m_nCurrentRequestId;
		}

	protected:
		CHandler(ISession *session) 
			: m_s(session),
			m_nCurrentRequestId(0)
		{

		}

		virtual void OnSslHandshakeDone() 
		{

		}

		virtual void OnClosed()
		{

		}

		virtual void OnLess()
		{

		}

		virtual void OnArrive(unsigned short RequestId, CBuffer &buffer)
		{
			if (RequestId == idServerException)
				buffer >> m_nCurrentRequestId;
			else
				m_nCurrentRequestId = RequestId;
		}

		void DelaySet(ISession *session) 
		{
			m_s = session;
		}

	private:
		static ISessionCallback* Find(ISession *session)
		{
			assert(session); //valid session pointer required!
			std::unique_lock<std::mutex> al(g_cs);
			auto it = g_mapSessionHandler.find(session);
			if (it != g_mapSessionHandler.end())
				return it->second;
			assert(false); //should never come here!
			return nullptr;
		}

		//disable copy constructor and assignment operator
		CHandler(const CHandler &handler);
		CHandler& operator=(const CHandler &handler);

	private:
		ISession *m_s;
		unsigned short m_nCurrentRequestId;

		friend static void CALLBACK OnArrive(ISession *session, unsigned short RequestId, unsigned int Size);
		friend static void CALLBACK OnLess(ISession *session);
		friend static void CALLBACK OnSslHandshakeCompeleted(ISession *session);
		friend static void CALLBACK ClientSide::OnClosed(ISession *session);
		friend static void CALLBACK ServerSide::OnClosed(ISession *session);
	};

	static void CALLBACK OnArrive(ISession *session, unsigned short RequestId, unsigned int Size)
	{
		CScopeBuffer sb;
		if (Size > sb->GetMaxSize())
			sb->ReallocBuffer(Size);
		if (Size)
		{
			unsigned int res = session->Retrieve((unsigned char*)sb->GetBuffer(), Size);
			assert(res == Size);
			sb->SetSize(res);
		}
		CHandler::Find(session)->OnArrive(RequestId, *sb);
	}

	static void CALLBACK OnLess(ISession *session)
	{
		CHandler::Find(session)->OnLess();
	}

	static void CALLBACK OnSslHandshakeCompeleted(ISession *session)
	{
		CHandler::Find(session)->OnSslHandshakeDone();
	}
} //namespace SC

#endif