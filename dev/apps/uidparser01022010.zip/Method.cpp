#include "StdAfx.h"
#include "method.h"

CMethod::CMethod(short sRequestID)
{
	m_bSlow = false;
	m_dtReturn = dtVoid;
	m_sReqestID = sRequestID;
}

CMethod::~CMethod()
{

}

CMethod::CMethod(const CMethod &Method)
{
	m_strDeclaration = Method.m_strDeclaration;
	m_strName = Method.m_strName;
	m_dtReturn = Method.m_dtReturn;
	m_bSlow = Method.m_bSlow;
	m_lang = Method.m_lang;
	m_sReqestID = Method.m_sReqestID;
	m_aParameter = Method.m_aParameter;
	m_strErrorMessage = Method.m_strErrorMessage;
	m_strReturnType = Method.m_strReturnType;
	m_strServiceName = Method.m_strServiceName;
	m_strRtnProcessing = Method.m_strRtnProcessing;
	m_strSynFun = Method.m_strSynFun;
	m_strDefClass = Method.m_strDefClass;
}

CMethod& CMethod::operator=(const CMethod &Method)
{
	m_strDeclaration = Method.m_strDeclaration;
	m_strName = Method.m_strName;
	m_bSlow = Method.m_bSlow;
	m_lang = Method.m_lang;
	m_dtReturn = Method.m_dtReturn;
	m_sReqestID = Method.m_sReqestID;
	m_aParameter = Method.m_aParameter;
	m_strErrorMessage = Method.m_strErrorMessage;
	m_strReturnType = Method.m_strReturnType;
	m_strServiceName = Method.m_strServiceName;
	m_strRtnProcessing = Method.m_strRtnProcessing;
	m_strSynFun = Method.m_strSynFun;
	m_strDefClass = Method.m_strDefClass;
	return *this;
}

bool CMethod::operator==(const CMethod &Method)
{
	if(m_lang == lVBNet)
	{
		//VB.NET case-insensitive
		if(m_strName.CompareNoCase(Method.m_strName) != 0)
			return false;
	}
	else
	{
		if(m_strName != Method.m_strName)
			return false;
	}
	
	return true; //Two methods share the same name

	if(m_aParameter.GetSize() != Method.m_aParameter.GetSize())
		return false;

	int n;
	for(n=0; n<m_aParameter.GetSize(); n++)
	{
		if(m_aParameter[n].m_dt != Method.m_aParameter[n].m_dt)
			return false;
	}

	return true;
}

bool CMethod::operator!=(const CMethod &Method)
{
	return (*this == Method) ? false : true;
}

bool CMethod::IsValid(const CString &strName)
{
	CString strNum(_T("0123456789_"));
	CString strFirst(_T("qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"));
	if(strName.GetLength() == 0)
		return false;
	TCHAR tChar = strName[0];
	if(strFirst.Find(tChar) == -1)
		return false;
	int n; 
	int nLen = strName.GetLength();
	for(n=1; n<nLen; n++)
	{
		tChar = strName[n];
		if(strFirst.Find(tChar) == -1 && strNum.Find(tChar) == -1)
		{
			return false;
		}
	}
	return true;
}

tagDataType CMethod::GetDataType(const CString &strType)
{
	if(strType.GetLength() == 0)
		return dtUnknown;
	if(strType == "string")
	{
		return dtString;
	}
	else if(strType == "Guid")
	{
		return dtGuid;
	}
	else if(strType == "bool")
	{
		return dtBool;
	}
	else if(strType == "object")
	{
		return dtObject;
	}
	else if(strType == "decimal")
	{
		return dtDecimal;
	}
	else if(strType == "double")
	{
		return dtDouble;
	}
	else if(strType == "float")
	{
		return dtFloat;
	}
	else if(strType == "long")
	{
		return dtLong;
	}
	else if(strType == "ulong")
	{
		return dtULong;
	}
	else if(strType == "int")
	{
		return dtInt;
	}
	else if(strType == "uint")
	{
		return dtUInt;
	}
	else if(strType == "char")
	{
		return dtWChar;
	}
	else if(strType == "short")
	{
		return dtShort;
	}
	else if(strType == "ushort")
	{
		return dtUShort;
	}
	else if(strType == "byte")
	{
		return dtByte;
	}
	else if(strType == "sbyte")
	{
		return dtAChar;
	}
	else if(strType == "void")
	{
		return dtVoid;
	}
	else
	{
		if(IsValid(strType))
			return dtUDT;
	}

	return dtUnknown;
}

bool CMethod::SetDeclaration(LPCTSTR strDeclaration)
{
	m_aParameter.RemoveAll();
	m_strErrorMessage.Empty();
	CString strPType;
	CString strPName;
	CString strLine = strDeclaration;
	strLine.Trim(_T(' '));
	int nTwoFSlash = strLine.Find(_T("//"));
	if(nTwoFSlash != -1)
	{
		strLine = strLine.Left(nTwoFSlash);
		strLine.Trim(_T(' '));
	}
	
	int nDollar = strLine.Find(_T('$'));
	if(nDollar == 0)
	{
		m_bSlow = true;
		strLine = strLine.Mid(1);
	}
	else if(nDollar == -1)
	{
		m_bSlow = false;
	}
	else
	{
		m_strErrorMessage = _T("Position wrong for sign $"); 
		return false;
	}
	
	int nLeftP = strLine.Find(_T('('));
	if(nLeftP == -1)
	{
		m_strErrorMessage = _T("Left paratheis missing"); 
		return false;
	}
	
	int nRightP = strLine.Find(_T(')'));
	if(nRightP == -1)
	{
		m_strErrorMessage = _T("Right paratheis missing"); 
		return false;
	}

	if(nRightP <= nLeftP)
	{
		m_strErrorMessage = _T("Bad function in line %d"); 
		return false;
	}

	strLine.Trim(_T(' '));

	int nBlank = strLine.Find(_T(' '));
	if(nBlank == -1 || nBlank > nRightP)
	{
		m_strErrorMessage = _T("Can't get function return type in line %d"); 
		return false;
	}
	
	CString strRtn = strLine.Left(nBlank);
	strRtn.Trim(_T(' '));
	m_dtReturn = GetDataType(strRtn);
	if(m_dtReturn == dtUnknown)
	{
		m_strErrorMessage = _T("Function return type missing or invalid"); 
		return false;
	}
	if(m_dtReturn == dtUDT)
	{
		m_strReturnType = strRtn;
	}

	strLine = strLine.Mid(nBlank + 1);
	strLine.Trim(_T(' '));

	nLeftP = strLine.Find(_T('('));
	if(nLeftP <= 0)
	{
		m_strErrorMessage = _T("Function name missing"); 
		return false;
	}
	
	m_strName = strLine.Left(nLeftP);
	m_strName.Trim(_T(' '));
	if(m_strName.GetLength() == 0)
	{
		m_strErrorMessage = _T("Function name missing"); 
		return false;
	}
	if(!IsValid(m_strName))
	{
		m_strErrorMessage = _T("Function name invalid"); 
		return false;
	}

	strLine = strLine.Mid(nLeftP);
	strLine.Trim(_T(' '));
	
	nLeftP = strLine.Find(_T('('));
	nRightP = strLine.Find(_T(')'));
	if(nLeftP < 0 || nLeftP >= nRightP)
	{
		m_strErrorMessage = _T("Invalid function"); 
		return false;
	}
	strLine = strLine.Mid(1);
	strLine.Trim(_T(' '));
	int nComa = strLine.Find(_T(','));
	if(nComa >= nRightP)
	{
		m_strErrorMessage = _T("Invalid function"); 
		return false;
	}
	if(nComa == -1)
	{
		nComa = strLine.Find(_T(')'));
	}
	while(nComa != -1)
	{
		CParameter Parameter;
		::memset(&Parameter, 0, sizeof(Parameter));
		CString strParam = strLine.Left(nComa);
		strLine = strLine.Mid(nComa + 1);
		strLine.Trim(_T(' '));
		strParam.Trim(_T(' '));
		if(strParam.GetLength() == 0)
			break;
		if(strParam.Find(_T("in ")) == 0)
		{
			Parameter.m_pt = ptIn;
			strParam = strParam.Mid(3);
		}
		else if(strParam.Find(_T("out ")) == 0)
		{
			Parameter.m_pt = ptOut;
			strParam = strParam.Mid(4);
		}
		else if(strParam.Find(_T("inout ")) == 0)
		{
			Parameter.m_pt = ptInOut;
			strParam = strParam.Mid(6);
		}
		else
		{
			m_strErrorMessage = _T("Parameter input direction (in, inout or out) missing"); 
			return false;
		}
		strParam.Trim(_T(' '));
		nBlank = strParam.Find(_T(' '));
		if(nBlank == -1)
		{
			m_strErrorMessage = _T("Parameter type or name missing"); 
			return false;
		}
		
		strPType = strParam.Left(nBlank);
		strPName = strParam.Mid(nBlank + 1);
		strPType.Trim(_T(' '));
		strPName.Trim(_T(' '));
		
		Parameter.m_dt = GetDataType(strPType);
		if(Parameter.m_dt == dtUnknown)
		{
			m_strErrorMessage = _T("Parameter data type missing or invalid"); 
			return false;
		}

		if(Parameter.m_dt == dtVoid)
		{
			m_strErrorMessage = _T("Parameter data type can't be the type void"); 
			return false;
		}

		if(!IsValid(strPName))
		{
			m_strErrorMessage = _T("Parameter name missing or invalid"); 
			return false;
		}
		
		if(strPName.GetLength() > 255)
		{
			m_strErrorMessage = _T("Parameter name is too long"); 
			return false;
		}
		
		if(AlreadyExist(strPName))
		{
			m_strErrorMessage = _T("Two parameter names are same"); 
			return false;
		}

		if(strPType.GetLength() > 255)
		{
			m_strErrorMessage = _T("Parameter type is too long"); 
			return false;
		}
		::_tcscpy_s(Parameter.m_strType, strPType);
		::_tcscpy_s(Parameter.m_strName, strPName);
		m_aParameter.Add(Parameter);

		nComa = strLine.Find(_T(','));
		if(nComa >= nRightP)
		{
			m_strErrorMessage = _T("Invalid function"); 
			return false;
		}
		if(nComa == -1)
		{
			nComa = strLine.Find(_T(')'));
		}
	}
	strLine.Trim(_T(' '));
	if(strLine.GetLength() != 1 || strLine[0] != _T(';'))
	{
		m_strErrorMessage = _T("Invalid function or end char ';' missing"); 
		return false;
	}
	m_strDeclaration = strDeclaration;
	return true;
}

bool CMethod::AlreadyExist(const CString strParameterName)
{
	int n;
	for(n=0; n<m_aParameter.GetSize(); n++)
	{
		if(strParameterName.CompareNoCase(m_aParameter[n].m_strName) == 0)
		{
			return true;
		}
	}
	return false;
}


void CMethod::GetInputParameters(CSimpleArray<CParameter> &aParameter)
{
	int n;
	aParameter.RemoveAll();
	for(n=0; n<m_aParameter.GetSize(); n++)
	{
		if(m_aParameter[n].m_pt == ptIn || m_aParameter[n].m_pt == ptInOut)
		{
			aParameter.Add(m_aParameter[n]);
		}
	}
}

CString CMethod::GetMethodForPeerVBNet()
{
	int n;
	int nSize;
	CString strMethod(_T("\tProtected Sub "));
	strMethod += GetName();
	strMethod += _T("(");
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = m_aParameter[n];
		if(n)
		{
			strMethod += _T(", ");
		}
		if(p.m_pt == ptIn)
		{
			strMethod += _T("ByVal ");
		}
		else
		{
			strMethod += _T("ByRef ");
		}

		strMethod += p.m_strName;
		strMethod += _T(" As ");

		CString strParam = GetInputString(p.m_dt);
		if(strParam == _T("UDT"))
		{
			strMethod += p.m_strType;
		}
		else
		{
			strMethod += strParam;
		}
	}

	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		if(nSize)
		{
			strMethod += _T(", ");
		}
		strMethod += _T("ByRef ");
		strMethod += GetName();
		strMethod += _T("Rtn");
		strMethod += _T(" As ");

		CString strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strMethod += GetReturnType();
		}
		else
		{
			strMethod += strParam;
		}
	}
	strMethod += _T(")\n");

	strMethod += _T("\t\t'TODO: Add your code here\n\tEnd Sub\n");
	return strMethod;
}

CString CMethod::GetMethodForPeerCSharp()
{
	int n;
	int nSize;
	CString strMethod(_T("\tprotected void "));
	strMethod += GetName();
	strMethod += _T("(");
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = m_aParameter[n];
		if(n)
		{
			strMethod += _T(", ");
		}
		if(p.m_pt == ptOut)
		{
			strMethod += _T("out ");
		}
		else if(p.m_pt == ptInOut)
		{
			strMethod += _T("ref ");
		}
		CString strParam = GetInputString(p.m_dt);
		if(strParam == _T("UDT"))
		{
			strMethod += p.m_strType;
		}
		else
		{
			strMethod += strParam;
		}
		strMethod += _T(" ");
		strMethod += p.m_strName;
	}

	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		if(nSize)
		{
			strMethod += _T(", ");
		}
		strMethod += _T("out ");
		CString strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strMethod += GetReturnType();
		}
		else
		{
			strMethod += strParam;
		}
		strMethod += _T(" ");
		strMethod += GetName();
		strMethod += _T("Rtn");
	}
	strMethod += _T(")\n");
	strMethod += _T("\t{\n");
	
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		CString strCall;
		CParameter &p = m_aParameter[n];
		if(p.m_pt != ptOut)
		{
			continue;
		}

		//pt == ptOut
		CString strParam = GetInputString(p.m_dt);
		if(strParam == _T("UDT"))
		{
			strCall.Format(_T("\t\t%s = new %s();\n"), p.m_strName, p.m_strType);
		}
		else if(strParam == _T("Guid"))
		{
			strCall.Format(_T("\t\t%s = new %s();\n"), p.m_strName, _T("Guid"));
		}
		else if(strParam == _T("string") || strParam == _T("object"))
		{
			strCall.Format(_T("\t\t%s = null;\n"), p.m_strName);
		}
		else
		{
			strCall.Format(_T("\t\t%s = 0;\n"), p.m_strName);
		}
		strMethod += strCall;
	}

	dt = GetReturn();
	if(dt != dtVoid)
	{
		CString strCall;
		CString strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strCall.Format(_T("\t\t%sRtn = new %s();\n"), GetName(), GetReturnType());
		}
		else if(strParam == _T("Guid"))
		{
			strCall.Format(_T("\t\t%sRtn = new %s();\n"), GetName(), _T("Guid"));
		}
		else if(strParam == _T("string") || strParam == _T("object"))
		{
			strCall.Format(_T("\t\t%sRtn = null;\n"), GetName());
		}
		else
		{
			strCall.Format(_T("\t\t%sRtn = 0;\n"), GetName());
		}
		strMethod += strCall;
	}

	strMethod += _T("\n\t\t// TODO: Add your code here\n\t}\n");
	return strMethod;
}

CString CMethod::GetMethodForPeerCpp()
{
	int n;
	int nSize;
	CString strMethod(_T("\tvoid "));
	strMethod += GetName();
	strMethod += _T("(");
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = m_aParameter[n];
		if(n)
		{
			strMethod += _T(", ");
		}
		if(p.m_pt == ptOut)
		{
			strMethod += _T("/*out*/");
		}
		else if(p.m_pt == ptInOut)
		{
			strMethod += _T("/*inout*/");
		}
		CString strParam = GetInputString(p.m_dt);
		if(strParam == _T("UDT"))
		{
			if(p.m_pt == ptIn)
			{
				strMethod += _T("const ");
			}
			strMethod += p.m_strType;
			strMethod += _T(" &");
		}
		else if(strParam == _T("GUID"))
		{
			if(p.m_pt == ptIn)
			{
				strMethod += _T("const ");
			}
			strMethod += _T("GUID");
			strMethod += _T(" &");
		}
		else if(strParam == _T("VARIANT"))
		{
			if(p.m_pt == ptIn)
			{
				strMethod += _T("const ");
			}
			strMethod += _T("CComVariant");
			strMethod += _T(" &");
		}
		else if(strParam == _T("string"))
		{
			if(p.m_pt == ptIn)
			{
				strMethod += _T("const ");
			}
			strMethod += _T("CComBSTR");
			strMethod += _T(" &");
		}
		else
		{
			strMethod += strParam;
			if(p.m_pt != ptIn)
			{
				strMethod += _T(" &");
			}
			else
			{
				strMethod += _T(" ");
			}
		}
		strMethod += p.m_strName;
	}

	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		if(nSize)
		{
			strMethod += _T(", ");
		}
		strMethod += _T("/*out*/");
		CString strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strMethod += GetReturnType();
		}
		else if(strParam == _T("GUID"))
		{
			strMethod += _T("GUID");
		}
		else if(strParam == _T("VARIANT"))
		{
			strMethod += _T("CComVariant");
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("CComBSTR");
		}
		else
		{
			strMethod += strParam;
		}
		strMethod += _T(" &");
		strMethod += GetName();
		strMethod += _T("Rtn");
	}
	strMethod += _T(")\n");
	strMethod += _T("\t{\n\t\t// TODO: Add your code here\n\t}\n");
	return strMethod;
}


void CMethod::GetOutputParameters(CSimpleArray<CParameter> &aParameter)
{
	int n;
	aParameter.RemoveAll();
	for(n=0; n<m_aParameter.GetSize(); n++)
	{
		if(m_aParameter[n].m_pt == ptOut || m_aParameter[n].m_pt == ptInOut)
		{
			aParameter.Add(m_aParameter[n]);
		}
	}
}

CString CMethod::GetInputString(tagDataType dt)
{
	switch(dt)
	{
	case dtVoid:
		if(m_lang != lVBNet)
		{
			return _T("void");
		}
		break;
	case dtBool:
		if(m_lang == lVBNet)
		{
			return _T("Boolean");
		}
		return _T("bool");
		break;
	case dtByte:
		if(m_lang == lCpp)
			return _T("unsigned char");
		else if(m_lang == lCSharp)
			return _T("byte");
		else
			return _T("Byte");
		break;
	case dtAChar:
		if(m_lang == lCpp)
			return _T("char");
		else if(m_lang == lCSharp)
			return _T("sbyte");
		else
			return _T("SByte");
		break;
	case dtUShort:
		if(m_lang == lCpp)
			return _T("unsigned short");
		else if(m_lang == lCSharp)
			return _T("ushort");
		else
			return _T("UShort");
		break;
	case dtShort:
		if(m_lang == lVBNet)
			return _T("Short");
		return _T("short");
		break;
	case dtWChar: 
		if(m_lang == lCpp)
			return _T("WCHAR");
		return _T("char");
		break;
	case dtUInt:
		if(m_lang == lCpp)
			return _T("unsigned int");
		else if(m_lang == lCSharp)
			return _T("uint");
		else
			return _T("UInteger");
		break;
	case dtInt:
		if(m_lang == lVBNet)
		{
			return _T("Integer");
		}
		return _T("int");
		break;
	case dtULong:
		if(m_lang == lCpp)
			return _T("ULONGLONG");
		else if(m_lang == lCSharp)
			return _T("ulong");
		else
			return _T("ULong");
		break;
	case dtLong:
		if(m_lang == lCpp)
			return _T("LONGLONG");
		else if(m_lang == lCSharp)
			return _T("long");
		else
			return _T("Long");
		break;
	case dtFloat:
		if(m_lang == lVBNet)
			return _T("Single");
		return _T("float");
		break;
	case dtDouble:
		if(m_lang == lVBNet)
			return _T("Double");
		return _T("double");
		break;
	case dtDecimal:
		if(m_lang == lCpp)
			return _T("DECIMAL");
		else if(m_lang == lCSharp)
			return _T("decimal");
		else
			return _T("Decimal");
		break;
	case dtString:
		return _T("string");
		break;
	case dtGuid:
		if(m_lang == lCpp)
			return _T("GUID");
		else
			return _T("Guid");
		break;
	case dtObject:
		if(m_lang == lCpp)
			return _T("VARIANT");
		else if(m_lang == lCSharp)
			return _T("object");
		else 
			return _T("Object");
		break;
	default:
		break;
	}
	return _T("UDT");
}

CString	CMethod::GetPeerCallVBNet()
{
	int n;
	int nSize;
	CString strCallMethod(_T("\t\t\t"));
	CString strPop;
	CString strPush(_T("\t\t\tSendResult(sRequestID"));
	CString strInstance;
	CString strPeerCall;
	strCallMethod += GetName();
	strCallMethod += _T("(");
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		if(n)
		{
			strCallMethod += _T(", ");
		}
		CParameter &p = m_aParameter[n];
		CString strParam = GetInputString(p.m_dt);
		if(strParam == _T("UDT"))
		{
			strInstance.Format(_T("\t\t\tDim %s As %s = new %s()\n"), p.m_strName, p.m_strType, p.m_strType);
		}
		else if(strParam == _T("Guid"))
		{
			strInstance.Format(_T("\t\t\tDim %s As Guid = new Guid();\n"), p.m_strName);
		}
		else if(strParam == _T("Object"))
		{
			strInstance.Format(_T("\t\t\tDim %s As Object = Nothing\n"), p.m_strName);
		}
		else if(strParam == _T("string"))
		{
			strInstance.Format(_T("\t\t\tDim %s as String = Nothing\n"), p.m_strName);
		}
		else
		{
			strInstance.Format(_T("\t\t\tDim %s As %s\n"), p.m_strName, strParam);
		}
		strPeerCall += strInstance;
		if(p.m_pt != ptOut)
		{
			if(p.m_dt == dtString)
			{
				strPop += _T("\t\t\tm_UQueue.Load(");
			}
			else
			{
				strPop += _T("\t\t\tm_UQueue.Pop(");
			}
			strPop += p.m_strName;
			if(p.m_dt == dtUDT)
			{
				strPop += _T(") 'Correct ????\n");
			}
			else
			{
				strPop += _T(")\n");
			}
		}

		strCallMethod += p.m_strName;

		if(p.m_pt != ptIn)
		{
			strPush += _T(", ");
			strPush += p.m_strName;
		}
	}

	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		CString strRtn;
		strRtn.Format(_T("%sRtn"), GetName());
		CString strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strInstance.Format(_T("\t\t\tDim %s As %s = new %s()\n"), strRtn, GetReturnType(), GetReturnType());
		}
		else if(strParam == _T("Guid"))
		{
			strInstance.Format(_T("\t\t\tDim %s As Guid = new Guid()\n"), strRtn);
		}
		else if(strParam == _T("Object"))
		{
			strInstance.Format(_T("\t\t\tDim %s As Object = Nothing\n"), strRtn);
		}
		else if(strParam == _T("string"))
		{
			strInstance.Format(_T("\t\t\tDim %s As String = Nothing\n"), strRtn);
		}
		else
		{
			strInstance.Format(_T("\t\t\tDim %s As %s\n"), strRtn, strParam);
		}
		strPeerCall += strInstance;

		strPush += _T(", ");
		strPush += GetName();
		strPush += _T("Rtn");

		if(m_aParameter.GetSize())
		{
			strCallMethod += _T(", ");
		}
		strCallMethod += GetName();
		strCallMethod += _T("Rtn");
	}
	strCallMethod += _T(")\n");
	strPeerCall += strPop;
	strPeerCall += strCallMethod;
	strPeerCall += strPush;
	strPeerCall += _T(")\n");
	return strPeerCall;
}

CString	CMethod::GetPeerCallCSharp()
{
	int n;
	int nSize;
	CString strCallMethod(_T("\t\t\t"));
	CString strPop;
	CString strPush(_T("\t\t\tSendResult(sRequestID"));
	CString strInstance;
	CString strPeerCall;
	strCallMethod += GetName();
	strCallMethod += _T("(");
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		if(n)
		{
			strCallMethod += _T(", ");
		}
		CParameter &p = m_aParameter[n];
		CString strParam = GetInputString(p.m_dt);

		if(strParam == _T("UDT"))
		{
			if(p.m_pt == ptOut)
				strInstance.Format(_T("\t\t\t%s %s;\n"), p.m_strType, p.m_strName);
			else
				strInstance.Format(_T("\t\t\t%s %s = new %s();\n"), p.m_strType, p.m_strName, p.m_strType);
		}
		else if(strParam == _T("Guid"))
		{
			if(p.m_pt == ptOut)
				strInstance.Format(_T("\t\t\t%s %s;\n"), _T("Guid"), p.m_strName);
			else
				strInstance.Format(_T("\t\t\t%s %s = new Guid();\n"), _T("Guid"), p.m_strName);
		}
		else if(strParam == _T("object"))
		{
			if(p.m_pt == ptOut)
				strInstance.Format(_T("\t\t\t%s %s;\n"), _T("object"), p.m_strName);
			else
				strInstance.Format(_T("\t\t\t%s %s = null;\n"), _T("object"), p.m_strName);
		}
		else if(strParam == _T("string"))
		{
			if(p.m_pt == ptOut)
				strInstance.Format(_T("\t\t\t%s %s;\n"), _T("string"), p.m_strName);
			else
				strInstance.Format(_T("\t\t\t%s %s = null;\n"), _T("string"), p.m_strName);
		}
		else
		{
			if(p.m_pt == ptOut)
				strInstance.Format(_T("\t\t\t%s %s;\n"), strParam, p.m_strName);
			else if(p.m_dt == dtBool)
				strInstance.Format(_T("\t\t\t%s %s = false;\n"), strParam, p.m_strName);
			else if(p.m_dt == dtWChar)
				strInstance.Format(_T("\t\t\t%s %s = (char)0;\n"), strParam, p.m_strName);
			else
				strInstance.Format(_T("\t\t\t%s %s = 0;\n"), strParam, p.m_strName);
		}
		strPeerCall += strInstance;
		if(p.m_pt != ptOut)
		{
			if(p.m_dt == dtString)
			{
				strPop += _T("\t\t\tm_UQueue.Load(ref ");
			}
			else
			{
				strPop += _T("\t\t\tm_UQueue.Pop(ref ");
			}
			strPop += p.m_strName;
			if(p.m_dt == dtUDT)
			{
				strPop += _T("); //Correct ????\n");
			}
			else
			{
				strPop += _T(");\n");
			}
		}

		if(p.m_pt == ptInOut)
			strCallMethod += _T("ref ");
		else if(p.m_pt == ptOut)
			strCallMethod += _T("out ");

		strCallMethod += p.m_strName;

		if(p.m_pt != ptIn)
		{
			strPush += _T(", ");
			strPush += p.m_strName;
		}
	}

	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		CString strRtn;
		strRtn.Format(_T("%sRtn"), GetName());
		CString strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), GetReturnType(), strRtn);
		}
		else if(strParam == _T("Guid"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("Guid"), strRtn);
		}
		else if(strParam == _T("object"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("object"), strRtn);
		}
		else if(strParam == _T("string"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("string"), strRtn);
		}
		else
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), strParam, strRtn);
		}
		strPeerCall += strInstance;
		strPush += _T(", ");
		strPush += GetName();
		if(strParam == _T("UDT"))
		{
			strPush += _T("Rtn/*Correct ????*/");
		}
		else
		{
			strPush += _T("Rtn");
		}
		if(m_aParameter.GetSize())
		{
			strCallMethod += _T(", ");
		}
		strCallMethod += _T("out ");
		strCallMethod += GetName();
		strCallMethod += _T("Rtn");
	}
	strCallMethod += _T(");\n");
	strPeerCall += strPop;
	strPeerCall += strCallMethod;
	strPeerCall += strPush;
	strPeerCall += _T(");\n");

	return strPeerCall;
}

CString	CMethod::GetPeerCallCpp()
{
	int n;
	int nSize;
	CString strCallMethod(_T("\t\t\t"));
	CString strPop;
	CString strPush(_T("\t\t\tSendResult(usRequestID"));
	CString strInstance;
	CString strPeerCall;
	strCallMethod += GetName();
	strCallMethod += _T("(");
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		if(n)
		{
			strCallMethod += _T(", ");
		}
		CParameter &p = m_aParameter[n];
		CString strParam = GetInputString(p.m_dt);
		if(strParam == _T("UDT"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), p.m_strType, p.m_strName);
		}
		else if(strParam == _T("GUID"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("GUID"), p.m_strName);
		}
		else if(strParam == _T("VARIANT"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("CComVariant"), p.m_strName);
		}
		else if(strParam == _T("string"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("CComBSTR"), p.m_strName);
		}
		else
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), strParam, p.m_strName);
		}
		strPeerCall += strInstance;
		if(p.m_pt != ptOut)
		{
			strPop += _T("\t\t\tm_UQueue >> ");
			strPop += p.m_strName;
			if(p.m_dt == dtUDT)
			{
				strPop += _T("; //Correct ????\n");
			}
			else
			{
				strPop += _T(";\n");
			}
		}

		strCallMethod += p.m_strName;

		if(p.m_pt != ptIn)
		{
			strPush += _T(", ");
			strPush += p.m_strName;
			if(p.m_dt == dtUDT)
			{
				strPush += _T("/*Correct ????*/");
			}
		}
	}

	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		CString strRtn;
		strRtn.Format(_T("%sRtn"), GetName());
		CString strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), GetReturnType(), strRtn);
		}
		else if(strParam == _T("GUID"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("GUID"), strRtn);
		}
		else if(strParam == _T("VARIANT"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("CComVariant"), strRtn);
		}
		else if(strParam == _T("string"))
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), _T("CComBSTR"), strRtn);
		}
		else
		{
			strInstance.Format(_T("\t\t\t%s %s;\n"), strParam, strRtn);
		}
		strPeerCall += strInstance;
		strPush += _T(", ");
		strPush += GetName();
		if(dt == dtUDT)
			strPush += _T("Rtn/*Correct ????*/");
		else
			strPush += _T("Rtn");
		if(m_aParameter.GetSize())
			strCallMethod += _T(", ");
		strCallMethod += GetName();
		strCallMethod += _T("Rtn");
	}
	strCallMethod += _T(");\n");
	strPeerCall += strPop;
	strPeerCall += strCallMethod;
	strPeerCall += strPush;
	strPeerCall += _T(");\n");

	return strPeerCall;
}

CString CMethod::GetClientAsynInputMethodVBNet()
{
	int n;
	int nSize;
	CString strTemp;
	CString strMethod;
	CString strParam;
	m_strRtnProcessing.Empty();
	CSimpleArray<CParameter> aOutParameter;
	CSimpleArray<CParameter> aParameter;

	GetOutputParameters(aOutParameter);
	nSize = aOutParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		strMethod += _T("\tProtected ");
		strMethod += _T("m_");
		strMethod += aOutParameter[n].m_strName;
		strMethod += _T("_");
		strMethod += GetName();
		strMethod += _T(" As ");
		strParam = GetInputString(aOutParameter[n].m_dt);
		if(strParam == _T("UDT"))
		{
			strMethod += aOutParameter[n].m_strType;
			strMethod += _T(" = new ");
			strMethod += aOutParameter[n].m_strType;
			strMethod += _T("()");
		}
		else if(strParam == _T("Guid"))
		{
			strMethod += _T("Guid = new Guid()");
		}
		else if(strParam == _T("Object"))
		{
			strMethod += _T("Object");
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("String");
		}
		else
		{
			strMethod += strParam;
		}
		strMethod += _T("\n");
		
		if(aOutParameter[n].m_dt == dtString)
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Load(");
		}
		else
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Pop(");
		}
		m_strRtnProcessing += _T("m_");
		m_strRtnProcessing += aOutParameter[n].m_strName;
		m_strRtnProcessing += _T("_");
		m_strRtnProcessing += GetName();
		m_strRtnProcessing += _T(")\n");
	}
	
	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		strMethod += _T("\tProtected m_");
		strMethod += GetName();
		strMethod += _T("Rtn As ");
		strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strMethod += GetReturnType();
			strMethod += _T(" = new ");
			strMethod += GetReturnType();
			strMethod += _T("()");
		}
		else if(strParam == _T("Guid"))
		{
			strMethod += _T("Guid = new Guid()");
		}
		else if(strParam == _T("Object"))
		{
			strMethod += _T("Object");
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("String");
		}
		else
		{
			strMethod += strParam;
		}
		if(dt == dtString)
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Load(");
		}
		else
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Pop(");
		}
		m_strRtnProcessing += _T("m_");
		m_strRtnProcessing += GetName();
		if(dt == dtUDT)
		{
			m_strRtnProcessing += _T("Rtn) 'Correct ????\n");
		}
		else
		{
			m_strRtnProcessing += _T("Rtn)\n");
		}
		strMethod += _T("\n");
	}

	GetInputParameters(aParameter);
	nSize = aParameter.GetSize();
	strMethod += (_T("\tProtected Sub "));
	strMethod += GetName();
	strMethod += _T("Asyn");
	strMethod += _T("(");

	for(n=0; n<nSize; n++)
	{
		if(n)
		{
			strMethod += _T(", ");
		}
		strParam = GetInputString(aParameter[n].m_dt);
		strMethod += _T("ByVal ");
		if(strParam == _T("UDT"))
		{
			strMethod += aParameter[n].m_strName;
			strMethod += _T(" AS ");
			strMethod += aParameter[n].m_strType;
		}
		else if(strParam == _T("Guid"))
		{
			strMethod += aParameter[n].m_strName;
			strMethod += _T(" As Guid");
		}
		else if(strParam == _T("Object"))
		{
			strMethod += aParameter[n].m_strName;
			strMethod += _T(" As Object");
		}
		else if(strParam == _T("string"))
		{
			strMethod += aParameter[n].m_strName;
			strMethod += _T(" As String");
		}
		else
		{
			strMethod += aParameter[n].m_strName;
			strMethod += _T(" As ");
			strMethod += strParam;
		}
	}
	strMethod += _T(")\n");
	CString strCase;
	strCase.Format(_T("\t\tcase %s.id%s%s\n"), m_strDefClass, GetName(), GetServiceName());
	m_strRtnProcessing = strCase + m_strRtnProcessing;
	CString strHead(_T("\t\t'make sure that the handler is attached to a client socket before calling the below statement\n"));
	if(nSize > 0) 
	{
		CString strP;
		for(n=0; n<nSize; n++)
		{
			strP += _T(", ");
			strP += aParameter[n].m_strName;
		}
		strTemp.Format(_T("\t\tSendRequest(%s.id%s%s%s)"), m_strDefClass, GetName(), GetServiceName(), strP);
	}
	else
	{
		strTemp.Format(_T("\t\tSendRequest(%s.id%s%s)"), m_strDefClass, GetName(), GetServiceName());
	}
	strTemp = strHead + strTemp;
	strMethod += strTemp;
	strMethod += _T("\n\tEnd Sub");	
	return strMethod;
}

CString CMethod::GetClientAsynInputMethodCSharp()
{
	int n;
	int nSize;
	CString strTemp;
	CString strMethod;
	CString strParam;
	m_strRtnProcessing.Empty();
	CSimpleArray<CParameter> aOutParameter;
	CSimpleArray<CParameter> aParameter;
	
	GetOutputParameters(aOutParameter);
	nSize = aOutParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		strMethod += _T("protected ");
		strParam = GetInputString(aOutParameter[n].m_dt);
		if(strParam == _T("UDT"))
		{
			strMethod += aOutParameter[n].m_strType;
		}
		else if(strParam == _T("Guid"))
		{
			strMethod += _T("Guid");
		}
		else if(strParam == _T("object"))
		{
			strMethod += _T("object");
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("string");
		}
		else
		{
			strMethod += strParam;
		}
		
		if(aOutParameter[n].m_dt == dtString)
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Load(ref ");
		}
		else
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Pop(ref ");
		}
		m_strRtnProcessing += _T("m_");
		m_strRtnProcessing += aOutParameter[n].m_strName;
		m_strRtnProcessing += _T("_");
		m_strRtnProcessing += GetName();
		m_strRtnProcessing += _T(");\n");

		strMethod += _T(" m_");
		strMethod += aOutParameter[n].m_strName;
		strMethod += _T("_");
		strMethod += GetName();
		strMethod += _T(";\n\t");
	}
	
	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		strMethod += _T("protected ");
		strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strMethod += GetReturnType();
		}
		else if(strParam == _T("Guid"))
		{
			strMethod += _T("Guid");
		}
		else if(strParam == _T("object"))
		{
			strMethod += _T("object");
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("string");
		}
		else
		{
			strMethod += strParam;
		}
		if(dt == dtString)
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Load(ref ");
		}
		else
		{
			m_strRtnProcessing += _T("\t\t\tUQueue.Pop(ref ");
		}
		m_strRtnProcessing += _T("m_");
		m_strRtnProcessing += GetName();
		if(dt == dtUDT)
		{
			m_strRtnProcessing += _T("Rtn); //Correct ????\n");
		}
		else
		{
			m_strRtnProcessing += _T("Rtn);\n");
		}
		strMethod += _T(" m_");
		strMethod += GetName();
		strMethod += _T("Rtn;\n\t");
	}

	GetInputParameters(aParameter);
	nSize = aParameter.GetSize();
	strMethod += (_T("protected void "));
	strMethod += GetName();
	strMethod += _T("Asyn");
	strMethod += _T("(");

	for(n=0; n<nSize; n++)
	{
		if(n)
		{
			strMethod += _T(", ");
		}
		strParam = GetInputString(aParameter[n].m_dt);
		if(strParam == _T("UDT"))
		{
			strMethod += aParameter[n].m_strType;
			strMethod += _T(" ");
			strMethod += aParameter[n].m_strName;
		}
		else if(strParam == _T("Guid"))
		{
			strMethod += _T("Guid");
			strMethod += _T(" ");
			strMethod += aParameter[n].m_strName;
		}
		else if(strParam == _T("object"))
		{
			strMethod += _T("object");
			strMethod += _T(" ");
			strMethod += aParameter[n].m_strName;
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("string");
			strMethod += _T(" ");
			strMethod += aParameter[n].m_strName;
		}
		else
		{
			strMethod += strParam;
			strMethod += _T(" ");
			strMethod += aParameter[n].m_strName;
		}
	}
	strMethod += _T(")\n\t{\n");
	CString strCase;
	strCase.Format(_T("\t\tcase %s.id%s%s:\n"), m_strDefClass, GetName(), GetServiceName());
	m_strRtnProcessing = strCase + m_strRtnProcessing;
	if(nSize > 0) 
	{
		CString strP;
		CString strHead(_T("\t\t//make sure that the handler is attached to a client socket before calling the below statement\n"));
		for(n=0; n<nSize; n++)
		{
			strP += _T(", ");
			strP += aParameter[n].m_strName;
			if(aParameter[n].m_dt == dtUDT)
			{
				strP += _T("/*Correct ????*/");
			}
		}
		strTemp.Format(_T("\t\tSendRequest(%s.id%s%s%s);"), m_strDefClass, GetName(), GetServiceName(), strP);
		strTemp = strHead + strTemp;
	}
	else
	{
		CString strHead(_T("\t\t//make sure that the handler is attached to a client socket before calling the below statement\n"));
		strTemp.Format(_T("\t\tSendRequest(%s.id%s%s);"), m_strDefClass, GetName(), GetServiceName());
		strTemp = strHead + strTemp;
	}
	m_strRtnProcessing += _T("\t\t\tbreak;\n");
	strMethod += strTemp;
	strMethod += _T("\n\t}");	
	return strMethod;
}

CString CMethod::GetClientAsynInputMethodCpp()
{
	int n;
	int nSize;
	CString strTemp;
	CString strMethod;
	CString strParam;
	m_strRtnProcessing.Empty();
	CSimpleArray<CParameter> aOutParameter;
	CSimpleArray<CParameter> aParameter;
	
	GetOutputParameters(aOutParameter);
	nSize = aOutParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		strParam = GetInputString(aOutParameter[n].m_dt);
		if(strParam == _T("UDT"))
		{
			strMethod += aOutParameter[n].m_strType;
		}
		else if(strParam == _T("GUID"))
		{
			strMethod += _T("GUID");
		}
		else if(strParam == _T("VARIANT"))
		{
			strMethod += _T("CComVariant");
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("CComBSTR");
		}
		else
		{
			strMethod += strParam;
		}

		m_strRtnProcessing += _T("\t\t\tUQueue >> ");
		m_strRtnProcessing += _T("m_");
		m_strRtnProcessing += aOutParameter[n].m_strName;
		m_strRtnProcessing += _T("_");
		m_strRtnProcessing += GetName();
		m_strRtnProcessing += _T(";\n");

		strMethod += _T(" m_");
		strMethod += aOutParameter[n].m_strName;
		strMethod += _T("_");
		strMethod += GetName();
		strMethod += _T(";\n\t");
	}
	
	tagDataType dt = GetReturn();
	if(dt != dtVoid)
	{
		strParam = GetInputString(dt);
		if(strParam == _T("UDT"))
		{
			strMethod += this->GetReturnType();
		}
		else if(strParam == _T("GUID"))
		{
			strMethod += _T("GUID");
		}
		else if(strParam == _T("VARIANT"))
		{
			strMethod += _T("CComVariant");
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("CComBSTR");
		}
		else
		{
			strMethod += strParam;
		}
		m_strRtnProcessing += _T("\t\t\tUQueue >> ");
		m_strRtnProcessing += _T("m_");
		m_strRtnProcessing += GetName();
		if(dt == dtUDT)
		{
			m_strRtnProcessing += _T("Rtn; //Correct ????\n");
		}
		else
		{
			m_strRtnProcessing += _T("Rtn;\n");
		}
		strMethod += _T(" m_");
		strMethod += GetName();
		strMethod += _T("Rtn;\n\t");
	}

	GetInputParameters(aParameter);
	nSize = aParameter.GetSize();
	strMethod += (_T("void "));
	strMethod += GetName();
	strMethod += _T("Asyn");
	strMethod += _T("(");

	for(n=0; n<nSize; n++)
	{
		if(n)
		{
			strMethod += _T(", ");
		}
		strParam = GetInputString(aParameter[n].m_dt);
		if(strParam == _T("UDT"))
		{
			strMethod += _T("const ");
			strMethod += aParameter[n].m_strType;
			strMethod += _T(" &");
			strMethod += aParameter[n].m_strName;
		}
		else if(strParam == _T("GUID"))
		{
			strMethod += _T("const ");
			strMethod += _T("GUID");
			strMethod += _T(" &");
			strMethod += aParameter[n].m_strName;
		}
		else if(strParam == _T("VARIANT"))
		{
			strMethod += _T("const ");
			strMethod += _T("VARIANT");
			strMethod += _T(" &");
			strMethod += aParameter[n].m_strName;
		}
		else if(strParam == _T("string"))
		{
			strMethod += _T("LPCWSTR");
			strMethod += _T(" ");
			strMethod += aParameter[n].m_strName;
		}
		else
		{
			strMethod += strParam;
			strMethod += _T(" ");
			strMethod += aParameter[n].m_strName;
		}
	}
	strMethod += _T(")\n\t{\n");
	CString strCase;
	strCase.Format(_T("\t\tcase id%s%s:\n"), GetName(), GetServiceName());
	m_strRtnProcessing = strCase + m_strRtnProcessing;
	CString strHead(_T("\t\t//make sure that the handler is attached to a client socket before calling the below statement\n"));
	if(nSize > 0) 
	{
		CString strP;
		for(n=0; n<nSize; n++)
		{
			strP += _T(", ");
			strP += aParameter[n].m_strName;
			if(aParameter[n].m_dt == dtUDT)
			{
				strP += _T("/*Correct ????*/");
			}
		}
		strTemp.Format(_T("\t\tSendRequest(id%s%s%s);"), GetName(), GetServiceName(), strP);
	}
	else
	{
		strTemp.Format(_T("\t\tSendRequest(id%s%s, NULL, 0);"), GetName(), GetServiceName());
	}
	strTemp = strHead + strTemp;
	m_strRtnProcessing += _T("\t\t\tbreak;\n");
	strMethod += strTemp;
	strMethod += _T("\n\t}");	
	return strMethod;
}

LPCTSTR CMethod::GetSynFunVBNet()
{
	int n;
	int nSize;
	CString strTemp;
	CString strParam;
	m_strSynFun = _T("\tPublic ");
	tagDataType dt = GetReturn();
	if(dt == dtVoid)
	{
		m_strSynFun += _T("Sub ");
	}
	else
	{
		m_strSynFun += _T("Function ");
	}

	m_strSynFun += GetName();
	m_strSynFun += _T("(");

	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = m_aParameter[n];
		if(n > 0)
		{
			m_strSynFun += _T(", ");
		}
		strParam = GetInputString(p.m_dt);
		if(p.m_pt == ptIn)
		{
			m_strSynFun += _T("ByVal ");
		}
		else
		{
			m_strSynFun += _T("ByRef ");
		}
		m_strSynFun += p.m_strName;
		m_strSynFun += _T(" As ");
		if(strParam == _T("UDT"))
		{
			m_strSynFun += p.m_strType;
		}
		else if(strParam == _T("Guid"))
		{
			m_strSynFun += _T("Guid");
		}
		else if(strParam == _T("Object"))
		{
			m_strSynFun += _T("Object");
		}
		else if(strParam == _T("string"))
		{
			m_strSynFun += _T("String");
		}
		else
		{
			m_strSynFun += strParam;
		}
	}
	m_strSynFun += _T(") ");
	if(dt != dtVoid)
	{
		m_strSynFun += _T("As ");
		strParam = GetInputString(GetReturn());
		if(strParam == _T("UDT"))
		{
			m_strSynFun += GetReturnType();
		}
		else if(strParam == _T("Guid"))
		{
			m_strSynFun += _T("Guid");
		}
		else if(strParam == _T("Object"))
		{
			m_strSynFun += _T("Object");
		}
		else if(strParam == _T("string"))
		{
			m_strSynFun += _T("String");
		}
		else
		{
			m_strSynFun += strParam;
		}
	}

	m_strSynFun += _T("\n");
	m_strSynFun += _T("\t\t");
	m_strSynFun += GetName();
	m_strSynFun += _T("Asyn(");
	
	CSimpleArray<CParameter> aInput;
	GetInputParameters(aInput);
	nSize = aInput.GetSize();
	for(n=0; n<nSize; n++)
	{
		if(n > 0)
		{
			m_strSynFun += _T(", ");
		}
		CParameter &p = aInput[n];
		m_strSynFun += p.m_strName;
	}
	m_strSynFun += _T(")\n");
	m_strSynFun += _T("\t\tGetAttachedClientSocket().WaitAll()\n");
	
	GetOutputParameters(aInput);
	nSize = aInput.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = aInput[n];
		strTemp.Format(_T("\t\t%s = m_%s_%s\n"), p.m_strName, p.m_strName, GetName());
		m_strSynFun += strTemp;
	}

	if(GetReturn() != dtVoid)
	{
		m_strSynFun += _T("\t\treturn ");
		m_strSynFun += _T("m_");
		m_strSynFun += GetName();
		m_strSynFun += _T("Rtn\n");
	}
	if(GetReturn() == dtVoid)
	{
		m_strSynFun += _T("\tEnd Sub\n");
	}
	else
	{
		m_strSynFun += _T("\tEnd Function\n");
	}
	return m_strSynFun;
}

LPCTSTR CMethod::GetSynFunCSharp()
{
	int n;
	int nSize;
	CString strTemp;
	CString strParam;
	m_strSynFun = _T("\tpublic ");
	tagDataType dt = GetReturn();
	if(dt == dtVoid)
	{
		m_strSynFun += _T("void ");
	}
	else
	{
		strParam = GetInputString(GetReturn());
		if(strParam == _T("UDT"))
		{
			m_strSynFun += GetReturnType();
			m_strSynFun += _T(" ");
		}
		else if(strParam == _T("Guid"))
		{
			m_strSynFun += _T("Guid ");
		}
		else if(strParam == _T("object"))
		{
			m_strSynFun += _T("object ");
		}
		else if(strParam == _T("string"))
		{
			m_strSynFun += _T("string ");
		}
		else
		{
			m_strSynFun += strParam;
			m_strSynFun += _T(" ");
		}
	}
	m_strSynFun += GetName();
	m_strSynFun += _T("(");
	
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = m_aParameter[n];
		if(n > 0)
		{
			m_strSynFun += _T(", ");
		}
		strParam = GetInputString(p.m_dt);
		if(p.m_pt == ptInOut)
		{
			m_strSynFun += _T("ref ");
		}
		else if(p.m_pt == ptOut)
		{
			m_strSynFun += _T("out ");
		}
		if(strParam == _T("UDT"))
		{
			m_strSynFun += p.m_strType;
			m_strSynFun += _T(" ");
		}
		else if(strParam == _T("Guid"))
		{
			m_strSynFun += _T("Guid ");
		}
		else if(strParam == _T("object"))
		{
			m_strSynFun += _T("object ");
		}
		else if(strParam == _T("string"))
		{
			m_strSynFun += _T("string ");
		}
		else
		{
			m_strSynFun += strParam;
			m_strSynFun += _T(" ");
		}
		m_strSynFun += p.m_strName;
	}
	
	m_strSynFun += _T(")\n\t{\n");
	
	m_strSynFun += _T("\t\t");
	m_strSynFun += GetName();
	m_strSynFun += _T("Asyn(");
	
	CSimpleArray<CParameter> aInput;
	GetInputParameters(aInput);
	nSize = aInput.GetSize();
	for(n=0; n<nSize; n++)
	{
		if(n > 0)
		{
			m_strSynFun += _T(", ");
		}
		CParameter &p = aInput[n];
		m_strSynFun += p.m_strName;
	}
	m_strSynFun += _T(");\n");
	m_strSynFun += _T("\t\tGetAttachedClientSocket().WaitAll();\n");
	
	GetOutputParameters(aInput);
	nSize = aInput.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = aInput[n];
		strTemp.Format(_T("\t\t%s = m_%s_%s;\n"), p.m_strName, p.m_strName, GetName());
		m_strSynFun += strTemp;
	}

	if(GetReturn() != dtVoid)
	{
		m_strSynFun += _T("\t\treturn ");
		m_strSynFun += _T("m_");
		m_strSynFun += GetName();
		m_strSynFun += _T("Rtn;\n");
	}
	m_strSynFun += _T("\t}\n");
	return m_strSynFun;
}

LPCTSTR CMethod::GetSynFunCpp()
{
	int n;
	int nSize;
	CString strTemp;
	CString strParam;
	m_strSynFun = _T("\t");
	tagDataType dt = GetReturn();
	if(dt == dtVoid)
	{
		m_strSynFun += _T("void ");
	}
	else
	{
		strParam = GetInputString(GetReturn());
		if(strParam == _T("UDT"))
		{
			m_strSynFun += _T("const ");
			m_strSynFun += GetReturnType();
			m_strSynFun += _T("& ");
		}
		else if(strParam == _T("GUID"))
		{
			m_strSynFun += _T("const GUID& ");
		}
		else if(strParam == _T("VARIANT"))
		{
			m_strSynFun += _T("const CComVariant& ");
		}
		else if(strParam == _T("string"))
		{
			m_strSynFun += _T("const CComBSTR& ");
		}
		else
		{
			m_strSynFun += strParam;
			m_strSynFun += _T(" ");
		}
	}
	m_strSynFun += GetName();
	m_strSynFun += _T("(");
	
	nSize = m_aParameter.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = m_aParameter[n];
		if(n > 0)
		{
			m_strSynFun += _T(", ");
		}
		strParam = GetInputString(p.m_dt);
		if(strParam == _T("UDT"))
		{
			if(p.m_pt == ptIn)
			{
				m_strSynFun += _T("const ");
			}
			else if(p.m_pt == ptOut)
			{
				m_strSynFun += _T("/*out*/");
			}
			else
			{
				m_strSynFun += _T("/*inout*/");
			}
			m_strSynFun += p.m_strType;
			m_strSynFun += _T(" &");
		}
		else if(strParam == _T("GUID"))
		{
			if(p.m_pt == ptIn)
			{
				m_strSynFun += _T("const ");
			}
			else if(p.m_pt == ptOut)
			{
				m_strSynFun += _T("/*out*/");
			}
			else
			{
				m_strSynFun += _T("/*inout*/");
			}
			m_strSynFun += _T("GUID &");
		}
		else if(strParam == _T("VARIANT"))
		{
			if(p.m_pt == ptIn)
			{
				m_strSynFun += _T("const ");
			}
			else if(p.m_pt == ptOut)
			{
				m_strSynFun += _T("/*out*/");
			}
			else
			{
				m_strSynFun += _T("/*inout*/");
			}
			m_strSynFun += _T("VARIANT &");
		}
		else if(strParam == _T("string"))
		{
			if(p.m_pt == ptIn)
			{
				m_strSynFun += _T("LPCWSTR ");
			}
			else if(p.m_pt == ptOut)
			{
				m_strSynFun += _T("/*out*/CComBSTR &");
			}
			else
			{
				m_strSynFun += _T("/*inout*/CComBSTR &");
			}
		}
		else
		{
			if(p.m_pt == ptOut)
			{
				m_strSynFun += _T("/*out*/");
			}
			else if(p.m_pt == ptInOut)
			{
				m_strSynFun += _T("/*inout*/");
			}
			m_strSynFun += strParam;
			if(p.m_pt == ptIn)
			{
				m_strSynFun += _T(" ");
			}
			else
			{
				m_strSynFun += _T(" &");
			}
		}
		m_strSynFun += p.m_strName;
	}
	
	m_strSynFun += _T(")\n\t{\n");
	
	m_strSynFun += _T("\t\t");
	m_strSynFun += GetName();
	m_strSynFun += _T("Asyn(");
	
	CSimpleArray<CParameter> aInput;
	GetInputParameters(aInput);
	nSize = aInput.GetSize();
	for(n=0; n<nSize; n++)
	{
		if(n > 0)
		{
			m_strSynFun += _T(", ");
		}
		CParameter &p = aInput[n];
		m_strSynFun += p.m_strName;
	}
	m_strSynFun += _T(");\n");
	m_strSynFun += _T("\t\tGetAttachedClientSocket()->WaitAll();\n");
	
	GetOutputParameters(aInput);
	nSize = aInput.GetSize();
	for(n=0; n<nSize; n++)
	{
		CParameter &p = aInput[n];
		strTemp.Format(_T("\t\t%s = m_%s_%s;\n"), p.m_strName, p.m_strName, GetName());
		m_strSynFun += strTemp;
	}

	if(GetReturn() != dtVoid)
	{
		m_strSynFun += _T("\t\treturn ");
		m_strSynFun += _T("m_");
		m_strSynFun += GetName();
		m_strSynFun += _T("Rtn;\n");
	}
	m_strSynFun += _T("\t}\n");
	return m_strSynFun;
}
