#include "StdAfx.h"
#include "uidfile.h"

CUidFile::CUidFile(tagLanguage lang)
{
	m_lang = lang;
}

CUidFile::~CUidFile(void)
{
}

void CUidFile::SetLanguage(tagLanguage lang)
{
	m_lang = lang;
}

LPCTSTR CUidFile::GetErrorMessage()
{
	return m_strErrorMessage;
}

bool CUidFile::ExistingService(LPCTSTR strSvsName)
{
	int n;
	for(n=0; n<m_aService.GetSize(); n++)
	{
		if(m_aService[n].GetName().CompareNoCase(strSvsName) == 0)
			return true;
	}
	return false;
}

bool CUidFile::ExistingService(ULONG ulSvsID)
{
	int n;
	for(n=0; n<m_aService.GetSize(); n++)
	{
		if(m_aService[n].GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			continue;
		if(m_aService[n].GetSvsID() == ulSvsID)
			return true;
	}
	return false;
}

bool CUidFile::CreateDefFileVBNet()
{
	int n;
	ULONG ulWrite;
	CString strDef;
	CString strTemp;
	CString strComment;
	int nSlash = m_strOutputFile.ReverseFind(_T('\\'));
	if(nSlash != -1)
	{
		strTemp = m_strOutputFile.Mid(nSlash + 1);
	}
	else
	{
		strTemp = m_strOutputFile;
	}
	int nDot = strTemp.Find(_T('.'));
	if(nDot != -1)
	{
		strTemp = strTemp.Left(nDot);
	}
	
	strDef.Format(_T("public class %sConst\n"), strTemp);
	
	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		if(n)
		{
			strDef += _T("\n");
		}
		CUIDService &Svs = m_aService[n];
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strComment.Format(_T("\t'defines for service %s\n"), Svs.GetName());
			strDef += strComment;
			strTemp.Format(_T("\tpublic const sid%s as Integer = (USOCKETLib.tagOtherDefine.odUserServiceIDMin + %d)\n\n"), Svs.GetName(), Svs.GetSvsID());
			strDef += strTemp;
		}

		int j;
		CString strPrev = GetInitialRequestID(Svs.GetName());
		int jAll = Svs.GetMethods().GetSize();
		for(j = 0; j<jAll; j++)
		{
			CMethod &mb = Svs.GetMethods()[j];
			if(j == 0)
			{
				strTemp.Format(_T("\tpublic Const id%s%s as Short = (%s)\n"), mb.GetName(), Svs.GetName(), strPrev);
			}
			else
			{
				strTemp.Format(_T("\tpublic Const id%s%s as Short = (%s + 1)\n"), mb.GetName(), Svs.GetName(), strPrev);
			}
			strDef += strTemp;
			strPrev.Format(_T("id%s%s"), mb.GetName(), Svs.GetName());
		}
	}
	strDef += _T("End Class");

	::DeleteFile(m_strDefFile);
	HANDLE hFile = ::CreateFile(m_strDefFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::CreateDefFileCSharp()
{
	int n;
	ULONG ulWrite;
	CString strDef;
	CString strTemp;
	CString strComment;
	int nSlash = m_strOutputFile.ReverseFind(_T('\\'));
	if(nSlash != -1)
	{
		strTemp = m_strOutputFile.Mid(nSlash + 1);
	}
	else
	{
		strTemp = m_strOutputFile;
	}
	int nDot = strTemp.Find(_T('.'));
	if(nDot != -1)
	{
		strTemp = strTemp.Left(nDot);
	}
	
	strDef.Format(_T("public class %sConst\n{\n"), strTemp);
	
	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		if(n)
		{
			strDef += _T("\n");
		}
		CUIDService &Svs = m_aService[n];
		
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strComment.Format(_T("\t//defines for service %s\n"), Svs.GetName());
			strDef += strComment;
			strTemp.Format(_T("\tpublic const int sid%s = ((int)USOCKETLib.tagOtherDefine.odUserServiceIDMin + %d);\n\n"), Svs.GetName(), Svs.GetSvsID());
			strDef += strTemp;
		}

		int j;
		CString strPrev = GetInitialRequestID(Svs.GetName());
		int jAll = Svs.GetMethods().GetSize();
		for(j = 0; j<jAll; j++)
		{
			CMethod &mb = Svs.GetMethods()[j];
			if(j == 0)
			{
				strTemp.Format(_T("\tpublic const short id%s%s = (%s);\n"), mb.GetName(), Svs.GetName(), strPrev);
			}
			else
			{
				strTemp.Format(_T("\tpublic const short id%s%s = (%s + 1);\n"), mb.GetName(), Svs.GetName(), strPrev);
			}
			strDef += strTemp;
			strPrev.Format(_T("id%s%s"), mb.GetName(), Svs.GetName());
		}
	}
	strDef += _T("}");

	::DeleteFile(m_strDefFile);
	HANDLE hFile = ::CreateFile(m_strDefFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::HandleIncludeFiles(CString &strUID)
{
	int nFHead;
	int nFEnd;
	bool bSuc = true;
	int nInclude = -1;
	
	do
	{
		nInclude = strUID.Find(UID_INCLUDE);
		if(nInclude == -1)
			break;
		nFHead = strUID.Find(_T('"'), nInclude + 8);
		nFEnd = strUID.Find(_T('"'), nFHead + 1);
		if(nFHead > 0 && nFEnd > (nFHead + 4))
		{
			CString strTempL;
			CString strTempR;
			CString strFile;
			strTempL = strUID.Left(nInclude);
			strTempR = strUID.Mid(nFEnd + 1);
			strFile = strUID.Mid(nFHead + 1, (nFEnd- (nFHead + 1)));
			CUidFile UidFile(m_lang);
			if(!UidFile.SetInputFile(strFile))
			{
				m_strErrorMessage = UidFile.m_strErrorMessage + _T("(");
				m_strErrorMessage += UidFile.m_strFileName;
				m_strErrorMessage += _T(")");
				return false;
			}
			
			strUID = strTempL;
			strUID += UidFile.m_strCleanUID;
			strUID += strTempR;
		}
	}while(true);
	
	return bSuc;
}

bool CUidFile::GenerateFiles()
{
	int nDot = m_strFileName.ReverseFind(_T('.'));
	if(nDot != -1)
	{
		m_strOutputFile = m_strFileName.Left(nDot);
	}
	else
	{
		m_strOutputFile = m_strFileName;
	}

	m_strDefFile = m_strOutputFile + _T("_i");
	m_strOutputFile += _T(".");
	m_strDefFile += _T(".");

	switch(m_lang)
	{
	case lCSharp:
		m_strDefFile += _T("cs");
		m_strOutputFile += _T("cs");
		if(CreateDefFileCSharp())
		{
			CreateClientFileCSharp();
			nDot = m_strOutputFile.ReverseFind(_T('.'));
			m_strOutputFile.Insert(nDot, _T("Impl"));
			CreateServerPeerFileCSharp();
		}
		break;
	case lCpp:
		m_strOutputFile += _T("h");
		m_strDefFile += _T("h");
		if(CreateCommonDefFileH())
		{
			CreateClientHandlerFileH();
			nDot = m_strOutputFile.ReverseFind(_T('.'));
			m_strOutputFile.Insert(nDot, _T("Impl"));
			CreateServerPeerFileH();
		}
		break;
	case lVBNet:
		m_strOutputFile += _T("vb");
		m_strDefFile += _T("vb");
		if(CreateDefFileVBNet())
		{
			CreateClientFileVBNet();
			nDot = m_strOutputFile.ReverseFind(_T('.'));
			m_strOutputFile.Insert(nDot, _T("Impl"));
			CreateServerPeerFileVBNet();
		}
		break;
	case lCLI:
		m_strOutputFile += _T("h");
		m_strDefFile += _T("h");
		nDot = m_strDefFile.ReverseFind(_T('.'));
		m_strDefFile.Insert(nDot, _T("Cli"));
		if(CreateCommonDefFileH())
		{
			nDot = m_strOutputFile.ReverseFind(_T('.'));
			m_strOutputFile.Insert(nDot, _T("Cli"));
			CreateClientHandlerFileH();
			nDot = m_strOutputFile.ReverseFind(_T('.'));
			m_strOutputFile.Insert(nDot, _T("Impl"));
			CreateServerPeerFileH();
		}
		break;
	default:
		ATLASSERT(FALSE);
		break;
	}

	return true;
}

bool CUidFile::CreateServerPeerFileVBNet()
{
	int n;
	ULONG ulWrite;
	CString strDef;
	CString strTemp;
	strDef += _T("' **** including all of defines, service id(s) and request id(s) *****\n");
	strDef += _T("Imports System\nImports SocketProAdapter\nImports SocketProAdapter.ServerSide\nImports USOCKETLib 'you may need it for accessing various constants\n");
	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CString strSvsImp;
		CUIDService &Svs = m_aService[n];
		int j;
		int jAll = Svs.GetMethods().GetSize();
		strDef += _T("'server implementation for service ");
		strDef += Svs.GetName();
		strDef += _T("\n");
		
		strDef += _T("Public class ");
		strDef += Svs.GetName();
		if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
		{
			CString str;
			str.Format(_T("Peer\n\tInherits %s\n"), Svs.GetBaseSvs());
			strDef += str;
		}
		else
		{
			strDef += _T("Peer\n\tInherits CClientPeer\n");
		}
		
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("\tProtected Overrides Sub OnSwitchFrom(ByVal nServiceID As Integer)\n\t\t'initialize the object here\n\tEnd Sub\n\n");
			strDef += _T("\tProtected Overrides Sub OnReleaseResource(ByVal bClosing As Boolean, ByVal nInfo As Integer)\n\t\tIf bClosing Then\n\t\t\t'closing the socket with error code = nInfo\n\t\tElse\n\t\t\t'switch to a new service with the service id = nInfo\n\t\tEnd If\n\n\t\t'release all of your resources here as early as possible\n\tEnd Sub\n\n");
		}
		for(j=0; j<jAll; j++)
		{
			CMethod &method = Svs.GetMethods()[j];
			strDef += method.GetMethodForPeerVBNet();
			strDef += _T("\n");
		}
		
		int nSlows = Svs.GetCountOfSlowMethods();
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE || Svs.GetMethods().GetSize() > nSlows)
		{
			strDef += _T("\tProtected Overrides Sub OnFastRequestArrive(ByVal sRequestID As Short, ByVal nLen As Integer)\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			{
				strDef += _T("\t\tMyBase.OnFastRequestArrive(sRequestID, nLen)\n");
			}
			strDef += Svs.GetPeerSwitchVBNet(false);
			strDef += _T("\tEnd Sub\n\n");
		}

		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE || nSlows > 0)
		{
			strDef += _T("\tProtected Overrides Function OnSlowRequestArrive(ByVal sRequestID As Short, ByVal nLen As Integer) As Integer\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			{
				strDef += _T("\t\tMyBase.OnSlowRequestArrive(sRequestID, nLen)\n");
			}
			strDef += Svs.GetPeerSwitchVBNet(true);
			strDef += _T("\t\treturn 0\n");
			strDef += _T("\tEnd Function\n\n");
		}
		
	/*	if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("\tProtected Sub PushNullException()\n");
			strDef += _T("\t\tIf TransferServerException Then\n");
			strDef += _T("\t\t\tDim nRtn as Integer = 0\n\t\t\tm_UQueue.Push(nRtn) 'required by SocketProAdapter client side!!! \n\t\tEnd If\n\tEnd Sub\n");
		}*/

		strDef += _T("\nEnd Class\n\n");

/*		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		strSvsImp.Empty();
		if(LastSvs.GetName() == Svs.GetName())
		{
			strSvsImp = _T("Public class ");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Svs\n\tInherits CBaseService\n\tPublic Sub New()\n");
			strSvsImp += _T("\t\t'Using pool is good for reusing objects,\n");
			strSvsImp += _T("\t\t'especially when clients have to close socket connections repeatedly\n");
			strSvsImp += _T("\t\tm_bUsePool = True\n");
			strSvsImp += _T("\tEnd Sub\n\n");

			strSvsImp += _T("\t'SocketPro will call this function to create a ClientPeer on the fly if needed\n");
			strSvsImp += _T("\tProtected Overrides Function GetPeerSocket(ByVal hSocket As Integer) As CClientPeer\n");
			strSvsImp += _T("\t\t'Associate a peer object into this service\n");
			strSvsImp += _T("\t\t'Note that you must not delete the object but SocketProAdapter will take care it for you\n");
			strSvsImp += _T("\t\tReturn new ");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Peer()\n");
			strSvsImp += _T("\tEnd Function\n");
			strSvsImp += _T("End Class\n\n");
			strDef += strSvsImp;
		}*/
	}

	strDef += _T("public class CMySocketProServer\n\tInherits CSocketProServer\n");
	strDef += _T("\tProtected Overrides Function OnIsPermitted(ByVal hSocket As Integer, ByVal nSvsID As Integer) As Boolean\n\t\t'give permission to all\n");
	strDef += _T("\t\treturn true\n\tEnd Function\n\n");

	strDef += _T("\tProtected Overrides Sub OnAccept(ByVal hSocket as Integer, ByVal nError as Integer)\n\t\t'when a socket is initially established\n\tEnd Sub\n\n");
	strDef += _T("\tProtected Overrides Sub OnClose(ByVal hSocket as Integer, ByVal nError as Integer)\n\t\t'when a socket is closed\n\tEnd Sub\n\n");

	strDef += _T("\tPublic Sub Run()\n\t\tDo\n\t\t\t'try amIntegrated and amMixed yourself\n");
	strDef += _T("\t\t\tConfig.AuthenticationMethod = USOCKETLib.tagAuthenticationMethod.amOwn\n\n");
	strDef += _T("\t\t\tAskForEvents(tagEvent.eOnAccept + tagEvent.eOnClose + tagEvent.eOnIsPermitted) 'three common global events\n\n");
	strDef += _T("\t\t\t'add service(s) into SocketPro server\n");
	strDef += _T("\t\t\tAddService()\n\n\t\t\t'start listening socket\n\t\t\tIf Not StartSocketProServer(20901) Then\n");
	strDef += _T("\t\t\t\t'Can't start SocketPro server!\n\t\t\t\t'Check if the port 20901 is available, please.\n");
	strDef += _T("\t\t\t\t'Error code = CClientPeer.LastSocketError.\n\t\t\t\tExit Do\n\t\t\tEnd If\n");
	strDef += _T("\t\t\t'SocketPro successfully started at the port 20901!\n\n");
	strDef += _T("\t\t\t'start message pump. SocketPro requires it and runs at 100% non-blocking fashion\n");
	strDef += _T("\t\t\t'if a message already exist, don't call the following function\n\t\t\tStartMessagePump()\n\n");
	strDef += _T("\t\t\t'stop listening socket, and shutdown all of socket connections\n\t\t\tStopSocketProServer()\n");
	strDef += _T("\t\tLoop Until False\n\tEnd Sub\n\n");
	
	nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CUIDService &Svs = m_aService[n];
		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		if(LastSvs.GetName() == Svs.GetName())
		{
			strTemp.Format(_T("\tPrivate m_%s As CSocketProService(Of %sPeer) = new CSocketProService(Of %sPeer)()\n"), Svs.GetName(), Svs.GetName(), Svs.GetName());
			strDef += strTemp;
		}
	}
	
	int nD = 0;
	strDef += _T("\n\tPrivate Sub AddService()\n\t\tDim bSuc As Boolean\n");
	for(n=0; n<nSvs; n++)
	{
		int j;
		int jAll;
		CUIDService &Svs = m_aService[n];
		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		if(LastSvs.GetName() != Svs.GetName())
			continue;
		if(nD)
		{
			strDef += _T("\n");
		}
		nD++;
		strDef += _T("\t\t'No COM -- taNone; STA COM -- taApartment; and Free COM -- taFree\n");
		CUIDService RootSvs = FindRootService(Svs.GetName());
		strTemp.Format(_T("\t\tbSuc = m_%s.AddMe(%s.sid%s, 0, tagThreadApartment.taNone)\n"), Svs.GetName(), m_strDefClass, RootSvs.GetName());
		strDef += strTemp;
		strDef += _T("\t\t'If bSuc is false, very possibly you have two services with the same service id!\n\n");
		CSimpleArray<CMethod> aMethod = GetAllSlowMethods(Svs.GetName());
		jAll = aMethod.GetSize();
		for(j=0; j<jAll; j++)
		{
			CMethod &method = aMethod[j];
			if(method.IsSlow())
			{
				strTemp.Format(_T("\t\tbSuc = m_%s.AddSlowRequest(%s.id%s%s)\n"), Svs.GetName(), m_strDefClass, method.GetName(), method.GetServiceName());
				strDef += strTemp;
			}
		}
	}
	strDef += _T("\tEnd Sub\n");

	strDef += _T("End Class\n\n");

	::DeleteFile(m_strOutputFile);
	HANDLE hFile = ::CreateFile(m_strOutputFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::CreateServerPeerFileCSharp()
{
	int n;
	ULONG ulWrite;
	CString strDef;
	CString strTemp;
	strDef += _T("/* **** including all of defines, service id(s) and request id(s) ***** */\n");
	strDef += _T("using System;\nusing SocketProAdapter;\nusing SocketProAdapter.ServerSide;\nusing USOCKETLib; //you may need it for accessing various constants\n");
	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CString strSvsImp;
		CUIDService &Svs = m_aService[n];
		int j;
		int jAll = Svs.GetMethods().GetSize();
		strDef += _T("//server implementation for service ");
		strDef += Svs.GetName();
		strDef += _T("\n");
		
		strDef += _T("public class ");
		strDef += Svs.GetName();
		if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
		{
			CString str;
			str.Format(_T("Peer : %s\n{\n"), Svs.GetBaseSvs());
			strDef += str;
		}
		else
		{
			strDef += _T("Peer : CClientPeer\n{\n");
		}
		
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("\tprotected override void OnSwitchFrom(int nServiceID)\n\t{\n\t\t//initialize the object here\n\t}\n\n");
			strDef += _T("\tprotected override void OnReleaseResource(bool bClosing, int nInfo)\n\t{\n\t\tif(bClosing)\n\t\t{\n\t\t\t//closing the socket with error code = nInfo\n\t\t}\n\t\telse\n\t\t{\n\t\t\t//switch to a new service with the service id = nInfo\n\t\t}\n\n\t\t//release all of your resources here as early as possible\n\t}\n\n");
		}
		for(j=0; j<jAll; j++)
		{
			CMethod &method = Svs.GetMethods()[j];
			strDef += method.GetMethodForPeerCSharp();
			strDef += _T("\n");
		}
		int nSlows = Svs.GetCountOfSlowMethods();
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE || Svs.GetMethods().GetSize() > nSlows)
		{
			strDef += _T("\tprotected override void OnFastRequestArrive(short sRequestID, int nLen)\n\t{\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE && Svs.GetMethods().GetSize() > nSlows)
			{
				strDef += _T("\t\tbase.OnFastRequestArrive(sRequestID, nLen);\n");
			}
			strDef += Svs.GetPeerSwitchCSharp(false);
			strDef += _T("\t}\n\n");
		}
		
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE || nSlows > 0)
		{
			strDef += _T("\tprotected override int OnSlowRequestArrive(short sRequestID, int nLen)\n\t{\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE && nSlows > 0)
			{
				strDef += _T("\t\tbase.OnSlowRequestArrive(sRequestID, nLen);\n");
			}
			strDef += Svs.GetPeerSwitchCSharp(true);
			strDef += _T("\t\treturn 0;\n");
			strDef += _T("\t}\n\n");
		}
		
/*		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("\tprotected void PushNullException()\n");
			strDef += _T("\t{\n");
			strDef += _T("\t\tif(TransferServerException)\n");
			strDef += _T("\t\t{\n\t\t\tint nRtn = 0;\n\t\t\tm_UQueue.Push(nRtn); //required by SocketProAdapter client side!!! \n\t\t}\n\t}\n");
		}*/
		strDef += _T("}\n\n");

/*		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		strSvsImp.Empty();
		if(LastSvs.GetName() == Svs.GetName())
		{
			strSvsImp = _T("public class ");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Svs : CBaseService\n{\n\tpublic ");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Svs()\n\t{\n");
			strSvsImp += _T("\t\t//Using pool is good for reusing objects,\n");
			strSvsImp += _T("\t\t//especially when clients have to close socket connections repeatedly\n");
			strSvsImp += _T("\t\tm_bUsePool = true;\n");
			strSvsImp += _T("\t}\n\n");

			strSvsImp += _T("\t//SocketPro will call this function to create a ClientPeer on the fly if needed\n");
			strSvsImp += _T("\tprotected override CClientPeer GetPeerSocket(int hSocket)\n\t{\n");
			strSvsImp += _T("\t\t//Associate a peer object into this service\n");
			strSvsImp += _T("\t\t//Note that you must not delete the object but SocketProAdapter will take care it for you\n");
			strSvsImp += _T("\t\treturn new ");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Peer();\n");
			strSvsImp += _T("\t}\n");
			strSvsImp += _T("}\n\n");
			strDef += strSvsImp;
		}*/
	}

	strDef += _T("public class CMySocketProServer : CSocketProServer\n{\n");
	strDef += _T("\tprotected override bool OnIsPermitted(int hSocket, int nSvsID)\n\t{\n\t\t//give permission to all\n");
	strDef += _T("\t\treturn true;\n\t}\n\n");

	strDef += _T("\tprotected override void OnAccept(int hSocket, int nError)\n\t{\n\t\t//when a socket is initially established\n\t}\n\n");
	strDef += _T("\tprotected override void OnClose(int hSocket, int nError)\n\t{\n\t\t//when a socket is closed\n\t}\n\n");

	strDef += _T("\tpublic void Run()\n\t{\n\t\tdo\n\t\t{\n\t\t\t//try amIntegrated and amMixed yourself\n");
	strDef += _T("\t\t\tConfig.AuthenticationMethod = tagAuthenticationMethod.amOwn;\n\n\t\t\t//add service(s) into SocketPro server\n");
	strDef += _T("\t\t\tAskForEvents((int)tagEvent.eOnAccept + (int)tagEvent.eOnClose + (int)tagEvent.eOnIsPermitted); //three common global events\n\n");
	strDef += _T("\t\t\tAddService();\n\n\t\t\t//start listening socket\n\t\t\tif(!StartSocketProServer(20901))\n");
	strDef += _T("\t\t\t{\n\t\t\t\t//Can't start SocketPro server!\n\t\t\t\t//Check if the port 20901 is available, please.\n");
	strDef += _T("\t\t\t\t//Error code = CClientPeer.LastSocketError.\n\t\t\t\tbreak;\n\t\t\t}\n");
	strDef += _T("\t\t\t//SocketPro successfully started at the port 20901!\n\n");
	strDef += _T("\t\t\t//start message pump. SocketPro requires it and runs at 100% non-blocking fashion\n");
	strDef += _T("\t\t\t//if a message already exist, don't call the following function\n\t\t\tStartMessagePump();\n\n");
	strDef += _T("\t\t\t//stop listening socket, and shutdown all of socket connections\n\t\t\tStopSocketProServer();\n");
	strDef += _T("\t\t}while(false);\n\t}\n\n");
	
	nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CUIDService &Svs = m_aService[n];
		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		if(LastSvs.GetName() == Svs.GetName())
		{
			strTemp.Format(_T("\tprivate CSocketProService<%sPeer> m_%s = new CSocketProService<%sPeer>();\n"), Svs.GetName(), Svs.GetName(), Svs.GetName());
			strDef += strTemp;
		}
	}
	
	int nD = 0;
	strDef += _T("\n\tprivate void AddService()\n\t{\n\t\tbool bSuc;\n");
	for(n=0; n<nSvs; n++)
	{
		int j;
		int jAll;
		CUIDService &Svs = m_aService[n];
		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		if(LastSvs.GetName() != Svs.GetName())
			continue;
		nD++;
		if(nD)
		{
			strDef += _T("\n");
		}
		strDef += _T("\t\t//No COM -- taNone; STA COM -- taApartment; and Free COM -- taFree\n");
		CUIDService RootSvs = FindRootService(Svs.GetName());
		strTemp.Format(_T("\t\tbSuc = m_%s.AddMe(%s.sid%s, 0, tagThreadApartment.taNone);\n"), Svs.GetName(), m_strDefClass, RootSvs.GetName());
		strDef += strTemp;
		strDef += _T("\t\t//If bSuc is false, very possibly you have two services with the same service id!\n\n");
		CSimpleArray<CMethod> aMethod = GetAllSlowMethods(Svs.GetName());
		jAll = aMethod.GetSize();
		for(j=0; j<jAll; j++)
		{
			CMethod &method = aMethod[j];
			if(method.IsSlow())
			{
				strTemp.Format(_T("\t\tbSuc = m_%s.AddSlowRequest(%s.id%s%s);\n"), Svs.GetName(), m_strDefClass, method.GetName(), method.GetServiceName());
				strDef += strTemp;
			}
		}
	}
	strDef += _T("\t}\n");

	strDef += _T("}\n\n");

	::DeleteFile(m_strOutputFile);
	HANDLE hFile = ::CreateFile(m_strOutputFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

CUIDService CUidFile::FindLastDerived(LPCTSTR strSvsName)
{
	CUIDService SvsRtn;
	int n;
	int nSize = m_aService.GetSize();
	for(n=0; n<nSize; n++)
	{
		CUIDService &svs = m_aService[n];
		if(svs.GetName() == strSvsName || svs.GetBaseSvs() == SvsRtn.GetName())
		{
			SvsRtn = svs;
		}
	}
	return SvsRtn;
}

CUIDService CUidFile::FindRootService(LPCTSTR strSvsName)
{
	CUIDService SvsRtn;
	int n;
	int nSize = m_aService.GetSize();
	for(n=nSize-1; n>=0; n--)
	{
		CUIDService &Svs = m_aService[n];
		if(Svs.GetName() == strSvsName)
		{
			SvsRtn = Svs;
			strSvsName = Svs.GetBaseSvs();
		}
	}
	return SvsRtn;
}

CUIDService CUidFile::FindService(LPCTSTR strBaseSvsName)
{
	CUIDService SvsRtn;
	int n;
	int nSize = m_aService.GetSize();
	for(n=0; n<nSize; n++)
	{
		CUIDService &Svs = m_aService[n];
		if(Svs.GetName() == strBaseSvsName)
		{
			if(Svs.GetMethods().GetSize() != 0)
			{
				SvsRtn = Svs;
				break;
			}
			else
			{
				strBaseSvsName = Svs.GetBaseSvs();
			}
		}
	}
	return SvsRtn;
}

CSimpleArray<CMethod> CUidFile::GetAllSlowMethods(LPCTSTR strSvsName)
{
	CSimpleArray<CMethod> aMethod;
	int n;
	int nSize = m_aService.GetSize();
	for(n=nSize-1; n>=0; n--)
	{
		CUIDService &Svs = m_aService[n];
		if(Svs.GetName() == strSvsName)
		{
			int j;
			CSimpleArray<CMethod> aM = Svs.GetMethods();
			int jAll = aM.GetSize();
			for(j=0; j<jAll; j++)
			{
				CMethod &method = aM[j];
				if(method.IsSlow())
				{
					aMethod.Add(method);
				}
			}
			strSvsName = Svs.GetBaseSvs();
		}
	}
	return aMethod;
}

CString CUidFile::GetBaseClassName(bool bClient, LPCTSTR strMyClassName)
{
	CString str;
	int n;
	int nSize = m_aService.GetSize();
	for(n=0; n<nSize; n++)
	{
		CUIDService &Svs = m_aService[n];
		if(Svs.GetName() == strMyClassName)
		{
			str = Svs.GetBaseSvs();
			break;
		}
	}
	if(bClient)
	{
		if(str.GetLength() == 0)
		{
			str = _T("CRequestAsynHandlerBase");
		}
	}
	else
	{
		if(str.GetLength() == 0)
		{
			str = _T("CClientPeer");
		}
	}
	return str;
}

CString CUidFile::GetInitialRequestID(LPCTSTR strMyClassName)
{
	CString str;
	int n;
	int nSize = m_aService.GetSize();
	for(n=0; n<nSize; n++)
	{
		CUIDService &Svs = m_aService[n];
		if(Svs.GetName() == strMyClassName)
		{
			str = Svs.GetBaseSvs();
			if(str.GetLength() == 0)
			{
				switch(m_lang)
				{
				case lCpp:
					str = _T("odUserRequestIDMin + 0");
					break;
				case lCSharp:
					str = _T("(short)USOCKETLib.tagOtherDefine.odUserRequestIDMin + 0");
					break;
				case lVBNet:
					str = _T("USOCKETLib.tagOtherDefine.odUserRequestIDMin + 0");
					break;
				default:
					ATLASSERT(FALSE);
					break;
				}
			}
			else
			{
				CUIDService BaseSvs = FindService(str);
				int nSize = BaseSvs.GetMethods().GetSize();
				switch(m_lang)
				{
				case lCpp:
					if(nSize == 0)
					{
						str = _T("odUserRequestIDMin + 50");
					}
					else
					{
						CMethod &method = BaseSvs.GetMethods()[nSize - 1];
						str.Format(_T("id%s%s + 50"), method.GetName(), BaseSvs.GetName());
					}
					break;
				case lCSharp:
					if(nSize == 0)
					{
						str = _T("((short)USOCKETLib.tagOtherDefine.odUserRequestIDMin + 50");
					}
					else
					{
						CMethod &method = BaseSvs.GetMethods()[nSize - 1];
						str.Format(_T("id%s%s + 50"), method.GetName(), BaseSvs.GetName());
					}
					break;
				case lVBNet:
					if(nSize == 0)
					{
						str = _T("(USOCKETLib.tagOtherDefine.odUserRequestIDMin + 50");
					}
					else
					{
						CMethod &method = BaseSvs.GetMethods()[nSize - 1];
						str.Format(_T("id%s%s + 50"), method.GetName(), BaseSvs.GetName());
					}
					break;
				default:
					ATLASSERT(FALSE);
					break;
				}
			}
		}
	}
	return str;
}

bool CUidFile::CreateServerPeerFileH()
{
	int n;
	ULONG ulWrite;
	CString strInc;
	CString strNum;
	CString strDef(_T("#ifndef "));
	CString strTemp = m_strOutputFile;
	int nSlash = strTemp.ReverseFind(_T('\\'));
	if(nSlash != -1)
	{
		strTemp = strTemp.Mid(nSlash + 1);
	}
	strTemp.Replace(_T('.'), _T('_'));
	strTemp.MakeUpper();
	strTemp += _T("__");
	strTemp = _T("___SOCKETPRO_SERVICES_IMPL_") + strTemp;

	strDef += strTemp;
	strDef += _T("\n");
	
	strDef += _T("#define ");
	strDef += strTemp;
	strDef += _T("\n\n");
	
	strDef += _T("/* **** including all of defines, service id(s) and request id(s) ***** */\n");

	nSlash = m_strDefFile.ReverseFind(_T('\\'));
	strInc = m_strDefFile.Mid(nSlash + 1);
	strInc = _T("#include \"") + strInc;
	strInc += _T("\"");

	strDef += strInc;
	strDef += _T("\n\n");
	
	strDef += _T("#include \"sprowrap.h\"\nusing namespace SocketProAdapter;\nusing namespace SocketProAdapter::ServerSide;\n\n");

	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CString strSvsImp;
		CUIDService &Svs = m_aService[n];
		strDef += _T("//server implementation for service ");
		strDef += Svs.GetName();
		strDef += _T("\n");
		
		strDef += _T("class ");
		strDef += Svs.GetName();
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("Peer : public CClientPeer\n");
		}
		else
		{
			strDef += _T("Peer : public ");
			strDef += Svs.GetBaseSvs();
			strDef += _T("Peer\n");
		}
		strDef += _T("{\nprotected:\n");
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("\tvirtual void OnSwitchFrom(unsigned long ulServiceID)\n\t{\n\t\t//initialize the object here\n\t}\n\n");
			strDef += _T("\tvirtual void OnReleaseResource(bool bClosing, unsigned long ulInfo)\n\t{\n\t\tif(bClosing)\n\t\t{\n\t\t\t//closing the socket with error code = ulInfo\n\t\t}\n\t\telse\n\t\t{\n\t\t\t//switch to a new service with the service id = ulInfo\n\t\t}\n\n\t\t//release all of your resources here as early as possible\n\t}\n\n");
		}
		int j;
		int jAll = Svs.GetMethods().GetSize();
		for(j=0; j<jAll; j++)
		{
			CMethod &method = Svs.GetMethods()[j];
			strDef += method.GetMethodForPeerCpp();
			strDef += _T("\n");
		}

		int nCountOfSlows = Svs.GetCountOfSlowMethods();

		if(nCountOfSlows < Svs.GetMethods().GetSize() || Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("\tvirtual void OnFastRequestArrive(unsigned short usRequestID, unsigned long ulLen)\n\t{\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			{
				CString str;
				str.Format(_T("\t\t%sPeer::OnFastRequestArrive(usRequestID, ulLen);\n"), Svs.GetBaseSvs());
				strDef += str;
			}
			strDef += Svs.GetPeerSwitchCpp(false);
			strDef += _T("\t}\n\n");
		}
		
		if(nCountOfSlows != 0 || Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("\tvirtual long OnSlowRequestArrive(unsigned short usRequestID, unsigned long ulLen)\n\t{\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			{
				CString str;
				str.Format(_T("\t\t%sPeer::OnSlowRequestArrive(usRequestID, ulLen);\n"), Svs.GetBaseSvs());
				strDef += str;
			}
			strDef += Svs.GetPeerSwitchCpp(true);
			strDef += _T("\t\treturn S_OK;\n");
			strDef += _T("\t}\n\n");

/*			if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
			{
				strDef += _T("protected:\n");
				strDef += _T("\tvoid PushNullException()\n");
				strDef += _T("\t{\n");
				strDef += _T("\t\tif(TransferServerException())\n");
				strDef += _T("\t\t{\n\t\t\tHRESULT lRtn = S_OK;\n\t\t\tm_UQueue << lRtn; //required by SocketProAdapter client side!!! \n\t\t}\n\t}\n");
			}*/
			
		}

		strDef += _T("};\n\n");

/*		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		if(LastSvs.GetName() == Svs.GetName())
		{
			strSvsImp = _T("class ");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Svs : public CBaseService\n");
			strSvsImp += _T("{\npublic:\n\t");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Svs()\n\t{\n");
			strSvsImp += _T("\t\t//Using pool is good for reusing objects,\n");
			strSvsImp += _T("\t\t//especially when clients have to close socket connections repeatedly\n");
			strSvsImp += _T("\t\tm_bUsePool = true;\n");
			strSvsImp += _T("\t}\n\n");

			strSvsImp += _T("protected:\n\t//SocketPro will call this function to create a ClientPeer on the fly if needed\n");
			strSvsImp += _T("\tvirtual CClientPeer* GetPeerSocket(unsigned int hSocket)\n\t{\n");
			strSvsImp += _T("\t\t//Associate a peer object into this service\n");
			strSvsImp += _T("\t\t//Note that you must not delete the object but SocketProAdapter will take care it for you\n");
			strSvsImp += _T("\t\treturn new ");
			strSvsImp += Svs.GetName();
			strSvsImp += _T("Peer;\n");
			strSvsImp += _T("\t}\n");
			strSvsImp += _T("};\n\n");
			strDef += strSvsImp;
		}*/
	}
	
	strDef += _T("class CMySocketProServer : public CSocketProServer\n{\nprotected:\n");
	strDef += _T("\tvirtual bool OnIsPermitted(unsigned int hSocket, unsigned long ulSvsID)\n\t{\n\t\t//give permission to all\n");
	strDef += _T("\t\treturn true;\n\t}\n\n");

	strDef += _T("\tvirtual void OnAccept(unsigned int hSocket, int nError)\n\t{\n\t\t//when a socket is initially established\n\t}\n\n");
	strDef += _T("\tvirtual void OnClose(unsigned int hSocket, int nError)\n\t{\n\t\t//when a socket is closed\n\t}\n\n");

	strDef += _T("public:\n\tvoid Run()\n\t{\n\t\tdo\n\t\t{\n\t\t\t//try amIntegrated and amMixed yourself\n");
	strDef += _T("\t\t\tCSocketProServer::Config::SetAuthenticationMethod(amOwn);\n\n\t\t\t//add service(s) into SocketPro server\n");
	strDef += _T("\t\t\tAskForEvents(eOnAccept + eOnClose + eOnIsPermitted); //three common global events\n\n");
	strDef += _T("\t\t\tAddService();\n\n\t\t\t//start listening socket\n\t\t\tif(!StartSocketProServer(20901))\n");
	strDef += _T("\t\t\t{\n\t\t\t\t//Can't start SocketPro server!\n\t\t\t\t//Check if the port 20901 is available, please.\n");
	strDef += _T("\t\t\t\t//Error code = CClientPeer::GetLastSocketError().\n\t\t\t\tbreak;\n\t\t\t}\n");
	strDef += _T("\t\t\t//SocketPro successfully started at the port 20901!\n\n");
	strDef += _T("\t\t\t//start message pump. SocketPro requires it and runs at 100% non-blocking fashion\n");
	strDef += _T("\t\t\t//if a message already exist, don't call the following function\n\t\t\tStartMessagePump();\n\n");
	strDef += _T("\t\t\t//stop listening socket, and shutdown all of socket connections\n\t\t\tStopSocketProServer();\n");
	strDef += _T("\t\t}while(false);\n\t}\n\nprivate:\n");
	
	nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CUIDService &Svs = m_aService[n];
		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		if(LastSvs.GetName() == Svs.GetName())
		{
			strTemp.Format(_T("\tCSocketProService<%sPeer> m_%s;\n"), Svs.GetName(), Svs.GetName());
			strDef += strTemp;
		}
	}
	int nD = 0;
	strDef += _T("\nprivate:\n\tvoid AddService()\n\t{\n\t\tbool bSuc;\n");
	for(n=0; n<nSvs; n++)
	{
		int j;
		int jAll;
		CUIDService &Svs = m_aService[n];
		CUIDService LastSvs = FindLastDerived(Svs.GetName());
		if(LastSvs.GetName() != Svs.GetName())
			continue;
		nD++;
		if(nD)
		{
			strDef += _T("\n");
		}
		strDef += _T("\t\t//No COM -- taNone; STA COM -- taApartment; and Free COM -- taFree\n");
		
		CUIDService RootSvs = FindRootService(Svs.GetName());
		strTemp.Format(_T("\t\tbSuc = m_%s.AddMe(sid%s, 0, taNone);\n"), Svs.GetName(), RootSvs.GetName());
		strDef += strTemp;
		strDef += _T("\t\t//If bSuc is false, very possibly you have two services with the same service id!\n\n");
		CSimpleArray<CMethod> aMethod = GetAllSlowMethods(Svs.GetName());
		jAll = aMethod.GetSize();
		for(j=0; j<jAll; j++)
		{
			CMethod &method = aMethod[j];
			if(method.IsSlow())
			{
				strTemp.Format(_T("\t\tbSuc = m_%s.AddSlowRequest(id%s%s);\n"), Svs.GetName(), method.GetName(), method.GetServiceName());
				strDef += strTemp;
			}
		}
	}
	strDef += _T("\t}\n");

	strDef +=_T("};\n\n");

	strDef += _T("\n#endif");
	
	::DeleteFile(m_strOutputFile);
	HANDLE hFile = ::CreateFile(m_strOutputFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::CreateClientFileVBNet()
{
	int n;
	ULONG ulWrite;
	CString strTemp;
	CString strComment;
	CString strDefClass;
	int nSlash = m_strOutputFile.ReverseFind(_T('\\'));
	if(nSlash != -1)
	{
		strTemp = m_strOutputFile.Mid(nSlash + 1);
	}
	else
	{
		strTemp = m_strOutputFile;
	}
	int nDot = strTemp.Find(_T('.'));
	if(nDot != -1)
	{
		strTemp = strTemp.Left(nDot);
	}
	strDefClass.Format(_T("%sConst"), strTemp);
	m_strDefClass = strDefClass;

	CString strDef(_T("Imports System\nImports SocketProAdapter\nImports SocketProAdapter.ClientSide\nImports USOCKETLib\n\n"));
	
	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		if(n)
		{
			strDef += _T("\n");
		}
		CUIDService &Svs = m_aService[n];
		if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
		{
			strTemp.Format(_T("public class %s\n\tInherits %s\n"), Svs.GetName(), Svs.GetBaseSvs());
		}
		else
		{
			strTemp.Format(_T("public class %s\n\tInherits CRequestAsynHandlerBase\n"), Svs.GetName());
		}
		strDef += strTemp;
		int j;
		int jAll = Svs.GetMethods().GetSize();
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strTemp.Format(_T("\tPublic Overrides Function GetSvsID() as Integer\n\t\treturn %s.sid%s\n\tEnd Function\n\n"), strDefClass, Svs.GetName());
			strDef += strTemp;
		}

		for(j=0; j<jAll; j++)
		{
			CMethod &mb = Svs.GetMethods()[j];
			mb.SetDefClass(strDefClass);
			CString strM = mb.GetClientAsynInputMethodVBNet();
			strDef += strM;
			strDef += _T("\n\n");
		}
		
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE || Svs.GetMethods().GetSize() > 0)
		{
			//for processing returning results
			strDef += _T("\t'When a result comes from a remote SocketPro server, the below virtual function will be called.\n\t'We always process returning results inside the function.\n");
			strDef += _T("\tProtected Overrides Sub OnResultReturned(ByVal sRequestID As Short, ByVal UQueue As CUQueue)\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			{
				strDef += _T("\t\tMyBase.OnResultReturned(sRequestID, CUQueue)\n");
			}
			strDef += _T("\t\tIf SocketProServerException.HResult <> 0 then return 'exception transfered from SocketPro server\n");
			strDef += _T("\t\tSelect Case(sRequestID)\n");
			for(j = 0; j<jAll; j++)
			{
				CMethod &mb = Svs.GetMethods()[j];
				strDef += mb.GetRtnProcessing();
			}
			strDef += _T("\t\tCase Else\n\t\tEnd Select\n\tEnd Sub\n");
		}
		
		for(j = 0; j<jAll; j++)
		{
			CMethod &mb = Svs.GetMethods()[j];
			strDef += mb.GetSynFunVBNet();
			strDef += _T("\n");
		}

		strDef += _T("End Class\n");
	}
	
	::DeleteFile(m_strOutputFile);
	HANDLE hFile = ::CreateFile(m_strOutputFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::CreateClientFileCSharp()
{
	int n;
	ULONG ulWrite;
	CString strTemp;
	CString strComment;
	CString strDefClass;
	int nSlash = m_strOutputFile.ReverseFind(_T('\\'));
	if(nSlash != -1)
	{
		strTemp = m_strOutputFile.Mid(nSlash + 1);
	}
	else
	{
		strTemp = m_strOutputFile;
	}
	int nDot = strTemp.Find(_T('.'));
	if(nDot != -1)
	{
		strTemp = strTemp.Left(nDot);
	}
	strDefClass.Format(_T("%sConst"), strTemp);
	m_strDefClass = strDefClass;

	CString strDef(_T("\n\nusing System;\nusing SocketProAdapter;\nusing SocketProAdapter.ClientSide;\nusing USOCKETLib;\n\n"));
	
	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		if(n)
		{
			strDef += _T("\n");
		}
		CUIDService &Svs = m_aService[n];
		if(Svs.GetBaseSvs().GetLength() == 0)
			strTemp.Format(_T("public class %s : CRequestAsynHandlerBase\n{\n"), Svs.GetName());
		else
			strTemp.Format(_T("public class %s : %s\n{\n"), Svs.GetName(), Svs.GetBaseSvs());
		strDef += strTemp;
		
		if(Svs.GetBaseSvs().GetLength() == 0)
		{
			strTemp.Format(_T("\tpublic override int GetSvsID()\n\t{\n\t\treturn %s.sid%s;\n\t}\n\n"), strDefClass, Svs.GetName());
			strDef += strTemp;
		}
		
		int j;
		int jAll = Svs.GetMethods().GetSize();
		for(j=0; j<jAll; j++)
		{
			CMethod &mb = Svs.GetMethods()[j];
			mb.SetDefClass(strDefClass);
			CString strM = mb.GetClientAsynInputMethodCSharp();
			strDef += _T("\t");
			strDef += strM;
			strDef += _T("\n\n");
		}
		
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE || Svs.GetMethods().GetSize() > 0)
		{
			//for processing returning results
			strDef += _T("\t//When a result comes from a remote SocketPro server, the below virtual function will be called.\n\t//We always process returning results inside the function.\n");
			strDef += _T("\tprotected override void OnResultReturned(short sRequestID, CUQueue UQueue)\n\t{\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			{
				strDef += _T("\t\tbase.OnResultReturned(sRequestID, UQueue);\n");
			}
			strDef += _T("\t\tif(SocketProServerException.HResult != 0) return; //exception transfered from SocketPro server\n");
			strDef += _T("\t\tswitch(sRequestID)\n\t\t{\n");
			for(j = 0; j<jAll; j++)
			{
				CMethod &mb = Svs.GetMethods()[j];
				strDef += mb.GetRtnProcessing();
			}
			strDef += _T("\t\tdefault:\n\t\t\tbreak;\n\t\t}\n\t}\n");
		}
		
		for(j = 0; j<jAll; j++)
		{
			if(j)
				strDef += _T("\n");
			CMethod &mb = Svs.GetMethods()[j];
			strDef += mb.GetSynFunCSharp();
		}
		strDef += _T("}\n");
	}
	

	::DeleteFile(m_strOutputFile);
	HANDLE hFile = ::CreateFile(m_strOutputFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::CreateClientHandlerFileH()
{
	int n;
	ULONG ulWrite;
	CString strInc;
	CString strNum;
	CString strDef(_T("#ifndef "));
	CString strTemp = m_strOutputFile;
	int nSlash = strTemp.ReverseFind(_T('\\'));
	if(nSlash != -1)
	{
		strTemp = strTemp.Mid(nSlash + 1);
	}
	strTemp.Replace(_T('.'), _T('_'));
	strTemp.MakeUpper();
	strTemp += _T("__");
	strTemp = _T("___SOCKETPRO_CLIENT_HANDLER_") + strTemp;

	strDef += strTemp;
	strDef += _T("\n");
	
	strDef += _T("#define ");
	strDef += strTemp;
	strDef += _T("\n\n");

	strDef += _T("#include \"sprowrap.h\"\nusing namespace SocketProAdapter;\nusing namespace SocketProAdapter::ClientSide;\n\n");

	strDef += _T("/* **** including all of defines, service id(s) and request id(s) ***** */\n");

	nSlash = m_strDefFile.ReverseFind(_T('\\'));
	strInc = m_strDefFile.Mid(nSlash + 1);
	strInc = _T("#include \"") + strInc;
	strInc += _T("\"");

	strDef += strInc;
	strDef += _T("\n\n");
	
	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CUIDService &Svs = m_aService[n];
		int j;
		int jAll = Svs.GetMethods().GetSize();
		strDef += _T("//client handler for service ");
		strDef += Svs.GetName();
		strDef += _T("\n");
		
		strDef += _T("class ");
		strDef += Svs.GetName();
		if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T(" : public ");
			strDef += Svs.GetBaseSvs();
			strDef += _T("\n");
		}
		else
		{
			strDef += _T(" : public CRequestAsynHandlerBase\n");
		}
		strDef += _T("{\n");
		
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("public:\n");
			strDef += _T("\tvirtual unsigned long GetSvsID()\n");
			strDef += _T("\t{\n");
			strDef += _T("\t\treturn sid");
			strDef += Svs.GetName();
			strDef += _T(";\n\t}\n\n");
		}
		if(jAll > 0 || Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("protected:\n");
		}

		for(j = 0; j<jAll; j++)
		{
			CMethod &mb = Svs.GetMethods()[j];
			CString strM = mb.GetClientAsynInputMethodCpp();
			strDef += _T("\t");
			strDef += strM;
			strDef += _T("\n\n");
		}
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE || Svs.GetMethods().GetSize() > 0)
		{
			//for processing returning results
			strDef += _T("\t//When a result comes from a remote SocketPro server, the below virtual function will be called.\n\t//We always process returning results inside the function.\n");
			strDef += _T("\tvirtual void OnResultReturned(unsigned short usRequestID, CUQueue &UQueue)\n\t{\n");
			if(Svs.GetSvsID() == SERVICE_ID_NOT_AVAILABLE)
			{
				CString str;
				str.Format(_T("\t\t%s::OnResultReturned(usRequestID, UQueue);\n"), Svs.GetBaseSvs());
				strDef += str;
			}
			strDef += _T("\t\tif(m_err.m_hr != S_OK) return; //exception transfered from SocketPro server\n");
			strDef += _T("\t\tswitch(usRequestID)\n\t\t{\n");
			for(j = 0; j<jAll; j++)
			{
				CMethod &mb = Svs.GetMethods()[j];
				strDef += mb.GetRtnProcessing();
			}
			strDef += _T("\t\tdefault:\n\t\t\tbreak;\n\t\t}\n\t}\n");
			strDef += _T("\npublic:\n");
		}
		
		for(j = 0; j<jAll; j++)
		{
			if(j)
			{
				strDef += _T("\n");
			}
			CMethod &mb = Svs.GetMethods()[j];
			strDef += mb.GetSynFunCpp();
		}

		strDef += _T("};\n");
	}
	strDef += _T("#endif\n");
	
	::DeleteFile(m_strOutputFile);
	HANDLE hFile = ::CreateFile(m_strOutputFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strOutputFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::CreateCommonDefFileH()
{
	int n;
	ULONG ulWrite;
	CString strNum;
	CString strDef(_T("#ifndef "));
	CString strTemp = m_strDefFile;
	int nSlash = strTemp.ReverseFind(_T('\\'));
	if(nSlash != -1)
	{
		strTemp = strTemp.Mid(nSlash + 1);
	}
	strTemp.Replace(_T('.'), _T('_'));
	strTemp.MakeUpper();
	strTemp += _T("__");
	strTemp = _T("___SOCKETPRO_DEFINES_") + strTemp;

	strDef += strTemp;
	
	strDef += _T("\n#define ");
	strDef += strTemp;
	strDef += _T("\n\n");

	int nSvs = m_aService.GetSize();
	for(n=0; n<nSvs; n++)
	{
		CUIDService &Svs = m_aService[n];
		if(Svs.GetSvsID() != SERVICE_ID_NOT_AVAILABLE)
		{
			strDef += _T("//defines for service ");
			strDef += Svs.GetName();
			strDef += _T("\n#define ");
			strDef += _T("sid");
			strDef += Svs.GetName();
			strDef += _T("\t(odUserServiceIDMin + ");
			strNum.Format(_T("%d"), Svs.GetSvsID());
			strDef += strNum;
			strDef += _T(")\n\n");
		}
		int j;
		CString strPrev = GetInitialRequestID(Svs.GetName());
		int jAll = Svs.GetMethods().GetSize();
		for(j = 0; j<jAll; j++)
		{
			CMethod &mb = Svs.GetMethods()[j];
			strDef += _T("#define ");
			strDef += _T("id");
			strDef += mb.GetName();
			strDef += Svs.GetName();
			strDef += _T("\t(");
			strDef += strPrev;
			if(j == 0)
			{
				strDef += _T(")\n");
			}
			else
			{
				strDef += _T(" + 1)\n");
			}
			strPrev.Format(_T("id%s%s"), mb.GetName(), Svs.GetName());
		}
		strDef += _T("\n\n");
	}

	strDef += _T("\n#endif");
	
	::DeleteFile(m_strDefFile);
	HANDLE hFile = ::CreateFile(m_strDefFile, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Error in opening the file %s"), m_strDefFile);
		return false;
	}

	::WriteFile(hFile, (LPVOID)LPCTSTR(strDef), strDef.GetLength(), &ulWrite, NULL);
	::CloseHandle(hFile);
	return true;
}

bool CUidFile::SetInputFile(LPCTSTR strInputFile)
{
	CString strTemp;
	CString strLeft;
	int nIndex2;
	CUIDService	UIDService;
	UIDService.SetLanguage(m_lang);
	m_aService.RemoveAll();
	bool bSuc = true;
	HANDLE hFile = ::CreateFile(strInputFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		m_strErrorMessage.Format(_T("Can't open the file %s"), strInputFile);
		return false;
	}

	ULONG lSize = ::GetFileSize(hFile, NULL);
	TCHAR *strDescription = new TCHAR[lSize + 1];
	::ReadFile(hFile, strDescription, lSize, &lSize, NULL);
	strDescription[lSize] = 0;

	CString strAll = strDescription;
	CString strService;

	strAll.Replace(cTab, cBlank);
	strAll.Replace(cLine, cBlank);
	
	//remove //
	int nIndex = strAll.Find(_T("//"));
	while(nIndex != -1)
	{
		nIndex2 = strAll.Find(cReturn, nIndex + 2);
		if(nIndex2 == -1)
		{
			strAll = strAll.Left(nIndex);
		}
		else
		{
			strTemp = strAll.Left(nIndex);
			strAll = strAll.Mid(nIndex2);
			strAll = strTemp + strAll;
		}
		nIndex = strAll.Find(_T("//")); 
	}
	
	strAll.Replace(cReturn, cBlank);

	//remove all /* and */
	do
	{
		nIndex = strAll.Find(_T("/*"));
		nIndex2 = strAll.Find(_T("*/"), nIndex + 2);
		if(nIndex == -1 && nIndex2 == -1)
		{
			break;
		}
		else if(nIndex2 > nIndex + 2)
		{
			strLeft = strAll.Left(nIndex);
			strAll = strAll.Mid(nIndex2 + 2); 
			strAll = strLeft + _T(" ") + strAll;
		}
		else
		{
			m_strErrorMessage = _T("Invalid service decalaration");
			delete []strDescription;
			::CloseHandle(hFile);
			return false;
			break;
		}
	}while(true);

	m_strCleanUID = strAll;

	if(!HandleIncludeFiles(strAll))
	{
		return false;
	}

	int nNext = strAll.Find(_T('}'));
	nNext += 1;
	while(nNext > 0)
	{
		strService = strAll.Left(nNext);
		strAll = strAll.Mid(nNext);

		if(UIDService.SetDeclaration(strService))
		{
			if(ExistingService(UIDService.GetName()))
			{
				m_strErrorMessage = _T("Two services can't have the same name");
				bSuc = false;
				break;
			}
			else if(ExistingService(UIDService.GetSvsID()))
			{
				m_strErrorMessage = _T("Two services can't have the same service id");
				bSuc = false;
				break;
			}
			else
			{
				m_aService.Add(UIDService);
			}
		}
		else
		{
			m_strErrorMessage = UIDService.GetErrorMessage();
			bSuc = false;
			break;
		}
		nNext = strAll.Find(_T('}'));
		nNext += 1;
	}

	delete []strDescription;
	::CloseHandle(hFile);
	if(bSuc)
	{
		m_strFileName = strInputFile;
	}
	return bSuc;
}
