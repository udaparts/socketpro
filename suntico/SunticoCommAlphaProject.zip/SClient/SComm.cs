

using System;
using SocketProAdapter;
using SocketProAdapter.ClientSide;
using USOCKETLib;
using SunticoClient;
using System.Collections.Generic;

namespace SunticoClient
{
    class CSunticoAsyncHandler : SocketProAdapter.ClientSide.CAsyncAdohandler
    {
        public CSunticoAsyncHandler()
            : base(SunticoConst.sidSunticoComm)
        {
            m_lstAsyncHandlers.Add(this);
        }

        public CSunticoAsyncHandler(CClientSocket cs)
            : base(SunticoConst.sidSunticoComm, cs)
        {
            m_lstAsyncHandlers.Add(this);
        }

        public CSunticoAsyncHandler(CClientSocket cs, IAsyncResultsHandler DefaultAsyncResultsHandler)
            : base(SunticoConst.sidSunticoComm, cs, DefaultAsyncResultsHandler)
        {
            m_lstAsyncHandlers.Add(this);
        }

        internal CSunticoClientPoint m_CustomerPoint;
        internal static List<CSunticoAsyncHandler> m_lstAsyncHandlers;

        internal void SetChat()
        {
            GetAttachedClientSocket().m_OnBaseRequestProcessed += delegate(short sRequestID)
            {
                switch (sRequestID)
                {
                    case (short)USOCKETLib.tagChatRequestID.idEnter:
                    case (short)USOCKETLib.tagChatRequestID.idXEnter:
                        //{
                        //    int nGroup;
                        //    int nPort;
                        //    int nSvsID;
                        //    string strUID;
                        //    USOCKETLib.USocketClass socket = GetAttachedClientSocket().GetUSocket();
                        //    string strIPAddr = socket.GetInfo(0, out nGroup, out strUID, out nSvsID, out nPort);
                        //    strIPAddr = null;
                        //}
                        break;
                    case (short)USOCKETLib.tagChatRequestID.idExit:
                        break;
                    case (short)USOCKETLib.tagChatRequestID.idSpeak:
                    case (short)USOCKETLib.tagChatRequestID.idXSpeak:
                        {
                            int nGroup;
                            int nPort;
                            int nSvsID;
                            string strUID;
                            USOCKETLib.USocketClass socket = GetAttachedClientSocket().GetUSocket();
                            string strMsg = (string)socket.Message;
                            string strIPAddr = socket.GetInfo(0, out nGroup, out strUID, out nSvsID, out nPort);
                            m_CustomerPoint.m_msgCloud.OnCloudGeneralMessage(strMsg, nGroup, nSvsID);
                        }
                        break;
                    default:
                        break;
                }
            };
        }

        private SunticoClient.DRequestCompletedAtCloud m_pDataReader = null;
        internal bool Send(SunticoClient.DRequestCompletedAtCloud p, System.Data.IDataReader dr)
        {
            m_pDataReader = p;
            if(dr != null)
                return Send(dr);
            return true;
        }

        private SunticoClient.DRequestCompletedAtCloud m_pDataTable = null;
        internal bool Send(SunticoClient.DRequestCompletedAtCloud p, System.Data.DataTable dt)
        {
            m_pDataTable = p;
            if (dt != null)
                return Send(dt);
            return true;
        }

        private SunticoClient.DRequestCompletedAtCloud m_pDataSet = null;
        internal bool Send(SunticoClient.DRequestCompletedAtCloud p, System.Data.DataSet ds)
        {
            m_pDataSet = p;
            if (ds != null)
                return Send(ds);
            return true;
        }

        internal void Send(string str, SunticoClient.StringObjectType sot, SunticoClient.DRequestCompletedAtCloud rp)
        {
            bool b = SendRequest(SunticoClient.SunticoConst.idClientSendString, str, (int)sot, delegate(CAsyncResult ar)
                {
                    if (rp != null)
                        rp.Invoke();
                }
           );
        }

        protected override void OnResultReturned(short sRequestID, CUQueue UQueue)
        {
            int len = UQueue.GetSize();
            CCloudMessage cm = (CCloudMessage)m_CustomerPoint.CloudMessage;


            switch (sRequestID)
            {
                case SunticoClient.SunticoConst.idClientConfirmation:
                    break;
                case SunticoClient.SunticoConst.idSunticoBeginTrans:
                    {
                        long Clue;
                        UQueue.Pop(out Clue);
                        cm.OnCloudBeginTrans(Clue);
                    }
                    break;
                case SunticoClient.SunticoConst.idSunticoCommit:
                    {
                        long Clue;
                        UQueue.Pop(out Clue);
                        long res = cm.OnCloudEndTrans(Clue);
                        
                        //reply a confirm message so that Suntico server knows that a client has processed objects safely
                        SendRequest(SunticoClient.SunticoConst.idClientConfirmation, res);
                    }
                    break;
                case CAsyncAdoSerializationHelper.idEndDataTable:
                    base.OnResultReturned(sRequestID, UQueue);
                    if (len > 0)
                        cm.OnCloudDataTable(m_AdoSerialier.CurrentDataTable);
                    else if (m_pDataTable != null)
                        m_pDataTable.Invoke();
                    break;
                case CAsyncAdoSerializationHelper.idEndDataReader:
                    base.OnResultReturned(sRequestID, UQueue);
                    if (len > 0)
                        cm.OnCloudDataReader(m_AdoSerialier.CurrentDataTable);
                    else if (m_pDataReader != null)
                        m_pDataTable.Invoke();
                    break;
                case CAsyncAdoSerializationHelper.idEndDataSet:
                    base.OnResultReturned(sRequestID, UQueue);
                    if (len > 0)
                        cm.OnCloudDataSet(m_AdoSerialier.CurrentDataSet);
                    else if (m_pDataSet != null)
                        m_pDataTable.Invoke();
                    break; 
                case SunticoClient.SunticoConst.idSunticoSendObject:
                    {
                        long Clue;
                        UQueue.Pop(out Clue);
                        cm.OnCloudObjectMessage(Clue, UQueue);
                    }
                    break;
                case SunticoClient.SunticoConst.idSunticoSendString:
                    {
                        int objectType;
                        string str;
                        UQueue.Pop(out objectType);
                        UQueue.Load(out str);
                        cm.OnCloudStringObject((StringObjectType)objectType, str);
                    }
                    break;
                default:
                    base.OnResultReturned(sRequestID, UQueue);
                    break;
            }
        }
    }
}
