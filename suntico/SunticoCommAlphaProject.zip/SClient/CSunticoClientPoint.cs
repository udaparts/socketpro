﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace SunticoClient
{
    public class CSunticoClientPoint : IDisposable
    {
        internal CCloudMessage m_msgCloud;
        private CClientMessage m_msgCustomer;

        private List<CCloudConnectionContext> CloudServers = new List<CCloudConnectionContext>();

        #region IDisposable Members
        public void Dispose()
        {
            m_ClientLoadBalancer.ShutdownPool();
        }
        #endregion

        public ICloudMessage CloudMessage 
        { 
            get { 
                return m_msgCloud; 
            } 
        }

        public ICustomerMessage CustomerMessage
        {
            get
            {
                return m_msgCustomer;
            }
        }

        public event DChannelsClosed ChannelsClosed;
        public event DFailover Failover;

        public CCloudConnectionContext[] SunticoCloudServers
        {
            get
            {
                return CloudServers.ToArray();
            }
        }

        public CSunticoClientPoint(CCloudConnectionContext []clouds)
        {
            CSunticoAsyncHandler.m_lstAsyncHandlers = new List<CSunticoAsyncHandler>();

            if (clouds == null || clouds.Length == 0)
                throw new InvalidOperationException("One cloud server required at least");
            foreach (CCloudConnectionContext s in clouds)
            {
                CloudServers.Add(s);
            }
            m_ClientLoadBalancer.m_ClientPoint = this;
            m_msgCustomer = new CClientMessage(this);
            m_ClientLoadBalancer.m_Client = m_msgCustomer;
            m_msgCloud = new CCloudMessage(this);
        }

        internal bool OnFailover(SocketProAdapter.IJobContext JobContext)
        {
            if (Failover != null)
                Failover.Invoke();
            return true;
        }

        internal void OnAllSocketsDisconnected()
        {
            if (ChannelsClosed != null)
                ChannelsClosed.Invoke();
        }

        private void InitialClientLoadBalancer()
        {
            if (CloudServers == null || CloudServers.Count == 0)
                throw new InvalidOperationException("Oops! You forget setting remote Suntico cloud server");

            SocketProAdapter.CConnectionContext[] ccs = new SocketProAdapter.CConnectionContext[CloudServers.Count];

            int n, count = CloudServers.Count;

            for (n = 0; n < count; ++n)
            {
                SocketProAdapter.CConnectionContext cc = new SocketProAdapter.CConnectionContext()
                {
                    m_strUID = CloudServers[n].UserId,
                    m_strPassword = CloudServers[n].Password,
                    m_strHost = CloudServers[n].IpAddress,
                    m_nPort = CloudServers[n].Port,
                    m_EncrytionMethod = CloudServers[n].Secure ? USOCKETLib.tagEncryptionMethod.MSTLSv1 : USOCKETLib.tagEncryptionMethod.NoEncryption,
                    m_bZip = CloudServers[n].Zip
                };
                ccs[n] = cc;
            }
            byte ChannelsPerThread;
            byte threads;
            int cores = System.Environment.ProcessorCount;
            if (cores >= CloudServers.Count)
            {
                ChannelsPerThread = 1;
                threads = (byte)CloudServers.Count;
            }
            else
            {
                bool r = ((count % cores) > 0);
                ChannelsPerThread = (byte)(count / cores + (r ? 1 : 0));
                threads = 0; //use the number of cores
            }
            bool ok = m_ClientLoadBalancer.StartSocketPool(ccs, ChannelsPerThread, threads);
            if (ok)
            {
                List<CSunticoAsyncHandler> Handlers = new List<CSunticoAsyncHandler>();
                byte b = 0;
                foreach (CSunticoAsyncHandler sah in CSunticoAsyncHandler.m_lstAsyncHandlers)
                {
                    SocketProAdapter.ClientSide.CClientSocket cs = sah.GetAttachedClientSocket();
                    if (cs == null)
                        continue;
                    sah.m_CustomerPoint = this;
                    sah.SetChat();
                    Handlers.Add(sah);
                    if (cs.IsConnected())
                    {
                        CloudServers[b].m_Connected = true;
                        CloudServers[b].m_hSocket = cs.Socket;

                        cs.m_OnClosing += delegate(int socket, int errCode)
                        {
                            foreach (CCloudConnectionContext c in CloudServers)
                            {
                                if (socket == c.m_hSocket)
                                {
                                    c.m_Connected = false;
                                    break;
                                }
                            }
                        };

                        //the following call will lead to dead lock
                        //sah.SendRequest(SunticoClient.SunticoConst.idClientFakeSlow);
                        cs.GetUSocket().SendRequestEx((ushort)SunticoClient.SunticoConst.idClientFakeSlow, 1, ref b);
                        ok = cs.WaitAll();
                    }
                    else
                        CloudServers[b].m_Connected = false;
                    CloudServers[b].m_Backup = (b > 0);
                    ++b;
                }
                CSunticoAsyncHandler.m_lstAsyncHandlers = Handlers;
            }
        }

        public SunticoClient.ConnectionStatus Start()
        {
           if(ConnectionStatus == SunticoClient.ConnectionStatus.Opened)
               return SunticoClient.ConnectionStatus.Opened;
            InitialClientLoadBalancer();
            return ConnectionStatus;
        }

        public void Close()
        {
            m_ClientLoadBalancer.ShutdownPool();
        }

        /// <summary>
        /// Connection status
        /// </summary>
        public SunticoClient.ConnectionStatus ConnectionStatus
        {
            get
            {
                return (m_ClientLoadBalancer.GetUSocketPool().ConnectedSocketsEx > 0) ? SunticoClient.ConnectionStatus.Opened : SunticoClient.ConnectionStatus.Closed;
            }
        }

        /// <summary>
        /// The number of channels to one or more Sunctico servers. The first one is master channel, and all of others are backups.
        /// </summary>
        public int Channels
        {
            get
            {
                return m_ClientLoadBalancer.GetUSocketPool().ConnectedSocketsEx;
            }
        }

        /// <summary>
        /// The number of fails
        /// </summary>
        public int Fails
        {
            get
            {
                return m_ClientLoadBalancer.Fails;
            }
        }

        internal CSunticoClientLoadBalancer m_ClientLoadBalancer = new CSunticoClientLoadBalancer();
    }
}
