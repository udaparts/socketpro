﻿using System;
using SunticoServer;
using SocketProAdapter.ServerSide;


namespace SServerTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            CSunticoServer MySocketProServer = new CSunticoServer();
            bool ok = MySocketProServer.Run(20901);
            if (!ok)
                Console.WriteLine("Error code = " + CSocketProServer.LastSocketError.ToString());
            Console.WriteLine("Input a line quit to close the application ......");
            CloudClientSharedForUnitTest.TestStructure ts = new CloudClientSharedForUnitTest.TestStructure()
            {
                n = 10,
                str = "ServerTest"
            };

            do
            {
                SunticoServer.CSunticoPeer p = MySocketProServer.SeekPeer("SocketPro", SunticoShare.SCommConst.sidSunticoComm);
                if (p != null)
                {
                    do
                    {
                        ok = p.SendBeginTrans(1);
                        if (!ok)
                        {
                            Console.WriteLine("Client is offline");
                            break;
                        }
                        p.SendStringObject(SunticoShare.StringObjectType.Json, "{\"testc\" : 1}");
                        p.SendGenericObject(1, ts);
                        ok = p.SendEndTrans(delegate(long confirm)
                            {
                                Console.WriteLine("Confirmed from client with number = " + confirm.ToString());
                            }, 
                        2);
                        if (!ok)
                        {
                            Console.WriteLine("Client is offline");
                            break;
                        }

                        long Confirm = 0;
                        ok = p.WaitConfirmation(ref Confirm, 3000);
                        if (!ok)
                        {
                            Console.WriteLine("Timeout now!");
                            break;
                        }
                    } while (false);
                }
                else
                    Console.WriteLine("User SocketPro not found");
                ts.n++;
                str = Console.ReadLine();
                ts.str = str;
            } while (str != "quit");
            MySocketProServer.StopSocketProServer(); //or MySocketProServer.Dispose();
        }
    }
}
