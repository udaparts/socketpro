﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace SunticoClient
{
    public class CSunticoClientPoint : IDisposable
    {
        private CCloudMessage m_msgCloud;
        private CClientMessage m_msgCustomer;

        private List<CCloudConnectionContext> CloudServers = new List<CCloudConnectionContext>();

        #region IDisposable Members
        public void Dispose()
        {
            m_ClientLoadBalancer.ShutdownPool();
        }
        #endregion

        public ICloudMessage CloudMessage 
        { 
            get { 
                return m_msgCloud; 
            } 
        }

        public ICustomerMessage CustomerMessage
        {
            get
            {
                return m_msgCustomer;
            }
        }

        public event DChannelsClosed ChannelsClosed;
        public event DFailover Failover;

        public CSunticoClientPoint(CCloudConnectionContext []clouds)
        {
            CSunticoAsyncHandler.m_lstAsyncHandlers = new List<CSunticoAsyncHandler>();

            if (clouds == null || clouds.Length == 0)
                throw new InvalidOperationException("One cloud server required at least");
            foreach (CCloudConnectionContext s in clouds)
            {
                CloudServers.Add(s);
            }
            m_ClientLoadBalancer.m_ClientPoint = this;
            m_msgCustomer = new CClientMessage(this);
            m_ClientLoadBalancer.m_Client = m_msgCustomer;
            m_msgCloud = new CCloudMessage(this);
        }

        internal bool OnFailover(SocketProAdapter.IJobContext JobContext)
        {
            if (Failover != null)
                Failover.Invoke(this);
            return true;
        }

        internal void OnAllSocketsDisconnected()
        {
            if (ChannelsClosed != null)
                ChannelsClosed.Invoke(this);
        }

        private void InitialClientLoadBalancer()
        {
            if (CloudServers == null || CloudServers.Count == 0)
                throw new InvalidOperationException("Oops! You forget setting remote Suntico cloud server");

            SocketProAdapter.CConnectionContext[] ccs = new SocketProAdapter.CConnectionContext[CloudServers.Count];

            int n, count = CloudServers.Count;

            for (n = 0; n < count; ++n)
            {
                SocketProAdapter.CConnectionContext cc = new SocketProAdapter.CConnectionContext()
                {
                    m_strUID = CloudServers[n].UserId,
                    m_strPassword = CloudServers[n].Password,
                    m_strHost = CloudServers[n].IpAddress,
                    m_nPort = CloudServers[n].Port,
                    m_EncrytionMethod = CloudServers[n].Secure ? USOCKETLib.tagEncryptionMethod.MSTLSv1 : USOCKETLib.tagEncryptionMethod.NoEncryption,
                    m_bZip = CloudServers[n].Zip
                };
                ccs[n] = cc;
            }

            int cores = System.Environment.ProcessorCount;
            byte ChannelsPerThread = (byte)(1 + count / cores);
            bool  ok = m_ClientLoadBalancer.StartSocketPool(ccs, ChannelsPerThread);
            if (ok)
            {
                List<CSunticoAsyncHandler> Handlers = new List<CSunticoAsyncHandler>();
                foreach (CSunticoAsyncHandler obj in CSunticoAsyncHandler.m_lstAsyncHandlers)
                {
                    SocketProAdapter.ClientSide.CClientSocket cs = obj.GetAttachedClientSocket();
                    if (cs == null)
                        continue;
                    if (cs.IsConnected())
                    {
                        obj.m_CustomerPoint = this;
                        Handlers.Add(obj);
                    }
                }

                CSunticoAsyncHandler.m_lstAsyncHandlers = Handlers;
            }
        }

        public SunticoShare.ConnectionStatus Start()
        {
           if(ConnectionStatus == SunticoShare.ConnectionStatus.Opened)
               return SunticoShare.ConnectionStatus.Opened;
            InitialClientLoadBalancer();
            return ConnectionStatus;
        }

        public void Close()
        {
            m_ClientLoadBalancer.ShutdownPool();
        }

        /// <summary>
        /// Connection status
        /// </summary>
        public SunticoShare.ConnectionStatus ConnectionStatus
        {
            get
            {
                return (m_ClientLoadBalancer.GetUSocketPool().ConnectedSocketsEx > 0) ? SunticoShare.ConnectionStatus.Opened : SunticoShare.ConnectionStatus.Closed;
            }
        }

        /// <summary>
        /// The number of channels to one or more Sunctico servers. The first one is master channel, and all of others are backups.
        /// </summary>
        public int Channels
        {
            get
            {
                return m_ClientLoadBalancer.GetUSocketPool().ConnectedSocketsEx;
            }
        }

        /// <summary>
        /// The number of fails
        /// </summary>
        public int Fails
        {
            get
            {
                return m_ClientLoadBalancer.Fails;
            }
        }

        internal CSunticoClientLoadBalancer m_ClientLoadBalancer = new CSunticoClientLoadBalancer();
    }
}
