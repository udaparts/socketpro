

using System;
using SocketProAdapter;
using SocketProAdapter.ClientSide;
using USOCKETLib;
using SunticoShare;
using System.Collections.Generic;

namespace SunticoClient
{
    class CSunticoAsyncHandler : SocketProAdapter.ClientSide.CAsyncAdohandler
    {
        public CSunticoAsyncHandler()
            : base(SCommConst.sidSunticoComm)
        {
            m_lstAsyncHandlers.Add(this);
        }

        public CSunticoAsyncHandler(CClientSocket cs)
            : base(SCommConst.sidSunticoComm, cs)
        {
            m_lstAsyncHandlers.Add(this);
        }

        public CSunticoAsyncHandler(CClientSocket cs, IAsyncResultsHandler DefaultAsyncResultsHandler)
            : base(SCommConst.sidSunticoComm, cs, DefaultAsyncResultsHandler)
        {
            m_lstAsyncHandlers.Add(this);
        }

        internal CSunticoClientPoint m_CustomerPoint;
        internal static List<CSunticoAsyncHandler> m_lstAsyncHandlers;

        internal void Send(System.Data.IDataReader dr, SunticoClient.DRequestProgress p)
        {
            bool b;
            if(dr != null)
                b = Send(dr);
            b = SendRequest(SunticoShare.SCommConst.idClientSendDataReader, delegate(CAsyncResult ar)
                {
                    if (p != null)
                        p.Invoke(Progress.DataReader);
                }
            );
        }

        internal void Send(System.Data.DataTable dt, SunticoClient.DRequestProgress p)
        {
            bool b;
            if (dt != null)
                b = Send(dt);
            b = SendRequest(SunticoShare.SCommConst.idClientSendDataTable, delegate(CAsyncResult ar)
                {
                    if (p != null)
                        p.Invoke(Progress.Table);
                }
            );
        }

        internal void Send(System.Data.DataSet ds, SunticoClient.DRequestProgress p)
        {
            bool b;
            if (ds != null)
                b = Send(ds);
            b = SendRequest(SunticoShare.SCommConst.idClientSendDataSet, delegate(CAsyncResult ar)
                {
                    if (p != null)
                        p.Invoke(Progress.Table);
                }
            );
        }

        internal void Send(string str, SunticoShare.StringObjectType sot, SunticoClient.DRequestProgress rp)
        {
            bool b = SendRequest(SunticoShare.SCommConst.idClientSendString, str, (int)sot, delegate(CAsyncResult ar)
                {
                    if (rp != null)
                        rp.Invoke(Progress.StringObject);
                }
           );
        }

        protected override void OnResultReturned(short sRequestID, CUQueue UQueue)
        {
            CCloudMessage cm = (CCloudMessage)m_CustomerPoint.CloudMessage;

            switch (sRequestID)
            {
                case SunticoShare.SCommConst.idClientConfirmation:
                    break;
                case SunticoShare.SCommConst.idSunticoBeginTrans:
                    {
                        long Clue;
                        UQueue.Pop(out Clue);
                        cm.OnCloudBeginTrans(Clue);
                    }
                    break;
                case SunticoShare.SCommConst.idSunticoCommit:
                    {
                        long Clue;
                        UQueue.Pop(out Clue);
                        long res = cm.OnCloudEndTrans(Clue);
                        
                        //reply a confirm message so that Suntico server knows that a client has processed objects safely
                        SendRequest(SunticoShare.SCommConst.idClientConfirmation, res);
                    }
                    break;
                case SunticoShare.SCommConst.idSunticoSendDataReader:
                    cm.OnCloudDataReader(m_AdoSerialier.CurrentDataTable);
                    break;
                case SunticoShare.SCommConst.idSunticoSendDataSet:
                    cm.OnCloudDataSet(m_AdoSerialier.CurrentDataSet);
                    break;
                case SunticoShare.SCommConst.idSunticoSendDataTable:
                    cm.OnCloudDataTable(m_AdoSerialier.CurrentDataTable);
                    break;
                case SunticoShare.SCommConst.idSunticoSendObject:
                    {
                        long Clue;
                        UQueue.Pop(out Clue);
                        cm.OnCloudObjectMessage(Clue, UQueue);
                    }
                    break;
                case SunticoShare.SCommConst.idSunticoSendString:
                    {
                        int objectType;
                        string str;
                        UQueue.Pop(out objectType);
                        UQueue.Load(out str);
                        cm.OnCloudStringObject((StringObjectType)objectType, str);
                    }
                    break;
                default:
                    base.OnResultReturned(sRequestID, UQueue);
                    break;
            }
        }
    }
}
