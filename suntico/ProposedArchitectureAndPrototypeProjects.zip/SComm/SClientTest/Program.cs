﻿using System;
using System.Collections.Generic;
using System.Text;
using SunticoClient;
using SocketProAdapter;

namespace SClientTest
{
    class Program
    {
        [MTAThread]
        static void Main(string[] args)
        {
            bool ok;

            CloudClientSharedForUnitTest.TestStructure ts = new CloudClientSharedForUnitTest.TestStructure()
            {
                n = 10,
                str = "ClientTest"
            };

            SunticoClient.CCloudConnectionContext []clouds =new CCloudConnectionContext[2];

            //set one master server and one or more backup cloud servers
            clouds[0] = new CCloudConnectionContext()
            {
                IpAddress = "localhost",
                Port = 20901,
                UserId = "SocketPro",
                Password = "PassOne",
                Secure = false,
                Zip = false
            };

            clouds[1] = new CCloudConnectionContext()
            {
                IpAddress = "127.0.0.1",
                Port = 20901,
                UserId = "SocketPro",
                Password = "PassOne",
                Secure = false,
                Zip = true
            };

            CSunticoClientPoint client = new CSunticoClientPoint(clouds);

            client.Failover += new DFailover(client_Failover);
            client.ChannelsClosed += new DChannelsClosed(client_ChannelsClosed);
            client.CloudMessage.OnGenericObject += new DGenericObject(CloudMessage_OnGenericObject);
            client.CloudMessage.OnEndTrans += new DEndTrans(CloudMessage_OnEndTrans);
            client.CloudMessage.OnStartTrans += new DStartTrans(CloudMessage_OnStartTrans);
            client.CloudMessage.OnGeneralMessage += new DGeneralMessage(CloudMessage_OnGeneralMessage);
            client.CloudMessage.OnStringObject += new DStringObject(CloudMessage_OnStringObject);

            ICustomerMessage cm = client.CustomerMessage;
            
            do
            {
                ok = (client.Start() == SunticoShare.ConnectionStatus.Opened);
                if (!ok)
                    Console.WriteLine("Can not open channels to remote Suntico cloud servers");

                //start socket connections (channels)
                SunticoShare.ConnectionStatus cs = cm.BeginTrans(22,
                    delegate(long res)
                    {
                        Console.WriteLine("A remote Suntico cloud server just started a transaction with res = " + res.ToString());
                    }
                );

                if (cs == SunticoShare.ConnectionStatus.Closed)
                {
                    Console.WriteLine("Remote Suntico cloud servers not available!");
                    break;
                }

                cm.Send("{\"AInt\":12345,\"AStr\":\"test\",\"ABool\":true}",
                    SunticoShare.StringObjectType.Json,
                    delegate(Progress p)
                    {
                        Console.WriteLine("A remote Suntico cloud processed JSON text string");
                    }
                );

                cm.Send(12, ts, delegate(Progress p)
                    {
                        Console.WriteLine("A remote Suntico cloud processed a customer object");
                    }
                );

                cs = cm.Commit(1,
                    delegate(long res)
                    {
                        Console.WriteLine("A remote Suntico cloud server just committed a transaction with res = " + res.ToString());
                    }
                );

                if (cs == SunticoShare.ConnectionStatus.Closed)
                {
                    Console.WriteLine("Remote Suntico cloud servers not available!");
                    break;
                }

                ok = cm.Wait(); //optional call for converting async into sync
                if (!ok)
                    Console.WriteLine("Remote Suntico cloud servers do not process transaction in 30 seconds!");
            
                if(client.Channels == 0)
                    Console.WriteLine("Remote Suntico cloud servers are closed!");

            } while (false);

            Console.WriteLine("Fails = " + client.Fails.ToString());
            Console.WriteLine("Press any key to close the application ......");
            Console.Read();
            client.Dispose();
        }

        static void CloudMessage_OnStringObject(SunticoShare.StringObjectType sot, string str)
        {
            Console.WriteLine("StringObject {0} from Suntico cloud server with type = " + sot.ToString(), str);
        }

        static void CloudMessage_OnGeneralMessage(string msg, long Clue)
        {
            
        }

        static void CloudMessage_OnStartTrans(long Clue)
        {
            Clue = 0;
        }

        static void CloudMessage_OnEndTrans(long Clue)
        {
            Console.WriteLine("Suntico ends a transaction with clue = " + Clue.ToString());
        }

        static void CloudMessage_OnGenericObject(long Clue, SocketProAdapter.CUQueue Queue)
        {
            switch (Clue)
            {
                case 1:
                    {
                        CloudClientSharedForUnitTest.TestStructure objFromCloudServer;
                        Queue.Load(out objFromCloudServer);
                        Console.WriteLine(objFromCloudServer.ToString());
                    }
                    break;
                default:
                    break;
            }
        }

        static void client_ChannelsClosed(CSunticoClientPoint client)
        {
            Console.WriteLine("Oops, all of channels are closed now!");
        }

        static void client_Failover(CSunticoClientPoint client)
        {
            Console.WriteLine("A remote Suntico cloud server is closed");
            if (client.Channels > 0)
            {
                Console.WriteLine("Client will automatically try a new cloud server because there are {0} servers available at the momnet", client.Channels);
            }
            else
            {
                Console.WriteLine("Transaction failed completely because all of channels are closed at this time!");
            }
        }
    }
}
