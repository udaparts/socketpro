/* **** including all of defines, service id(s) and request id(s) ***** */
using System;
using SocketProAdapter;
using SocketProAdapter.ServerSide;
using USOCKETLib; //you may need it for accessing various constants
using SunticoShare;
using System.Threading;

namespace SunticoServer
{
    public delegate void DConfirmed(long Clue);

    //server implementation for service CSunticoAsyncHandler
    public class CSunticoPeer : SocketProAdapter.ServerSide.CAdoClientPeer
    {
        private bool m_bDoingTransaction = false;
        private System.Threading.AutoResetEvent m_event = new System.Threading.AutoResetEvent(true);
        protected override void OnSwitchFrom(int nServiceID)
        {
            int []groups = { 1 };

            //subscribe event
            Push.Enter(groups);

            m_bDoingTransaction = false;
        }

        protected override void OnReleaseResource(bool bClosing, int nInfo)
        {
            if (bClosing)
            {
                //closing the socket with error code = nInfo
            }
            else
            {
                //switch to a new service with the service id = nInfo
            }

            //release all of your resources here as early as possible
            m_bDoingTransaction = false;
            m_event.Set();
        }

        private bool IsOk(int res)
        {
            return (res != CClientPeer.REQUEST_CANCELED && res != CClientPeer.SOCKET_NOT_FOUND);
        }

        public bool SendBeginTrans(long Clue = 0)
        {
            bool b;
            if (m_bDoingTransaction)
                throw new InvalidProgramException("Can not start a new transaction without closing previous transaction");
            m_bDoingTransaction = true;
            b = IsBatching;
            if (!b)
                b = StartBatching();
            return IsOk(SendResult(SunticoShare.SCommConst.idSunticoBeginTrans, Clue));
        }
        private DConfirmed m_confirm;
        public bool SendEndTrans(DConfirmed confirm, long Clue = 0)
        {
            bool b;
            if (!m_bDoingTransaction)
                throw new InvalidProgramException("Must start a new transaction first by calling the method CSunticoPeer::SendBeginTrans");
            m_confirm = confirm;
            int res = SendResult(SunticoShare.SCommConst.idSunticoCommit, Clue);
            if (res != CClientPeer.REQUEST_CANCELED && res != CClientPeer.SOCKET_NOT_FOUND)
                b = CommitBatching();
            m_bDoingTransaction = false;
            m_event.Reset();
            return IsOk(res);
        }

        public bool SendStringObject(SunticoShare.StringObjectType sot, string str)
        {
            if (!m_bDoingTransaction)
                throw new InvalidProgramException("Must start a new transaction first by calling the method CSunticoPeer::SendBeginTrans");
            return IsOk(SendResult(SunticoShare.SCommConst.idSunticoSendString, (int)sot, str));
        }

        public bool SendGenericObject<T>(long Clue, T obj) where T : SocketProAdapter.IUSerializer, new()
        {
            if (!m_bDoingTransaction)
                throw new InvalidProgramException("Must start a new transaction first by calling the method CSunticoPeer::SendBeginTrans");
            return IsOk(SendResult(SunticoShare.SCommConst.idSunticoSendObject, Clue, obj));
        }

        public bool SendDataReader(System.Data.IDataReader dr)
        {
            if (!m_bDoingTransaction)
                throw new InvalidProgramException("Must start a new transaction first by calling the method CSunticoPeer::SendBeginTrans");
            if(!IsOk((int)Send(dr)))
                return false;
            return IsOk(SendResult(SunticoShare.SCommConst.idSunticoSendDataReader));
        }

        public bool SendDataTable(System.Data.DataTable dt)
        {
            if (!m_bDoingTransaction)
                throw new InvalidProgramException("Must start a new transaction first by calling the method CSunticoPeer::SendBeginTrans");
            if (!IsOk((int)Send(dt)))
                return false;
            return IsOk(SendResult(SunticoShare.SCommConst.idSunticoSendDataTable));
        }

        public bool SendDataSet(System.Data.DataSet ds)
        {
            if (!m_bDoingTransaction)
                throw new InvalidProgramException("Must start a new transaction first by calling the method CSunticoPeer::SendBeginTrans");
            if (!IsOk((int)Send(ds)))
                return false;
            return IsOk(SendResult(SunticoShare.SCommConst.idSunticoSendDataSet));
        }

        private void BeginTrans(long data, out long BeginTransRtn)
        {
            BeginTransRtn = 100 + data;
        }

        private void Commit(long data, out long CommitRtn)
        {
            
            CommitRtn = 20 + data;
        }

        private void ClientSendDataReader()
        {
            System.Data.DataTable dt = m_AdoSerialier.CurrentDataTable;

            //do whatever you like here
        }

        private void ClientSendDataSet()
        {
            System.Data.DataSet ds = m_AdoSerialier.CurrentDataSet;

            //do whatever you like here
        }

        private void ClientSendDataTable()
        {
            System.Data.DataTable dt = m_AdoSerialier.CurrentDataTable;

            //do whatever you like here
        }

        public long Confirmation
        {
            get
            {
                return m_ClientConfirmation;
            }
        }

        public bool WaitConfirmation(ref long ClientConfirmation, int timeout = 30000)
        {
            System.Threading.WaitHandle []handles = {m_event};
            bool ok = System.Threading.WaitHandle.WaitAll(handles, timeout);
            if (ok)
                ClientConfirmation = m_ClientConfirmation;
            return ok;
        }

        private long m_ClientConfirmation;
        private void ClientConfirmation(long Clue)
        {
            m_ClientConfirmation = Clue;
            if (m_confirm != null)
                m_confirm.Invoke(Clue);
            m_event.Set();
        }

        protected override void OnFastRequestArrive(short sRequestID, int nLen)
        {
            int res;
            switch (sRequestID)
            {
                case CAsyncAdoSerializationHelper.idDataSetHeaderArrive:
                case CAsyncAdoSerializationHelper.idDataTableHeaderArrive:
                case CAsyncAdoSerializationHelper.idDataReaderHeaderArrive:
                case CAsyncAdoSerializationHelper.idEndDataTable:
                case CAsyncAdoSerializationHelper.idEndDataReader:
                case CAsyncAdoSerializationHelper.idEndDataSet:
                    base.OnFastRequestArrive(sRequestID, nLen); //chain down to CAdoClientPeer for processing
                    break;
                case SCommConst.idClientBeginTrans:
                    res = M_I1_R1<long, long>(BeginTrans);
                    break;
                case SCommConst.idClientCommit:
                    res = M_I1_R1<long, long>(Commit);
                    break;
                case SCommConst.idClientSendDataReader:
                    res = M_I0_R0(ClientSendDataReader);
                    break;
                case SCommConst.idClientSendDataSet:
                    res = M_I0_R0(ClientSendDataSet);
                    break;
                case SCommConst.idClientSendDataTable:
                    res = M_I0_R0(ClientSendDataTable);
                    break;
                case SCommConst.idClientConfirmation:
                    res = M_I1_R0<long>(ClientConfirmation);
                    break;
                default:
                    break;
            }
        }

        private void ClientSendString(string str, int objectType)
        {
            SunticoShare.StringObjectType sot = (SunticoShare.StringObjectType)objectType;


        }

        private void ClientSendObject(long Hint)
        {

            switch (Hint)
            {
                case 1:
                    {
                        CloudClientSharedForUnitTest.TestStructure ts;
                        int res = m_UQueue.Load(out ts);

                        res = 0;
                    }
                    break;
                default:
                    break;
            }
        }

        protected override int OnSlowRequestArrive(short sRequestID, int nLen)
        {
            int res;
            switch (sRequestID)
            {
                case CAsyncAdoSerializationHelper.idDataReaderRecordsArrive:
                case CAsyncAdoSerializationHelper.idDataTableRowsArrive:
                    base.OnSlowRequestArrive(sRequestID, nLen); //chain down to CAdoClientPeer for processing
                    break;
                case SunticoShare.SCommConst.idClientSendObject:
                    res = M_I1_R0<long>(ClientSendObject);
                    break;
                case SunticoShare.SCommConst.idClientSendString:
                    res = M_I2_R0<string, int>(ClientSendString);
                    break;
                default:
                    break;
            }
            return 0;
        }

    }

    public class CSunticoServer : CSocketProServer
    {
        protected override bool OnSettingServer()
        {
            //try amIntegrated and amMixed instead by yourself
            Config.AuthenticationMethod = tagAuthenticationMethod.amOwn;

            //add service(s) into SocketPro server
            AddServices();
            SetBuiltinChatService();

            //You may set others here

            return true; //true -- ok; false -- no listening server
        }

        protected override void OnAccept(int hSocket, int nError)
        {
            //when a socket is initially established
        }

        protected override bool OnIsPermitted(int hSocket, int nSvsID)
        {
            Console.WriteLine("Switch to service = " + nSvsID);

            //give permission to all
            return true;
        }

        protected override void OnClose(int hSocket, int nError)
        {
            Console.WriteLine("Socket closed = " + hSocket);
        }

        CSocketProService<CSunticoPeer> m_SunticoComm = new CSocketProService<CSunticoPeer>();
        CSocketProService<CPushPeer> m_OnlineMessenger = new CSocketProService<CPushPeer>();
        //One SocketPro server supports any number of services. You can list them here!

        public CSunticoPeer SeekPeer(string userId, int nSvsId)
        {
            if (userId != null)
                userId = userId.ToLower();
            lock (this)
            {
                int n, count = CSocketProServer.CountOfClients;
                for (n = 0; n < count; ++n)
                {
                    int socket = CSocketProServer.GetClient(n);
                    string id = CSocketProServer.GetUserID(socket);
                    id = id.ToLower();
                    if (id == userId)
                        return (CSunticoPeer)m_SunticoComm.SeekClientPeer(socket);
                }
            }
            return null;
        }

        private void AddServices()
        {
            bool ok;

            //No COM -- taNone; STA COM -- taApartment; and Free COM -- taFree
            ok = m_SunticoComm.AddMe(SCommConst.sidSunticoComm, 0, tagThreadApartment.taNone);
            //If ok is false, very possibly you have two services with the same service id!

            ok = m_SunticoComm.AddSlowRequest(CAsyncAdoSerializationHelper.idDataReaderRecordsArrive);
            ok = m_SunticoComm.AddSlowRequest(CAsyncAdoSerializationHelper.idDataTableRowsArrive);
            ok = m_SunticoComm.AddSlowRequest(SunticoShare.SCommConst.idClientSendString);
            ok = m_SunticoComm.AddSlowRequest(SunticoShare.SCommConst.idClientSendObject);

            //Add all of other services into SocketPro server here!

            //enable builtin chat service for broadcasting message
            ok = m_OnlineMessenger.AddMe((int)USOCKETLib.tagServiceID.sidChat);
        }

        private void SetBuiltinChatService()
        {
            bool ok = PushManager.AddAChatGroup(1, "All Customers");
        }

    }

}

