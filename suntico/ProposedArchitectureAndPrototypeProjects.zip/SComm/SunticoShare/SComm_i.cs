namespace SunticoShare
{
    public enum StringObjectType
    {
        RegularText = 0,
        Json,
        Xml,
    }

    public enum ConnectionStatus
    {
        Closed = 0,
        Opened
    }

    public static class SCommConst
    {
        //defines for service CSunticoAsyncHandler
        public const int sidSunticoComm = ((int)USOCKETLib.tagOtherDefine.odUserServiceIDMin + 2112);
        
        //BeginTrans and commit from client side
        public const short idClientBeginTrans = ((short)USOCKETLib.tagOtherDefine.odUserRequestIDMin + 0);
        public const short idClientCommit = idClientBeginTrans + 1;

        //BeginTrans and commit from Suntico server side
        public const short idSunticoBeginTrans = idClientCommit + 1;
        public const short idSunticoCommit = idSunticoBeginTrans + 1;

        //object from client to Suntico server
        public const short idClientSendDataReader = idSunticoCommit + 1;
        public const short idClientSendDataTable = idClientSendDataReader + 1;
        public const short idClientSendDataSet = idClientSendDataTable + 1;
        public const short idClientSendString = idClientSendDataSet + 1;
        public const short idClientSendObject = idClientSendString + 1;

        //object from Suntico cloud server to client
        public const short idSunticoSendDataReader = idClientSendObject + 1;
        public const short idSunticoSendDataTable = idSunticoSendDataReader + 1;
        public const short idSunticoSendDataSet = idSunticoSendDataTable + 1;
        public const short idSunticoSendString = idSunticoSendDataSet + 1;
        public const short idSunticoSendObject = idSunticoSendString + 1;

        //client confirmation
        public const short idClientConfirmation = idSunticoSendObject + 1;
    }
}